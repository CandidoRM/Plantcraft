import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { GameView } from "@/game/GameView";
import { useGame } from "@/game/store";
import { TestScreen } from "@/lab/TestScreen";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [lab, setLab] = useState(false);
  const phase = useGame((s) => s.hud.phase);
  const inMenu = phase === "menu";
  return (
    <>
      <GameView />
      {inMenu ? (
        <button
          type="button"
          onClick={() => setLab((open) => !open)}
          className="pointer-events-auto fixed top-3 right-3 z-[100] rounded-md border border-cream/30 bg-ink/90 px-3 py-1.5 font-display text-sm tracking-wide text-cream shadow-lg"
          style={{ marginTop: "env(safe-area-inset-top)" }}
        >
          Teste
        </button>
      ) : null}
      {lab && inMenu ? <TestScreen /> : null}
    </>
  );
}
