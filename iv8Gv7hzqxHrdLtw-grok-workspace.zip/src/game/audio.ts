import {
  ACID, AQUIFER, ASH_DIRT, ASH_GRASS, ASH_GRASS_FULL, BREJO_DIRT, BREJO_GRASS, BREJO_GRASS_FULL, CAATINGA_DIRT, CAATINGA_GRASS, CAATINGA_GRASS_FULL, CERRADO_DIRT, CERRADO_GRASS, CRACKED_STONE, DIRT, FALL_TRAP, FARMLAND, GRASS, GRASS_FULL, MARBLE, MARBLE_BLUE, MARBLE_BRICK, MARBLE_BROKEN, MARBLE_GRASS, MARBLE_GRASS_FULL, MARBLE_ORANGE, MARBLE_PURPLE, MELON, MELON_SLICE, PLANKS, RED_CARPET, SAND, STONE, VARZEA_GRASS, WATER,
  isCarpet, isFluid, isLeaves, isLog, isMud, isPlant, isWeed,
} from "./blocks";

export type BlockMat = "dirt" | "grass" | "stone" | "wood" | "leaves" | "sand" | "plant" | "cloth" | "melon" | "liquid" | "mud" | "generic";

export function blockMat(id: number): BlockMat {
  if (isMud(id)) return "mud";
  if (isFluid(id) || id === WATER || id === ACID) return "liquid";
  if (isLeaves(id)) return "leaves";
  if (isLog(id) || id === PLANKS) return "wood";
  if (id === STONE || id === CRACKED_STONE || id === AQUIFER || id === MARBLE || id === MARBLE_BRICK || id === MARBLE_BROKEN || id === MARBLE_ORANGE || id === MARBLE_PURPLE || id === MARBLE_BLUE || id === FALL_TRAP) return "stone";
  if (id === SAND) return "sand";
  if (id === MELON || id === MELON_SLICE) return "melon";
  if (id === RED_CARPET) return "cloth";
  if (isWeed(id) || isPlant(id) || isCarpet(id)) return "plant";
  if (id === GRASS || id === GRASS_FULL || id === CERRADO_GRASS || id === VARZEA_GRASS || id === FARMLAND || id === MARBLE_GRASS || id === MARBLE_GRASS_FULL || id === CAATINGA_GRASS || id === CAATINGA_GRASS_FULL || id === BREJO_GRASS || id === BREJO_GRASS_FULL || id === ASH_GRASS || id === ASH_GRASS_FULL) return "grass";
  if (id === DIRT || id === CERRADO_DIRT || id === CAATINGA_DIRT || id === BREJO_DIRT || id === ASH_DIRT) return "dirt";
  return "generic";
}

type Loop = { src: AudioBufferSourceNode; filter: BiquadFilterNode; gain: GainNode };

export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  amb: GainNode | null = null;
  muted = false;
  private white: AudioBuffer | null = null;
  private brown: AudioBuffer | null = null;
  private wind: Loop | null = null;
  private water: Loop | null = null;
  private mud: Loop | null = null;
  private bugs: Loop | null = null;
  private under: BiquadFilterNode | null = null;
  private birdT = 1.5;
  private cricketT = 0.8;
  private mudT = 1.2;
  private mineT = 0;
  private active = false;
  private quakeBed: {
    src: AudioBufferSourceNode;
    filter: BiquadFilterNode;
    gain: GainNode;
    osc: OscillatorNode;
    oscGain: GainNode;
    lfo: OscillatorNode;
  } | null = null;

  unlock() {
    if (!this.ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.28;
      this.sfx = this.ctx.createGain(); this.sfx.gain.value = 1;
      this.amb = this.ctx.createGain(); this.amb.gain.value = 0;
      this.under = this.ctx.createBiquadFilter();
      this.under.type = "lowpass"; this.under.frequency.value = 18000;
      this.sfx.connect(this.under); this.amb.connect(this.under); this.under.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.white = this.makeNoise(1.4, "white");
      this.brown = this.makeNoise(2.2, "brown");
      this.startLoops();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setActive(on: boolean) {
    this.active = on;
    if (!this.ctx || !this.amb) return;
    this.amb.gain.setTargetAtTime(on ? 1 : 0, this.ctx.currentTime, 0.08);
  }

  setUnderwater(on: boolean, mud = false) {
    if (!this.ctx || !this.under) return;
    const freq = mud ? 180 : on ? 420 : 18000;
    this.under.frequency.setTargetAtTime(freq, this.ctx.currentTime, 0.05);
  }

  private makeNoise(seconds: number, color: "white" | "brown") {
    const ctx = this.ctx!;
    const n = Math.max(1, Math.floor(ctx.sampleRate * seconds));
    const buf = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) {
      const w = Math.random() * 2 - 1;
      if (color === "brown") { last = (last + 0.02 * w) / 1.02; d[i] = Math.max(-1, Math.min(1, last * 4.2)); }
      else d[i] = w;
    }
    return buf;
  }

  private startLoops() {
    if (!this.ctx || !this.amb || !this.brown || !this.white) return;
    this.wind = this.loop(this.brown, "bandpass", 380, 0.7, 0);
    this.water = this.loop(this.white, "bandpass", 780, 0.85, 0);
    this.mud = this.loop(this.brown, "lowpass", 140, 0.55, 0);
    this.bugs = this.loop(this.white, "bandpass", 4200, 1.4, 0);
  }

  private loop(buf: AudioBuffer, type: BiquadFilterType, freq: number, q: number, vol: number): Loop {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
    const filter = ctx.createBiquadFilter(); filter.type = type; filter.frequency.value = freq; filter.Q.value = q;
    const gain = ctx.createGain(); gain.gain.value = vol;
    src.connect(filter); filter.connect(gain); gain.connect(this.amb!); src.start();
    return { src, filter, gain };
  }

  private bus() { return this.sfx ?? this.master; }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slide = 0) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator(); const g = this.ctx.createGain();
    osc.type = type; osc.frequency.setValueAtTime(Math.max(30, freq), t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g); g.connect(this.bus()!); osc.start(t); osc.stop(t + dur + 0.03);
    osc.onended = () => { osc.disconnect(); g.disconnect(); };
  }

  private burst(buf: AudioBuffer | null, dur: number, vol: number, filter: BiquadFilterType, freq: number, q = 0.8, rate = 1, freqEnd?: number, delay = 0) {
    if (!this.ctx || !this.master || this.muted || !buf) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource(); src.buffer = buf; src.playbackRate.value = rate * (0.92 + Math.random() * 0.16);
    const f = this.ctx.createBiquadFilter(); f.type = filter; f.Q.value = q; f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(Math.max(60, freqEnd), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.bus()!);
    src.start(t); src.stop(t + dur + 0.04);
    src.onended = () => { src.disconnect(); f.disconnect(); g.disconnect(); };
  }

  door() {
    const r = 0.94 + Math.random() * 0.1;
    this.tone(210 * r, 0.07, "triangle", 0.2, -28);
    this.burst(this.white, 0.05, 0.16, "bandpass", 640, 1.3, r);
    this.tone(120 * r, 0.09, "sine", 0.14, -36);
  }

  place(id = 0) {
    const m = blockMat(id); const r = 0.92 + Math.random() * 0.16;
    if (m === "stone") { this.tone(92 * r, 0.07, "sine", 0.28, -20); this.burst(this.white, 0.05, 0.22, "highpass", 1400, 0.7, r); this.burst(this.brown, 0.08, 0.18, "lowpass", 520, 0.8, r); }
    else if (m === "wood") { this.tone(180 * r, 0.055, "triangle", 0.22, -40); this.burst(this.white, 0.045, 0.2, "bandpass", 920, 1.4, r); }
    else if (m === "dirt") { this.burst(this.brown, 0.1, 0.32, "lowpass", 280, 0.6, r); }
    else if (m === "grass") { this.burst(this.brown, 0.08, 0.22, "lowpass", 240, 0.5, r); this.burst(this.white, 0.06, 0.16, "bandpass", 1800, 1.1, r); }
    else if (m === "sand") this.burst(this.white, 0.11, 0.28, "bandpass", 2100, 0.9, r, 700);
    else if (m === "leaves") this.burst(this.white, 0.09, 0.2, "bandpass", 2600, 1.2, r);
    else if (m === "plant") { this.burst(this.white, 0.07, 0.16, "bandpass", 2400, 1.3, r); this.tone(420 * r, 0.04, "sine", 0.06, -80); }
    else if (m === "cloth") this.burst(this.white, 0.08, 0.18, "lowpass", 900, 0.5, r);
    else if (m === "melon") { this.tone(140 * r, 0.08, "sine", 0.2, -50); this.burst(this.brown, 0.1, 0.22, "bandpass", 380, 0.9, r); }
    else if (m === "liquid") { this.burst(this.white, 0.12, 0.26, "lowpass", 900, 0.6, r, 180); }
    else if (m === "mud") { this.burst(this.brown, 0.18, 0.34, "lowpass", 140, 0.45, r * 0.55, 60); this.burst(this.brown, 0.1, 0.16, "bandpass", 260, 0.7, 0.45, undefined, 0.05); }
    else { this.tone(200 * r, 0.06, "square", 0.1, -70); this.burst(this.brown, 0.07, 0.16, "lowpass", 400, 0.7, r); }
  }

  eat() {
    this.burst(this.white, 0.04, 0.1, "bandpass", 1600, 1.1, 0.7);
    this.burst(this.brown, 0.05, 0.12, "lowpass", 700, 0.8, 0.5);
    this.tone(240, 0.04, "triangle", 0.04, -30);
  }

  villagerHum() {
    const f = 170 + Math.random() * 50;
    this.tone(f, 0.14, "sine", 0.045, -30);
    this.tone(f * 1.25, 0.1, "triangle", 0.03, -80);
  }

  villagerYes() {
    this.tone(330, 0.07, "sine", 0.07, -8);
    this.tone(440, 0.09, "sine", 0.06, -40);
  }

  break(id = 0) {
    const m = blockMat(id); const r = 0.9 + Math.random() * 0.2;
    if (m === "stone") {
      this.burst(this.white, 0.04, 0.2, "highpass", 3400, 0.65, r);
      this.burst(this.white, 0.08, 0.3, "bandpass", 1500, 1.5, r, 420);
      this.burst(this.brown, 0.11, 0.22, "lowpass", 480, 0.55, r, 160);
    }
    else if (m === "wood") { this.burst(this.white, 0.06, 0.28, "bandpass", 1100, 1.6, r); this.tone(210 * r, 0.07, "triangle", 0.14, -90); }
    else if (m === "dirt") {
      this.burst(this.brown, 0.05, 0.26, "lowpass", 540, 0.4, r, 200);
      this.burst(this.brown, 0.07, 0.22, "lowpass", 260, 0.35, r * 0.85, 80, 0.035);
      this.burst(this.white, 0.045, 0.1, "bandpass", 1500, 0.65, 1.05, 480, 0.04);
      this.burst(this.brown, 0.09, 0.16, "lowpass", 140, 0.3, 0.7, 55, 0.08);
      this.burst(this.white, 0.035, 0.06, "highpass", 2400, 0.35, 1.2, undefined, 0.11);
    }
    else if (m === "grass") {
      this.burst(this.brown, 0.09, 0.24, "lowpass", 320, 0.45, r, 110);
      this.burst(this.white, 0.06, 0.2, "bandpass", 2600, 1.35, r, 1200);
      this.burst(this.white, 0.045, 0.1, "highpass", 4000, 0.55, r);
    }
    else if (m === "sand") this.burst(this.white, 0.18, 0.36, "bandpass", 1900, 0.8, r, 500);
    else if (m === "leaves") this.burst(this.white, 0.16, 0.28, "bandpass", 2800, 1.1, r);
    else if (m === "plant") { this.burst(this.white, 0.1, 0.22, "bandpass", 2500, 1.2, r); this.tone(480 * r, 0.05, "triangle", 0.08, -160); }
    else if (m === "cloth") this.burst(this.white, 0.1, 0.2, "lowpass", 700, 0.45, r);
    else if (m === "melon") { this.burst(this.brown, 0.14, 0.32, "bandpass", 320, 1.1, r, 140); this.tone(120 * r, 0.1, "sine", 0.16, -70); }
    else if (m === "liquid") this.burst(this.white, 0.16, 0.3, "lowpass", 800, 0.55, r, 120);
    else if (m === "mud") { this.burst(this.brown, 0.2, 0.36, "lowpass", 110, 0.4, r * 0.5, 50); this.tone(48 * r, 0.12, "triangle", 0.16, -12); }
    else { this.burst(this.white, 0.1, 0.26, "bandpass", 900, 0.8, r); this.burst(this.brown, 0.1, 0.2, "lowpass", 300, 0.6, r); }
  }

  mine(id = 0) {
    if (this.mineT > 0) return;
    this.mineT = 0.16;
    const m = blockMat(id); const r = 0.9 + Math.random() * 0.2;
    if (m === "stone") this.burst(this.white, 0.045, 0.16, "highpass", 1600, 0.8, r);
    else if (m === "wood") this.burst(this.white, 0.04, 0.14, "bandpass", 1000, 1.3, r);
    else if (m === "sand") this.burst(this.white, 0.05, 0.12, "bandpass", 1800, 0.9, r);
    else if (m === "mud") this.burst(this.brown, 0.07, 0.12, "lowpass", 130, 0.4, r * 0.55);
    else if (m === "leaves" || m === "plant") this.burst(this.white, 0.05, 0.1, "bandpass", 2400, 1.1, r);
    else this.burst(this.brown, 0.05, 0.12, "lowpass", 400, 0.7, r);
  }

  punch() { this.tone(150, 0.07, "triangle", 0.22, -50); this.burst(this.brown, 0.06, 0.18, "lowpass", 280, 0.6, 1); }
  hurt() { this.tone(190, 0.14, "sawtooth", 0.22, -110); }
  witness() {
    this.tone(90, 0.45, "sine", 0.2, 40);
    this.tone(180, 0.35, "triangle", 0.12, 80);
    this.burst(this.brown, 0.2, 0.28, "lowpass", 220, 0.8, 0.9);
  }
  jump() { this.tone(300, 0.08, "sine", 0.1, 160); }
  step(id = 0) {
    const m = blockMat(id); const r = 0.88 + Math.random() * 0.24;
    if (m === "stone") this.burst(this.white, 0.04, 0.1, "highpass", 900, 0.7, r);
    else if (m === "wood") this.burst(this.white, 0.04, 0.1, "bandpass", 700, 1.2, r);
    else if (m === "sand") this.burst(this.white, 0.055, 0.12, "bandpass", 1600, 0.8, r);
    else if (m === "mud") this.burst(this.brown, 0.08, 0.14, "lowpass", 150, 0.4, r * 0.6);
    else if (m === "leaves" || m === "plant") this.burst(this.white, 0.05, 0.08, "bandpass", 2200, 1, r);
    else this.burst(this.brown, 0.045, 0.11, "lowpass", 220, 0.5, r);
  }

  splash(enter: boolean, strength = 1) {
    if (!this.ctx || !this.master || this.muted) return;
    const s = Math.max(0.28, Math.min(1.7, strength));
    const dur = enter ? 0.22 + s * 0.1 : 0.12;
    this.burst(this.white, dur, (enter ? 0.42 : 0.26) * s, "lowpass", enter ? 900 + s * 400 : 1400, 0.6, 1, 140);
    this.tone(enter ? 90 + s * 40 : 240, enter ? 0.1 : 0.06, "sine", (enter ? 0.16 : 0.1) * Math.min(1, s), enter ? -50 : 80);
  }

  /** Thick plop. Not the water splash. */
  mudSplash(enter: boolean, strength = 1) {
    if (!this.ctx || !this.master || this.muted) return;
    const s = Math.max(0.28, Math.min(1.7, strength));
    this.burst(this.brown, enter ? 0.32 : 0.18, (enter ? 0.48 : 0.3) * s, "lowpass", enter ? 150 : 210, 0.5, 0.42, 55);
    this.tone(enter ? 52 : 68, enter ? 0.18 : 0.1, "triangle", 0.2 * Math.min(1, s), enter ? -18 : 10);
    this.burst(this.brown, 0.14, 0.2 * s, "bandpass", 280, 0.9, 0.38, 120, 0.05);
  }

  tick(dt: number, env: { night: boolean; cerrado: boolean; nearWater: number; nearLeaves: number; inWater: boolean; inMud: boolean; inLeaves: boolean }) {
    this.mineT = Math.max(0, this.mineT - dt);
    if (!this.ctx || !this.amb || !this.wind || !this.water || !this.mud || !this.bugs) return;
    this.setUnderwater(env.inWater, env.inMud);
    if (!this.active) return;
    const t = this.ctx.currentTime;
    this.wind.gain.gain.setTargetAtTime((env.cerrado ? 0.085 : 0.055) + env.nearLeaves * 0.04 + (env.night ? 0.02 : 0), t, 0.25);
    this.wind.filter.frequency.setTargetAtTime(env.cerrado ? 520 : 340 + env.nearLeaves * 180, t, 0.4);
    this.water.gain.gain.setTargetAtTime(env.inMud ? 0 : env.inWater ? 0.16 : env.nearWater * 0.12, t, 0.2);
    this.water.filter.frequency.setTargetAtTime(env.inWater ? 380 : 820, t, 0.25);
    this.mud.gain.gain.setTargetAtTime(env.inMud ? 0.22 : 0, t, 0.2);
    this.mud.filter.frequency.setTargetAtTime(env.inMud ? 120 : 140, t, 0.25);
    let bugs = 0;
    if (!env.inWater && !env.inMud) bugs = env.night ? 0.045 + env.nearLeaves * 0.03 : env.cerrado ? 0.07 : 0.018 + env.nearLeaves * 0.02;
    this.bugs.gain.gain.setTargetAtTime(bugs, t, 0.3);
    this.bugs.filter.frequency.setTargetAtTime(env.night ? 5200 : env.cerrado ? 3400 : 4100, t, 0.4);
    this.birdT -= dt;
    if (this.birdT <= 0 && !env.night && !env.inWater && !env.inMud) {
      this.birdT = 4.5 + Math.random() * 7;
      if (env.nearLeaves > 0.08 || env.cerrado) this.birdCall(env.cerrado);
    }
    this.cricketT -= dt;
    if (this.cricketT <= 0 && env.night && !env.inWater && !env.inMud) {
      this.cricketT = 0.45 + Math.random() * 0.9;
      const n = 2 + ((Math.random() * 3) | 0);
      for (let i = 0; i < n; i++) this.burst(this.white, 0.035, 0.07, "bandpass", 5400, 4.5, 1.1, undefined, i * 0.045);
    }
    this.mudT -= dt;
    if (this.mudT <= 0 && env.inMud) {
      this.mudT = 1.6 + Math.random() * 2.2;
      this.burst(this.brown, 0.26, 0.14, "lowpass", 90, 0.45, 0.35, 48);
    }
  }

  private birdCall(cerrado: boolean) {
    const kind = Math.random();
    if (cerrado || kind > 0.72) { this.tone(780, 0.18, "sawtooth", 0.07, -280); this.tone(620, 0.22, "triangle", 0.05, -160); }
    else if (kind > 0.4) { this.tone(2400, 0.045, "sine", 0.05, 400); this.tone(2800, 0.04, "sine", 0.04, -200); }
    else { this.tone(980, 0.07, "sine", 0.055, 40); this.tone(720, 0.09, "sine", 0.05, -30); }
  }

  quakeRumble(vol = 1) {
    this.burst(this.brown, 0.38, 0.6 * vol, "lowpass", 95, 0.55, 0.45, 48);
    this.tone(40, 0.32, "sine", 0.48 * vol, -6);
  }

  /** Continuous Hill Top drone. Intensity follows the shake. */
  beginQuakeBed() {
    this.endQuakeBed();
    if (!this.ctx || !this.brown || !this.sfx) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.brown;
    src.loop = true;
    src.playbackRate.value = 0.48;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 140;
    filter.Q.value = 0.55;
    const gain = ctx.createGain();
    gain.gain.value = 0.0001;
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfx);
    src.start();
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = 36;
    const oscGain = ctx.createGain();
    oscGain.gain.value = 0.0001;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 4.2;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 7;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);
    osc.connect(oscGain);
    oscGain.connect(this.sfx);
    osc.start();
    lfo.start();
    this.quakeBed = { src, filter, gain, osc, oscGain, lfo };
  }

  setQuakeBed(amp: number) {
    if (!this.quakeBed || !this.ctx) return;
    const t = this.ctx.currentTime;
    const a = Math.max(0, Math.min(1, amp));
    this.quakeBed.gain.gain.setTargetAtTime(0.045 + a * 0.6, t, 0.08);
    this.quakeBed.oscGain.gain.setTargetAtTime(0.045 + a * 0.36, t, 0.08);
    this.quakeBed.filter.frequency.setTargetAtTime(80 + a * 200, t, 0.12);
  }

  endQuakeBed() {
    const bed = this.quakeBed;
    this.quakeBed = null;
    if (!bed || !this.ctx) return;
    const t = this.ctx.currentTime;
    bed.gain.gain.setTargetAtTime(0.0001, t, 0.18);
    bed.oscGain.gain.setTargetAtTime(0.0001, t, 0.14);
    const stopAt = t + 0.5;
    try {
      bed.src.stop(stopAt);
      bed.osc.stop(stopAt);
      bed.lfo.stop(stopAt);
    } catch { /* already stopped */ }
  }

  /** A heavy stone hit. */
  quakeThud() {
    this.burst(this.brown, 0.36, 1.2, "lowpass", 160, 0.45, 0.48, 48);
    this.tone(44, 0.24, "sine", 0.72, -18);
    this.burst(this.white, 0.07, 0.3, "bandpass", 880, 0.7, 0.65);
  }

  /** Ground cracking and grit falling into the ditch. */
  quakeCrack() {
    this.burst(this.brown, 0.32, 0.9, "lowpass", 380, 0.65, 0.62, 70);
    this.tone(64, 0.16, "sine", 0.48, -28);
    this.burst(this.white, 0.12, 0.3, "highpass", 1600, 0.45, 0.85, 500);
    for (let i = 0; i < 3; i++) this.burst(this.white, 0.035, 0.165, "bandpass", 2400, 2.2, 1.15, undefined, 0.06 + i * 0.07);
  }

  /** Water running into the opened ditch. */
  quakeSeep() {
    this.burst(this.white, 0.6, 0.78, "lowpass", 640, 0.5, 0.55, 160);
    this.tone(96, 0.28, "sine", 0.3, -36);
    this.burst(this.brown, 0.4, 0.48, "lowpass", 220, 0.4, 0.7, 80);
  }

  /** A pebble cracking loose from the ground. */
  pebbleCrack() {
    this.burst(this.white, 0.03, 0.16, "highpass", 2600, 0.7, 1.25);
    this.burst(this.brown, 0.05, 0.18, "bandpass", 980, 1.5, 0.85, 160);
  }

  /** A pebble hitting the ground. */
  pebbleLand() {
    this.burst(this.brown, 0.07, 0.28, "lowpass", 380, 0.55, 0.7, 120);
    this.burst(this.white, 0.04, 0.12, "highpass", 1900, 0.5, 1.05);
  }

  /** Leaves shaken off a canopy. */
  quakeLeaves() {
    this.burst(this.white, 0.14, 0.18, "bandpass", 2100, 1.15, 1, 800);
  }

  dispose() {
    this.endQuakeBed();
    try { this.wind?.src.stop(); this.water?.src.stop(); this.bugs?.src.stop(); } catch { /* */ }
    void this.ctx?.close(); this.ctx = null;
  }
}
