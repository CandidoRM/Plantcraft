import { create } from "zustand";
import {
  AIR,
  BLOCK_NAME,
  FOOD_ACAI,
  FOOD_AVOCADO,
  FOOD_BANANA,
  FOOD_CASSAVA,
  FOOD_CASSAVA_RAW,
  FOOD_COCONUT,
  FOOD_CORN,
  FOOD_GUAVA,
  FOOD_MANGO,
  FOOD_ORANGE,
  FOOD_PINEAPPLE,
  FOOD_RICE,
  GRASS,
  GRASS_FULL,
  LOG,
} from "./blocks";

export type Phase = "menu" | "playing" | "paused" | "dead";

export type Slot = { id: number; count: number };

export const HOTBAR_LEN = 9;
export const BAG_LEN = 27;
export const INV_LEN = HOTBAR_LEN + BAG_LEN;

export type Hud = {
  phase: Phase;
  health: number;
  maxHealth: number;
  slots: Slot[];
  selected: number;
  target: string;
  mine: number;
  time: number;
  hint: string;
  savedAt: number;
  underwater: boolean;
  underFluid: "water" | "acid" | "mud" | null;
  oxygen: number;
  hunger: number;
  hungerShake: boolean;
  eat: number;
  third: boolean;
  sneaking: boolean;
  craftSize: 2 | 3;
  craft: Slot[];
  craftOut: Slot;
  hovering: boolean;
  breathing: boolean;
  swift: boolean;
  inventoryOpen: boolean;
  cursor: Slot;
  compass: string;
  compassAng: number;
};

export type GameHandle = {
  play: () => void;
  toMenu: () => void;
  pause: () => void;
  resume: () => void;
  respawn: () => void;
  newWorld: () => void;
  selectSlot: (i: number) => void;
  toggleInventory: () => void;
  invClick: (i: number, right: boolean) => void;
  craftClick: (i: number, right: boolean) => void;
  craftTake: () => void;
  setTouchMove: (x: number, y: number) => void;
  addLook: (x: number, y: number) => void;
  setTouchJump: (v: boolean) => void;
  setTouchBreak: (v: boolean) => void;
  setTouchPlace: (v: boolean) => void;
};

export const emptySlot = (): Slot => ({ id: AIR, count: 0 });

export function packSlots(list: Slot[]): Slot[] {
  const out: Slot[] = Array.from({ length: INV_LEN }, emptySlot);
  let i = 0;
  for (const s of list) {
    if (!s || s.count <= 0 || !s.id) continue;
    if (i < INV_LEN) {
      out[i++] = { id: s.id, count: s.count };
      continue;
    }
    const stack = out.find((x) => x.id === s.id && x.count > 0);
    if (stack) stack.count += s.count;
  }
  return out;
}

const emptySlots = (): Slot[] =>
  packSlots([
    { id: GRASS, count: 1 },
    { id: GRASS_FULL, count: 1 },
    { id: LOG, count: 16 },
    { id: FOOD_BANANA, count: 8 },
    { id: FOOD_MANGO, count: 4 },
    { id: FOOD_AVOCADO, count: 3 },
    { id: FOOD_ORANGE, count: 6 },
    { id: FOOD_PINEAPPLE, count: 3 },
    { id: FOOD_COCONUT, count: 3 },
    { id: FOOD_ACAI, count: 2 },
    { id: FOOD_CASSAVA, count: 3 },
    { id: FOOD_CASSAVA_RAW, count: 2 },
    { id: FOOD_CORN, count: 4 },
    { id: FOOD_RICE, count: 3 },
    { id: FOOD_GUAVA, count: 4 },
  ]);

export const starterSlots = emptySlots;

export const initialHud = (): Hud => ({
  phase: "menu",
  health: 10,
  maxHealth: 10,
  slots: emptySlots(),
  selected: 0,
  target: "",
  mine: 0,
  time: 0.22,
  hint: "",
  savedAt: 0,
  underwater: false,
  underFluid: null,
  oxygen: 100,
  hunger: 20,
  hungerShake: false,
  eat: 0,
  third: false,
  sneaking: false,
  craftSize: 2,
  craft: Array.from({ length: 9 }, emptySlot),
  craftOut: emptySlot(),
  hovering: false,
  breathing: false,
  swift: false,
  inventoryOpen: false,
  cursor: emptySlot(),
  compass: "Floresta",
  compassAng: 0,
});

type Store = {
  hud: Hud;
  handle: GameHandle | null;
  setHud: (p: Partial<Hud>) => void;
  patchHud: (fn: (h: Hud) => Hud) => void;
  setHandle: (h: GameHandle | null) => void;
};

export const useGame = create<Store>((set) => ({
  hud: initialHud(),
  handle: null,
  setHud: (p) => set((s) => ({ hud: { ...s.hud, ...p } })),
  patchHud: (fn) => set((s) => ({ hud: fn(s.hud) })),
  setHandle: (handle) => set({ handle }),
}));

export function blockLabel(id: number): string {
  return BLOCK_NAME[id] ?? "";
}
