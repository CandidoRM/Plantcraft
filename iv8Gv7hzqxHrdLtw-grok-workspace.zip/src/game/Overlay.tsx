import { Backpack, Pause, Play, RotateCcw, Sprout, X } from "lucide-react";
import { useEffect, useRef, useState, type MutableRefObject } from "react";
import { AIR, MELON_SLICE, isFood } from "./blocks";
import { paintItem } from "./itemicon";
import { blockLabel, HOTBAR_LEN, useGame, type Slot } from "./store";

function hearts(n: number, max: number) {
  const out = [];
  for (let i = 0; i < max; i++) {
    out.push(
      <span
        key={i}
        className={`inline-block size-3 rounded-sm sm:size-3.5 ${i < n ? "bg-health" : "bg-line"}`}
      />,
    );
  }
  return out;
}

export function Overlay() {
  const hud = useGame((s) => s.hud);
  const handle = useGame((s) => s.handle);
  const joy = useRef<{ id: number; x: number; y: number; px: number; py: number } | null>(null);
  const look = useRef<{ id: number; x: number; y: number } | null>(null);
  const stick = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Tab") {
        if (hud.phase === "playing") {
          e.preventDefault();
          handle?.toggleInventory();
        }
        return;
      }
      if (e.code === "Escape") {
        if (hud.inventoryOpen) {
          e.preventDefault();
          handle?.toggleInventory();
          return;
        }
        if (hud.phase === "playing") handle?.pause();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [handle, hud.phase, hud.inventoryOpen]);

  const playing = hud.phase === "playing";

  return (
    <div className="pointer-events-none absolute inset-0 text-cream">
      {hud.phase === "menu" && (
        <div className="pointer-events-auto flex h-full flex-col items-center justify-center bg-ink/80 px-6">
          <div className="flex max-w-lg flex-col items-center text-center">
            <Sprout className="mb-4 size-10 text-leaf" strokeWidth={1.5} />
            <p className="font-sans text-xs font-medium tracking-[0.28em] text-leaf uppercase">bloco a bloco</p>
            <h1 className="font-display mt-2 text-5xl font-medium tracking-tight text-cream sm:text-6xl">
              Plantcraft
            </h1>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
              Capivaras, rebanho, tamanduá e tucano. Lagos profundos escondem traíras
              solitárias e a rara branquinha. O aquífero goteja e, de vez em quando,
              vaza água por uma face livre. De noite nascem Murchas e Beholders.
            </p>
            <button
              type="button"
              onClick={() => handle?.play()}
              className="mt-8 inline-flex h-12 items-center gap-2 rounded-lg bg-cream px-8 text-sm font-medium text-ink transition-transform duration-[var(--motion-quick)] hover:bg-cream/90 active:scale-[0.98]"
            >
              <Play className="size-4" strokeWidth={2} />
              Jogar
            </button>
            <dl className="mt-10 grid w-full grid-cols-2 gap-x-6 gap-y-3 text-left text-xs text-muted sm:grid-cols-2">
              <div>
                <dt className="font-medium text-cream">Mover</dt>
                <dd>WASD ou joystick</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Olhar</dt>
                <dd>Mouse ou arrastar</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Quebrar</dt>
                <dd>Clique esquerdo</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Colocar</dt>
                <dd>Clique direito</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Pular</dt>
                <dd>Espaço</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Blocos</dt>
                <dd>1–9 ou roda</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Inventário</dt>
                <dd>Tab</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Bússola</dt>
                <dd>F6 troca o bioma</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Velocidade</dt>
                <dd>F3 liga e desliga</dd>
              </div>
              <div>
                <dt className="font-medium text-cream">Terremoto</dt>
                <dd>F4</dd>
              </div>
            </dl>
          </div>
        </div>
      )}

      {hud.phase === "paused" && (
        <div className="pointer-events-auto flex h-full items-center justify-center bg-ink/70 px-6">
          <div className="w-full max-w-sm rounded-xl border border-line bg-panel p-6 shadow-lg">
            <h2 className="font-display text-2xl font-medium">Pausa</h2>
            <p className="mt-1 text-sm text-muted">O mundo ficou salvo neste aparelho.</p>
            <div className="mt-6 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => handle?.resume()}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-cream text-sm font-medium text-ink"
              >
                Continuar
              </button>
              <button
                type="button"
                onClick={() => handle?.newWorld()}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line text-sm text-cream"
              >
                Novo mundo
              </button>
            </div>
          </div>
        </div>
      )}

      {hud.phase === "dead" && (
        <div className="pointer-events-auto flex h-full items-center justify-center bg-ink/75 px-6">
          <div className="w-full max-w-sm rounded-xl border border-line bg-panel p-6">
            <h2 className="font-display text-2xl font-medium">Você caiu</h2>
            <p className="mt-1 text-sm text-muted">O mundo continua. Você volta no mesmo lugar de sempre.</p>
            <button
              type="button"
              onClick={() => handle?.respawn()}
              className="mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-cream text-sm font-medium text-ink"
            >
              <RotateCcw className="size-4" />
              Renascer
            </button>
          </div>
        </div>
      )}

      {playing && (
        <>
          {hud.underFluid && (
            <div
              className="pointer-events-none absolute inset-0 z-[5]"
              style={{
                background:
                  hud.underFluid === "acid"
                    ? "linear-gradient(180deg, rgba(32, 50, 20, 0.34) 0%, rgba(16, 30, 10, 0.43) 100%)"
                    : hud.underFluid === "mud"
                      ? "linear-gradient(180deg, rgba(46, 26, 38, 0.78) 0%, rgba(22, 12, 20, 0.9) 100%)"
                      : "linear-gradient(180deg, rgba(28, 95, 113, 0.22) 0%, rgba(19, 69, 86, 0.32) 100%)",
                boxShadow:
                  hud.underFluid === "acid"
                    ? "inset 0 0 80px rgba(20, 36, 10, 0.36)"
                    : hud.underFluid === "mud"
                      ? "inset 0 0 120px rgba(22, 10, 18, 0.78)"
                      : "inset 0 0 80px rgba(14, 63, 81, 0.26)",
              }}
            />
          )}
          <div className="pointer-events-none absolute top-4 left-4 right-4 z-20 flex items-start justify-between gap-3 pt-[env(safe-area-inset-top)]">
            <div className="rounded-md border border-line bg-soil/70 px-3 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-1.5">{hearts(hud.health, hud.maxHealth)}</div>
              <div
                className={`mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-line ${hud.hungerShake ? "animate-pulse" : ""}`}
                aria-label={`Fome ${hud.hunger} de 20`}
              >
                <div
                  className="h-full rounded-full bg-hunger"
                  style={{ width: `${Math.max(0, Math.min(100, (hud.hunger / 20) * 100))}%` }}
                />
              </div>
              <div
                className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-line"
                aria-label={`Oxigênio ${Math.round(hud.oxygen)}%`}
              >
                <div
                  className="h-full rounded-full bg-oxygen"
                  style={{ width: `${Math.max(0, Math.min(100, hud.oxygen))}%` }}
                />
              </div>
              <p className="mt-1 font-display text-sm leading-none">Plantcraft</p>
              {hud.hovering && (
                <p className="mt-1 text-[10px] tracking-wide text-cyan-200/90">Flutuando · F1</p>
              )}
              {hud.breathing && (
                <p className="mt-1 text-[10px] tracking-wide text-cyan-200/90">Respirando · F2</p>
              )}
              {hud.swift && (
                <p className="mt-1 text-[10px] tracking-wide text-cyan-200/90">Veloz · F3</p>
              )}
              {hud.third && (
                <p className="mt-1 text-[10px] tracking-wide text-cream/80">Terceira pessoa · P</p>
              )}
              {hud.sneaking && (
                <p className="mt-1 text-[10px] tracking-wide text-cream/80">Agachado · Ctrl</p>
              )}
            </div>
            <div className="flex flex-col items-end gap-2">
              <div className="flex flex-col items-center rounded-md border border-line bg-soil/70 px-2 py-1.5 backdrop-blur-sm">
                <div className="relative size-12 rounded-full border border-cream/30">
                  <div className="absolute inset-0" style={{ transform: `rotate(${(hud.compassAng * 180) / Math.PI}deg)` }}>
                    <span className="absolute top-1 left-1/2 h-5 w-0.5 -translate-x-1/2 rounded-full bg-health" />
                    <span className="absolute top-0.5 left-1/2 size-1.5 -translate-x-1/2 rounded-full bg-health" />
                  </div>
                  <span className="absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-cream/50" />
                </div>
                <p className="mt-1 max-w-28 text-center text-[10px] leading-tight text-cream">{hud.compass}</p>
                <p className="text-[9px] tracking-wide text-muted uppercase">F6</p>
              </div>
              <div className="flex items-center gap-2">
              <button
                type="button"
                className="pointer-events-auto inline-flex size-11 items-center justify-center rounded-md border border-line bg-soil/70 text-cream"
                onClick={() => handle?.toggleInventory()}
                aria-label="Inventário"
              >
                <Backpack className="size-4" />
              </button>
              <button
                type="button"
                className="pointer-events-auto inline-flex size-11 items-center justify-center rounded-md border border-line bg-soil/70 text-cream"
                onClick={() => handle?.pause()}
                aria-label="Pausar"
              >
                <Pause className="size-4" />
              </button>
              </div>
            </div>
          </div>

          <div className="pointer-events-none absolute top-1/2 left-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
            <div className="relative size-4">
              <span className="absolute top-1/2 left-0 h-px w-full bg-cream/90" />
              <span className="absolute top-0 left-1/2 h-full w-px bg-cream/90" />
            </div>
            {hud.eat > 0 && (
              <div className="absolute top-5 left-1/2 h-1 w-16 -translate-x-1/2 overflow-hidden rounded-full bg-ink/50">
                <div className="h-full bg-hunger" style={{ width: `${Math.min(100, hud.eat * 100)}%` }} />
              </div>
            )}
            {hud.mine > 0 && (
              <div className="absolute top-5 left-1/2 h-1 w-16 -translate-x-1/2 overflow-hidden rounded-full bg-ink/50">
                <div className="h-full bg-cream" style={{ width: `${Math.min(100, hud.mine * 100)}%` }} />
              </div>
            )}
            {hud.target && (
              <p className="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-[11px] tracking-wide text-cream/80">
                {hud.target}
              </p>
            )}
            {hud.hint && (
              <p className="absolute top-14 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-ink/70 px-3 py-1 font-display text-sm tracking-wide text-cream">
                {hud.hint}
              </p>
            )}
            {isFood(hud.slots[hud.selected]?.id ?? AIR) && (hud.slots[hud.selected]?.count ?? 0) > 0 && (
              <p className="absolute top-12 left-1/2 w-[18rem] -translate-x-1/2 text-center text-[10px] leading-snug text-cream/70">
                Segure o botão direito para comer
              </p>
            )}
            {hud.slots[hud.selected]?.id === MELON_SLICE && (hud.slots[hud.selected]?.count ?? 0) > 0 && (
              <p className="absolute top-12 left-1/2 w-[18rem] -translate-x-1/2 text-center text-[10px] leading-snug text-cream/70">
                Usar: comer · Agachar+usar: semente · 9 fatias+agachar: bloco
              </p>
            )}
          </div>

          {!hud.inventoryOpen && (
          <div className="absolute bottom-4 left-1/2 z-20 flex max-w-[calc(100%-1rem)] -translate-x-1/2 items-end gap-0.5 pb-[env(safe-area-inset-bottom)]">
            <HeldName />
            {hud.slots.slice(0, HOTBAR_LEN).map((slot, i) => (
              <ItemSlot
                key={i}
                slot={slot}
                index={i}
                selected={i === hud.selected}
                onSelect={() => handle?.selectSlot(i)}
              />
            ))}
          </div>
          )}

          {hud.inventoryOpen && <InventoryPanel />}

          <div
            data-joy
            className="pointer-events-auto absolute bottom-24 left-4 z-20 size-32 touch-none sm:hidden"
            onPointerDown={(e) => {
              (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
              const r = e.currentTarget.getBoundingClientRect();
              joy.current = { id: e.pointerId, x: r.left + r.width / 2, y: r.top + r.height / 2, px: 0, py: 0 };
            }}
            onPointerMove={(e) => {
              if (!joy.current || joy.current.id !== e.pointerId) return;
              const dx = (e.clientX - joy.current.x) / 48;
              const dy = (e.clientY - joy.current.y) / 48;
              const m = Math.hypot(dx, dy);
              const s = m > 1 ? 1 / m : 1;
              handle?.setTouchMove(dx * s, -dy * s);
              if (stick.current) {
                stick.current.style.transform = `translate(${dx * s * 22}px, ${dy * s * 22}px)`;
              }
            }}
            onPointerUp={() => {
              joy.current = null;
              handle?.setTouchMove(0, 0);
              if (stick.current) stick.current.style.transform = "translate(0,0)";
            }}
            onPointerCancel={() => {
              joy.current = null;
              handle?.setTouchMove(0, 0);
            }}
          >
            <div className="relative size-full rounded-full border border-line bg-soil/50">
              <div ref={stick} className="absolute top-1/2 left-1/2 size-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cream/80" />
            </div>
          </div>

          <div className="pointer-events-auto absolute right-4 bottom-24 z-20 flex flex-col gap-2 sm:hidden">
            <button
              type="button"
              className="h-12 min-w-20 rounded-md border border-line bg-soil/80 px-3 text-xs font-medium"
              onPointerDown={() => handle?.setTouchPlace(true)}
              onPointerUp={() => handle?.setTouchPlace(false)}
              onPointerCancel={() => handle?.setTouchPlace(false)}
            >
              Colocar
            </button>
            <button
              type="button"
              className="h-12 min-w-20 rounded-md border border-line bg-soil/80 px-3 text-xs font-medium"
              onPointerDown={() => handle?.setTouchBreak(true)}
              onPointerUp={() => handle?.setTouchBreak(false)}
              onPointerCancel={() => handle?.setTouchBreak(false)}
            >
              Quebrar
            </button>
            <button
              type="button"
              className="h-12 min-w-20 rounded-md bg-cream px-3 text-xs font-medium text-ink"
              onPointerDown={() => handle?.setTouchJump(true)}
              onPointerUp={() => handle?.setTouchJump(false)}
              onPointerCancel={() => handle?.setTouchJump(false)}
            >
              Pular
            </button>
          </div>
        </>
      )}

      {playing && !hud.inventoryOpen && (
        <LookCatcher
          onLook={(dx, dy) => handle?.addLook(dx, dy)}
          looking={look}
        />
      )}
    </div>
  );
}

function LookCatcher({
  onLook,
  looking,
}: {
  onLook: (dx: number, dy: number) => void;
  looking: MutableRefObject<{ id: number; x: number; y: number } | null>;
}) {
  return (
    <div
      className="pointer-events-auto absolute inset-0 z-0 sm:hidden"
      style={{ zIndex: 0 }}
      onPointerDown={(e) => {
        const t = e.target as HTMLElement;
        if (t.closest("button") || t.closest("[data-joy]")) return;
        looking.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
      }}
      onPointerMove={(e) => {
        if (!looking.current || looking.current.id !== e.pointerId) return;
        onLook(e.clientX - looking.current.x, e.clientY - looking.current.y);
        looking.current.x = e.clientX;
        looking.current.y = e.clientY;
      }}
      onPointerUp={() => {
        looking.current = null;
      }}
    />
  );
}

function isEmpty(slot: Slot) {
  return !slot || slot.count <= 0 || slot.id === AIR;
}

function ItemIcon({ id }: { id: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (canvas) paintItem(canvas, id);
  }, [id]);
  return (
    <canvas
      ref={ref}
      width={32}
      height={32}
      className="size-7 sm:size-8"
      style={{ imageRendering: "pixelated" }}
    />
  );
}

function ItemSlot({
  slot,
  index,
  selected,
  onSelect,
  onAlt,
}: {
  slot: Slot;
  index: number;
  selected?: boolean;
  onSelect: () => void;
  onAlt?: () => void;
}) {
  const empty = isEmpty(slot);
  const name = empty ? "Vazio" : blockLabel(slot.id) || `Item ${index + 1}`;
  return (
    <button
      type="button"
      onClick={onSelect}
      onContextMenu={(e) => {
        e.preventDefault();
        onAlt?.();
      }}
      className="group pointer-events-auto relative flex size-9 items-center justify-center sm:size-11"
      style={{
        background: "#8b8b8b",
        boxShadow: selected
          ? "inset 0 0 0 2px #fff, inset 3px 3px 0 #373737, inset -3px -3px 0 #fff"
          : "inset 2px 2px 0 #373737, inset -2px -2px 0 #fff",
      }}
      aria-label={empty ? name : `${name}, ${slot.count}`}
    >
      {!empty && <ItemIcon id={slot.id} />}
      {!empty && slot.count > 1 && (
        <span
          className="absolute right-0.5 bottom-0 font-mono text-[11px] leading-none text-white"
          style={{ textShadow: "1px 1px 0 #1a1a1a" }}
        >
          {slot.count}
        </span>
      )}
      {!empty && (
        <span
          className="pointer-events-none absolute bottom-[calc(100%+4px)] left-1/2 z-50 hidden -translate-x-1/2 px-1.5 py-0.5 text-[11px] whitespace-nowrap text-white group-hover:block"
          style={{ background: "#100010e8", boxShadow: "2px 2px 0 #2a0a28" }}
        >
          {name}
        </span>
      )}
    </button>
  );
}

function HeldName() {
  const hud = useGame((s) => s.hud);
  const slot = hud.slots[hud.selected];
  const [text, setText] = useState("");
  useEffect(() => {
    if (!slot || slot.count <= 0 || slot.id === AIR) {
      setText("");
      return;
    }
    setText(blockLabel(slot.id));
    const t = window.setTimeout(() => setText(""), 1600);
    return () => window.clearTimeout(t);
  }, [hud.selected, slot?.id]);
  if (!text) return null;
  return (
    <p
      className="absolute bottom-full left-1/2 mb-1 -translate-x-1/2 px-2 py-0.5 text-xs whitespace-nowrap text-white"
      style={{ background: "#100010e8" }}
    >
      {text}
    </p>
  );
}

function InventoryPanel() {
  const hud = useGame((s) => s.hud);
  const handle = useGame((s) => s.handle);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const bag = hud.slots.slice(HOTBAR_LEN);
  const hovering = !isEmpty(hud.cursor);

  return (
    <div
      className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/70 px-3 pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]"
      onPointerMove={(e) => setMouse({ x: e.clientX, y: e.clientY })}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        className="w-full max-w-lg p-3 sm:p-4"
        style={{
          background: "#c6c6c6",
          boxShadow: "inset 3px 3px 0 #fff, inset -3px -3px 0 #555",
        }}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg text-[#3f3f3f]">{hud.craftSize === 3 ? "Mesa de trabalho" : "Inventário"}</h2>
            <div className="mt-2 flex items-center gap-2">
              <div className={`grid gap-0.5 ${hud.craftSize === 3 ? "grid-cols-3" : "grid-cols-2"}`}>
                {(hud.craftSize === 3 ? [0, 1, 2, 3, 4, 5, 6, 7, 8] : [0, 1, 3, 4]).map((i) => (
                  <ItemSlot
                    key={`craft-${i}`}
                    slot={hud.craft[i] ?? { id: AIR, count: 0 }}
                    index={i}
                    onSelect={() => handle?.craftClick(i, false)}
                    onAlt={() => handle?.craftClick(i, true)}
                  />
                ))}
              </div>
              <span className="px-1 text-lg text-[#3f3f3f]">→</span>
              <ItemSlot
                slot={hud.craftOut}
                index={-1}
                onSelect={() => handle?.craftTake()}
                onAlt={() => handle?.craftTake()}
              />
            </div>
          </div>
          <button
            type="button"
            className="inline-flex size-8 items-center justify-center text-[#3f3f3f]"
            onClick={() => handle?.toggleInventory()}
            aria-label="Fechar inventário"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="grid grid-cols-9 gap-0.5">
          {bag.map((slot, i) => (
            <ItemSlot
              key={`bag-${i}`}
              slot={slot}
              index={HOTBAR_LEN + i}
              onSelect={() => handle?.invClick(HOTBAR_LEN + i, false)}
              onAlt={() => handle?.invClick(HOTBAR_LEN + i, true)}
            />
          ))}
        </div>

        <div className="mt-2 grid grid-cols-9 gap-0.5 border-t-2 border-[#555]/40 pt-2">
          {hud.slots.slice(0, HOTBAR_LEN).map((slot, i) => (
            <ItemSlot
              key={`hot-${i}`}
              slot={slot}
              index={i}
              selected={i === hud.selected}
              onSelect={() => handle?.invClick(i, false)}
              onAlt={() => handle?.invClick(i, true)}
            />
          ))}
        </div>
      </div>

      {hovering && (
        <div
          className="pointer-events-none fixed z-40 flex size-11 items-center justify-center"
          style={{ left: mouse.x + 8, top: mouse.y + 8, background: "transparent" }}
        >
          <ItemIcon id={hud.cursor.id} />
          <span className="absolute right-0.5 bottom-0 font-mono text-[10px] tabular-nums text-cream">
            {hud.cursor.count}
          </span>
        </div>
      )}
    </div>
  );
}

