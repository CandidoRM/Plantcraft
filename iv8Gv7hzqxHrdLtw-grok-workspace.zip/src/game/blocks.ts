export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const LOG = 4;
export const LEAVES = 5;
export const PLANKS = 6;
export const SAND = 7;
export const BEDROCK = 8;
export const WATER = 9;
/** Flowing water levels 1–7 live at WATER_FLOW .. WATER_FLOW+6 */
export const WATER_FLOW = 10;
export const WATER_FALL = 17;
export const FARMLAND = 18;
export const MELON = 19;
export const MELON_SEEDS = 20;
/** Stem growth 0–7 at MELON_STEM .. MELON_STEM+7 */
export const MELON_STEM = 21;
/** Attached stem facing +Z, -Z, +X, -X */
export const MELON_ATTACH = 29;
export const ACID = 33;
/** Flowing acid levels 1–7 */
export const ACID_FLOW = 34;
export const ACID_FALL = 41;
export const BIRCH_LOG = 42;
export const BIRCH_LEAVES = 43;
export const DARK_LOG = 44;
export const DARK_LEAVES = 45;
export const RED_CARPET = 46;
export const MELON_SLICE = 47;
export const RICCIA = 48;
export const GRASS_CARPET = 49;
export const GRASS_CARPET_WET = 50;
export const CRACKED_STONE = 51;
export const ARAU_LOG = 52;
export const ARAU_LEAVES = 53;
export const CERRADO_GRASS = 54;
export const CERRADO_DIRT = 55;
export const CERRADO_CARPET = 56;
export const CERRADO_LEAVES = 57;
export const VARZEA_GRASS = 58;
export const VARZEA_CARPET = 59;
export const WEED_SHORT = 60;
export const WEED_TALL = 61;
export const WEED_CERRADO = 62;
export const WEED_REED = 63;
export const WEED_BEACH = 64;
export const AQUIFER = 65;
export const CERRADO_CARPET_WET = 66;
/** Solid block of grass on every face — no dirt. */
export const GRASS_FULL = 67;
/** Minecraft-style vine. Facing 0=+Z, 1=-Z, 2=+X, 3=-X, toward the block it clings to. */
export const VINE = 68;
/** Distinct vine: large variegated leaves. Same facing layout as VINE. */
export const VINE_JIBOIA = 72;

export const FOOD_BANANA = 76;
export const FOOD_MANGO = 77;
export const FOOD_AVOCADO = 78;
export const FOOD_ORANGE = 79;
export const FOOD_PINEAPPLE = 80;
export const FOOD_COCONUT = 81;
export const FOOD_ACAI = 82;
export const FOOD_CASSAVA_RAW = 83;
export const FOOD_CASSAVA = 84;
export const FOOD_CORN = 85;
export const FOOD_RICE = 86;
export const FOOD_GUAVA = 87;

export const STICK = 88;
export const SHOVEL = 89;
export const CRAFTING_TABLE = 90;
export const FENCE = 91;
export const PATH = 92;
/** Door facing 0=-Z, 1=+Z, 2=-X, 3=+X. */
export const DOOR = 93;
/** Unlit candle. Lit form is the next id. */
export const CANDLE = 97;
export const CANDLE_LIT = 98;
/** Village dresser. No crafting. */
export const COMODA = 99;
/** Annatto. Stages 0–7. Not a Minecraft crop. */
export const URUCUM = 100;
/** Cape gooseberry. Stages 0–7. Not a Minecraft crop. */
export const CAMAPU = 108;
export const FOOD_URUCUM = 116;
export const FOOD_CAMAPU = 117;
/** Open wooden door. Same facing layout as DOOR. */
export const DOOR_OPEN = 118;
/** Closed fence gate. */
export const GATE = 122;
export const GATE_OPEN = 123;
/** Tomato. Stages 0–7. Not a Minecraft crop. */
export const TOMATO = 124;
export const FOOD_TOMATO = 132;
/** Pale ruin stone. Sides of the marble lawn read as marble cliffs. */
export const MARBLE = 133;
/** Bright lawn with marble sides, like grass laid over the ruins. */
export const MARBLE_GRASS = 134;
/** Walkable garden mud. Not a fluid and not a trap. */
export const MUD = 135;
/** White garden lily. */
export const GARDEN_LILY = 136;
/** Purple garden iris. */
export const GARDEN_IRIS = 137;
/** Thin lawn on marble half-grass. */
export const MARBLE_CARPET = 138;
/** Full marble lawn, no cream sides. */
export const MARBLE_GRASS_FULL = 139;
/** Orange ruin block. */
export const MARBLE_ORANGE = 140;
/** Gray-purple ruin block. */
export const MARBLE_PURPLE = 141;
export const APPLE_LEAVES = 142;
export const PALM_LEAVES = 143;
/** Opaque mud source. Flows like overworld lava: short and slow. */
export const MUD_FLUID = 144;
/** Flowing mud levels 1–7. */
export const MUD_FLOW = 145;
export const MUD_FALL = 152;
/** Veined marble split by cracks. Same stone, broken. */
export const MARBLE_BROKEN = 153;
/** Open peach canopy. Stored apart from the apple leaves. */
export const PEACH_LEAVES = 154;
/** Cream running-bond used by the columns. Not the veined soil. */
export const MARBLE_BRICK = 155;
/** Marble flower pot with a clipped bush. One block, not a full cube. */
export const MARBLE_VASE = 156;
/** Hanging peach. Not a full cube: the fruit passes through the leaf above. */
export const PEACH = 157;
export const FOOD_PEACH = 158;
/** Dry half-grass. Straw over pale sand. */
export const CAATINGA_GRASS = 159;
export const CAATINGA_DIRT = 160;
export const CAATINGA_GRASS_FULL = 161;
export const CAATINGA_CARPET = 162;
/** Bare pale slab. Nothing leafy takes root here except the cactus. */
export const CAATINGA_ROCK = 163;
export const CAATINGA_LOG = 164;
export const CAATINGA_LEAVES = 165;
/** Mandacaru. A thin column, not a full cube. */
export const CAATINGA_CACTUS = 166;
/** Ground bromeliad of the dry scrub. */
export const WEED_MACAMBIRA = 167;
/** Hanging garden tuft. */
export const WEED_DROOP = 171;
/** Monument plinth. A framed marble panel, not a column brick. */
export const MONUMENT_BASE = 168;
/** Fluted pale shaft. Vertical grooves, not a brick course. */
export const MONUMENT_SHAFT = 169;
/** Crown with a gold band. The capital of a monument. */
export const MONUMENT_CROWN = 170;

/** Cobalt marble from the garden mechanisms. A mineable stone, not a machine. */
export const MARBLE_BLUE = 172;
/** Green ruin brick from the marble palace. A mineable stone. */
export const GREEN_BRICK = 173;
/** Grass-capped slab that sinks while stood on, then rises back. */
export const SINK_PLAT = 174;
/** Rusted metal bolted onto the old marble ruin. A mineable block. */
export const RUST_METAL = 175;

/** Half-grass of the wet meadow. Blue-green over peat. */
export const BREJO_GRASS = 176;
export const BREJO_DIRT = 177;
export const BREJO_GRASS_FULL = 178;
export const BREJO_CARPET = 179;

/** Stone relief set into a ruin wall. The figure is part of the wall, not a free statue. */
export const WALL_STATUE = 180;
/** Still iron ball with spikes. It does not spin or swing. */
export const SPIKE_BALL = 181;

/** Empty marble pot. One plant only. */
export const VASE_LILY = 182;
export const VASE_IRIS = 183;
/** Crop in a pot, stages 0–7. The pot is the item, so the stage travels with it. */
export const VASE_URUCUM = 184;
export const VASE_CAMAPU = 192;
export const VASE_TOMATO = 200;

/** Pale ash crust over charcoal. A dry plain, not a lawn. */
export const ASH_GRASS = 208;
export const ASH_DIRT = 209;
export const ASH_GRASS_FULL = 210;
export const ASH_CARPET = 211;
export const ASH_ROCK = 212;
/** Bleached trunk. The crown stays thin. */
export const ASH_LOG = 213;
export const ASH_LEAVES = 214;
/** Low white crust plant. */
export const WEED_LICHEN = 215;
/** Small copper bloom on the ash. */
export const WEED_EMBER = 216;

/** Looks like the local ground, with a small crack. Drops after a short step. */
export const FALL_TRAP = 217;

export const BLOCK_COUNT = 218;

export const CARPET_H = 1 / 16;

/** Horizontal flow steps from a source. Minecraft spreads 7 blocks. */
export const FLOW_MAX = 7;

export type BlockId = number;

export const STEM_DIRS: [number, number][] = [
  [0, 1],
  [0, -1],
  [1, 0],
  [-1, 0],
];

export const BLOCK_NAME: Record<number, string> = {
  [AIR]: "Ar",
  [GRASS]: "Bloco de Meia-Grama",
  [DIRT]: "Terra",
  [STONE]: "Pedra",
  [LOG]: "Tronco",
  [LEAVES]: "Folhas",
  [PLANKS]: "Tábuas",
  [SAND]: "Areia",
  [BEDROCK]: "Leito",
  [WATER]: "Água",
  [WATER_FALL]: "Água",
  [FARMLAND]: "Terra arada",
  [MELON]: "Melão",
  [MELON_SEEDS]: "Sementes de melão",
  [MELON_SLICE]: "Fatia de melão",
  [ACID]: "Ácido",
  [ACID_FALL]: "Ácido",
  [BIRCH_LOG]: "Tronco de bétula",
  [BIRCH_LEAVES]: "Folhas de bétula",
  [DARK_LOG]: "Tronco de mogno",
  [DARK_LEAVES]: "Folhas de mogno",
  [RED_CARPET]: "Tapete vermelho",
  [GRASS_CARPET]: "Tapete de grama",
  [GRASS_CARPET_WET]: "Tapete de grama",
  [RICCIA]: "Riccia",
  [CRACKED_STONE]: "Pedra rachada",
  [ARAU_LOG]: "Tronco de araucária",
  [ARAU_LEAVES]: "Folhas de araucária",
  [CERRADO_GRASS]: "Grama do cerrado",
  [CERRADO_DIRT]: "Laterita",
  [CERRADO_CARPET]: "Tapete do cerrado",
  [CERRADO_CARPET_WET]: "Tapete do cerrado",
  [CERRADO_LEAVES]: "Folhas do cerrado",
  [VARZEA_GRASS]: "Grama de várzea",
  [VARZEA_CARPET]: "Tapete de várzea",
  [WEED_SHORT]: "Mato curto",
  [WEED_TALL]: "Mato alto",
  [WEED_CERRADO]: "Capim-flecha",
  [WEED_REED]: "Junco",
  [WEED_BEACH]: "Capim de restinga",
  [AQUIFER]: "Aquífero",
  [GRASS_FULL]: "Bloco de Grama",
  [VINE]: "Trepadeira",
  [VINE + 1]: "Trepadeira",
  [VINE + 2]: "Trepadeira",
  [VINE + 3]: "Trepadeira",
  [VINE_JIBOIA]: "Jiboia",
  [VINE_JIBOIA + 1]: "Jiboia",
  [VINE_JIBOIA + 2]: "Jiboia",
  [VINE_JIBOIA + 3]: "Jiboia",
  [FOOD_BANANA]: "Banana",
  [FOOD_MANGO]: "Manga",
  [FOOD_AVOCADO]: "Abacate",
  [FOOD_ORANGE]: "Laranja",
  [FOOD_PINEAPPLE]: "Abacaxi",
  [FOOD_COCONUT]: "Coco",
  [FOOD_ACAI]: "Açaí",
  [FOOD_CASSAVA_RAW]: "Mandioca crua",
  [FOOD_CASSAVA]: "Mandioca cozida",
  [FOOD_CORN]: "Milho",
  [FOOD_RICE]: "Arroz",
  [FOOD_GUAVA]: "Goiaba",
  [STICK]: "Graveto",
  [SHOVEL]: "Pá",
  [CRAFTING_TABLE]: "Mesa de trabalho",
  [FENCE]: "Cerca",
  [PATH]: "Caminho",
  [DOOR]: "Porta",
  [DOOR + 1]: "Porta",
  [DOOR + 2]: "Porta",
  [DOOR + 3]: "Porta",
  [DOOR_OPEN]: "Porta",
  [DOOR_OPEN + 1]: "Porta",
  [DOOR_OPEN + 2]: "Porta",
  [DOOR_OPEN + 3]: "Porta",
  [GATE]: "Portão",
  [GATE_OPEN]: "Portão",
  [CANDLE]: "Vela",
  [CANDLE_LIT]: "Vela",
  [COMODA]: "Cômoda",
  [FOOD_URUCUM]: "Urucum",
  [FOOD_CAMAPU]: "Camapu",
  [FOOD_TOMATO]: "Tomate",
  [MARBLE]: "Bloco de Mármore",
  [MARBLE_BRICK]: "Bloco de Tijolo de Mármore",
  [MARBLE_VASE]: "Vaso de mármore",
  [PEACH]: "Pêssego",
  [FOOD_PEACH]: "Pêssego",
  [CAATINGA_GRASS]: "Meia-Grama da Caatinga",
  [CAATINGA_DIRT]: "Solo da Caatinga",
  [CAATINGA_GRASS_FULL]: "Grama da Caatinga",
  [CAATINGA_CARPET]: "Tapete da Caatinga",
  [CAATINGA_ROCK]: "Lajedo",
  [CAATINGA_LOG]: "Tronco da caatinga",
  [CAATINGA_LEAVES]: "Folhas da caatinga",
  [CAATINGA_CACTUS]: "Mandacaru",
  [WEED_MACAMBIRA]: "Macambira",
  [WEED_DROOP]: "Matinho de folhas caídas",
  [MONUMENT_BASE]: "Base de monumento",
  [MONUMENT_SHAFT]: "Fuste de monumento",
  [MONUMENT_CROWN]: "Coroamento de monumento",
  [MARBLE_BLUE]: "Mármore azul",
  [GREEN_BRICK]: "Tijolo verde",
  [SINK_PLAT]: "Plataforma que afunda",
  [RUST_METAL]: "Metal enferrujado",
  [BREJO_GRASS]: "Meia-Grama do Brejo",
  [BREJO_DIRT]: "Turfa",
  [BREJO_GRASS_FULL]: "Grama do Brejo",
  [BREJO_CARPET]: "Tapete do Brejo",
  [WALL_STATUE]: "Estátua de parede",
  [SPIKE_BALL]: "Bola de espinhos",
  [ASH_GRASS]: "Crosta de cinza",
  [ASH_DIRT]: "Carvão",
  [ASH_GRASS_FULL]: "Crosta fechada",
  [ASH_CARPET]: "Tapete de cinza",
  [ASH_ROCK]: "Bloco de carvão",
  [ASH_LOG]: "Tronco pálido",
  [ASH_LEAVES]: "Folhas de brasa",
  [WEED_LICHEN]: "Líquen",
  [WEED_EMBER]: "Flor de brasa",
  [FALL_TRAP]: "Bloco instável",
  [MARBLE_BROKEN]: "Mármore quebrado",
  [MARBLE_GRASS]: "Meia-Grama de Mármore",
  [MARBLE_GRASS_FULL]: "Grama de Mármore",
  [MARBLE_CARPET]: "Tapete de Grama de Mármore",
  [MARBLE_ORANGE]: "Mármore laranja",
  [MARBLE_PURPLE]: "Mármore roxo",
  [MUD]: "Bloco de lama",
  [MUD_FLUID]: "Lama líquida",
  [GARDEN_LILY]: "Lírio do jardim",
  [GARDEN_IRIS]: "Íris do jardim",
  [APPLE_LEAVES]: "Folhas de macieira",
  [PALM_LEAVES]: "Folhas de palmeira",
  [PEACH_LEAVES]: "Folhas de pessegueiro",
};

for (let i = 0; i < 7; i++) BLOCK_NAME[WATER_FLOW + i] = "Água";
for (let i = 0; i < 8; i++) BLOCK_NAME[MELON_STEM + i] = "Caule de melão";
for (let i = 0; i < 4; i++) BLOCK_NAME[MELON_ATTACH + i] = "Caule de melão";
for (let i = 0; i < 8; i++) {
  BLOCK_NAME[URUCUM + i] = "Urucum";
  BLOCK_NAME[CAMAPU + i] = "Camapu";
  BLOCK_NAME[TOMATO + i] = "Tomate";
  BLOCK_NAME[VASE_URUCUM + i] = "Vaso com urucum";
  BLOCK_NAME[VASE_CAMAPU + i] = "Vaso com camapu";
  BLOCK_NAME[VASE_TOMATO + i] = "Vaso com tomate";
}
BLOCK_NAME[VASE_LILY] = "Vaso com lírio";
BLOCK_NAME[VASE_IRIS] = "Vaso com íris";
for (let i = 0; i < 7; i++) BLOCK_NAME[ACID_FLOW + i] = "Ácido";
for (let i = 0; i < 7; i++) BLOCK_NAME[MUD_FLOW + i] = "Lama líquida";
BLOCK_NAME[MUD_FALL] = "Lama líquida";

export const BLOCK_COLOR: Record<number, string> = {
  [GRASS]: "#5c9a3c",
  [DIRT]: "#865c34",
  [STONE]: "#808084",
  [LOG]: "#6b4a28",
  [LEAVES]: "#30762a",
  [PLANKS]: "#c6a05a",
  [SAND]: "#d6c67c",
  [BEDROCK]: "#2a2a30",
  [WATER]: "#68a2ac",
  [FARMLAND]: "#6b4424",
  [MELON]: "#f0c24a",
  [MELON_SEEDS]: "#c4b05a",
  [MELON_SLICE]: "#e6c05a",
  [ACID]: "#3a5428",
  [BIRCH_LOG]: "#d8d2c2",
  [BIRCH_LEAVES]: "#7aaa3a",
  [DARK_LOG]: "#4a2e18",
  [DARK_LEAVES]: "#1e6a46",
  [RED_CARPET]: "#b32626",
  [GRASS_CARPET]: "#5c9a3c",
  [GRASS_CARPET_WET]: "#5c9a3c",
  [RICCIA]: "#6dcc44",
  [CRACKED_STONE]: "#b0b0b2",
  [ARAU_LOG]: "#5a3a22",
  [ARAU_LEAVES]: "#2a6a38",
  [CERRADO_GRASS]: "#c4a63a",
  [CERRADO_DIRT]: "#a45a32",
  [CERRADO_CARPET]: "#c4a63a",
  [CERRADO_CARPET_WET]: "#c4a63a",
  [CERRADO_LEAVES]: "#8a9a32",
  [VARZEA_GRASS]: "#1e8a72",
  [VARZEA_CARPET]: "#1e8a72",
  [WEED_SHORT]: "#5cb03a",
  [WEED_TALL]: "#2e7a28",
  [WEED_CERRADO]: "#c4a43a",
  [WEED_REED]: "#2a8a78",
  [WEED_BEACH]: "#c8b86a",
  [AQUIFER]: "#5a6a6e",
  [GRASS_FULL]: "#3f9a34",
  [VINE]: "#3d8c28",
  [VINE + 1]: "#3d8c28",
  [VINE + 2]: "#3d8c28",
  [VINE + 3]: "#3d8c28",
  [VINE_JIBOIA]: "#b6d24a",
  [VINE_JIBOIA + 1]: "#b6d24a",
  [VINE_JIBOIA + 2]: "#b6d24a",
  [VINE_JIBOIA + 3]: "#b6d24a",
  [FOOD_BANANA]: "#f2d24a",
  [FOOD_MANGO]: "#f0a030",
  [FOOD_AVOCADO]: "#6a8f3a",
  [FOOD_ORANGE]: "#ef8a1a",
  [FOOD_PINEAPPLE]: "#e6c44a",
  [FOOD_COCONUT]: "#f3efe2",
  [FOOD_ACAI]: "#4a2060",
  [FOOD_CASSAVA_RAW]: "#c8b48a",
  [FOOD_CASSAVA]: "#e6d2a4",
  [FOOD_CORN]: "#f2e15a",
  [FOOD_RICE]: "#f7f3ea",
  [FOOD_GUAVA]: "#d4e07a",
  [STICK]: "#b08a4a",
  [SHOVEL]: "#c6a05a",
  [CRAFTING_TABLE]: "#a67a3a",
  [FENCE]: "#c6a05a",
  [PATH]: "#c2a36a",
  [DOOR]: "#a67a3a",
  [DOOR + 1]: "#a67a3a",
  [DOOR + 2]: "#a67a3a",
  [DOOR + 3]: "#a67a3a",
  [DOOR_OPEN]: "#a67a3a",
  [DOOR_OPEN + 1]: "#a67a3a",
  [DOOR_OPEN + 2]: "#a67a3a",
  [DOOR_OPEN + 3]: "#a67a3a",
  [GATE]: "#c6a05a",
  [GATE_OPEN]: "#c6a05a",
  [CANDLE]: "#f3ead0",
  [CANDLE_LIT]: "#f3ead0",
  [COMODA]: "#a67a3a",
  [FOOD_URUCUM]: "#c4482a",
  [FOOD_CAMAPU]: "#e39a3a",
  [FOOD_TOMATO]: "#d63a2a",
  [MARBLE]: "#efe2c4",
  [MARBLE_BRICK]: "#e6d8bc",
  [MARBLE_VASE]: "#e6d8bc",
  [VASE_LILY]: "#f4f0dc",
  [VASE_IRIS]: "#7a68b0",
  [PEACH]: "#f0a088",
  [FOOD_PEACH]: "#f0a088",
  [CAATINGA_GRASS]: "#c6ae58",
  [CAATINGA_DIRT]: "#d2c09a",
  [CAATINGA_GRASS_FULL]: "#c6ae58",
  [CAATINGA_CARPET]: "#d4bc68",
  [CAATINGA_ROCK]: "#e6decc",
  [CAATINGA_LOG]: "#8a7560",
  [CAATINGA_LEAVES]: "#6a8a3c",
  [CAATINGA_CACTUS]: "#6e9448",
  [WEED_MACAMBIRA]: "#7a9a52",
  [WEED_DROOP]: "#5cb83a",
  [MONUMENT_BASE]: "#c8b8a0",
  [MONUMENT_SHAFT]: "#e4d6c4",
  [MONUMENT_CROWN]: "#f0e4cc",
  [MARBLE_BROKEN]: "#d8cbb4",
  [MARBLE_GRASS]: "#7dce46",
  [MARBLE_GRASS_FULL]: "#7dce46",
  [MARBLE_CARPET]: "#8ed85a",
  [MARBLE_ORANGE]: "#e09048",
  [MARBLE_PURPLE]: "#8a849c",
  [MARBLE_BLUE]: "#3f78c8",
  [GREEN_BRICK]: "#689068",
  [SINK_PLAT]: "#7dce46",
  [RUST_METAL]: "#a85a32",
  [BREJO_GRASS]: "#4e9a68",
  [BREJO_DIRT]: "#3a2a22",
  [BREJO_GRASS_FULL]: "#4e9a68",
  [BREJO_CARPET]: "#5aaa74",
  [WALL_STATUE]: "#d8cbb4",
  [SPIKE_BALL]: "#a85a32",
  [ASH_GRASS]: "#d4cec2",
  [ASH_DIRT]: "#3a3634",
  [ASH_GRASS_FULL]: "#d4cec2",
  [ASH_CARPET]: "#e4ddd0",
  [ASH_ROCK]: "#2e2a28",
  [ASH_LOG]: "#e6dfd2",
  [ASH_LEAVES]: "#8a4634",
  [WEED_LICHEN]: "#e8e0d4",
  [WEED_EMBER]: "#d26830",
  [FALL_TRAP]: "#6a9444",
  [MUD]: "#5c4630",
  [MUD_FLUID]: "#5c4630",
  [GARDEN_LILY]: "#f4f0e4",
  [GARDEN_IRIS]: "#7a4ad0",
  [APPLE_LEAVES]: "#4aaa32",
  [PALM_LEAVES]: "#2e9a38",
  [PEACH_LEAVES]: "#3d9a2e",
};

for (let i = 0; i < 8; i++) {
  BLOCK_COLOR[URUCUM + i] = i >= 5 ? "#c4482a" : "#3e8a34";
  BLOCK_COLOR[CAMAPU + i] = i >= 5 ? "#e39a3a" : "#4a9a3a";
  BLOCK_COLOR[TOMATO + i] = i >= 7 ? "#d63a2a" : i === 6 ? "#a8cc6c" : i >= 4 ? "#6aaa34" : "#3e8a34";
  BLOCK_COLOR[VASE_URUCUM + i] = i >= 5 ? "#c4482a" : "#3e8a34";
  BLOCK_COLOR[VASE_CAMAPU + i] = i >= 5 ? "#e39a3a" : "#4a9a3a";
  BLOCK_COLOR[VASE_TOMATO + i] = i >= 7 ? "#d63a2a" : i === 6 ? "#a8cc6c" : i >= 4 ? "#6aaa34" : "#3e8a34";
}

export const HOTBAR_ORDER: BlockId[] = [
  GRASS,
  GRASS_FULL,
  DIRT,
  STONE,
  CRACKED_STONE,
  AQUIFER,
  LOG,
  PLANKS,
  LEAVES,
  SAND,
  WATER,
  RICCIA,
  MELON_SEEDS,
  ACID,
  RED_CARPET,
  GRASS_CARPET,
  CERRADO_GRASS,
  CERRADO_DIRT,
  CERRADO_CARPET,
  VARZEA_GRASS,
  VARZEA_CARPET,
  WEED_SHORT,
  WEED_TALL,
  WEED_CERRADO,
  WEED_REED,
  WEED_BEACH,
  VINE,
  VINE_JIBOIA,
];

export function isWater(id: number): boolean {
  return id >= WATER && id <= WATER_FALL;
}

export function isWaterSource(id: number): boolean {
  return id === WATER;
}

export function isWaterFall(id: number): boolean {
  return id === WATER_FALL;
}

export type FluidKind = "water" | "acid" | "mud";

export function isMud(id: number): boolean {
  return id >= MUD_FLUID && id <= MUD_FALL;
}

export function isMudSource(id: number): boolean {
  return id === MUD_FLUID;
}

export function isAcid(id: number): boolean {
  return id >= ACID && id <= ACID_FALL;
}

export function isAcidSource(id: number): boolean {
  return id === ACID;
}

export function isAcidFall(id: number): boolean {
  return id === ACID_FALL;
}

export function isFluid(id: number): boolean {
  return isWater(id) || isAcid(id) || isMud(id) || isRiccia(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET;
}

export function fluidKind(id: number): FluidKind | null {
  if (isRiccia(id) || isWater(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET) return "water";
  if (isAcid(id)) return "acid";
  if (isMud(id)) return "mud";
  return null;
}

export function isFluidSource(id: number): boolean {
  return id === WATER || id === ACID || id === MUD_FLUID;
}

export function isFluidFall(id: number): boolean {
  return id === WATER_FALL || id === ACID_FALL || id === MUD_FALL;
}

export function fluidSource(kind: FluidKind): number {
  if (kind === "acid") return ACID;
  if (kind === "mud") return MUD_FLUID;
  return WATER;
}

export function fluidFall(kind: FluidKind): number {
  if (kind === "acid") return ACID_FALL;
  if (kind === "mud") return MUD_FALL;
  return WATER_FALL;
}

export function sameFluid(id: number, kind: FluidKind): boolean {
  return fluidKind(id) === kind;
}

export function waterLevel(id: number): number {
  return fluidLevel(id);
}

export function fluidLevel(id: number): number {
  if (id === WATER || id === ACID || id === MUD_FLUID) return 0;
  if (id === WATER_FALL || id === ACID_FALL || id === MUD_FALL) return 8;
  if (id >= WATER_FLOW && id < WATER_FLOW + 7) return id - WATER_FLOW + 1;
  if (id >= ACID_FLOW && id < ACID_FLOW + 7) return id - ACID_FLOW + 1;
  if (id >= MUD_FLOW && id < MUD_FLOW + 7) return id - MUD_FLOW + 1;
  return -1;
}

export function waterFromLevel(level: number): number {
  return fluidFromLevel("water", level);
}

/** Overworld lava loses 2 levels per block and stops at 3 blocks. */
export function flowStep(kind: FluidKind): number {
  return kind === "mud" ? 2 : 1;
}

export function flowReach(kind: FluidKind): number {
  return kind === "mud" ? 6 : FLOW_MAX;
}

export function fluidFromLevel(kind: FluidKind, level: number): number {
  const flow = kind === "acid" ? ACID_FLOW : kind === "mud" ? MUD_FLOW : WATER_FLOW;
  const reach = flowReach(kind);
  if (level <= 0) return fluidSource(kind);
  if (level > reach) return AIR;
  return flow + level - 1;
}

/** Visual fill 0–1. Source ≈ 8/9, falling is full, flow gets shallower. */
export function waterFill(id: number): number {
  return fluidFill(id);
}

export function fluidFill(id: number): number {
  if (!isFluid(id)) return 0;
  if (isFluidFall(id)) return 1;
  if (isRiccia(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET || isFluidSource(id)) return 8 / 9;
  return (8 - fluidLevel(id)) / 9;
}

export function isStem(id: number): boolean {
  return id >= MELON_STEM && id < MELON_STEM + 8;
}

export function isMelonAttach(id: number): boolean {
  return id >= MELON_ATTACH && id < MELON_ATTACH + 4;
}

export function isVine(id: number): boolean {
  return id >= VINE && id < VINE + 8;
}

export function vineSpecies(id: number): number {
  return id >= VINE_JIBOIA ? 1 : 0;
}

/** 0=+Z, 1=-Z, 2=+X, 3=-X. The vine plane sits on that side, against the support block. */
export function vineFace(id: number): number {
  return (id - (id >= VINE_JIBOIA ? VINE_JIBOIA : VINE)) & 3;
}

export function vineId(species: number, face: number): number {
  return (species ? VINE_JIBOIA : VINE) + (face & 3);
}

/** Side the vine clings to, from the clicked block's outward normal. -1 if it is not a side. */
export function vineFaceFromNormal(nx: number, ny: number, nz: number): number {
  if (ny !== 0) return -1;
  if (nz > 0) return 1;
  if (nz < 0) return 0;
  if (nx > 0) return 3;
  if (nx < 0) return 2;
  return -1;
}

export function isGardenFlower(id: number): boolean {
  return id === GARDEN_LILY || id === GARDEN_IRIS;
}

export function gardenTile(id: number): number {
  return id === GARDEN_IRIS ? 45 : 44;
}

export function isPlant(id: number): boolean {
  return isStem(id) || isMelonAttach(id) || isRiccia(id) || isWeed(id) || isVine(id) || isCrop(id) || isGardenFlower(id);
}

export function isWeed(id: number): boolean {
  return (id >= WEED_SHORT && id <= WEED_BEACH) || id === WEED_MACAMBIRA || id === WEED_DROOP || id === WEED_LICHEN || id === WEED_EMBER;
}

/** Plants, leaves and carpets let liquid pass. Red carpet blocks it. Riccia stays put. */
export function isFluidPermeable(id: number): boolean {
  if (id === RED_CARPET || isRiccia(id)) return false;
  return isLeaves(id) || isWeed(id) || isStem(id) || isMelonAttach(id) || isVine(id) || isCrop(id) || isGardenFlower(id) || isCarpet(id);
}

export function isMeadowGrass(id: number): boolean {
  return id === GRASS || id === GRASS_FULL;
}

export function isMarbleGrass(id: number): boolean {
  return id === MARBLE_GRASS || id === MARBLE_GRASS_FULL;
}

export function isCaatingaGrass(id: number): boolean {
  return id === CAATINGA_GRASS || id === CAATINGA_GRASS_FULL;
}

export function isBrejoGrass(id: number): boolean {
  return id === BREJO_GRASS || id === BREJO_GRASS_FULL;
}

export function isAshGrass(id: number): boolean {
  return id === ASH_GRASS || id === ASH_GRASS_FULL;
}

export function weedTile(id: number): number {
  if (id === WEED_MACAMBIRA) return 46;
  if (id === WEED_DROOP) return 47;
  if (id === WEED_LICHEN) return 48;
  if (id === WEED_EMBER) return 49;
  if (!isWeed(id)) return 10;
  return 10 + (id - WEED_SHORT);
}

export function isRiccia(id: number): boolean {
  return id === RICCIA;
}

export function isLeaves(id: number): boolean {
  return id === LEAVES || id === BIRCH_LEAVES || id === DARK_LEAVES || id === ARAU_LEAVES || id === CERRADO_LEAVES || id === APPLE_LEAVES || id === PALM_LEAVES || id === PEACH_LEAVES || id === CAATINGA_LEAVES || id === ASH_LEAVES;
}

export function isLog(id: number): boolean {
  return id === LOG || id === BIRCH_LOG || id === DARK_LOG || id === ARAU_LOG || id === CAATINGA_LOG || id === ASH_LOG;
}

export function stemStage(id: number): number {
  if (!isStem(id)) return -1;
  return id - MELON_STEM;
}

export function stemFromStage(stage: number): number {
  if (stage < 0) return AIR;
  if (stage > 7) return MELON_STEM + 7;
  return MELON_STEM + stage;
}

export function attachFacing(id: number): number {
  if (!isMelonAttach(id)) return -1;
  return id - MELON_ATTACH;
}

export function isSoil(id: number): boolean {
  return id === DIRT || id === GRASS || id === FARMLAND || id === CERRADO_DIRT || id === CERRADO_GRASS || id === VARZEA_GRASS;
}

export function canHoldFruit(id: number): boolean {
  return id === DIRT || id === GRASS || id === FARMLAND || id === CERRADO_DIRT || id === CERRADO_GRASS || id === VARZEA_GRASS;
}

export function isFood(id: number): boolean {
  return (id >= FOOD_BANANA && id <= FOOD_GUAVA) || id === FOOD_URUCUM || id === FOOD_CAMAPU || id === FOOD_TOMATO || id === FOOD_PEACH;
}

export type CropKind = "urucum" | "camapu" | "tomate";

export function isUrucum(id: number): boolean {
  return id >= URUCUM && id < URUCUM + 8;
}

export function isCamapu(id: number): boolean {
  return id >= CAMAPU && id < CAMAPU + 8;
}

export function isTomato(id: number): boolean {
  return id >= TOMATO && id < TOMATO + 8;
}

export function isCrop(id: number): boolean {
  return isUrucum(id) || isCamapu(id) || isTomato(id);
}

export function cropKind(id: number): CropKind {
  if (isCamapu(id)) return "camapu";
  if (isTomato(id)) return "tomate";
  return "urucum";
}

export function cropStage(id: number): number {
  if (isCamapu(id)) return id - CAMAPU;
  if (isTomato(id)) return id - TOMATO;
  if (isUrucum(id)) return id - URUCUM;
  return -1;
}

export function cropFromStage(kind: CropKind, stage: number): number {
  const s = Math.max(0, Math.min(7, stage));
  if (kind === "camapu") return CAMAPU + s;
  if (kind === "tomate") return TOMATO + s;
  return URUCUM + s;
}

export function cropTile(id: number): number {
  const stage = Math.max(0, cropStage(id));
  if (isCamapu(id)) return 28 + stage;
  if (isTomato(id)) return 36 + stage;
  return 20 + stage;
}

export function cropFood(id: number): number {
  const kind = cropKind(id);
  if (kind === "camapu") return FOOD_CAMAPU;
  if (kind === "tomate") return FOOD_TOMATO;
  return FOOD_URUCUM;
}

export function isRipeCrop(id: number): boolean {
  return isCrop(id) && cropStage(id) >= 7;
}

export function isDoor(id: number): boolean {
  return (id >= DOOR && id < DOOR + 4) || (id >= DOOR_OPEN && id < DOOR_OPEN + 4);
}

export function isDoorOpen(id: number): boolean {
  return id >= DOOR_OPEN && id < DOOR_OPEN + 4;
}

export function doorFacing(id: number): number {
  if (isDoorOpen(id)) return id - DOOR_OPEN;
  if (id >= DOOR && id < DOOR + 4) return id - DOOR;
  return 0;
}

export function doorWithOpen(id: number, open: boolean): number {
  return (open ? DOOR_OPEN : DOOR) + doorFacing(id);
}

export function isGate(id: number): boolean {
  return id === GATE || id === GATE_OPEN;
}

export function isGateOpen(id: number): boolean {
  return id === GATE_OPEN;
}

export function isCandle(id: number): boolean {
  return id === CANDLE || id === CANDLE_LIT;
}

export function isCandleLit(id: number): boolean {
  return id === CANDLE_LIT;
}

export function isVase(id: number): boolean {
  return id === MARBLE_VASE || (id >= VASE_LILY && id <= VASE_TOMATO + 7);
}

/** The single flower or crop inside a pot. AIR if the pot is empty. */
export function vasePlant(id: number): number {
  if (id === VASE_LILY) return GARDEN_LILY;
  if (id === VASE_IRIS) return GARDEN_IRIS;
  if (id >= VASE_URUCUM && id < VASE_URUCUM + 8) return URUCUM + (id - VASE_URUCUM);
  if (id >= VASE_CAMAPU && id < VASE_CAMAPU + 8) return CAMAPU + (id - VASE_CAMAPU);
  if (id >= VASE_TOMATO && id < VASE_TOMATO + 8) return TOMATO + (id - VASE_TOMATO);
  return AIR;
}

/** Pot id that holds this flower, crop stage, or nothing. */
export function vaseWith(plant: number): number {
  if (plant === GARDEN_LILY) return VASE_LILY;
  if (plant === GARDEN_IRIS) return VASE_IRIS;
  if (isUrucum(plant)) return VASE_URUCUM + cropStage(plant);
  if (isCamapu(plant)) return VASE_CAMAPU + cropStage(plant);
  if (isTomato(plant)) return VASE_TOMATO + cropStage(plant);
  return MARBLE_VASE;
}

/** What a held item becomes when planted in an empty pot. 0 if it does not fit. */
export function vaseFromItem(id: number): number {
  if (id === GARDEN_LILY || id === GARDEN_IRIS || isCrop(id)) return vaseWith(id);
  if (id === FOOD_URUCUM) return vaseWith(URUCUM);
  if (id === FOOD_CAMAPU) return vaseWith(CAMAPU);
  if (id === FOOD_TOMATO) return vaseWith(TOMATO);
  return 0;
}

/** Flower, or ripe crop food, taken out of a pot. AIR if it should stay inside. */
export function vaseYield(id: number): number {
  const plant = vasePlant(id);
  if (isGardenFlower(plant)) return plant;
  if (isRipeCrop(plant)) return cropFood(plant);
  return AIR;
}

export function isPeach(id: number): boolean {
  return id === PEACH;
}

export function isItemOnly(id: number): boolean {
  return id === MELON_SLICE || isFood(id) || id === STICK || id === SHOVEL;
}

export function isCarpet(id: number): boolean {
  return id === RED_CARPET || isGrassCarpet(id) || isCerradoCarpet(id) || id === VARZEA_CARPET || id === MARBLE_CARPET || id === CAATINGA_CARPET || id === BREJO_CARPET || id === ASH_CARPET;
}

export function isGrassCarpet(id: number): boolean {
  return id === GRASS_CARPET || id === GRASS_CARPET_WET;
}

export function isCerradoCarpet(id: number): boolean {
  return id === CERRADO_CARPET || id === CERRADO_CARPET_WET;
}

export function isFloorCarpet(id: number): boolean {
  return isGrassCarpet(id) || isCerradoCarpet(id) || id === VARZEA_CARPET || id === MARBLE_CARPET || id === CAATINGA_CARPET || id === BREJO_CARPET || id === ASH_CARPET;
}

export function canSupportCarpet(id: number): boolean {
  return isSolid(id);
}

export function isSolid(id: number): boolean {
  return id !== AIR && !isFluid(id) && !isPlant(id) && !isCarpet(id) && !isItemOnly(id) && !isDoor(id) && !isGate(id) && !isCandle(id) && !isVase(id) && !isPeach(id);
}

export function isOpaque(id: number): boolean {
  return isSolid(id) && !isLeaves(id) && id !== FENCE && id !== COMODA && id !== CAATINGA_CACTUS && id !== SPIKE_BALL;
}

export function isTarget(id: number): boolean {
  return isSolid(id) || isPlant(id) || isCarpet(id) || isDoor(id) || isGate(id) || isCandle(id) || isVase(id) || isPeach(id);
}

export function weedModelHeight(id: number): number {
  if (id === WEED_TALL) return 2;
  if (id === WEED_BEACH) return 0.95;
  if (id === WEED_MACAMBIRA) return 0.55;
  if (id === WEED_DROOP) return 0.62;
  if (id === WEED_LICHEN) return 0.38;
  if (id === WEED_EMBER) return 0.7;
  return 1;
}

/** Aim box in world space. Short weeds match the cross; tall stays two blocks. Riccia stays its own small patch. */
export function aimBox(
  id: number,
  x: number,
  y: number,
  z: number,
  below: number,
): { x0: number; y0: number; z0: number; x1: number; y1: number; z1: number } | null {
  if (isCandle(id)) {
    return { x0: x + 0.42, y0: y, z0: z + 0.42, x1: x + 0.58, y1: y + 0.5, z1: z + 0.58 };
  }
  if (isVase(id)) {
    return { x0: x + 0.12, y0: y, z0: z + 0.12, x1: x + 0.88, y1: y + 1.7, z1: z + 0.88 };
  }
  if (isPeach(id)) {
    return { x0: x + 0.33, y0: y + 0.74, z0: z + 0.33, x1: x + 0.67, y1: y + 1.15, z1: z + 0.67 };
  }
  if (id === COMODA) {
    return { x0: x + 0.1, y0: y, z0: z + 0.18, x1: x + 0.9, y1: y + 0.7, z1: z + 0.82 };
  }
  if (isVine(id)) {
    const t = 1.5 / 16;
    const face = vineFace(id);
    if (face === 0) return { x0: x, y0: y, z0: z + 1 - t, x1: x + 1, y1: y + 1, z1: z + 1 };
    if (face === 1) return { x0: x, y0: y, z0: z, x1: x + 1, y1: y + 1, z1: z + t };
    if (face === 2) return { x0: x + 1 - t, y0: y, z0: z, x1: x + 1, y1: y + 1, z1: z + 1 };
    return { x0: x, y0: y, z0: z, x1: x + t, y1: y + 1, z1: z + 1 };
  }
  if (isRiccia(id)) {
    return { x0: x, y0: y, z0: z, x1: x + 1, y1: y + 0.72, z1: z + 1 };
  }
  if (isWeed(id)) {
    const y0 =
      isFloorCarpet(below) || below === AIR || (isFluid(below) && !isRiccia(below)) ? y - 1 + CARPET_H : y;
    const h = weedModelHeight(id);
    return { x0: x, y0, z0: z, x1: x + 1, y1: y0 + h, z1: z + 1 };
  }
  if (isGardenFlower(id)) {
    const y0 = isFloorCarpet(below) ? y - 1 + CARPET_H : y;
    return { x0: x + 0.28, y0, z0: z + 0.28, x1: x + 0.72, y1: y0 + 0.56, z1: z + 0.72 };
  }
  if (isCarpet(id)) {
    return { x0: x, y0: y, z0: z, x1: x + 1, y1: y + CARPET_H, z1: z + 1 };
  }
  return null;
}

export function collisionTop(id: number): number {
  if (id === SINK_PLAT) return 0;
  if (id === SPIKE_BALL) return 0.72;
  if (isVase(id)) return 1;
  if (isCarpet(id) || isLeaves(id) || isCandle(id) || isDoorOpen(id) || isGateOpen(id)) return 0;
  if (isDoor(id)) return 1;
  if (isGate(id)) return 2;
  if (id === COMODA) return 0.7;
  if (isSolid(id)) return 1;
  return 0;
}

export function isFluidReplaceable(id: number): boolean {
  return id === AIR || (isCarpet(id) && !isFloorCarpet(id)) || (isPlant(id) && !isRiccia(id));
}

export function isBreakable(id: number): boolean {
  return id !== AIR && id !== BEDROCK && (!isFluid(id) || isRiccia(id) || isGrassCarpet(id) || isCerradoCarpet(id));
}

export function hardness(id: number): number {
  if (isVase(id)) return 0.35;
  switch (id) {
    case RED_CARPET:
    case GRASS_CARPET:
    case GRASS_CARPET_WET:
    case CERRADO_CARPET:
    case CERRADO_CARPET_WET:
    case VARZEA_CARPET:
    case MARBLE_CARPET:
    case CAATINGA_CARPET:
    case BREJO_CARPET:
    case ASH_CARPET:
      return 0.08;
    case CANDLE:
    case CANDLE_LIT:
      return 0.05;
    case PEACH:
      return 0.12;
    case LEAVES:
    case BIRCH_LEAVES:
    case DARK_LEAVES:
    case ARAU_LEAVES:
    case CERRADO_LEAVES:
    case APPLE_LEAVES:
    case PALM_LEAVES:
    case PEACH_LEAVES:
    case CAATINGA_LEAVES:
    case ASH_LEAVES:
      return 0.18;
    case GRASS:
    case GRASS_FULL:
    case DIRT:
    case SAND:
    case FARMLAND:
    case CERRADO_GRASS:
    case CERRADO_DIRT:
    case VARZEA_GRASS:
    case MARBLE_GRASS:
    case MARBLE_GRASS_FULL:
    case MUD:
    case SINK_PLAT:
    case CAATINGA_GRASS:
    case CAATINGA_GRASS_FULL:
    case CAATINGA_DIRT:
    case BREJO_GRASS:
    case BREJO_GRASS_FULL:
    case BREJO_DIRT:
    case ASH_GRASS:
    case ASH_GRASS_FULL:
    case ASH_DIRT:
      return 0.28;
    case LOG:
    case BIRCH_LOG:
    case DARK_LOG:
    case ARAU_LOG:
    case CAATINGA_LOG:
    case ASH_LOG:
    case PLANKS:
    case CRAFTING_TABLE:
    case FENCE:
      return 0.45;
    case MELON:
      return 0.55;
    case STONE:
    case CRACKED_STONE:
    case AQUIFER:
    case MARBLE:
    case MARBLE_BRICK:
    case MARBLE_BROKEN:
    case MARBLE_ORANGE:
    case MARBLE_PURPLE:
    case MARBLE_BLUE:
    case GREEN_BRICK:
    case RUST_METAL:
    case WALL_STATUE:
    case SPIKE_BALL:
    case MONUMENT_BASE:
    case MONUMENT_SHAFT:
    case MONUMENT_CROWN:
    case CAATINGA_ROCK:
    case ASH_ROCK:
    case FALL_TRAP:
      return 0.75;
    default:
      if (isDoor(id)) return 0.45;
      if (id === PATH) return 0.28;
      if (isVine(id)) return 0.2;
      if (id === CAATINGA_CACTUS) return 0.35;
      if (isPlant(id)) return 0.08;
      return 1;
  }
}

/** Binomial 3 tries at p=(age+1)/15 — caules de melancia/melão. */
export function stemSeedDrops(age: number): number {
  const a = Math.max(0, Math.min(7, age));
  const p = (a + 1) / 15;
  let n = 0;
  for (let i = 0; i < 3; i++) if (Math.random() < p) n++;
  return n;
}

export function dropsFrom(id: number): { id: number; n: number }[] {
  if (id === MELON) {
    const n = 3 + ((Math.random() * 5) | 0);
    return [{ id: MELON_SLICE, n }];
  }
  if (isRiccia(id)) return [{ id: RICCIA, n: 1 }];
  if (isCerradoCarpet(id)) return [{ id: CERRADO_CARPET, n: 1 }];
  if (id === VARZEA_CARPET) return [{ id: VARZEA_CARPET, n: 1 }];
  if (isGrassCarpet(id)) return [{ id: GRASS_CARPET, n: 1 }];
  if (isWeed(id)) return [{ id, n: 1 }];
  if (isVine(id)) return [{ id, n: 1 }];
  if (isGardenFlower(id)) return [{ id, n: 1 }];
  if (isRipeCrop(id)) {
    const food = cropFood(id);
    return [{ id: food, n: 1 + ((Math.random() * 2) | 0) }];
  }
  if (isCrop(id)) return [];
  if (isPlant(id)) {
    const age = isMelonAttach(id) ? 7 : stemStage(id);
    const n = stemSeedDrops(age);
    return n > 0 ? [{ id: MELON_SEEDS, n }] : [];
  }
  const d = dropOf(id);
  return d === AIR ? [] : [{ id: d, n: 1 }];
}

export function dropOf(id: number): number {
  if (id === GRASS) return DIRT;
  if (id === CERRADO_GRASS) return CERRADO_DIRT;
  if (id === VARZEA_GRASS) return DIRT;
  if (id === MARBLE_GRASS) return MARBLE;
  if (id === CAATINGA_GRASS) return CAATINGA_DIRT;
  if (id === BREJO_GRASS) return BREJO_DIRT;
  if (id === ASH_GRASS) return ASH_DIRT;
  if (id === MARBLE_GRASS_FULL) return MARBLE_GRASS_FULL;
  if (id === MARBLE_CARPET) return MARBLE_CARPET;
  if (id === FARMLAND) return DIRT;
  if (isRiccia(id)) return RICCIA;
  if (isCerradoCarpet(id)) return CERRADO_CARPET;
  if (id === VARZEA_CARPET) return VARZEA_CARPET;
  if (isGrassCarpet(id)) return GRASS_CARPET;
  if (isWeed(id)) return id;
  if (isVine(id)) return id;
  if (isGardenFlower(id)) return id;
  if (isRipeCrop(id)) return cropFood(id);
  if (isCrop(id)) return AIR;
  if (isPlant(id)) return MELON_SEEDS;
  if (isDoor(id)) return DOOR + doorFacing(id);
  if (isGate(id)) return GATE;
  if (id === CANDLE_LIT) return CANDLE;
  if (id === PEACH) return FOOD_PEACH;
  if (id === BEDROCK || id === AIR || isFluid(id)) return AIR;
  return id;
}

/** Atlas tile index per face: 0=+Y, 1=-Y, 2=+X, 3=-X, 4=+Z, 5=-Z */
export function faceTile(id: number, face: number): number {
  switch (id) {
    case GRASS:
      if (face === 0) return 0;
      if (face === 1) return 2;
      return 1;
    case GRASS_FULL:
      return 0;
    case DIRT:
      return 2;
    case STONE:
      return 3;
    case LOG:
      return face === 0 || face === 1 ? 5 : 4;
    case LEAVES:
      return 6;
    case PLANKS:
      return 7;
    case SAND:
      return 8;
    case BEDROCK:
      return 9;
    case FARMLAND:
      return face === 0 ? 12 : 2;
    case MELON:
      return face === 0 || face === 1 ? 11 : 10;
    case BIRCH_LOG:
      return face === 0 || face === 1 ? 14 : 13;
    case BIRCH_LEAVES:
      return 6;
    case DARK_LOG:
      return face === 0 || face === 1 ? 16 : 15;
    case DARK_LEAVES:
      return 6;
    case RED_CARPET:
      return 17;
    case GRASS_CARPET:
    case GRASS_CARPET_WET:
      return 0;
    case CRACKED_STONE:
      return 18;
    case AQUIFER:
      return 26;
    case ARAU_LOG:
      return face === 0 || face === 1 ? 20 : 19;
    case ARAU_LEAVES:
      return 6;
    case CERRADO_GRASS:
      if (face === 0) return 21;
      if (face === 1) return 23;
      return 22;
    case CERRADO_DIRT:
      return 23;
    case CERRADO_CARPET:
    case CERRADO_CARPET_WET:
      return 21;
    case CERRADO_LEAVES:
      return 6;
    case VARZEA_GRASS:
      if (face === 0) return 24;
      if (face === 1) return 2;
      return 25;
    case VARZEA_CARPET:
      return 24;
    case MARBLE:
      return 27;
    case MARBLE_VASE:
      return 35;
    case MARBLE_BRICK:
      return 34;
    case MARBLE_BROKEN:
      return 33;
    case MARBLE_GRASS:
      if (face === 0) return 28;
      if (face === 1) return 27;
      return 30;
    case MARBLE_GRASS_FULL:
    case MARBLE_CARPET:
      return 28;
    case MUD:
      return 29;
    case MARBLE_ORANGE:
      return 31;
    case MARBLE_PURPLE:
      return 32;
    case MARBLE_BLUE:
      return 47;
    case GREEN_BRICK:
      return 48;
    case SINK_PLAT:
      return face === 0 ? 28 : 48;
    case RUST_METAL:
      return 49;
    case MONUMENT_BASE:
      return 43;
    case MONUMENT_SHAFT:
      return 44;
    case MONUMENT_CROWN:
      return 45;
    case CAATINGA_GRASS:
      if (face === 0) return 36;
      if (face === 1) return 37;
      return 38;
    case CAATINGA_GRASS_FULL:
    case CAATINGA_CARPET:
      return 36;
    case CAATINGA_DIRT:
      return 37;
    case BREJO_GRASS:
      if (face === 0) return 50;
      if (face === 1) return 51;
      return 52;
    case BREJO_GRASS_FULL:
    case BREJO_CARPET:
      return 50;
    case BREJO_DIRT:
      return 51;
    case ASH_GRASS:
      if (face === 0) return 53;
      if (face === 1) return 54;
      return 55;
    case ASH_GRASS_FULL:
    case ASH_CARPET:
      return 53;
    case ASH_DIRT:
      return 54;
    case ASH_ROCK:
      return 56;
    case ASH_LOG:
      return face === 0 || face === 1 ? 58 : 57;
    case CAATINGA_ROCK:
      return 39;
    case CAATINGA_CACTUS:
      return 40;
    case CAATINGA_LOG:
      return face === 0 || face === 1 ? 42 : 41;
    case CRAFTING_TABLE:
      return face === 0 ? 5 : 7;
    case FENCE:
      return 7;
    case PATH:
      return face === 0 ? 8 : 2;
    default:
      if (isDoor(id) || isVase(id)) return isVase(id) ? 35 : 7;
      return 2;
  }
}

export function leafAtlasTile(id: number): number {
  if (id === BIRCH_LEAVES) return 1;
  if (id === DARK_LEAVES) return 2;
  if (id === ARAU_LEAVES) return 3;
  if (id === CERRADO_LEAVES) return 4;
  if (id === APPLE_LEAVES) return 5;
  if (id === PALM_LEAVES) return 6;
  if (id === PEACH_LEAVES) return 7;
  if (id === CAATINGA_LEAVES) return 8;
  if (id === ASH_LEAVES) return 9;
  return 0;
}
