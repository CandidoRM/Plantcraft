import { useEffect, useRef, useState } from "react";

type Stamp = {
  id: string;
  name: string;
  color: string;
  ink: string;
};

const STAMPS: Stamp[] = [
  { id: "casa", name: "Casa", color: "#c4a574", ink: "#2a1c12" },
  { id: "melao", name: "Melão", color: "#7fbf4a", ink: "#14240c" },
  { id: "tomate", name: "Tomate", color: "#d4533a", ink: "#2a100c" },
  { id: "urucum", name: "Urucum", color: "#c4482a", ink: "#2a100c" },
  { id: "camapu", name: "Camapu", color: "#e39a3a", ink: "#2a1c08" },
  { id: "portao", name: "Portão", color: "#8d6a3a", ink: "#1c140c" },
  { id: "aldeao", name: "Aldeão", color: "#d8c4a0", ink: "#24180e" },
  { id: "agua", name: "Água", color: "#3c8f9a", ink: "#062024" },
  { id: "vala", name: "Vala", color: "#5c4632", ink: "#1a120c" },
];

const COLS = 16;
const ROWS = 10;
const STORE = "plantcraft-test-lab";
const PICK = "plantcraft-mud-choice";
const MUD_S = 32;
const MUD_PX = 4;
const MUD_W = MUD_S * MUD_PX;
const CELL_W = 42;
const CELL_H = 54;
const TW = CELL_W * 4;
const TH = CELL_H * 2;

type Board = {
  cells: (string | null)[];
  note: string;
  tool: string;
};

type Concept = {
  id: string;
  name: string;
  note: string;
  paint: (ctx: CanvasRenderingContext2D) => void;
};

type Ripe = "red" | "green" | "orange" | "pale";
type Style = "moita" | "estaca" | "trelica" | "rasteira" | "cereja" | "cacho" | "misto" | "folha";

function dot(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, w = 1, h = 1) {
  if (w < 0) {
    x += w;
    w = -w;
  }
  if (h < 0) {
    y += h;
    h = -h;
  }
  ctx.fillStyle = color;
  ctx.fillRect(x | 0, y | 0, w, h);
}

function disc(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, fill: string, hi: string, shade: string) {
  for (let y = -r; y <= r; y++) {
    for (let x = -r; x <= r; x++) {
      if (x * x + y * y > r * r + 0.2) continue;
      const color = x > r * 0.35 && y > 0 ? shade : x < 0 && y < r * 0.4 ? hi : fill;
      dot(ctx, cx + x, cy + y, color);
    }
  }
}

function calyx(ctx: CanvasRenderingContext2D, x: number, y: number) {
  dot(ctx, x, y, "#1e5018");
  dot(ctx, x - 1, y, "#2f7a22");
  dot(ctx, x + 1, y, "#2f7a22");
  dot(ctx, x, y - 1, "#57a83c");
  dot(ctx, x - 1, y - 1, "#2f7a22");
  dot(ctx, x + 1, y - 1, "#2f7a22");
}

function fruit(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, ripe: Ripe) {
  const fill = ripe === "red" ? "#d23b28" : ripe === "orange" ? "#e07a28" : ripe === "pale" ? "#a8cc6c" : "#6aaa32";
  const hi = ripe === "red" ? "#f4a090" : ripe === "orange" ? "#f6c98a" : ripe === "pale" ? "#d6e89c" : "#d4f09a";
  const shade = ripe === "red" ? "#8a1c14" : ripe === "orange" ? "#9a4814" : ripe === "pale" ? "#608c3a" : "#3a641c";
  if (r <= 1) {
    dot(ctx, x, y, fill);
    dot(ctx, x, y - 1, "#2f7a22");
    return;
  }
  disc(ctx, x, y, r, fill, hi, shade);
  calyx(ctx, x, y - r);
}

function digit(ctx: CanvasRenderingContext2D, x: number, y: number, n: number) {
  const g: Record<number, string[]> = {
    1: ["010", "110", "010", "010", "011"],
    2: ["111", "001", "111", "100", "111"],
    3: ["111", "001", "111", "001", "111"],
    4: ["101", "101", "111", "001", "001"],
    5: ["111", "100", "111", "001", "111"],
    6: ["111", "100", "111", "101", "111"],
    7: ["111", "001", "010", "010", "010"],
    8: ["111", "101", "111", "101", "111"],
  };
  const rows = g[n] ?? g[1]!;
  for (let j = 0; j < rows.length; j++) {
    for (let i = 0; i < 3; i++) if (rows[j]![i] === "1") dot(ctx, x + i, y + j, "#1c140c");
  }
}

function compoundLeaf(ctx: CanvasRenderingContext2D, x: number, y: number, dir: 1 | -1, tier: 0 | 1 | 2) {
  const dark = "#245c1c";
  const mid = "#3c8a2c";
  const lite = "#7cc454";
  const n = tier === 0 ? 2 : tier === 1 ? 3 : 5;
  for (let i = 0; i <= n; i++) dot(ctx, x + dir * i, y, i === 0 ? dark : mid);
  for (let i = 1; i <= n; i++) {
    const lx = x + dir * i;
    dot(ctx, lx, y - 1, mid);
    dot(ctx, lx + dir, y - 2, lite);
    dot(ctx, lx + dir, y - 1, dark);
    dot(ctx, lx, y + 1, mid);
    dot(ctx, lx + dir, y + 2, lite);
    dot(ctx, lx + dir, y + 1, dark);
    if (tier === 2 && i % 2 === 0) {
      dot(ctx, lx + dir * 2, y - 2, lite);
      dot(ctx, lx + dir * 2, y + 2, mid);
    }
  }
  dot(ctx, x + dir * (n + 1), y, lite);
  dot(ctx, x + dir * (n + 1), y - 1, mid);
}

function flower(ctx: CanvasRenderingContext2D, x: number, y: number) {
  dot(ctx, x, y, "#f4e25a");
  dot(ctx, x - 1, y, "#e2c23a");
  dot(ctx, x + 1, y, "#e2c23a");
  dot(ctx, x, y - 1, "#fff6b0");
  dot(ctx, x, y + 1, "#c89820");
}

function stem(ctx: CanvasRenderingContext2D, x: number, top: number, bot: number) {
  for (let y = top; y <= bot; y++) {
    dot(ctx, x, y, y % 2 === 0 ? "#2f7424" : "#245c1c");
    if (y % 3 === 0) dot(ctx, x + 1, y, "#4ea338");
  }
}

function stake(ctx: CanvasRenderingContext2D, x: number, top: number, bot: number) {
  for (let y = top; y <= bot; y++) {
    dot(ctx, x, y, y % 5 === 0 ? "#a07848" : "#6b4328");
    dot(ctx, x + 1, y, "#4a2e18");
  }
}

function cellBg(ctx: CanvasRenderingContext2D, ox: number, oy: number) {
  ctx.fillStyle = "#9ec8ee";
  ctx.fillRect(ox, oy, CELL_W, CELL_H);
  ctx.fillStyle = "#5c9a3c";
  ctx.fillRect(ox, oy + 40, CELL_W, CELL_H - 40);
  ctx.fillStyle = "#6b4424";
  ctx.fillRect(ox + 1, oy + 41, CELL_W - 2, 11);
  ctx.fillStyle = "#4a2c16";
  ctx.fillRect(ox + 1, oy + 41, CELL_W - 2, 2);
  ctx.fillStyle = "#8d5c34";
  ctx.fillRect(ox + 6, oy + 45, 1, 6);
  ctx.fillRect(ox + 16, oy + 45, 1, 6);
  ctx.fillRect(ox + 28, oy + 45, 1, 6);
}

function grow(ctx: CanvasRenderingContext2D, cx: number, base: number, stage: number, style: Style) {
  if (stage <= 0) {
    stem(ctx, cx, base - 4, base);
    dot(ctx, cx - 2, base - 4, "#7cc454", 2, 2);
    dot(ctx, cx + 1, base - 4, "#4ea338", 2, 2);
    return;
  }

  const low = style === "rasteira";
  const tall = style === "cereja" || style === "trelica";
  const h = low ? 5 + stage * 2 : tall ? 8 + stage * 4 : 7 + stage * 3;
  const top = base - h;
  const tier: 0 | 1 | 2 = stage < 3 ? 0 : stage < 5 ? 1 : 2;

  if (style === "estaca" && stage >= 2) stake(ctx, cx + 3, top - 1, base);
  if (style === "trelica" && stage >= 3) {
    stake(ctx, cx - 8, top, base);
    stake(ctx, cx + 8, top + 2, base);
    dot(ctx, cx - 8, top + 3, "#e4d2a4", 17, 1);
    if (stage >= 5) dot(ctx, cx - 8, top + 8, "#c4a06a", 17, 1);
  }

  stem(ctx, cx, top, base);

  const leafCount = 1 + Math.min(4, stage);
  for (let i = 0; i < leafCount; i++) {
    const y = Math.min(base - 2, top + 2 + i * (low ? 2 : 3));
    const dir: 1 | -1 = i % 2 === 0 ? -1 : 1;
    const leafTier: 0 | 1 | 2 = style === "folha" && stage >= 4 ? 2 : tier;
    compoundLeaf(ctx, cx, y, dir, leafTier);
    if (style === "folha" && stage >= 5 && i === leafCount - 1) compoundLeaf(ctx, cx, y + 2, dir === 1 ? -1 : 1, 2);
  }

  if (low && stage >= 2) {
    const reach = 3 + stage;
    dot(ctx, cx - reach, base - 1, "#2f7424", reach * 2, 1);
    compoundLeaf(ctx, cx - 2, base - 2, -1, stage >= 5 ? 1 : 0);
    compoundLeaf(ctx, cx + 1, base - 2, 1, stage >= 5 ? 1 : 0);
  }

  if (stage === 2 || stage === 3) flower(ctx, cx + (stage === 2 ? -2 : 2), top + 1);
  if (stage === 3 && style !== "cereja") flower(ctx, cx - 3, top + 4);

  if (stage < 4) return;

  const ripe: Ripe = stage >= 7 ? "red" : stage === 6 ? "orange" : "green";
  if (style === "moita") {
    fruit(ctx, cx - 4, base - 6, stage >= 6 ? 3 : 2, ripe);
    if (stage >= 5) fruit(ctx, cx + 4, base - 8, stage >= 7 ? 3 : 2, ripe);
  } else if (style === "estaca") {
    fruit(ctx, cx - 5, top + 8, stage >= 6 ? 3 : 2, ripe);
    if (stage >= 5) fruit(ctx, cx + 6, top + 14, 2, ripe);
  } else if (style === "trelica") {
    fruit(ctx, cx - 3, top + 8, stage >= 6 ? 3 : 2, ripe);
    if (stage >= 5) fruit(ctx, cx + 4, top + 12, 2, stage >= 7 ? "red" : "green");
  } else if (style === "rasteira") {
    fruit(ctx, cx - 5, base - 2, stage >= 6 ? 3 : 2, ripe);
    if (stage >= 6) fruit(ctx, cx + 6, base - 2, 2, ripe);
  } else if (style === "cereja") {
    const spots: [number, number][] = [
      [-3, 4],
      [3, 7],
      [-2, 11],
      [3, 14],
      [0, 18],
      [-4, 16],
    ];
    const n = 2 + (stage - 4) * 1;
    for (let i = 0; i < n && i < spots.length; i++) {
      const [dx, dy] = spots[i]!;
      fruit(ctx, cx + dx, top + dy, 1, stage >= 7 || i < stage - 5 ? "red" : "green");
    }
  } else if (style === "cacho") {
    const bunch: Ripe = stage === 6 ? "pale" : ripe;
    fruit(ctx, cx - 3, top + 8, stage >= 6 ? 3 : 2, bunch);
    fruit(ctx, cx + 2, top + 9, stage >= 6 ? 3 : 2, bunch);
    if (stage >= 5) fruit(ctx, cx, top + 13, stage >= 7 ? 3 : 2, bunch);
    if (stage >= 7) fruit(ctx, cx + 4, top + 14, 2, "red");
  } else if (style === "misto") {
    fruit(ctx, cx - 4, top + 8, 2, "green");
    if (stage >= 5) fruit(ctx, cx + 4, top + 12, 2, stage >= 6 ? "orange" : "green");
    if (stage >= 6) fruit(ctx, cx, top + 16, stage >= 7 ? 3 : 2, "red");
  } else {
    fruit(ctx, cx + 2, base - 8, stage >= 7 ? 4 : 3, ripe);
    if (stage >= 6) compoundLeaf(ctx, cx, base - 10, -1, 2);
  }
}

function paintStyle(style: Style): (ctx: CanvasRenderingContext2D) => void {
  return (ctx) => {
    ctx.clearRect(0, 0, TW, TH);
    for (let s = 0; s < 8; s++) {
      const col = s % 4;
      const row = (s / 4) | 0;
      const ox = col * CELL_W;
      const oy = row * CELL_H;
      cellBg(ctx, ox, oy);
      grow(ctx, ox + ((CELL_W / 2) | 0), oy + 41, s, style);
      digit(ctx, ox + 2, oy + 2, s + 1);
    }
  };
}

function mudHash(x: number, y: number, s: number) {
  const n = Math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

function mudRgb(r: number, g: number, b: number) {
  const c = (n: number) => Math.max(0, Math.min(255, n | 0));
  return `rgb(${c(r)},${c(g)},${c(b)})`;
}

function paintMudConcept(style: number) {
  return (ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, MUD_W, MUD_W);
    const dark = [48, 34, 20];
    const base = [92, 70, 42];
    const light = [132, 100, 64];
    const foam = [196, 168, 122];
    const rust = [168, 84, 36];
    const deep = [28, 18, 12];
    for (let y = 0; y < MUD_S; y++) {
      for (let x = 0; x < MUD_S; x++) {
        const n = mudHash(x, y, style + 5);
        const n2 = mudHash((x / 4) | 0, (y / 4) | 0, style + 17);
        let r = base[0];
        let g = base[1];
        let b = base[2];
        if (style === 0) {
          r = base[0] + n2 * 14;
          g = base[1] + n2 * 8;
          b = base[2];
          const clump = n > 0.86 && mudHash(x + 1, y, 2) > 0.4;
          if (clump || (n > 0.93 && n2 > 0.5)) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          }
        } else if (style === 1) {
          const dx = x - 16;
          const dy = y - 16;
          const ang = Math.atan2(dy, dx);
          const dist = Math.hypot(dx, dy);
          const arm = Math.sin(ang * 3 + dist * 0.55) * 0.5 + 0.5;
          r = dark[0] + arm * 90;
          g = dark[1] + arm * 62;
          b = dark[2] + arm * 28;
        } else if (style === 2) {
          const row = (y / 6) | 0;
          const shift = (row % 2) * 4;
          const cx = ((x + shift) % 8) - 4;
          const cy = (y % 6) - 3;
          const arc = cy * cy + cx * cx;
          r = arc < 10 ? light[0] : base[0];
          g = arc < 10 ? light[1] : base[1];
          b = arc < 10 ? light[2] : base[2];
          if (cy === -2 && Math.abs(cx) < 3) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          }
        } else if (style === 3) {
          r = deep[0] + n2 * 40;
          g = deep[1] + n2 * 28;
          b = deep[2] + n2 * 12;
          const drop = n > 0.9;
          if (drop) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          } else if (n > 0.82 && y > 2 && mudHash(x, y - 2, 9) > 0.9) {
            r = light[0];
            g = light[1];
            b = light[2];
          }
        } else if (style === 4) {
          const dist = Math.hypot(x - 16, y - 16) / 22;
          const k = Math.max(0, Math.min(1, dist));
          r = deep[0] + (light[0] - deep[0]) * k;
          g = deep[1] + (light[1] - deep[1]) * k;
          b = deep[2] + (light[2] - deep[2]) * k;
          if (Math.abs(dist - 0.45) < 0.06 || Math.abs(dist - 0.75) < 0.05) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          }
        } else if (style === 5) {
          r = base[0] + n * 10;
          g = base[1];
          b = base[2] - 6;
          const stain = Math.sin(x * 0.4 + n2 * 2) * Math.sin(y * 0.35) > 0.35;
          if (stain) {
            r = rust[0];
            g = rust[1];
            b = rust[2];
          }
        } else if (style === 6) {
          r = deep[0] + n * 16;
          g = deep[1] + n * 10;
          b = deep[2];
          if (n2 > 0.62) {
            r = 168 + n * 20;
            g = 142 + n * 12;
            b = 102;
          }
        } else if (style === 7) {
          const a = (x + y) % 6 < 1;
          const c = (x - y + 32) % 6 < 1;
          if (a || c) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          } else {
            r = base[0] + n2 * 8;
            g = base[1];
            b = base[2];
          }
        } else if (style === 8) {
          r = base[0] + n2 * 12;
          g = base[1] + n2 * 8;
          b = base[2];
          const hit = x % 5 === (y % 3) && n > 0.45;
          if (hit) {
            r = foam[0];
            g = foam[1];
            b = foam[2];
          } else if (hit && y > 0) {
            r = light[0];
            g = light[1];
            b = light[2];
          }
          if (x % 5 === (y % 3) && y % 4 !== 0 && n > 0.2) {
            r = light[0];
            g = light[1];
            b = light[2];
          }
        } else {
          const tide = Math.sin(y * 0.35 + Math.sin(x * 0.2) * 2) * 0.5 + 0.5;
          const crest = tide > 0.72;
          r = crest ? foam[0] : dark[0] + tide * 70;
          g = crest ? foam[1] : dark[1] + tide * 48;
          b = crest ? foam[2] : dark[2] + tide * 22;
        }
        ctx.fillStyle = mudRgb(r, g, b);
        ctx.fillRect(x * MUD_PX, y * MUD_PX, MUD_PX, MUD_PX);
      }
    }
  };
}

const CONCEPTS: Concept[] = [
  {
    id: "espuma",
    name: "1. Espuma",
    note: "Pontos claros espalhados, como espuma suja na superfície.",
    paint: paintMudConcept(0),
  },
  {
    id: "redemoinho",
    name: "2. Redemoinho",
    note: "Três braços girando a partir do centro.",
    paint: paintMudConcept(1),
  },
  {
    id: "escama",
    name: "3. Escama",
    note: "Escamas de luz, fileira sim fileira não.",
    paint: paintMudConcept(2),
  },
  {
    id: "salpico",
    name: "4. Salpico",
    note: "Pingos claros com um rastro curto embaixo.",
    paint: paintMudConcept(3),
  },
  {
    id: "poco",
    name: "5. Poço",
    note: "Centro fundo e dois anéis de luz, como uma pedra na poça.",
    paint: paintMudConcept(4),
  },
  {
    id: "ferrugem",
    name: "6. Ferrugem",
    note: "Manchas laranja de ferrugem dentro do marrom.",
    paint: paintMudConcept(5),
  },
  {
    id: "nata",
    name: "7. Nata",
    note: "Placas claras boiando sobre a lama escura.",
    paint: paintMudConcept(6),
  },
  {
    id: "trama",
    name: "8. Trama",
    note: "Riscos cruzados, uma película esticada por cima.",
    paint: paintMudConcept(7),
  },
  {
    id: "chuva",
    name: "9. Chuva",
    note: "Risquinhos de gota batendo, superfície calma no resto.",
    paint: paintMudConcept(8),
  },
  {
    id: "mare",
    name: "10. Maré",
    note: "Ondas largas com crista clara. A mais parecida com água.",
    paint: paintMudConcept(9),
  },
];

function emptyBoard(): Board {
  return { cells: Array(COLS * ROWS).fill(null), note: "", tool: "casa" };
}

function loadBoard(): Board {
  try {
    const raw = sessionStorage.getItem(STORE);
    if (!raw) return emptyBoard();
    const data = JSON.parse(raw) as Partial<Board>;
    const cells = Array.isArray(data.cells) ? data.cells.slice(0, COLS * ROWS) : [];
    while (cells.length < COLS * ROWS) cells.push(null);
    return {
      cells: cells.map((id) => (STAMPS.some((s) => s.id === id) ? id : null)),
      note: typeof data.note === "string" ? data.note : "",
      tool: STAMPS.some((s) => s.id === data.tool) ? (data.tool as string) : "casa",
    };
  } catch {
    return emptyBoard();
  }
}

function Face({ paint }: { paint: (ctx: CanvasRenderingContext2D) => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    paint(ctx);
  }, [paint]);
  return (
    <canvas
      ref={ref}
      width={MUD_W}
      height={MUD_W}
      className="h-52 w-auto max-w-full border border-black/40 [image-rendering:pixelated]"
    />
  );
}

export function TestScreen() {
  const [board, setBoard] = useState<Board>(emptyBoard);
  const [ready, setReady] = useState(false);
  const [pick, setPick] = useState<string | null>(null);

  useEffect(() => {
    setBoard(loadBoard());
    const saved = sessionStorage.getItem(PICK);
    setPick(CONCEPTS.some((c) => c.id === saved) ? saved : null);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    sessionStorage.setItem(STORE, JSON.stringify(board));
  }, [board, ready]);

  useEffect(() => {
    if (!ready) return;
    if (pick) sessionStorage.setItem(PICK, pick);
  }, [pick, ready]);

  const stamp = STAMPS.find((s) => s.id === board.tool) ?? STAMPS[0]!;

  const paint = (index: number) => {
    setBoard((prev) => {
      const cells = prev.cells.slice();
      cells[index] = cells[index] === prev.tool ? null : prev.tool;
      return { ...prev, cells };
    });
  };

  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-ink text-cream">
      <header className="border-b border-line px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <p className="font-display text-xl tracking-tight">Tela de teste</p>
        <p className="text-xs text-muted">Dez conceitos novos da lama líquida. Nada disto entrou no jogo.</p>
      </header>

      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-auto p-4 lg:flex-row">
        <aside className="flex shrink-0 flex-col gap-3 lg:w-56">
          <p className="text-[11px] tracking-wide text-muted uppercase">Carimbo</p>
          <div className="flex flex-wrap gap-2">
            {STAMPS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setBoard((prev) => ({ ...prev, tool: item.id }))}
                className={`rounded-md border px-2.5 py-1 text-sm ${
                  board.tool === item.id ? "border-cream" : "border-line"
                }`}
                style={{ background: item.color, color: item.ink }}
              >
                {item.name}
              </button>
            ))}
          </div>
          <label className="mt-2 flex flex-col gap-1 text-xs text-muted">
            Nota do conceito
            <textarea
              value={board.note}
              onChange={(e) => setBoard((prev) => ({ ...prev, note: e.target.value }))}
              rows={5}
              placeholder="O que este teste está tentando ver?"
              className="resize-none rounded-md border border-line bg-soil px-2 py-2 text-sm text-cream outline-none"
            />
          </label>
          <button
            type="button"
            onClick={() => setBoard((prev) => ({ ...prev, cells: Array(COLS * ROWS).fill(null) }))}
            className="self-start rounded-md border border-line px-3 py-1.5 text-sm text-muted"
          >
            Limpar quadro
          </button>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
            {CONCEPTS.map((concept) => {
              const chosen = pick === concept.id;
              return (
                <button
                  key={concept.id}
                  type="button"
                  onClick={() => setPick(concept.id)}
                  className={`flex flex-col items-start gap-2 rounded-md border bg-soil p-3 text-left ${
                    chosen ? "border-cream" : "border-line"
                  }`}
                >
                  <Face paint={concept.paint} />
                  <span className="font-display text-base">{concept.name}</span>
                  <span className="text-xs leading-snug text-muted">{concept.note}</span>
                  {chosen ? <span className="text-[11px] tracking-wide text-leaf uppercase">Escolhido</span> : null}
                </button>
              );
            })}
          </div>

          <p className="mt-6 mb-2 text-xs text-muted">
            Quadro livre. Clique para marcar com {stamp.name}. Clique de novo para apagar.
          </p>
          <div
            className="grid w-full max-w-3xl gap-1"
            style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))` }}
          >
            {board.cells.map((id, index) => {
              const mark = STAMPS.find((s) => s.id === id);
              return (
                <button
                  key={index}
                  type="button"
                  onClick={() => paint(index)}
                  className="aspect-square rounded-sm border border-line/80"
                  style={{ background: mark ? mark.color : "#161410" }}
                  aria-label={mark ? mark.name : "vazio"}
                />
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
