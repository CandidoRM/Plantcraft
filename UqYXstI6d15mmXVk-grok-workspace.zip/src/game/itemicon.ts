import {
  BLOCK_COLOR,
  CANDLE,
  CANDLE_LIT,
  DOOR,
  FENCE,
  MELON_SEEDS,
  MELON_SLICE,
  SHOVEL,
  STICK,
  faceTile,
  isCarpet,
  isCandle,
  isDoor,
  isFood,
  isPlant,
  isVine,
  isWeed,
} from "./blocks";
import { tileImage } from "./textures";

const N = 16;

function sample(img: ImageData, u: number, v: number): [number, number, number, number] {
  const x = Math.max(0, Math.min(img.width - 1, ((u + 0.5) * img.width) / N | 0));
  const y = Math.max(0, Math.min(img.height - 1, ((v + 0.5) * img.height) / N | 0));
  const i = (y * img.width + x) * 4;
  return [img.data[i]!, img.data[i + 1]!, img.data[i + 2]!, img.data[i + 3]!];
}

function put(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  c: [number, number, number, number],
  shade: number,
) {
  const X = x | 0;
  const Y = y | 0;
  if (c[3] < 12 || X < 0 || Y < 0 || X >= 32 || Y >= 32) return;
  ctx.fillStyle = `rgb(${(c[0] * shade) | 0},${(c[1] * shade) | 0},${(c[2] * shade) | 0})`;
  ctx.fillRect(X, Y, 1, 1);
}

function solid(r: number, g: number, b: number): ImageData {
  const img = new ImageData(32, 32);
  for (let i = 0; i < img.data.length; i += 4) {
    img.data[i] = r;
    img.data[i + 1] = g;
    img.data[i + 2] = b;
    img.data[i + 3] = 255;
  }
  return img;
}

function hex(id: number): [number, number, number] {
  const h = BLOCK_COLOR[id] ?? "#8a8a8a";
  const n = Number.parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function drawIso(ctx: CanvasRenderingContext2D, top: ImageData, side: ImageData, front: ImageData) {
  for (let v = 0; v < N; v++) {
    for (let y = 0; y < N; y++) put(ctx, 16 - v, v + y + 1, sample(side, v, y), 0.62);
  }
  for (let u = 0; u < N; u++) {
    for (let y = 0; y < N; y++) put(ctx, 16 + u, u + y + 1, sample(front, u, y), 0.86);
  }
  for (let v = 0; v < N; v++) {
    for (let u = 0; u < N; u++) put(ctx, 16 + u - v, u + v, sample(top, u, v), 1);
  }
}

function sprite(ctx: CanvasRenderingContext2D, rows: string[], pal: Record<string, string>) {
  const h = rows.length;
  const w = rows[0]?.length ?? 0;
  const ox = (32 - w * 2) >> 1;
  const oy = (32 - h * 2) >> 1;
  for (let y = 0; y < h; y++) {
    const row = rows[y] ?? "";
    for (let x = 0; x < w; x++) {
      const ch = row[x];
      if (!ch || ch === "." || ch === " ") continue;
      ctx.fillStyle = pal[ch] ?? "#ffffff";
      ctx.fillRect(ox + x * 2, oy + y * 2, 2, 2);
    }
  }
}

function flatIcon(ctx: CanvasRenderingContext2D, id: number) {
  if (id === STICK) {
    sprite(ctx, [".....a", "....a.", "...a..", "..a...", ".a....", "a....."], { a: "#c4944a" });
    return;
  }
  if (id === SHOVEL) {
    sprite(
      ctx,
      ["..bbb.", ".bccb.", "..bbb.", "...a..", "...a..", "...a..", "...a.."],
      { a: "#c4944a", b: "#e6d2a4", c: "#f3e6c4" },
    );
    return;
  }
  if (id === MELON_SLICE) {
    sprite(ctx, ["..ggg.", ".grrrg", "grrrrg", "grrrrg", ".grrg.", "..g.."], { g: "#3d8a32", r: "#e24b4b" });
    return;
  }
  if (id === MELON_SEEDS) {
    sprite(ctx, ["..a.a.", ".a...a", "..a.a.", ".a..a.", "..a..."], { a: "#d8c48a" });
    return;
  }
  if (id === FENCE) {
    sprite(ctx, ["a.aa.a", "aaaaaa", "a.aa.a", "a.aa.a", "aaaaaa", "a.aa.a"], { a: "#c6a05a" });
    return;
  }
  if (id === CANDLE || id === CANDLE_LIT) {
    sprite(ctx, ["...y...", "..yyy..", "..www..", "..www..", "..www..", ".wwwww."], {
      w: "#f3ead0",
      y: "#f2c14a",
    });
    return;
  }
  if (isDoor(id)) {
    sprite(ctx, ["bbbbbb", "bwwwwb", "bwwwwb", "bbbbbb", "bbbbbb", "bbobbb", "bbbbbb"], {
      b: "#8a5a2a",
      w: "#d8ecf4",
      o: "#3a2a1c",
    });
    return;
  }
  if (isFood(id)) {
    const food: Record<number, [string[], Record<string, string>]> = {
      76: [["..yyyy", ".yyyyy", "yyyyy.", ".yy..."], { y: "#f2d24a", g: "#3d8a32" }],
      77: [[".gg...", "yyyyyy", "yyyyyy", ".yyyy."], { y: "#f0a030", g: "#3d8a32" }],
      78: [[".ggg..", "ggggg.", "ggdgg.", ".gggg.", "..gg.."], { g: "#4e7a32", d: "#c4a05a" }],
      79: [["..g...", ".oooo.", "oooooo", ".oooo."], { o: "#ef8a1a", g: "#3d8a32" }],
      80: [[".gggg.", "yyyyyy", "yyyyyy", "yyyyyy"], { y: "#e6c44a", g: "#2f7a28" }],
      81: [[".wwww.", "wbbbbw", "bbbbbb", ".bbbb."], { w: "#f3efe2", b: "#6a4a2a" }],
      82: [["bbbbbb", "pppppp", "ppdppp", ".pppp."], { b: "#2a1a14", p: "#6a2878", d: "#c4a05a" }],
      83: [["..aaa.", ".aaaaa", "aaaaaa", ".aaaa."], { a: "#c8b48a" }],
      84: [["..aaa.", ".aaaaa", "aabaaa", ".aaaa."], { a: "#e6d2a4", b: "#f7f0dc" }],
      85: [["gggggg", "yyyyyy", "yyyyyy", "yyyyyy"], { y: "#f2e15a", g: "#5a9a32" }],
      86: [["wwwwww", "wwdwww", "wwwwww", ".wwww."], { w: "#f7f3ea", d: "#e6dcc8" }],
      87: [[".ggg..", "gyyyyg", "gyyyyg", ".gggg."], { g: "#6a9a32", y: "#d4e07a" }],
      116: [[".gggg.", "grrrrg", "grrrrg", ".gggg."], { g: "#3e8a34", r: "#c4482a" }],
      117: [["..g...", ".oooo.", "oooooo", ".oooo."], { g: "#3e8a34", o: "#e39a3a" }],
      132: [["..g...", ".rrrr.", "rrrrrr", ".rrrr."], { g: "#3e8a34", r: "#d63a2a" }],
      158: [["..g...", ".oooo.", "oooooo", "ooodoo", ".oooo."], { g: "#3e8a34", o: "#f0a070", d: "#e07058" }],
    };
    const spec = food[id];
    if (spec) {
      sprite(ctx, spec[0], spec[1]);
      return;
    }
  }
  if (isCarpet(id) || isWeed(id) || isPlant(id) || isVine(id) || id === 48) {
    const [r, g, b] = hex(id);
    const col = `rgb(${r},${g},${b})`;
    const dark = `rgb(${(r * 0.6) | 0},${(g * 0.6) | 0},${(b * 0.6) | 0})`;
    if (isCarpet(id)) {
      sprite(ctx, ["cccccccc", "cccccccc"], { c: col });
      return;
    }
    sprite(ctx, ["...d.c.", "..d.c..", ".d.c.d.", "d.c.d..", ".d.c...", "d.c...."], { c: col, d: dark });
    return;
  }
  const [r, g, b] = hex(id);
  drawIso(ctx, solid(r, g, b), solid((r * 0.7) | 0, (g * 0.7) | 0, (b * 0.7) | 0), solid(r, g, b));
}

function isFlat(id: number): boolean {
  return isFood(id) || id === STICK || id === SHOVEL || id === MELON_SEEDS || id === MELON_SLICE || id === FENCE || isDoor(id) || isCandle(id) || isCarpet(id) || isWeed(id) || isPlant(id) || isVine(id) || id === 48;
}

export function paintItem(canvas: HTMLCanvasElement, id: number) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = false;
  if (isFlat(id)) {
    flatIcon(ctx, id);
    return;
  }
  if (id === 9 || (id >= 10 && id <= 17)) {
    const top = solid(90, 170, 190);
    const side = solid(40, 110, 140);
    drawIso(ctx, top, side, solid(70, 150, 176));
    return;
  }
  if (id === 33 || (id >= 34 && id <= 41)) {
    drawIso(ctx, solid(70, 100, 48), solid(36, 60, 24), solid(58, 90, 40));
    return;
  }
  drawIso(ctx, tileImage(faceTile(id, 0)), tileImage(faceTile(id, 3)), tileImage(faceTile(id, 2)));
}
