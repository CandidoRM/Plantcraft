export type Actions = {
  moveX: number;
  moveY: number;
  jump: boolean;
  jumpHeld: boolean;
  crouch: boolean;
  sprint: boolean;
  break: boolean;
  place: boolean;
  useHeld: boolean;
  punch: boolean;
  lookX: number;
  lookY: number;
  slot: number | null;
  hover: boolean;
  gills: boolean;
  quake: boolean;
  cam: boolean;
};

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "ControlLeft",
  "ControlRight",
  "KeyC",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "F1",
  "F2",
  "F3",
  "F6",
]);

function radial(x: number, y: number, dz = 0.15): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Input {
  physical = new Set<string>();
  injected: Set<string> | null = null;
  lookAccX = 0;
  lookAccY = 0;
  touchMoveX = 0;
  touchMoveY = 0;
  touchLookX = 0;
  touchLookY = 0;
  touchJump = false;
  touchBreak = false;
  touchPlace = false;
  mouseBreak = false;
  mousePlace = false;
  mousePunch = false;
  slotPress: number | null = null;
  enabled = true;

  private prevBreak = false;
  private prevPlace = false;
  private prevJump = false;
  private prevHover = false;
  private prevGills = false;
  private prevQuake = false;
  private prevCam = false;

  attach(target: HTMLElement) {
    const down = (e: KeyboardEvent) => {
      const gameKey =
        GAME_KEYS.has(e.code) ||
        e.code.startsWith("Digit") ||
        e.code === "Minus" ||
        e.code === "NumpadSubtract" ||
        e.code === "Tab" ||
        e.code === "KeyP";
      // Ctrl+W fecha a aba. O agachar é Ctrl, então isso precisa ser bloqueado antes do navegador.
      if (gameKey || ((e.ctrlKey || e.metaKey) && /^Key[A-Z]$/.test(e.code))) e.preventDefault();
      if (!this.enabled) return;
      this.physical.add(e.code);
      const digit = e.code.match(/^Digit([1-9])$/);
      if (digit) this.slotPress = Number(digit[1]) - 1;
    };
    const up = (e: KeyboardEvent) => {
      this.physical.delete(e.code);
    };
    const blur = () => this.physical.clear();
    const mm = (e: MouseEvent) => {
      if (!this.enabled) return;
      this.lookAccX += e.movementX;
      this.lookAccY += e.movementY;
    };
    const md = (e: MouseEvent) => {
      if (!this.enabled) return;
      if (e.button === 0) {
        this.mouseBreak = true;
        this.mousePunch = true;
      }
      if (e.button === 2) this.mousePlace = true;
    };
    const mu = (e: MouseEvent) => {
      if (e.button === 0) this.mouseBreak = false;
      if (e.button === 2) this.mousePlace = false;
    };
    const ctx = (e: Event) => e.preventDefault();
    const wheel = (e: WheelEvent) => {
      if (!this.enabled) return;
      e.preventDefault();
      this.slotPress = e.deltaY > 0 ? 100 : 101;
    };

    window.addEventListener("keydown", down, { capture: true });
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    document.addEventListener("visibilitychange", blur);
    target.addEventListener("mousemove", mm);
    target.addEventListener("mousedown", md);
    window.addEventListener("mouseup", mu);
    target.addEventListener("contextmenu", ctx);
    target.addEventListener("wheel", wheel, { passive: false });

    this.detach = () => {
      window.removeEventListener("keydown", down, { capture: true });
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
      document.removeEventListener("visibilitychange", blur);
      target.removeEventListener("mousemove", mm);
      target.removeEventListener("mousedown", md);
      window.removeEventListener("mouseup", mu);
      target.removeEventListener("contextmenu", ctx);
      target.removeEventListener("wheel", wheel);
    };
  }

  detach: () => void = () => {};

  setKeys(codes: string[]) {
    if (codes.length === 0) {
      this.injected = null;
      this.physical.clear();
    } else {
      this.injected = new Set(codes);
    }
  }

  private keys(): Set<string> {
    return this.injected ?? this.physical;
  }

  poll(): Actions {
    const keys = this.keys();
    let moveX = 0;
    let moveY = 0;
    if (keys.has("KeyD") || keys.has("ArrowRight")) moveX += 1;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) moveX -= 1;
    if (keys.has("KeyW") || keys.has("ArrowUp")) moveY += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) moveY -= 1;

    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() ?? [] : [];
    for (const pad of pads) {
      if (!pad || pad.mapping !== "standard") continue;
      const st = radial(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
      moveX += st.x;
      moveY += -st.y;
      const look = radial(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.12);
      this.lookAccX += look.x * 14;
      this.lookAccY += look.y * 14;
      if (pad.buttons[0]?.pressed) this.touchJump = true;
      if (pad.buttons[7]?.pressed || pad.buttons[2]?.pressed) this.mouseBreak = true;
      if (pad.buttons[6]?.pressed || pad.buttons[1]?.pressed) this.mousePlace = true;
    }

    moveX += this.touchMoveX;
    moveY += this.touchMoveY;
    moveX = Math.max(-1, Math.min(1, moveX));
    moveY = Math.max(-1, Math.min(1, moveY));

    const lookX = this.lookAccX + this.touchLookX;
    const lookY = this.lookAccY + this.touchLookY;
    this.lookAccX = 0;
    this.lookAccY = 0;
    this.touchLookX = 0;
    this.touchLookY = 0;

    const jumpHeld = keys.has("Space") || this.touchJump;
    const jump = jumpHeld && !this.prevJump;
    this.prevJump = jumpHeld;

    const brk = this.mouseBreak || this.touchBreak;
    const plc = this.mousePlace || this.touchPlace;
    const punch = this.mousePunch || (brk && !this.prevBreak);
    const place = plc && !this.prevPlace;
    this.mousePunch = false;
    this.prevBreak = brk;
    this.prevPlace = plc;

    const slot = this.slotPress;
    this.slotPress = null;

    const hoverHeld = keys.has("F1");
    const hover = hoverHeld && !this.prevHover;
    this.prevHover = hoverHeld;
    const gillsHeld = keys.has("F2");
    const gills = gillsHeld && !this.prevGills;
    this.prevGills = gillsHeld;
    const quakeHeld = keys.has("F3");
    const quake = quakeHeld && !this.prevQuake;
    this.prevQuake = quakeHeld;
    const camHeld = keys.has("KeyP");
    const cam = camHeld && !this.prevCam;
    this.prevCam = camHeld;

    return {
      moveX,
      moveY,
      jump,
      jumpHeld,
      crouch: keys.has("ControlLeft") || keys.has("ControlRight") || keys.has("KeyC"),
      sprint: keys.has("ShiftLeft") || keys.has("ShiftRight"),
      break: brk,
      place,
      useHeld: plc,
      punch,
      lookX,
      lookY,
      slot,
      hover,
      gills,
      quake,
      cam,
    };
  }
}
