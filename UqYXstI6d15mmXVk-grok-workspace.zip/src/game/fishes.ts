import * as THREE from "three";

export type FishKind = "lambari" | "cascudo" | "tucunare" | "traira" | "branco";

export type FishInfo = {
  name: string;
  rarity: "comum" | "incomum" | "raro";
  w: number;
  h: number;
  d: number;
  hp: number;
  speed: number;
};

export const FISH_KINDS: FishKind[] = ["lambari", "cascudo", "tucunare", "traira", "branco"];

export function isFishKind(k: string): k is FishKind {
  return k === "lambari" || k === "cascudo" || k === "tucunare" || k === "traira" || k === "branco";
}

export function fishStats(kind: FishKind, baby: boolean): FishInfo {
  const s = baby ? 0.55 : 1;
  if (kind === "lambari") {
    return {
      name: baby ? "Lambari (filhote)" : "Lambari",
      rarity: "comum",
      w: 0.2 * s,
      h: 0.13 * s,
      d: 0.38 * s,
      hp: baby ? 1 : 2,
      speed: baby ? 1.55 : 1.9,
    };
  }
  if (kind === "cascudo") {
    return {
      name: baby ? "Cascudo (filhote)" : "Cascudo",
      rarity: "incomum",
      w: 0.4 * s,
      h: 0.15 * s,
      d: 0.56 * s,
      hp: baby ? 2 : 4,
      speed: baby ? 0.26 : 0.34,
    };
  }
  if (kind === "traira") {
    return {
      name: baby ? "Traíra (filhote)" : "Traíra",
      rarity: "incomum",
      w: 0.28 * s,
      h: 0.2 * s,
      d: 0.62 * s,
      hp: baby ? 3 : 7,
      speed: baby ? 0.85 : 1.08,
    };
  }
  if (kind === "branco") {
    return {
      name: baby ? "Branquinha (filhote)" : "Branquinha",
      rarity: "raro",
      w: 0.18 * s,
      h: 0.16 * s,
      d: 0.34 * s,
      hp: baby ? 1 : 2,
      speed: baby ? 1.2 : 1.48,
    };
  }
  return {
    name: baby ? "Tucunaré (filhote)" : "Tucunaré",
    rarity: "raro",
    w: 0.36 * s,
    h: 0.26 * s,
    d: 0.52 * s,
    hp: baby ? 3 : 6,
    speed: baby ? 1.15 : 1.42,
  };
}

function tex(paint: (ctx: CanvasRenderingContext2D, s: number) => void): THREE.CanvasTexture {
  const s = 16;
  const canvas = document.createElement("canvas");
  canvas.width = s;
  canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  paint(ctx, s);
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

function px(ctx: CanvasRenderingContext2D, c: string, x: number, y: number, w = 1, h = 1) {
  ctx.fillStyle = c;
  ctx.fillRect(x, y, w, h);
}

function noise(ctx: CanvasRenderingContext2D, s: number, base: string, spec: string, n = 16) {
  px(ctx, base, 0, 0, s, s);
  ctx.fillStyle = spec;
  for (let i = 0; i < n; i++) ctx.fillRect((i * 7 + 2) % s, (i * 11 + 4) % s, 1, 1);
}

function mat(map: THREE.CanvasTexture) {
  return new THREE.MeshLambertMaterial({ map });
}

function solid(color: number) {
  return new THREE.MeshLambertMaterial({ color });
}

function box(
  parent: THREE.Group,
  w: number,
  h: number,
  d: number,
  x: number,
  y: number,
  z: number,
  material: THREE.Material | THREE.Material[],
  part?: string,
) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  if (part) m.userData.part = part;
  parent.add(m);
  return m;
}

function faces(paint: {
  px?: (ctx: CanvasRenderingContext2D, s: number) => void;
  nx?: (ctx: CanvasRenderingContext2D, s: number) => void;
  py?: (ctx: CanvasRenderingContext2D, s: number) => void;
  ny?: (ctx: CanvasRenderingContext2D, s: number) => void;
  pz?: (ctx: CanvasRenderingContext2D, s: number) => void;
  nz?: (ctx: CanvasRenderingContext2D, s: number) => void;
}): THREE.MeshLambertMaterial[] {
  const fallback = (ctx: CanvasRenderingContext2D, s: number) => px(ctx, "#8899aa", 0, 0, s, s);
  return [paint.px, paint.nx, paint.py, paint.ny, paint.pz, paint.nz].map((fn) => mat(tex(fn ?? fallback)));
}

/** Slim silver tetra. Gold fins, dark back, schooling dart. */
export function buildLambari(): THREE.Group {
  const g = new THREE.Group();
  const back = "#6d7c86";
  const silver = "#c5d2d8";
  const belly = "#eef3f6";
  const gold = "#e0b24a";
  const side = (left: boolean) => (ctx: CanvasRenderingContext2D, s: number) => {
    noise(ctx, s, silver, "#9aadb6", 14);
    px(ctx, back, 0, 0, s, 5);
    px(ctx, belly, 0, 12, s, 4);
    px(ctx, gold, left ? 12 : 0, 7, 4, 3);
    px(ctx, "#1a1c18", left ? 10 : 4, 5, 2, 2);
  };
  const body = faces({
    px: side(false),
    nx: side(true),
    py: (ctx, s) => noise(ctx, s, back, "#4e5c64", 10),
    ny: (ctx, s) => noise(ctx, s, belly, silver, 8),
    pz: (ctx, s) => {
      noise(ctx, s, silver, belly, 8);
      px(ctx, "#f4f6f2", 4, 5, 3, 3);
      px(ctx, "#f4f6f2", 9, 5, 3, 3);
      px(ctx, "#141210", 5, 6, 2, 2);
      px(ctx, "#141210", 10, 6, 2, 2);
      px(ctx, "#3a2a18", 7, 11, 2, 2);
    },
    nz: (ctx, s) => noise(ctx, s, silver, gold, 6),
  });
  box(g, 0.16, 0.11, 0.26, 0, 0.08, 0.02, body);
  box(g, 0.13, 0.1, 0.1, 0, 0.08, 0.18, body);
  box(g, 0.04, 0.12, 0.1, 0, 0.09, -0.16, solid(0xe0b24a), "tail");
  box(g, 0.02, 0.09, 0.08, 0, 0.16, 0.0, solid(0xd4a43c));
  box(g, 0.1, 0.02, 0.06, 0.1, 0.07, 0.04, solid(0xe0b24a));
  box(g, 0.1, 0.02, 0.06, -0.1, 0.07, 0.04, solid(0xe0b24a));
  return g;
}

/** Flattened armored catfish. Hugs the bed, bony plates, whiskers. */
export function buildCascudo(): THREE.Group {
  const g = new THREE.Group();
  const plate = "#3c3224";
  const plateL = "#5a4a32";
  const plateD = "#241c14";
  const cream = "#cbb892";
  const side = (ctx: CanvasRenderingContext2D, s: number) => {
    noise(ctx, s, plate, plateL, 12);
    for (let i = 0; i < 4; i++) px(ctx, plateD, i * 4, 3, 3, 10);
    px(ctx, cream, 0, 13, s, 3);
  };
  const body = faces({
    px: side,
    nx: side,
    py: (ctx, s) => {
      noise(ctx, s, plateL, plateD, 18);
      for (let y = 1; y < 15; y += 3) px(ctx, plateD, 1, y, 14, 1);
    },
    ny: (ctx, s) => noise(ctx, s, cream, "#a8946a", 10),
    pz: (ctx, s) => {
      noise(ctx, s, plate, cream, 8);
      px(ctx, "#1a140e", 4, 6, 3, 3);
      px(ctx, "#1a140e", 9, 6, 3, 3);
      px(ctx, "#0e0c08", 5, 7, 2, 2);
      px(ctx, "#0e0c08", 10, 7, 2, 2);
      px(ctx, cream, 5, 12, 6, 3);
    },
    nz: (ctx, s) => noise(ctx, s, plateD, plate, 8),
  });
  box(g, 0.36, 0.1, 0.38, 0, 0.08, -0.02, body);
  box(g, 0.3, 0.12, 0.18, 0, 0.09, 0.22, body);
  box(g, 0.04, 0.08, 0.1, 0, 0.1, -0.26, solid(0x2a2218), "tail");
  box(g, 0.16, 0.02, 0.08, 0.22, 0.07, 0.04, solid(0x4a3a28));
  box(g, 0.16, 0.02, 0.08, -0.22, 0.07, 0.04, solid(0x4a3a28));
  const whisker = solid(0x2a2218);
  box(g, 0.02, 0.02, 0.16, 0.1, 0.06, 0.34, whisker);
  box(g, 0.02, 0.02, 0.16, -0.1, 0.06, 0.34, whisker);
  return g;
}

/** Peacock bass. Gold-olive bars, orange belly, eyespot on the tail. */
export function buildTucunare(): THREE.Group {
  const g = new THREE.Group();
  const olive = "#6f8c32";
  const gold = "#c4a24a";
  const bar = "#1c2410";
  const orange = "#d87832";
  const side = (left: boolean) => (ctx: CanvasRenderingContext2D, s: number) => {
    noise(ctx, s, olive, gold, 10);
    px(ctx, orange, 0, 12, s, 4);
    for (const x of [2, 6, 10, 13]) px(ctx, bar, left ? s - 1 - x : x, 2, 2, 11);
    px(ctx, gold, left ? 1 : 13, 6, 2, 3);
  };
  const body = faces({
    px: side(false),
    nx: side(true),
    py: (ctx, s) => noise(ctx, s, "#4a641c", bar, 12),
    ny: (ctx, s) => noise(ctx, s, orange, gold, 10),
    pz: (ctx, s) => {
      noise(ctx, s, olive, gold, 8);
      px(ctx, "#f0e8c8", 3, 5, 4, 4);
      px(ctx, "#f0e8c8", 9, 5, 4, 4);
      px(ctx, "#e8c84a", 4, 6, 2, 2);
      px(ctx, "#e8c84a", 10, 6, 2, 2);
      px(ctx, "#14110a", 5, 6, 1, 1);
      px(ctx, "#14110a", 11, 6, 1, 1);
      px(ctx, "#3a2410", 6, 11, 4, 3);
    },
    nz: (ctx, s) => noise(ctx, s, olive, bar, 8),
  });
  box(g, 0.22, 0.24, 0.52, 0, 0.16, -0.04, body);
  box(g, 0.2, 0.22, 0.22, 0, 0.16, 0.3, body);
  const tail = faces({
    px: (ctx, s) => {
      noise(ctx, s, olive, gold, 6);
      px(ctx, "#0e0e0a", 6, 5, 5, 5);
      px(ctx, "#e8c84a", 7, 6, 3, 3);
      px(ctx, "#14110a", 8, 7, 1, 1);
    },
    nx: (ctx, s) => {
      noise(ctx, s, olive, gold, 6);
      px(ctx, "#0e0e0a", 5, 5, 5, 5);
      px(ctx, "#e8c84a", 6, 6, 3, 3);
      px(ctx, "#14110a", 7, 7, 1, 1);
    },
    py: (ctx, s) => noise(ctx, s, olive, gold, 4),
    ny: (ctx, s) => noise(ctx, s, orange, gold, 4),
    pz: (ctx, s) => noise(ctx, s, olive, bar, 4),
    nz: (ctx, s) => noise(ctx, s, olive, bar, 4),
  });
  box(g, 0.06, 0.26, 0.18, 0, 0.16, -0.4, tail, "tail");
  box(g, 0.03, 0.16, 0.2, 0, 0.32, -0.02, solid(0x3a4a18));
  box(g, 0.14, 0.03, 0.1, 0.16, 0.12, 0.08, solid(0xc47828));
  box(g, 0.14, 0.03, 0.1, -0.16, 0.12, 0.08, solid(0xc47828));
  return g;
}

/** Solitary wolf-fish. Dirty brown, mottled, heavy jaw. */
export function buildTraira(): THREE.Group {
  const g = new THREE.Group();
  const mud = "#5a4228";
  const dirt = "#3a2a18";
  const rust = "#6e4a28";
  const belly = "#8a7050";
  const side = (left: boolean) => (ctx: CanvasRenderingContext2D, s: number) => {
    noise(ctx, s, mud, rust, 14);
    px(ctx, dirt, 0, 0, s, 4);
    px(ctx, belly, 0, 12, s, 4);
    for (const x of [1, 5, 9, 13]) px(ctx, dirt, left ? s - 1 - x : x, 3, 2, 9);
    px(ctx, "#1a140c", left ? 11 : 3, 5, 2, 2);
  };
  const body = faces({
    px: side(false),
    nx: side(true),
    py: (ctx, s) => noise(ctx, s, dirt, mud, 12),
    ny: (ctx, s) => noise(ctx, s, belly, rust, 8),
    pz: (ctx, s) => {
      noise(ctx, s, mud, belly, 8);
      px(ctx, "#d8c49a", 3, 5, 4, 4);
      px(ctx, "#d8c49a", 9, 5, 4, 4);
      px(ctx, "#14110a", 4, 6, 2, 2);
      px(ctx, "#14110a", 10, 6, 2, 2);
      px(ctx, "#2a1c10", 5, 11, 6, 3);
    },
    nz: (ctx, s) => noise(ctx, s, dirt, mud, 6),
  });
  box(g, 0.22, 0.16, 0.42, 0, 0.12, -0.04, body);
  box(g, 0.24, 0.18, 0.22, 0, 0.12, 0.26, body);
  box(g, 0.05, 0.16, 0.16, 0, 0.12, -0.34, solid(0x3a2818), "tail");
  box(g, 0.03, 0.12, 0.14, 0, 0.24, 0.02, solid(0x4a321c));
  box(g, 0.1, 0.02, 0.08, 0.14, 0.08, 0.06, solid(0x5a4228));
  box(g, 0.1, 0.02, 0.08, -0.14, 0.08, 0.06, solid(0x5a4228));
  return g;
}

/** Ghost-white tetra. Almost white, delicate, very rare. */
export function buildBranco(): THREE.Group {
  const g = new THREE.Group();
  const snow = "#f4f2ea";
  const pearl = "#e4e6e2";
  const mist = "#d0d4d2";
  const blush = "#ead8d0";
  const side = (left: boolean) => (ctx: CanvasRenderingContext2D, s: number) => {
    noise(ctx, s, snow, pearl, 10);
    px(ctx, mist, 0, 0, s, 3);
    px(ctx, blush, 0, 13, s, 3);
    px(ctx, "#8a8e8c", left ? 11 : 3, 5, 2, 2);
    px(ctx, "#1a1c1a", left ? 11 : 3, 5, 1, 1);
  };
  const body = faces({
    px: side(false),
    nx: side(true),
    py: (ctx, s) => noise(ctx, s, pearl, mist, 8),
    ny: (ctx, s) => noise(ctx, s, snow, blush, 6),
    pz: (ctx, s) => {
      noise(ctx, s, snow, pearl, 6);
      px(ctx, "#f8f6f2", 4, 5, 3, 3);
      px(ctx, "#f8f6f2", 9, 5, 3, 3);
      px(ctx, "#2a2c2a", 5, 6, 1, 1);
      px(ctx, "#2a2c2a", 10, 6, 1, 1);
      px(ctx, blush, 6, 11, 4, 2);
    },
    nz: (ctx, s) => noise(ctx, s, pearl, snow, 4),
  });
  box(g, 0.12, 0.12, 0.22, 0, 0.09, 0.0, body);
  box(g, 0.1, 0.1, 0.1, 0, 0.09, 0.14, body);
  box(g, 0.03, 0.12, 0.1, 0, 0.1, -0.16, solid(0xe8e4dc), "tail");
  box(g, 0.02, 0.08, 0.08, 0, 0.18, 0.0, solid(0xf0ece4));
  box(g, 0.08, 0.02, 0.05, 0.08, 0.08, 0.02, solid(0xe8d8d0));
  box(g, 0.08, 0.02, 0.05, -0.08, 0.08, 0.02, solid(0xe8d8d0));
  return g;
}

export function buildFish(kind: FishKind): THREE.Group {
  if (kind === "lambari") return buildLambari();
  if (kind === "cascudo") return buildCascudo();
  if (kind === "traira") return buildTraira();
  if (kind === "branco") return buildBranco();
  return buildTucunare();
}
