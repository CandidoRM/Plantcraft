import * as THREE from "three";

const TILE = 32;
const COLS = 4;
const ROWS = 11;
const ATLAS_EXTRA = 2;
const ATLAS_SPAN = COLS + ATLAS_EXTRA;
const ATLAS_W = TILE * ATLAS_SPAN;
const ATLAS_H = TILE * ROWS;

function atlasCell(tile: number): { col: number; row: number } {
  if (tile === 44) return { col: 4, row: 2 };
  if (tile === 45) return { col: 5, row: 2 };
  if (tile === 46) return { col: 4, row: 3 };
  if (tile === 47) return { col: 5, row: 3 };
  if (tile === 48) return { col: 4, row: 4 };
  if (tile === 49) return { col: 5, row: 4 };
  if (tile === 50) return { col: 4, row: 5 };
  if (tile === 51) return { col: 5, row: 5 };
  if (tile === 52) return { col: 4, row: 6 };
  return { col: tile % COLS, row: (tile / COLS) | 0 };
}

function clamp(n: number): number {
  return n < 0 ? 0 : n > 255 ? 255 : n | 0;
}

function px(data: Uint8ClampedArray, x: number, y: number, r: number, g: number, b: number, a = 255) {
  if (x < 0 || y < 0 || x >= TILE || y >= TILE) return;
  const i = (y * TILE + x) * 4;
  data[i] = clamp(r);
  data[i + 1] = clamp(g);
  data[i + 2] = clamp(b);
  data[i + 3] = a;
}

function hash3(x: number, y: number, seed: number): number {
  let n = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 1274126177);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function mix(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function valueNoise(x: number, y: number, seed: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);
  const a = hash3(x0, y0, seed);
  const b = hash3(x0 + 1, y0, seed);
  const c = hash3(x0, y0 + 1, seed);
  const d = hash3(x0 + 1, y0 + 1, seed);
  return mix(mix(a, b, sx), mix(c, d, sx), sy);
}

function rgb(data: Uint8ClampedArray, x: number, y: number, c: [number, number, number], a = 255) {
  const n = hash3(x, y, 91);
  px(data, x, y, c[0] + (n - 0.5) * 10, c[1] + (n - 0.5) * 10, c[2] + (n - 0.5) * 10, a);
}

function drawTile(kind: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const h = (x: number, y: number, s = 0) => hash3(x, y, kind * 997 + 17 + s);

  switch (kind) {
    case 0: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          const n = h(x, y);
          const n2 = h(x, y, 3);
          let r = 74,
            g = 148,
            b = 52;
          if (n < 0.12) {
            r = 52;
            g = 112;
            b = 38;
          } else if (n > 0.82) {
            r = 118;
            g = 176;
            b = 64;
          } else if (n2 > 0.9) {
            r = 156;
            g = 168;
            b = 58;
          }
          const tuft = Math.sin(x * 1.7 + y * 0.4) * 0.5 + 0.5;
          if (tuft > 0.72 && n > 0.4) {
            g += 14;
            r -= 6;
          }
          px(d, x, y, r + (n - 0.5) * 16, g + (n2 - 0.5) * 14, b + (n - 0.5) * 10);
        }
      }
      break;
    }
    case 1: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          dirtPixel(d, x, y, h);
        }
      }
      for (let x = 0; x < TILE; x++) {
        const edge = 9 + ((h(x, 0, 8) * 5) | 0);
        for (let y = 0; y < edge; y++) {
          const n = h(x, y, 2);
          let r = 86,
            g = 152,
            b = 54;
          if (n < 0.2) {
            r = 58;
            g = 118;
            b = 40;
          } else if (n > 0.85) {
            r = 124;
            g = 174;
            b = 62;
          }
          if (y > edge - 2) {
            r = mix(r, 118, 0.35);
            g = mix(g, 78, 0.35);
            b = mix(b, 42, 0.35);
          }
          px(d, x, y, r, g, b);
        }
      }
      break;
    }
    case 2: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) dirtPixel(d, x, y, h);
      }
      break;
    }
    case 3: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          const blotch = valueNoise(x / 5.4, y / 5.0, 31);
          const blotch2 = valueNoise(x / 2.3 + 3.1, y / 2.5 + 1.4, 44);
          const grain = h(x, y);
          const t = blotch * 0.5 + blotch2 * 0.32 + grain * 0.18;
          let v = 104 + t * 44;
          if (blotch > 0.7 && grain > 0.5) v += 10;
          if (blotch < 0.28) v -= 12;
          if (grain > 0.94) v += 14;
          if (grain < 0.06) v -= 16;
          v += (grain - 0.5) * 6;
          px(d, x, y, v, v, v + 2);
        }
      }
      break;
    }
    case 4: {
      paintOakBark(d, h);
      break;
    }
    case 5: {
      paintLogRings(d, h, "oak");
      break;
    }
    case 6: {
      paintLeaves(d, "oak");
      break;
    }
    case 7: {
      paintOakPlanks(d, h);
      break;
    }
    case 8: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          const n = h(x, y);
          const n2 = h(x, y, 4);
          let r = 214,
            g = 198,
            b = 124;
          if (n < 0.15) {
            r = 196;
            g = 170;
            b = 96;
          } else if (n > 0.86) {
            r = 232;
            g = 218;
            b = 160;
          }
          if (n2 > 0.92) {
            r = 168;
            g = 142;
            b = 78;
          }
          px(d, x, y, r, g, b);
        }
      }
      break;
    }
    case 9: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          const n = h(x, y);
          const n2 = h(x * 2, y * 2, 7);
          let r = 42,
            g = 42,
            b = 48;
          if (n < 0.28) {
            r = 24;
            g = 24;
            b = 28;
          } else if (n > 0.72) {
            r = 72;
            g = 70;
            b = 76;
          }
          if (n2 > 0.9) {
            r = 96;
            g = 94;
            b = 100;
          }
          px(d, x, y, r, g, b);
        }
      }
      break;
    }
    case 10: {
      paintMelonSide(d, h, false);
      break;
    }
    case 11: {
      paintMelonSide(d, h, true);
      break;
    }
    case 12: {
      paintFarmland(d, h);
      break;
    }
    case 13: {
      paintBirchBark(d, h);
      break;
    }
    case 14: {
      paintLogRings(d, h, "birch");
      break;
    }
    case 15: {
      paintDarkBark(d, h);
      break;
    }
    case 16: {
      paintLogRings(d, h, "dark");
      break;
    }
    case 17: {
      paintRedCarpet(d, h);
      break;
    }
    case 18: {
      paintCrackedStone(d);
      break;
    }
    case 19: {
      paintArauBark(d, h);
      break;
    }
    case 20: {
      paintLogRings(d, h, "arau");
      break;
    }
    case 21: {
      paintCerradoGrassTop(d, h);
      break;
    }
    case 22: {
      paintCerradoGrassSide(d, h);
      break;
    }
    case 23: {
      paintLaterite(d, h);
      break;
    }
    case 24: {
      paintVarzeaGrassTop(d, h);
      break;
    }
    case 25: {
      paintVarzeaGrassSide(d, h);
      break;
    }
    case 26: {
      paintAquifer(d, h);
      break;
    }
    case 27: {
      paintMarble(d, h);
      break;
    }
    case 28: {
      paintMarbleLawn(d, h);
      break;
    }
    case 29: {
      paintMud(d, h);
      break;
    }
    case 30: {
      paintMarbleSide(d, h);
      break;
    }
    case 31: {
      paintMarbleOrange(d, h);
      break;
    }
    case 32: {
      paintMarblePurple(d, h);
      break;
    }
    case 33: {
      paintMarbleBroken(d, h);
      break;
    }
    case 34: {
      paintMarbleBrick(d, h);
      break;
    }
    case 35: {
      paintMarbleVase(d, h);
      break;
    }
    case 36: {
      paintCaatingaGrass(d, h);
      break;
    }
    case 37: {
      paintCaatingaSoil(d, h);
      break;
    }
    case 38: {
      paintCaatingaSide(d, h);
      break;
    }
    case 39: {
      paintLajedo(d, h);
      break;
    }
    case 40: {
      paintMandacaru(d, h);
      break;
    }
    case 41: {
      paintCaatingaBark(d, h);
      break;
    }
    case 42: {
      paintCaatingaRings(d, h);
      break;
    }
    case 43: {
      paintMonumentBase(d, h);
      break;
    }
    case 44: {
      paintMonumentShaft(d, h);
      break;
    }
    case 45: {
      paintMonumentCrown(d, h);
      break;
    }
    case 46: {
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) {
          const hi = x < 13 && y < 14;
          const shade = x > 18 || y > 20;
          const c: [number, number, number] = hi ? [252, 178, 148] : shade ? [196, 102, 96] : [236, 142, 118];
          px(d, x, y, c[0], c[1], c[2]);
        }
      }
      break;
    }
    case 47: {
      paintMarbleBlue(d, h);
      break;
    }
    case 48: {
      paintGreenBrick(d, h);
      break;
    }
    case 49: {
      paintRustMetal(d, h);
      break;
    }
    case 50: {
      paintBrejoGrass(d, h);
      break;
    }
    case 51: {
      paintBrejoSoil(d, h);
      break;
    }
    case 52: {
      paintBrejoSide(d, h);
      break;
    }
    default:
      for (let y = 0; y < TILE; y++) {
        for (let x = 0; x < TILE; x++) rgb(d, x, y, [80, 80, 80]);
      }
  }
  return img;
}

function paintRedCarpet(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 4);
      const weave = ((Math.floor(x / 2) + Math.floor(y / 2)) % 2) * 8;
      let r = 178 + weave;
      let g = 36 + weave * 0.2;
      let b = 36;
      if (n < 0.16) {
        r = 132;
        g = 22;
        b = 24;
      } else if (n > 0.84) {
        r = 210;
        g = 58;
        b = 52;
      }
      if (n2 > 0.92) {
        r -= 24;
        g -= 8;
      }
      if (y === 0 || x === 0) {
        r -= 18;
        g -= 6;
        b -= 6;
      }
      px(d, x, y, r + (n - 0.5) * 14, g + (n2 - 0.5) * 8, b);
    }
  }
}

const CRACKED_ROWS = [
  "444444444444444444444422222222222222222222222200000022223344444444444444",
  "444444444444444444444422222222222222222222222222222222334444444444444444",
  "444444444444444444444422222222222222222222222222222222334444444444444444",
  "444444444444444444440000002222222222222222222200000033334444444444444444",
  "444444444444444444440000002222222222222222222200000033334444444444444444",
  "444444444444444400000011000022222222222222220000220033223344444444444444",
  "444444444444444400000011000022222222222222220000220033223344444444444444",
  "444444444444000000111111110000002222222222222222222200332233444444444444",
  "444444444444000000111111110000002222222222222222222200332233444444444444",
  "444444440000001111111111111111000000222222222222222222223322334444444444",
  "444444440000001111111111111111000000222222222222222222223322334444444444",
  "444444000011111111111111111111111111005522222222222222222244444444444444",
  "444444000011111111111111111111111111005522222222222222222244444444444444",
  "444400000011111111111111111111111100225544222222222222224444444444444444",
  "444400000011111111111111111111111100225544222222222222224444444444444444",
  "440000222200001111111111111111110022334455442222222244444444444444444444",
  "440000222200001111111111111111110022334455442222222244444444444444444444",
  "000022222222220000111111111111002233444455444422224444444444444444444444",
  "000022222222220000111111111111002233444455444422224444444444444444444444",
  "002222222222222222000011111100223344444444554444444444444444444444444455",
  "002222222222222222000011111100223344444444554444444444444444444444444455",
  "222222222222222222222200000022334444444444555544444444444444444444445555",
  "222222222222222222222200000022334444444444555544444444444444444444445555",
  "222222222222222222222222222244444444444444555555554444444444445555555555",
  "222222222222222222222222222244444444444444555555554444444444445555555555",
  "222222222222222222222222334444444444444455555555555555555555555555555555",
  "222222222222222222222222334444444444444455555555555555555555555555555555",
  "222222222222222233333333444444444455111111111111111111000000111155555522",
  "222222222222222233333333444444444455111111111111111111000000111155555522",
  "222222222222333322002233444444445522111111111111111111111111111122552222",
  "222222222222333322002233444444445522111111111111111111111111111122552222",
  "222222223322332211110000444444555511111111111111111111111111111111222222",
  "222222223322332211110000444444555511111111111111111111111111111111222222",
  "222233223333001111111111005555552211111111111111111111111111111111111122",
  "222233223333001111111111005555552211111111111111111111111111111111111122",
  "222233333300111111111111110000220000111111111111111111111111111111111122",
  "222233333300111111111111110000220000111111111111111111111111111111111122",
  "333333330011111111111111111100002222001111111111111111111111111111111111",
  "333333330011111111111111111100002222001111111111111111111111111111111111",
  "333300001111111111111111111111000022222211111111111111111111111111111111",
  "333300001111111111111111111111000022222211111111111111111111111111111111",
  "440011111111111111111111111111111100000022000011111111111111111111111111",
  "440011111111111111111111111111111100000022000011111111111111111111111111",
  "111111111111111111111111111111112255552222222211111111111111111111111111",
  "111111111111111111111111111111112255552222222211111111111111111111111111",
  "221111111111111111111111111111223344553322222222222211111111111111112244",
  "221111111111111111111111111111223344553322222222222211111111111111112244",
  "222211111111111111111111111122334444553322222222222222222222223344444444",
  "222211111111111111111111111122334444553322222222222222222222223344444444",
  "222222111111111111111111112233444444553322222222222222222233444444444444",
  "222222111111111111111111112233444444553322222222222222222233444444444444",
  "222222221111111111111111223344444444553322222222222222334444444444444444",
  "222222221111111111111111223344444444553322222222222222334444444444444444",
  "222222222211111111111122334444444444553322222222222222444444444444444444",
  "222222222211111111111122334444444444553322222222222222444444444444444444",
  "222222222222111111223344444444444444553322222222222222554444444444444444",
  "222222222222111111223344444444444444553322222222222222554444444444444444",
  "222222222222223333444444444444444444553322222222222233554444444444444444",
  "222222222222223333444444444444444444553322222222222233554444444444444444",
  "222222222222334444444444444444444444554422222222222244554444444444444444",
  "222222222222334444444444444444444444554422222222222244554444444444444444",
  "222222222233334444444444444444444444554433222222223344554444444444444444",
  "222222222233334444444444444444444444554433222222223344554444444444444444",
  "222222223333334444444444444444444444554444332222224455554444444444444444",
  "222222223333334444444444444444444444554444332222224455554444444444444444",
  "222233333333334444444444444444444455554444443322334455554444444444444444",
  "222233333333334444444444444444444455554444443322334455554444444444444444",
  "443333333333334444444444444444445555554444443333444455554444444444444444",
  "443333333333334444444444444444445555554444443333444455554444444444444444",
  "444444333333334444444444444444555555554444444444445555554444444444444455",
  "444444333333334444444444444444555555554444444444445555554444444444444455",
  "444444444444444444444444445555555555555544444444445555555544444444555555",
];

const CRACKED_PAL: [number, number, number][] = [
  [236, 236, 236],
  [214, 214, 216],
  [176, 176, 178],
  [112, 112, 114],
  [78, 78, 80],
  [78, 78, 80],
];

function paintCrackedStone(d: Uint8ClampedArray) {
  const n = CRACKED_ROWS.length;
  for (let y = 0; y < TILE; y++) {
    const sy = Math.round((y * (n - 1)) / (TILE - 1));
    const row = CRACKED_ROWS[sy] ?? CRACKED_ROWS[0]!;
    for (let x = 0; x < TILE; x++) {
      const sx = Math.round((x * (row.length - 1)) / (TILE - 1));
      const [r, g, b] = CRACKED_PAL[row.charCodeAt(sx) - 48] ?? CRACKED_PAL[4]!;
      px(d, x, y, r, g, b);
    }
  }
}

function paintAquifer(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const blotch = valueNoise(x / 5.4, y / 5.0, 211);
      const blotch2 = valueNoise(x / 2.3 + 2.2, y / 2.5 + 0.8, 224);
      const grain = h(x, y);
      const t = blotch * 0.48 + blotch2 * 0.34 + grain * 0.18;
      let r = 86 + t * 28;
      let g = 92 + t * 30;
      let b = 96 + t * 32;
      if (blotch > 0.68 && grain > 0.48) {
        r += 6;
        g += 10;
        b += 14;
      }
      if (blotch < 0.26) {
        r -= 12;
        g -= 8;
        b -= 4;
      }
      if (grain > 0.94) {
        r += 10;
        g += 12;
        b += 16;
      }
      px(d, x, y, r, g, b);
    }
  }
  const cracks: [number, number, number, number][] = [
    [3, 4, 12, 18],
    [14, 2, 28, 11],
    [6, 20, 22, 29],
    [20, 12, 30, 26],
    [1, 14, 10, 28],
    [16, 16, 26, 22],
  ];
  for (const [x0, y0, x1, y1] of cracks) {
    const steps = Math.max(8, Math.hypot(x1 - x0, y1 - y0) * 1.4);
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const wobble = Math.sin(t * 9.2 + x0) * 0.9;
      const x = (x0 + (x1 - x0) * t + wobble) | 0;
      const y = (y0 + (y1 - y0) * t + Math.sin(t * 5.1) * 0.4) | 0;
      const wet = h(x, y, 7);
      if (wet > 0.42) {
        px(d, x, y, 38, 92, 118);
        px(d, x + 1, y, 52, 118, 142);
        if (wet > 0.7) px(d, x, y + 1, 72, 148, 168);
      } else {
        px(d, x, y, 32, 40, 44);
        px(d, x + 1, y, 48, 58, 62);
      }
    }
  }
  for (let i = 0; i < 7; i++) {
    const sx = 4 + ((h(i, 3, 11) * 24) | 0);
    const sy = 5 + ((h(i, 9, 13) * 22) | 0);
    px(d, sx, sy, 96, 168, 186);
    px(d, sx + 1, sy, 70, 132, 154);
  }
}

function paintArauBark(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    const plate = Math.floor((y + hash3(0, Math.floor(y / 6), 84) * 1.2) / 6);
    for (let x = 0; x < TILE; x++) {
      const grain = valueNoise(x * 0.7, y / 9, 81);
      const n = h(x, y, plate);
      let r = 98 + grain * 22;
      let g = 62 + grain * 12;
      let b = 36 + grain * 8;
      const seam = (x + plate * 3) % 8;
      if (seam === 0) {
        r = 58;
        g = 34;
        b = 20;
      } else if (seam === 1) {
        r -= 16;
        g -= 10;
      }
      if (n > 0.9) {
        r += 18;
        g += 10;
      }
      if (n < 0.08) {
        r -= 14;
        g -= 10;
      }
      px(d, x, y, r + (n - 0.5) * 8, g + (n - 0.5) * 6, b);
    }
  }
}

function paintCerradoGrassTop(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 5);
      let r = 188,
        g = 158,
        b = 48;
      if (n < 0.16) {
        r = 148;
        g = 112;
        b = 32;
      } else if (n > 0.82) {
        r = 214;
        g = 186;
        b = 72;
      } else if (n2 > 0.88) {
        r = 168;
        g = 132;
        b = 40;
      }
      const tuft = Math.sin(x * 1.9 + y * 0.5) * 0.5 + 0.5;
      if (tuft > 0.7 && n > 0.35) {
        r += 16;
        g += 10;
      }
      px(d, x, y, r + (n - 0.5) * 14, g + (n2 - 0.5) * 12, b + (n - 0.5) * 8);
    }
  }
}

function paintLaterite(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 13);
      let r = 168,
        g = 92,
        b = 48;
      if (n < 0.18) {
        r = 132;
        g = 64;
        b = 32;
      } else if (n > 0.84) {
        r = 196;
        g = 118;
        b = 62;
      }
      if (n2 > 0.92) {
        r = 112;
        g = 72;
        b = 44;
      }
      px(d, x, y, r + (n - 0.5) * 12, g + (n - 0.5) * 8, b + (n - 0.5) * 6);
    }
  }
}

function paintCerradoGrassSide(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintLaterite(d, h);
  for (let x = 0; x < TILE; x++) {
    const edge = 8 + ((h(x, 0, 8) * 6) | 0);
    for (let y = 0; y < edge; y++) {
      const n = h(x, y, 2);
      let r = 176,
        g = 148,
        b = 46;
      if (n < 0.22) {
        r = 140;
        g = 108;
        b = 30;
      } else if (n > 0.84) {
        r = 210;
        g = 178;
        b = 68;
      }
      if (y > edge - 2) {
        r = mix(r, 164, 0.4);
        g = mix(g, 92, 0.4);
        b = mix(b, 46, 0.4);
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintVarzeaGrassTop(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 6);
      let r = 28,
        g = 138,
        b = 108;
      if (n < 0.14) {
        r = 16;
        g = 96;
        b = 78;
      } else if (n > 0.82) {
        r = 56;
        g = 176;
        b = 118;
      } else if (n2 > 0.9) {
        r = 40;
        g = 154;
        b = 86;
      }
      const tuft = Math.sin(x * 1.6 + y * 0.45) * 0.5 + 0.5;
      if (tuft > 0.72 && n > 0.4) {
        g += 16;
        r -= 4;
      }
      px(d, x, y, r + (n - 0.5) * 10, g + (n2 - 0.5) * 12, b + (n - 0.5) * 8);
    }
  }
}

function paintVarzeaGrassSide(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) dirtPixel(d, x, y, h);
  }
  for (let x = 0; x < TILE; x++) {
    const edge = 9 + ((h(x, 0, 9) * 5) | 0);
    for (let y = 0; y < edge; y++) {
      const n = h(x, y, 2);
      let r = 32,
        g = 142,
        b = 112;
      if (n < 0.2) {
        r = 18;
        g = 102;
        b = 80;
      } else if (n > 0.85) {
        r = 62;
        g = 172;
        b = 124;
      }
      if (y > edge - 2) {
        r = mix(r, 118, 0.32);
        g = mix(g, 78, 0.32);
        b = mix(b, 42, 0.32);
      }
      px(d, x, y, r, g, b);
    }
  }
}

function dirtPixel(d: Uint8ClampedArray, x: number, y: number, h: (x: number, y: number, s?: number) => number) {
  const n = h(x, y);
  const n2 = h(x, y, 11);
  let r = 134,
    g = 92,
    b = 52;
  if (n < 0.16) {
    r = 102;
    g = 68;
    b = 38;
  } else if (n > 0.84) {
    r = 158;
    g = 112;
    b = 64;
  }
  if (n2 > 0.93) {
    r = 88;
    g = 72;
    b = 54;
  }
  px(d, x, y, r + (n - 0.5) * 14, g + (n - 0.5) * 10, b + (n - 0.5) * 8);
}

function paintOakBark(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const grain = valueNoise(x * 0.85, y / 11, 21);
      const moss = valueNoise(x / 6.2, y / 7.4, 27);
      const n = h(x, y);
      let r = 118 + grain * 28;
      let g = 82 + grain * 18;
      let b = 44 + grain * 10;
      const crack = hash3(x, 0, 44);
      const crackX = 2 + Math.floor(crack * 28);
      const wiggle = ((h(0, y, 8) - 0.5) * 1.6) | 0;
      if (Math.abs(x - crackX - wiggle) <= 0 || Math.abs(x - ((crackX + 11) % TILE) - wiggle) === 0) {
        r = 72;
        g = 48;
        b = 26;
      } else if (Math.abs(x - crackX - wiggle) === 1) {
        r -= 18;
        g -= 12;
      }
      if (n > 0.93) {
        r -= 22;
        g -= 16;
      }
      if (moss > 0.78 && n > 0.4) {
        g += 10;
        r -= 8;
      }
      px(d, x, y, r + (n - 0.5) * 10, g + (n - 0.5) * 8, b);
    }
  }
}

function paintBirchBark(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const peel = valueNoise(x / 5.5, y / 9, 61);
      let r = 226 + peel * 16;
      let g = 220 + peel * 14;
      let b = 198 + peel * 12;
      if (n < 0.08) {
        r = 196;
        g = 188;
        b = 168;
      }
      px(d, x, y, r + (n - 0.5) * 8, g + (n - 0.5) * 8, b);
    }
  }
  for (let i = 0; i < 9; i++) {
    const yy = 2 + ((hash3(i, 3, 70) * (TILE - 5)) | 0);
    const x0 = 1 + ((hash3(i, 5, 71) * (TILE - 10)) | 0);
    const len = 4 + ((hash3(i, 8, 72) * 10) | 0);
    const thick = hash3(i, 9, 73) > 0.55 ? 2 : 1;
    for (let t = 0; t < len; t++) {
      const xx = x0 + t;
      const dark = hash3(i, t, 74) > 0.18;
      const cr = dark ? 38 : 86;
      const cg = dark ? 34 : 78;
      const cb = dark ? 32 : 68;
      px(d, xx, yy, cr, cg, cb);
      if (thick > 1) px(d, xx, yy + 1, cr + 10, cg + 8, cb + 6);
      if (t === 0 || t === len - 1) px(d, xx, yy - 1, 70, 64, 54);
    }
  }
  for (let k = 0; k < 6; k++) {
    const xx = (hash3(k, 1, 81) * TILE) | 0;
    const yy = (hash3(k, 2, 82) * TILE) | 0;
    px(d, xx, yy, 48, 44, 40);
  }
}

function paintLogRings(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number, kind: "oak" | "birch" | "dark" | "arau") {
  const cx = 15.5;
  const cy = 15.5;
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const ang = Math.atan2(dy, dx);
      const wobble = Math.sin(ang * 3.2) * 0.55 + Math.sin(ang * 7.1) * 0.18;
      const ring = Math.sin((dist + wobble) * 1.35);
      const n = h(x, y);
      let r: number, g: number, b: number;
      if (kind === "birch") {
        r = 214;
        g = 196;
        b = 150;
        if (ring > 0.28) {
          r = 186;
          g = 168;
          b = 122;
        }
        if (dist < 2.2) {
          r = 168;
          g = 150;
          b = 108;
        }
      } else if (kind === "dark") {
        r = 118;
        g = 78;
        b = 42;
        if (ring > 0.22) {
          r = 88;
          g = 54;
          b = 28;
        }
        if (dist < 2.4) {
          r = 64;
          g = 40;
          b = 22;
        }
      } else if (kind === "arau") {
        r = 168;
        g = 118;
        b = 62;
        if (ring > 0.22) {
          r = 132;
          g = 86;
          b = 42;
        }
        if (dist < 2.4) {
          r = 108;
          g = 68;
          b = 32;
        }
      } else {
        r = 186;
        g = 142;
        b = 78;
        if (ring > 0.22) {
          r = 152;
          g = 112;
          b = 58;
        }
        if (dist < 2.4) {
          r = 128;
          g = 92;
          b = 48;
        }
      }
      if (dist > 12.2) {
        if (kind === "birch") {
          r = 236 + n * 8;
          g = 230;
          b = 210;
          if (n > 0.84) {
            r = 48;
            g = 44;
            b = 40;
          }
        } else if (kind === "dark") {
          r = 52;
          g = 32;
          b = 18;
          if (n > 0.7) {
            r = 36;
            g = 22;
            b = 12;
          }
        } else if (kind === "arau") {
          r = 78;
          g = 46;
          b = 26;
          if (n > 0.7) {
            r = 58;
            g = 34;
            b = 18;
          }
        } else {
          r = 92;
          g = 62;
          b = 34;
          if (n > 0.7) {
            r = 72;
            g = 48;
            b = 26;
          }
        }
      } else if (dist > 11.1) {
        r = kind === "birch" ? 70 : kind === "dark" ? 38 : kind === "arau" ? 48 : 64;
        g = kind === "birch" ? 62 : kind === "dark" ? 24 : kind === "arau" ? 30 : 42;
        b = kind === "birch" ? 52 : kind === "dark" ? 14 : kind === "arau" ? 16 : 24;
      }
      r += (n - 0.5) * 10;
      g += (n - 0.5) * 8;
      px(d, x, y, r, g, b);
    }
  }
}

function paintDarkBark(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    const plate = Math.floor((y + hash3(0, Math.floor(y / 5), 90) * 1.4) / 5);
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y, plate);
      const grain = valueNoise(x / 3.2, y / 8, 51);
      const plateShift = (plate * 5) % 7;
      let r = 78 + grain * 18;
      let g = 48 + grain * 10;
      let b = 26 + grain * 6;
      if (plate % 2) {
        r -= 10;
        g -= 6;
        b -= 4;
      }
      const seamY = y % 5;
      if (seamY === 0) {
        r = 42;
        g = 26;
        b = 14;
      } else if (seamY === 1) {
        r -= 12;
        g -= 8;
      }
      const split = (x + plateShift) % 11;
      if (split === 0) {
        r = 36;
        g = 22;
        b = 12;
      } else if (split === 1) {
        r -= 8;
        g -= 6;
      }
      if (n > 0.92) {
        r += 16;
        g += 10;
      }
      px(d, x, y, r + (n - 0.5) * 8, g + (n - 0.5) * 6, b);
    }
  }
}

function paintOakPlanks(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  const boardH = 8;
  for (let y = 0; y < TILE; y++) {
    const board = Math.floor(y / boardH);
    const local = y % boardH;
    const shift = (board * 7) % TILE;
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y, board);
      const grain = valueNoise((x + shift) / 9, y / 2.4, 33 + board);
      let r = board % 2 ? 196 : 208;
      let g = board % 2 ? 148 : 162;
      let b = board % 2 ? 78 : 88;
      r += grain * 18 + (n - 0.5) * 12;
      g += grain * 14 + (n - 0.5) * 10;
      b += grain * 8;
      if (local === 0 || local === boardH - 1) {
        r = 96;
        g = 64;
        b = 32;
      } else if (local === 1) {
        r *= 0.9;
        g *= 0.9;
      }
      const seam = (x + shift) % 16;
      if (seam === 0) {
        r = 108;
        g = 72;
        b = 36;
      }
      if (h(x + shift, y, 4) > 0.96 && local > 1 && local < boardH - 1) {
        r = 120;
        g = 82;
        b = 42;
      }
      px(d, x, y, r, g, b);
    }
  }
  for (const [kx, ky] of [
    [9, 10],
    [10, 11],
    [21, 19],
    [22, 20],
  ] as [number, number][]) {
    px(d, kx, ky, 112, 76, 38);
    px(d, kx + 1, ky, 124, 86, 44);
  }
}

function paintMelonSide(
  d: Uint8ClampedArray,
  h: (x: number, y: number, s?: number) => number,
  top: boolean,
) {
  const cells: [number, number, number][] = [];
  for (let i = 0; i < 22; i++) {
    const cx = 1.5 + hash3(i, 3, 80) * (TILE - 3);
    const cy = 1.5 + hash3(i, 9, 81) * (TILE - 3);
    cells.push([cx, cy, hash3(i, 1, 82)]);
  }
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      let d1 = 99;
      let d2 = 99;
      let cell = 0.5;
      for (const [cx, cy, id] of cells) {
        const dist = Math.hypot(x - cx, y - cy);
        if (dist < d1) {
          d2 = d1;
          d1 = dist;
          cell = id;
        } else if (dist < d2) d2 = dist;
      }
      const edge = d2 - d1;
      let r: number, g: number, b: number;
      if (edge < 1.15) {
        r = 244;
        g = 226;
        b = 176;
      } else if (edge < 1.85) {
        r = 228;
        g = 198;
        b = 128;
      } else if (cell < 0.28) {
        r = 168;
        g = 186;
        b = 78;
      } else if (cell < 0.55) {
        r = 236;
        g = 176;
        b = 64;
      } else {
        r = 244;
        g = 196;
        b = 86;
      }
      r += (h(x, y) - 0.5) * 12;
      g += (h(x, y, 2) - 0.5) * 10;
      if (top) {
        const dist = Math.hypot(x - 15.5, y - 15.5);
        if (dist < 2.4) {
          r = 86;
          g = 92;
          b = 40;
        } else if (dist < 4.2) {
          r = 140;
          g = 132;
          b = 58;
        }
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintFarmland(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const furrow = Math.floor(x / 4) % 2 === 0;
      const n = h(x, y);
      let r = furrow ? 92 : 118;
      let g = furrow ? 58 : 78;
      let b = furrow ? 30 : 40;
      if (n < 0.18) {
        r -= 16;
        g -= 10;
      } else if (n > 0.84) {
        r += 18;
        g += 12;
      }
      if ((y + (furrow ? 0 : 2)) % 8 === 0) {
        r -= 10;
        g -= 8;
      }
      px(d, x, y, r, g, b);
    }
  }
}

/** 16×16 lace per species: # = folha, . = fresta (alfa 0). */
const OAK_LEAF_MASK = [
  "#####..###.#####",
  "###..#####..####",
  "##..##..###..###",
  "#.########.##.##",
  "###..####..#####",
  ".##.######.##...",
  "#####..##..#####",
  "###..######..###",
  "#..###..####..##",
  "#####.##..######",
  ".##..#####..##..",
  "####..###..#####",
  "##..######.##.##",
  "#####..##..#####",
  "###.##..####.###",
  "#####.##########",
];

const BIRCH_LEAF_MASK = [
  "####..###..#####",
  "##..####.##..###",
  "#..##..####..##.",
  "###..####..#####",
  ".##.######.##..#",
  "####..##..###.##",
  "##..######..####",
  "#..###..####..##",
  "#####.##..###.##",
  ".##..#####..##..",
  "####..###..#####",
  "##..######.##..#",
  "###..##..####.##",
  "#..#####..###..#",
  "####..####..####",
  "###.######.#####",
];

const DARK_LEAF_MASK = [
  "###.####..###.##",
  "#..##..####..###",
  "####..##..#..##.",
  ".##..######.##.#",
  "#####..##..#####",
  "##..#..####..##.",
  "#..#####..###.##",
  "####..##.##..###",
  ".##..####..##..#",
  "#####..##..#####",
  "##..###..####..#",
  "#..##..#####..##",
  "####.##..##..###",
  ".##..#####..##.#",
  "###..##..####.##",
  "##.#####..######",
];

const ARAU_LEAF_MASK = [
  "..###..##..###..",
  ".#####.####.###.",
  "##..########..##",
  "#####..##..#####",
  "..###.####.###..",
  ".####..##..####.",
  "###..######..###",
  ".#####.##.#####.",
  "##..###..###..##",
  "#####.####.#####",
  "..###..##..###..",
  ".####..##..####.",
  "###..######..###",
  ".#####.##.#####.",
  "..###.####.###..",
  ".##..######..##.",
];

const CERRADO_LEAF_MASK = [
  "##..###..##..###",
  "..####..####..##",
  "###..##..##..###",
  "#..######..##..#",
  "####..##..####..",
  "..##..####..###.",
  "###..##..######.",
  "#..####..##..###",
  "####..######..#.",
  "..##..##..####..",
  "###..####..##..#",
  "#..##..######..#",
  "####..##..##..##",
  "..######..####..",
  "###..##..##..###",
  "##..####..###..#",
];

/** More open than the oak lace: the peach block itself is a window. */
const PEACH_LEAF_MASK = [
  "#..#..##..#..#.",
  ".#..##..#..##..",
  "#..#..#..##..#.",
  "..##..#..#..##.",
  "#..#..##..#..#.",
  ".#..#..#..##..#",
  "#..##..#..#..#.",
  ".#..#..##..#..#",
  "#..#..#..#..##.",
  ".##..#..##..#..",
  "#..#..#..#..#.#",
  ".#..##..#..#..#",
  "#..#..#..##..#.",
  ".#..#..##..#..#",
  "#..##..#..#..#.",
  ".#..#..#..##..#",
];

function paintLeaves(data: Uint8ClampedArray, kind: "oak" | "birch" | "dark" | "arau" | "cerrado" | "apple" | "palm" | "peach" | "caatinga") {
  const S = 16;
  const mask =
    kind === "birch"
      ? BIRCH_LEAF_MASK
      : kind === "dark"
        ? DARK_LEAF_MASK
        : kind === "arau"
          ? ARAU_LEAF_MASK
          : kind === "cerrado"
            ? CERRADO_LEAF_MASK
            : kind === "peach" || kind === "caatinga"
              ? PEACH_LEAF_MASK
              : OAK_LEAF_MASK;
  const seedA = kind === "birch" ? 808 : kind === "dark" ? 909 : kind === "arau" ? 707 : kind === "cerrado" ? 818 : kind === "apple" ? 515 : kind === "palm" ? 414 : kind === "peach" ? 616 : kind === "caatinga" ? 303 : 606;
  const seedB = kind === "birch" ? 811 : kind === "dark" ? 914 : kind === "arau" ? 717 : kind === "cerrado" ? 821 : kind === "apple" ? 518 : kind === "palm" ? 417 : kind === "peach" ? 619 : kind === "caatinga" ? 307 : 611;
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const mx = ((x * S) / TILE) | 0;
      const my = ((y * S) / TILE) | 0;
      const solid = mask[my]!.charAt(mx) === "#";
      const i = (y * TILE + x) * 4;
      if (!solid) {
        data[i] = 0;
        data[i + 1] = 0;
        data[i + 2] = 0;
        data[i + 3] = 0;
        continue;
      }
      const n = hash3(mx, my, seedA);
      const n2 = hash3(mx, my, seedB);
      let r: number, g: number, b: number;
      if (kind === "birch") {
        r = 92;
        g = 168;
        b = 48;
        if (n < 0.22) {
          r = 70;
          g = 132;
          b = 32;
        } else if (n > 0.78) {
          r = 150;
          g = 196;
          b = 62;
        } else if (n2 > 0.8) {
          r = 176;
          g = 186;
          b = 58;
        }
      } else if (kind === "dark") {
        r = 26;
        g = 92;
        b = 58;
        if (n < 0.22) {
          r = 16;
          g = 62;
          b = 40;
        } else if (n > 0.78) {
          r = 48;
          g = 124;
          b = 78;
        } else if (n2 > 0.8) {
          r = 22;
          g = 108;
          b = 72;
        }
      } else if (kind === "arau") {
        r = 36;
        g = 108;
        b = 52;
        if (n < 0.22) {
          r = 22;
          g = 72;
          b = 34;
        } else if (n > 0.78) {
          r = 58;
          g = 142;
          b = 64;
        } else if (n2 > 0.8) {
          r = 28;
          g = 96;
          b = 44;
        }
      } else if (kind === "cerrado") {
        r = 122;
        g = 148;
        b = 42;
        if (n < 0.22) {
          r = 92;
          g = 108;
          b = 28;
        } else if (n > 0.78) {
          r = 168;
          g = 176;
          b = 56;
        } else if (n2 > 0.8) {
          r = 148;
          g = 132;
          b = 40;
        }
      } else if (kind === "apple") {
        r = 64;
        g = 168;
        b = 36;
        if (n2 > 0.84) {
          r = 196;
          g = 36;
          b = 28;
        } else if (n < 0.2) {
          r = 40;
          g = 120;
          b = 24;
        } else if (n > 0.8) {
          r = 110;
          g = 196;
          b = 52;
        }
      } else if (kind === "palm") {
        r = 36;
        g = 148;
        b = 40;
        if ((mx + my * 2) % 4 === 0) {
          r = 22;
          g = 108;
          b = 28;
        } else if (n > 0.75) {
          r = 78;
          g = 186;
          b = 58;
        }
      } else if (kind === "peach") {
        r = 46;
        g = 132;
        b = 36;
        if (n < 0.24) {
          r = 28;
          g = 92;
          b = 24;
        } else if (n > 0.78) {
          r = 68;
          g = 164;
          b = 46;
        }
      } else if (kind === "caatinga") {
        r = 86;
        g = 118;
        b = 46;
        if (n < 0.28) {
          r = 62;
          g = 86;
          b = 34;
        } else if (n > 0.78) {
          r = 128;
          g = 142;
          b = 58;
        }
      } else {
        r = 48;
        g = 120;
        b = 36;
        if (n < 0.22) {
          r = 28;
          g = 78;
          b = 22;
        } else if (n > 0.78) {
          r = 90;
          g = 156;
          b = 50;
        } else if (n2 > 0.8) {
          r = 64;
          g = 132;
          b = 30;
        }
      }
      data[i] = clamp(r + (n - 0.5) * 10);
      data[i + 1] = clamp(g + (n2 - 0.5) * 12);
      data[i + 2] = clamp(b);
      data[i + 3] = 255;
    }
  }
}

export function tileImage(kind: number): ImageData {
  return drawTile(kind);
}

function makeNearestTexture(canvas: HTMLCanvasElement): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.premultiplyAlpha = false;
  tex.needsUpdate = true;
  return tex;
}

export const ATLAS_SIZE = ATLAS_W;
export const TILE_SIZE = TILE;
export const ATLAS_COLS = COLS;

export function createAtlasTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = ATLAS_W;
  canvas.height = ATLAS_H;
  const ctx = canvas.getContext("2d", { alpha: true })!;
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, ATLAS_W, ATLAS_H);
  for (let i = 0; i < 53; i++) {
    if (i === 6) continue;
    const { col, row } = atlasCell(i);
    ctx.putImageData(drawTile(i), col * TILE, row * TILE);
  }
  return makeNearestTexture(canvas);
}

export function createLeafTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = TILE * 9;
  canvas.height = TILE;
  const ctx = canvas.getContext("2d", { alpha: true })!;
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, TILE * 9, TILE);
  const kinds: Array<"oak" | "birch" | "dark" | "arau" | "cerrado" | "apple" | "palm" | "peach" | "caatinga"> = ["oak", "birch", "dark", "arau", "cerrado", "apple", "palm", "peach", "caatinga"];
  for (let i = 0; i < kinds.length; i++) {
    const tile = new ImageData(TILE, TILE);
    paintLeaves(tile.data, kinds[i]!);
    ctx.putImageData(tile, i * TILE, 0);
  }
  return makeNearestTexture(canvas);
}

export const ACID_CONCEPT_NAMES = [
  "Atual",
  "Tóxico",
  "Lima",
  "Vítreo",
  "Enxofre",
  "Musgo",
  "Flúor",
  "Cobre",
] as const;

/** Guardados a pedido: 5 Enxofre e 8 Cobre, para usar depois. Índices 1-based. */
export const ARCHIVED_ACID_CONCEPTS = [5, 8] as const;

/** Conceito 6 (Musgo) — aparência atual do ácido no jogo. */
export const ACTIVE_ACID_CONCEPT = 6;

export function createAcidConceptTexture(kind: number): THREE.CanvasTexture {
  const S = 64;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(S, S);
  const d = img.data;
  const k = ((kind % 8) + 8) % 8;
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const n = valueNoise(x / 8, y / 8, 51 + k * 13);
      const n2 = valueNoise(x / 3.2 + 4, y / 3.4, 57 + k * 17);
      const n3 = hash3(x, y, 71 + k * 9);
      const wave = Math.sin((x + y) * (k === 2 ? 0.9 : 0.45)) * 0.5 + 0.5;
      const drip = Math.sin(x * 0.7 + y * 0.22) * 0.5 + 0.5;
      let r: number, g: number, b: number;
      if (k === 0) {
        r = 150 + n * 50 + wave * 18;
        g = 196 + n * 35 + n2 * 22;
        b = 36 + n * 18 + wave * 10;
        if (n2 > 0.7) {
          r += 28;
          g += 22;
        }
        if (n3 > 0.92) {
          r += 40;
          g += 36;
          b += 12;
        }
      } else if (k === 1) {
        r = 78 + n * 36 + wave * 10;
        g = 214 + n * 28 + n2 * 18;
        b = 44 + n * 14 + wave * 8;
        if (n2 > 0.7) g += 18;
        if (n3 > 0.9) {
          r += 20;
          g += 30;
        }
      } else if (k === 2) {
        r = 150 + n * 28 + wave * 30;
        g = 238 + n * 16 + n2 * 14;
        b = 62 + n * 20 + wave * 16;
        if (n3 > 0.88) {
          r += 50;
          g += 16;
          b += 40;
        }
      } else if (k === 3) {
        r = 188 + n * 22 + wave * 20;
        g = 214 + n * 18 + n2 * 12;
        b = 118 + n * 24 + wave * 22;
        if (n2 > 0.75) {
          r += 28;
          g += 24;
          b += 36;
        }
      } else if (k === 4) {
        r = 214 + n * 36 + n2 * 20;
        g = 196 + n * 28 + wave * 16;
        b = 28 + n * 14;
        if (n2 > 0.62) {
          r += 24;
          g += 10;
        }
        if (n3 > 0.9) {
          r += 30;
          g += 28;
          b += 8;
        }
      } else if (k === 5) {
        r = 36 + n * 22 + n2 * 12;
        g = 72 + n * 28 + wave * 10;
        b = 24 + n * 14;
        if (n3 > 0.86) {
          r += 24;
          g += 32;
          b += 8;
        }
      } else if (k === 6) {
        r = 72 + n * 40 + wave * 18;
        g = 250 + n * 6;
        b = 68 + n * 24 + n2 * 16;
        if (n3 > 0.84) {
          r = 230;
          g = 255;
          b = 180;
        }
      } else {
        r = 36 + n * 22 + drip * 10;
        g = 148 + n * 28 + n2 * 20;
        b = 122 + n * 24 + wave * 18;
        if (n2 > 0.72) {
          g += 22;
          b += 28;
        }
        if (n3 > 0.91) {
          r += 18;
          g += 40;
          b += 36;
        }
      }
      const i = (y * S + x) * 4;
      d[i] = clamp(r);
      d[i + 1] = clamp(g);
      d[i + 2] = clamp(b);
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.globalCompositeOperation = "lighter";
  const streaks = [
    "rgba(230, 230, 80, 0.14)",
    "rgba(180, 255, 90, 0.16)",
    "rgba(220, 255, 140, 0.18)",
    "rgba(240, 250, 210, 0.14)",
    "rgba(255, 230, 70, 0.16)",
    "rgba(78, 110, 42, 0.1)",
    "rgba(180, 255, 160, 0.22)",
    "rgba(90, 210, 190, 0.16)",
  ];
  ctx.strokeStyle = streaks[k]!;
  ctx.lineWidth = k === 5 ? 1.5 : 1;
  for (let i = 0; i < 7; i++) {
    ctx.beginPath();
    const y0 = 4 + i * 9 + (i % 2) * 2;
    ctx.moveTo(0, y0);
    for (let x = 0; x <= S; x += 4) {
      const wobble = k === 7 ? Math.sin(x * 0.4 + i) * 5 : Math.sin(x * 0.22 + i) * 2.2;
      ctx.lineTo(x, y0 + wobble);
    }
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";
  const tex = makeNearestTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

export const WATER_CONCEPT_NAMES = [
  "Atual",
  "Cristal",
  "Oceano",
  "Lago",
  "Gelo",
  "Turquesa",
  "Profunda",
  "Aurora",
] as const;

/** Guardados a pedido: os demais da galeria de água, para usar depois. Índices 1-based. */
export const ARCHIVED_WATER_CONCEPTS = [2, 3, 4, 5, 6, 7, 8] as const;

export function createWaterConceptTexture(kind: number): THREE.CanvasTexture {
  const S = 64;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(S, S);
  const d = img.data;
  const k = ((kind % 8) + 8) % 8;
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const n = valueNoise(x / 8, y / 8, 19 + k * 11);
      const n2 = valueNoise(x / 3.2 + 4, y / 3.4, 23 + k * 13);
      const n3 = hash3(x, y, 41 + k * 7);
      const wave = Math.sin((x + y) * (k === 1 || k === 4 ? 0.22 : k === 2 ? 0.7 : 0.45)) * 0.5 + 0.5;
      const drip = Math.sin(x * 0.55 + y * 0.28) * 0.5 + 0.5;
      let r: number, g: number, b: number;
      if (k === 0) {
        r = 100 + n * 28 + wave * 20;
        g = 166 + n * 22 + n2 * 12;
        b = 164 + n * 22 + wave * 18;
        if (n2 > 0.72) {
          r += 16;
          g += 20;
          b += 26;
        }
        if (n3 > 0.93) {
          r += 28;
          g += 30;
          b += 36;
        }
      } else if (k === 1) {
        r = 168 + n * 22 + wave * 18;
        g = 214 + n * 16 + n2 * 12;
        b = 226 + n * 14 + wave * 16;
        if (n3 > 0.88) {
          r += 36;
          g += 28;
          b += 24;
        }
      } else if (k === 2) {
        r = 36 + n * 22 + wave * 12;
        g = 88 + n * 26 + n2 * 16;
        b = 186 + n * 28 + wave * 18;
        if (n2 > 0.7) {
          g += 18;
          b += 22;
        }
        if (n3 > 0.9) {
          r += 24;
          g += 36;
          b += 40;
        }
      } else if (k === 3) {
        r = 62 + n * 24 + wave * 10;
        g = 148 + n * 28 + n2 * 18;
        b = 118 + n * 22 + wave * 16;
        if (n3 > 0.86) {
          r += 28;
          g += 36;
          b += 22;
        }
      } else if (k === 4) {
        r = 196 + n * 16 + wave * 14;
        g = 224 + n * 12 + n2 * 8;
        b = 238 + n * 10 + wave * 10;
        if (n3 > 0.9) {
          r = 255;
          g = 255;
          b = 255;
        }
      } else if (k === 5) {
        r = 28 + n * 22 + drip * 8;
        g = 186 + n * 22 + wave * 16;
        b = 176 + n * 24 + n2 * 16;
        if (n2 > 0.72) {
          g += 24;
          b += 20;
        }
        if (n3 > 0.9) {
          r += 40;
          g += 36;
          b += 32;
        }
      } else if (k === 6) {
        r = 16 + n * 18 + wave * 8;
        g = 38 + n * 22 + n2 * 12;
        b = 86 + n * 28 + wave * 16;
        if (n3 > 0.84) {
          r += 22;
          g += 36;
          b += 48;
        }
      } else {
        r = 72 + n * 28 + wave * 18;
        g = 188 + n * 20 + n2 * 16;
        b = 204 + n * 18 + drip * 12;
        if (n3 > 0.86) {
          r = 210;
          g = 245;
          b = 255;
        }
      }
      const i = (y * S + x) * 4;
      d[i] = clamp(r);
      d[i + 1] = clamp(g);
      d[i + 2] = clamp(b);
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.globalCompositeOperation = "lighter";
  const streaks = [
    "rgba(210, 240, 255, 0.14)",
    "rgba(240, 250, 255, 0.18)",
    "rgba(120, 170, 255, 0.16)",
    "rgba(160, 230, 190, 0.14)",
    "rgba(230, 245, 255, 0.2)",
    "rgba(80, 230, 210, 0.16)",
    "rgba(70, 110, 180, 0.12)",
    "rgba(160, 240, 255, 0.2)",
  ];
  ctx.strokeStyle = streaks[k]!;
  ctx.lineWidth = k === 6 ? 1.5 : 1;
  for (let i = 0; i < 7; i++) {
    ctx.beginPath();
    const y0 = 4 + i * 9 + (i % 2) * 2;
    ctx.moveTo(0, y0);
    for (let x = 0; x <= S; x += 4) {
      const wobble = k === 5 || k === 7 ? Math.sin(x * 0.38 + i) * 3.4 : Math.sin(x * 0.22 + i) * 2.2;
      ctx.lineTo(x, y0 + wobble);
    }
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";
  const tex = makeNearestTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

export function makeConceptLiquidMat(
  map: THREE.Texture,
  opacity: number,
  tint: [number, number, number],
): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uMap: { value: map },
      uLight: { value: 1 },
      uOpacity: { value: opacity },
      uTint: { value: new THREE.Vector3(tint[0], tint[1], tint[2]) },
    },
    vertexShader: `
      attribute vec3 color;
      varying vec2 vUv;
      varying vec3 vNorm;
      varying vec3 vWorld;
      varying vec3 vColor;
      void main() {
        vUv = uv;
        vColor = color;
        vNorm = normalize(normalMatrix * normal);
        vec4 w = modelMatrix * vec4(position, 1.0);
        vWorld = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform sampler2D uMap;
      uniform float uLight;
      uniform float uOpacity;
      uniform vec3 uTint;
      varying vec2 vUv;
      varying vec3 vNorm;
      varying vec3 vWorld;
      varying vec3 vColor;
      void main() {
        vec2 uv = vUv + vec2(uTime * 0.016, uTime * 0.011);
        uv += 0.028 * vec2(
          sin(vWorld.x * 1.6 + uTime * 0.95),
          cos(vWorld.z * 1.4 + uTime * 0.8)
        );
        vec3 tex = texture2D(uMap, uv).rgb * uTint * vColor.z;
        float nd = max(dot(normalize(vNorm), normalize(vec3(0.35, 1.0, 0.25))), 0.0);
        float fres = pow(1.0 - abs(dot(normalize(vNorm), vec3(0.0, 1.0, 0.0))), 2.2);
        float light = 0.55 + 0.5 * nd;
        vec3 col = tex * light * uLight + uTint * 0.22 * fres;
        gl_FragColor = vec4(col, uOpacity + fres * 0.16);
      }
    `,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
}


/** Conceito 1 (Atual) — aparência atual da água no jogo. */
export const ACTIVE_WATER_CONCEPT = 1;

export function createWaterTexture(): THREE.CanvasTexture {
  return createWaterConceptTexture(ACTIVE_WATER_CONCEPT - 1);
}

export function createAcidTexture(): THREE.CanvasTexture {
  return createAcidConceptTexture(ACTIVE_ACID_CONCEPT - 1);
}

export function createMudTexture(): THREE.CanvasTexture {
  const S = 64;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(S, S);
  const d = img.data;
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const n = hash3(x, y, 5);
      const tone = hash3(x, y, 11);
      const wet = hash3(x, y, 3);
      let r = 92;
      let g = 70;
      let b = 42;
      if (wet > 0.72) {
        r = 62;
        g = 74;
        b = 40;
      } else if (tone > 0.8) {
        r = 118;
        g = 92;
        b = 58;
      } else if (tone < 0.15) {
        r = 58;
        g = 44;
        b = 28;
      }
      if (n > 0.9) {
        r = 118;
        g = 92;
        b = 58;
      } else if (n > 0.82 && y > 2 && hash3(x, y - 2, 9) > 0.9) {
        r = 58;
        g = 44;
        b = 28;
      }
      const i = (y * S + x) * 4;
      d[i] = clamp(r);
      d[i + 1] = clamp(g);
      d[i + 2] = clamp(b);
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = makeNearestTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function createLiquidTexture(kind: "water" | "acid"): THREE.CanvasTexture {
  const S = 64;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(S, S);
  const d = img.data;
  const acid = kind === "acid";
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const n = valueNoise(x / 8, y / 8, acid ? 51 : 19);
      const n2 = valueNoise(x / 3.2 + 4, y / 3.4, acid ? 57 : 23);
      const n3 = hash3(x, y, acid ? 71 : 41);
      const wave = Math.sin((x + y) * 0.45) * 0.5 + 0.5;
      let r: number, g: number, b: number;
      if (acid) {
        r = 150 + n * 50 + wave * 18;
        g = 196 + n * 35 + n2 * 22;
        b = 36 + n * 18 + wave * 10;
        if (n2 > 0.7) {
          r += 28;
          g += 22;
        }
        if (n3 > 0.92) {
          r += 40;
          g += 36;
          b += 12;
        }
      } else {
        r = 100 + n * 28 + wave * 20;
        g = 166 + n * 22 + n2 * 12;
        b = 164 + n * 22 + wave * 18;
        if (n2 > 0.72) {
          r += 16;
          g += 20;
          b += 26;
        }
        if (n3 > 0.93) {
          r += 28;
          g += 30;
          b += 36;
        }
      }
      const i = (y * S + x) * 4;
      d[i] = clamp(r);
      d[i + 1] = clamp(g);
      d[i + 2] = clamp(b);
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.globalCompositeOperation = "lighter";
  if (acid) ctx.strokeStyle = "rgba(230, 230, 80, 0.14)";
  else ctx.strokeStyle = "rgba(210, 240, 255, 0.14)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 7; i++) {
    ctx.beginPath();
    const y0 = 4 + i * 9 + (i % 2) * 2;
    ctx.moveTo(0, y0);
    for (let x = 0; x <= S; x += 4) {
      ctx.lineTo(x, y0 + Math.sin(x * 0.22 + i) * 2.2);
    }
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";
  const tex = makeNearestTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

export function tileUv(tile: number): { u0: number; v0: number; u1: number; v1: number } {
  const { col, row } = atlasCell(tile);
  const insetU = 1 / ATLAS_W;
  const insetV = 1 / ATLAS_H;
  const u0 = col / ATLAS_SPAN + insetU;
  const u1 = (col + 1) / ATLAS_SPAN - insetU;
  const v1 = 1 - row / ROWS - insetV;
  const v0 = 1 - (row + 1) / ROWS + insetV;
  return { u0, v0, u1, v1 };
}

export function leafUv(tile = 0): { u0: number; v0: number; u1: number; v1: number } {
  const cols = 9;
  const insetU = 0.5 / (TILE * cols);
  const insetV = 0.5 / TILE;
  const u0 = tile / cols + insetU;
  const u1 = (tile + 1) / cols - insetU;
  const v0 = insetV;
  const v1 = 1 - insetV;
  return { u0, v0, u1, v1 };
}

const STEM_COLS = 4;
const STEM_ROWS = 12;

export function createStemTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = TILE * STEM_COLS;
  canvas.height = TILE * STEM_ROWS;
  const ctx = canvas.getContext("2d", { alpha: true })!;
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < 48; i++) {
    const col = i % STEM_COLS;
    const row = (i / STEM_COLS) | 0;
    const tile =
      i === 47
        ? drawDroopWeed()
        : i === 46
        ? drawMacambira()
        : i >= 44
        ? drawGardenFlower(i - 44)
        : i >= 36
          ? drawCropTile(2, i - 36)
        : i >= 28
          ? drawCropTile(1, i - 28)
          : i >= 20
            ? drawCropTile(0, i - 20)
            : i === 9
              ? drawRicciaTile()
              : i >= 16
                ? drawVineTile(i - 16)
                : i >= 10
                  ? drawWeedTile(i - 10)
                  : drawStemTile(i);
    ctx.putImageData(tile, col * TILE, row * TILE);
  }
  return makeNearestTexture(canvas);
}

export function stemUv(tile: number): { u0: number; v0: number; u1: number; v1: number } {
  const col = tile % STEM_COLS;
  const row = (tile / STEM_COLS) | 0;
  const inset = 0.5 / (TILE * STEM_COLS);
  const u0 = col / STEM_COLS + inset;
  const u1 = (col + 1) / STEM_COLS - inset;
  const v1 = 1 - row / STEM_ROWS - inset;
  const v0 = 1 - (row + 1) / STEM_ROWS + inset;
  return { u0, v0, u1, v1 };
}

function paintDisc(
  d: Uint8ClampedArray,
  cx: number,
  cy: number,
  r: number,
  fill: [number, number, number],
  hi: [number, number, number],
  shade: [number, number, number],
) {
  for (let y = -r; y <= r; y++) {
    for (let x = -r; x <= r; x++) {
      if (x * x + y * y > r * r + 0.3) continue;
      const col = x > r * 0.28 && y > 0 ? shade : x < 0 && y < r * 0.4 ? hi : fill;
      px(d, (cx + x) | 0, (cy + y) | 0, col[0], col[1], col[2]);
    }
  }
}

function paintTomatoLeaf(d: Uint8ClampedArray, x: number, y: number, dir: number, tier: number) {
  const dark: [number, number, number] = [32, 90, 26];
  const mid: [number, number, number] = [58, 140, 40];
  const lite: [number, number, number] = [128, 198, 78];
  const n = tier <= 0 ? 3 : tier === 1 ? 5 : 7;
  for (let i = 0; i <= n; i++) {
    const c = i === 0 ? dark : mid;
    px(d, x + dir * i, y, c[0], c[1], c[2]);
  }
  for (let i = 1; i <= n; i++) {
    const lx = x + dir * i;
    px(d, lx, y - 1, mid[0], mid[1], mid[2]);
    px(d, lx + dir, y - 2, lite[0], lite[1], lite[2]);
    px(d, lx + dir, y - 1, dark[0], dark[1], dark[2]);
    px(d, lx, y + 1, mid[0], mid[1], mid[2]);
    px(d, lx + dir, y + 1, lite[0], lite[1], lite[2]);
    px(d, lx + dir, y + 2, dark[0], dark[1], dark[2]);
    if (tier >= 2 && i % 2 === 0) {
      px(d, lx + dir * 2, y - 2, lite[0], lite[1], lite[2]);
      px(d, lx + dir * 2, y + 2, mid[0], mid[1], mid[2]);
    }
  }
  px(d, x + dir * (n + 1), y, lite[0], lite[1], lite[2]);
  px(d, x + dir * (n + 1), y - 1, mid[0], mid[1], mid[2]);
}

function paintTomatoFlower(d: Uint8ClampedArray, x: number, y: number) {
  px(d, x, y, 244, 226, 90);
  px(d, x - 1, y, 210, 170, 40);
  px(d, x + 1, y, 210, 170, 40);
  px(d, x, y - 1, 255, 246, 170);
  px(d, x, y + 1, 180, 130, 28);
}

function paintTomatoFruit(d: Uint8ClampedArray, cx: number, cy: number, r: number, ripe: number) {
  const pal: [[number, number, number], [number, number, number], [number, number, number]][] = [
    [
      [106, 170, 50],
      [214, 236, 128],
      [48, 96, 24],
    ],
    [
      [224, 122, 40],
      [250, 198, 124],
      [148, 68, 16],
    ],
    [
      [206, 48, 34],
      [248, 164, 138],
      [128, 22, 16],
    ],
    [
      [168, 204, 108],
      [214, 232, 156],
      [96, 140, 58],
    ],
  ];
  const set = pal[ripe] ?? pal[0]!;
  if (r <= 1) {
    px(d, cx, cy, set[0][0], set[0][1], set[0][2]);
    px(d, cx, cy - 1, 47, 122, 34);
    return;
  }
  paintDisc(d, cx, cy, r, set[0], set[1], set[2]);
  const gy = (cy - r) | 0;
  const gx = cx | 0;
  px(d, gx, gy, 30, 80, 24);
  px(d, gx - 1, gy, 47, 122, 34);
  px(d, gx + 1, gy, 47, 122, 34);
  px(d, gx, gy - 1, 96, 176, 58);
  px(d, gx - 1, gy - 1, 47, 122, 34);
  px(d, gx + 1, gy - 1, 47, 122, 34);
}

function paintVeined(
  d: Uint8ClampedArray,
  h: (x: number, y: number, s?: number) => number,
  base: [number, number, number],
  vein: [number, number, number],
  light: [number, number, number],
  dark: [number, number, number],
) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const v = Math.abs(Math.sin(x * 0.42 + y * 0.16 + h(x, y, 2) * 1.4));
      let r = base[0];
      let g = base[1];
      let b = base[2];
      if (v < 0.16) {
        r = vein[0];
        g = vein[1];
        b = vein[2];
      } else if (n > 0.84) {
        r = light[0];
        g = light[1];
        b = light[2];
      } else if (n < 0.12) {
        r = dark[0];
        g = dark[1];
        b = dark[2];
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintBrickCourse(
  d: Uint8ClampedArray,
  h: (x: number, y: number, s?: number) => number,
  fill: [number, number, number],
  light: [number, number, number],
  shade: [number, number, number],
  mortar: [number, number, number],
) {
  const bh = 8;
  const bw = 16;
  for (let y = 0; y < TILE; y++) {
    const row = (y / bh) | 0;
    const inRow = y % bh;
    const shift = (row & 1) * (bw >> 1);
    for (let x = 0; x < TILE; x++) {
      const bx = (x + shift) % bw;
      if (inRow === 0 || bx === 0) {
        px(d, x, y, mortar[0], mortar[1], mortar[2]);
        continue;
      }
      const n = h(x, y);
      const speckle = h(x, y, 3);
      let r = fill[0];
      let g = fill[1];
      let b = fill[2];
      if (speckle > 0.86) {
        r = light[0];
        g = light[1];
        b = light[2];
      } else if (n < 0.18 || inRow === bh - 1) {
        r = shade[0];
        g = shade[1];
        b = shade[2];
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintCaatingaGrass(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 5);
      let r = 186;
      let g = 164;
      let b = 72;
      if (n < 0.18) {
        r = 150;
        g = 124;
        b = 52;
      } else if (n > 0.84) {
        r = 214;
        g = 196;
        b = 96;
      } else if (n2 > 0.9) {
        r = 122;
        g = 132;
        b = 48;
      }
      const tuft = Math.sin(x * 1.8 + y * 0.45) * 0.5 + 0.5;
      if (tuft > 0.74 && n > 0.4) {
        g += 18;
        r -= 8;
      }
      px(d, x, y, r + (n - 0.5) * 12, g + (n2 - 0.5) * 10, b);
    }
  }
}

function paintBrejoGrass(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const wet = h(x, y, 3);
      let r = 58;
      let g = 122;
      let b = 78;
      if (wet > 0.72) {
        r = 40;
        g = 92;
        b = 70;
      } else if (n > 0.82) {
        r = 104;
        g = 168;
        b = 112;
      } else if (n < 0.16) {
        r = 36;
        g = 84;
        b = 58;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintBrejoSoil(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const wet = h(x, y, 4);
      let r = 58;
      let g = 40;
      let b = 30;
      if (wet > 0.78) {
        r = 42;
        g = 58;
        b = 36;
      } else if (n > 0.8) {
        r = 78;
        g = 56;
        b = 40;
      } else if (n < 0.18) {
        r = 36;
        g = 24;
        b = 18;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintBrejoSide(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintBrejoSoil(d, h);
  for (let x = 0; x < TILE; x++) {
    const edge = 7 + ((h(x, 0, 8) * 3) | 0);
    for (let y = 0; y < edge; y++) {
      const n = h(x, y, 2);
      px(d, x, y, n < 0.25 ? 36 : 58, n < 0.25 ? 84 : 122, n < 0.25 ? 58 : 78);
    }
  }
}

function paintCaatingaSoil(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 4);
      let r = 206 + n * 18;
      let g = 184 + n * 12;
      let b = 140 + n * 10;
      if (n2 > 0.86) {
        r -= 22;
        g -= 16;
        b -= 10;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintCaatingaSide(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintCaatingaSoil(d, h);
  for (let x = 0; x < TILE; x++) {
    const edge = 8 + ((h(x, 0, 8) * 4) | 0);
    for (let y = 0; y < edge; y++) {
      const n = h(x, y, 2);
      let r = 186;
      let g = 164;
      let b = 72;
      if (n < 0.25) {
        r = 140;
        g = 116;
        b = 48;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintLajedo(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y, 6);
      const slab = x < 14 ? 0 : x < 24 ? 1 : 2;
      let r = 214 + slab * 8;
      let g = 206 + slab * 4;
      let b = 186;
      if (n > 0.82) {
        r += 16;
        g += 14;
        b += 12;
      }
      const crack = Math.abs(x - 14) < 1 || Math.abs(x - 24) < 1 || (y > 18 && y < 20 && x > 4);
      if (crack) {
        r = 150;
        g = 140;
        b = 124;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintMandacaru(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const groove = x % 7 === 0 || x % 7 === 1;
      const n = h(x, y);
      let r = groove ? 52 : 108;
      let g = groove ? 78 : 142;
      let b = groove ? 40 : 62;
      if (!groove && n > 0.8) {
        r += 16;
        g += 18;
      }
      if (groove && y % 5 === 0) {
        r = 40;
        g = 48;
        b = 28;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintCaatingaBark(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const twist = Math.sin(y * 0.35 + x * 0.15) * 2;
      const n = h(x + twist, y);
      let r = 112 + n * 28;
      let g = 90 + n * 16;
      let b = 64;
      if (Math.abs(x - 8 - twist) < 1.2 || Math.abs(x - 22 + twist) < 1.2) {
        r -= 28;
        g -= 20;
        b -= 12;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintCaatingaRings(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  const cx = 16;
  const cy = 16;
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const dist = Math.hypot(x - cx, y - cy);
      const ring = Math.sin(dist * 1.3);
      const n = h(x, y);
      let r = 132 + ring * 18 + n * 10;
      let g = 104 + ring * 12;
      let b = 72;
      if (dist > 14) {
        r = 78;
        g = 60;
        b = 42;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function drawMacambira(): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const leaf = (x0: number, y0: number, x1: number, y1: number, tip: boolean) => {
    const steps = 10;
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const x = (x0 + (x1 - x0) * t) | 0;
      const y = (y0 + (y1 - y0) * t) | 0;
      const red = tip && t > 0.72;
      px(d, x, y, red ? 150 : 86, red ? 64 : 132, red ? 42 : 52);
      px(d, x + 1, y, red ? 120 : 64, red ? 48 : 108, red ? 36 : 42);
    }
  };
  leaf(16, 28, 16, 10, true);
  leaf(16, 26, 6, 14, true);
  leaf(16, 26, 26, 14, true);
  leaf(15, 24, 8, 22, false);
  leaf(17, 24, 24, 22, false);
  leaf(16, 27, 11, 18, true);
  leaf(16, 27, 21, 18, true);
  return img;
}

function paintMarbleVase(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintVeined(d, h, [232, 224, 214], [168, 156, 176], [248, 244, 236], [196, 186, 174]);
}

function paintMarbleBrick(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintBrickCourse(d, h, [228, 218, 198], [244, 238, 224], [196, 184, 168], [150, 140, 156]);
}

function paintMarble(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintVeined(d, h, [228, 218, 198], [168, 158, 176], [244, 238, 224], [196, 184, 168]);
}

function paintMarbleBroken(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  const faces: [number, number, number][] = [
    [232, 220, 200],
    [188, 176, 162],
    [214, 206, 190],
    [156, 146, 138],
  ];
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const lineA = x * 0.55 + y * 0.22;
      const lineB = -x * 0.18 + y * 0.72;
      const lineC = (x - 15) * 0.42 - (y - 11) * 0.3;
      let facet = 0;
      if (lineA > 14) facet = 1;
      if (lineB > 15) facet = 2;
      if (lineC > 1.5 && y < 22) facet = 3;
      let cr = faces[facet]![0];
      let cg = faces[facet]![1];
      let cb = faces[facet]![2];
      const edge = Math.min(Math.abs(lineA - 14), Math.abs(lineB - 15), Math.abs(lineC - 1.5));
      if (edge < 1.05) {
        cr = 78;
        cg = 70;
        cb = 76;
      } else if (edge < 2.1) {
        cr -= 30;
        cg -= 26;
        cb -= 20;
      }
      const n = h(x, y);
      cr += (n - 0.5) * 8;
      cg += (n - 0.5) * 6;
      cb += (n - 0.5) * 6;
      px(d, x, y, cr, cg, cb);
    }
  }
  const slab = (x0: number, y0: number, x1: number, y1: number, crack: boolean) => {
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const rimT = y === y0 || x === x0;
        const rimB = y === y1 || x === x1;
        let r = 214;
        let g = 206;
        let b = 194;
        if (rimT) {
          r = 242;
          g = 236;
          b = 224;
        } else if (rimB) {
          r = 132;
          g = 122;
          b = 118;
        }
        if (crack && y === ((y0 + y1) >> 1) && x > x0 + 1 && x < x1) {
          r = 86;
          g = 78;
          b = 84;
        }
        px(d, x, y, r, g, b);
      }
    }
  };
  slab(2, 3, 13, 14, true);
  slab(17, 2, 30, 11, false);
  slab(15, 16, 29, 29, true);
}

function paintMarbleLawn(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const n2 = h(x, y, 3);
      let r = 132;
      let g = 196;
      let b = 64;
      if (n < 0.12) {
        r = 96;
        g = 156;
        b = 42;
      } else if (n > 0.82) {
        r = 176;
        g = 220;
        b = 88;
      } else if (n2 > 0.9) {
        r = 196;
        g = 208;
        b = 78;
      }
      const tuft = Math.sin(x * 1.7 + y * 0.4) * 0.5 + 0.5;
      if (tuft > 0.72 && n > 0.4) {
        g += 14;
        r -= 6;
      }
      px(d, x, y, r + (n - 0.5) * 16, g + (n2 - 0.5) * 14, b + (n - 0.5) * 10);
    }
  }
}

function paintMarbleSide(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintMarble(d, h);
  for (let x = 0; x < TILE; x++) {
    const edge = 9 + ((h(x, 0, 8) * 5) | 0);
    for (let y = 0; y < edge; y++) {
      const n = h(x, y, 2);
      let r = 132;
      let g = 196;
      let b = 64;
      if (n < 0.2) {
        r = 96;
        g = 156;
        b = 42;
      } else if (n > 0.85) {
        r = 176;
        g = 220;
        b = 88;
      }
      if (y > edge - 2) {
        r = mix(r, 214, 0.35);
        g = mix(g, 196, 0.35);
        b = mix(b, 160, 0.35);
      }
      px(d, x, y, r, g, b);
    }
  }
}

function paintMarbleOrange(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintBrickCourse(d, h, [214, 128, 58], [232, 156, 78], [168, 88, 36], [120, 72, 40]);
}

function paintMarblePurple(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintBrickCourse(d, h, [138, 128, 150], [168, 160, 178], [96, 86, 118], [72, 64, 84]);
}

function paintMarbleBlue(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintVeined(d, h, [232, 224, 210], [58, 112, 196], [246, 242, 232], [36, 78, 156]);
}

function paintGreenBrick(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  paintBrickCourse(d, h, [104, 144, 104], [176, 216, 176], [72, 104, 72], [0, 72, 0]);
}

function paintRustMetal(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const rust = h(x * 2, y, 5);
      const streak = Math.abs(((x * 3 + y * 5) % 13) - 6) <= 1;
      if (rust > 0.58 || (streak && rust > 0.34)) {
        px(d, x, y, streak ? 168 : 146, streak ? 72 : 86, streak ? 28 : 42);
      } else if (n > 0.72) {
        px(d, x, y, 198, 186, 166);
      } else if (n < 0.22) {
        px(d, x, y, 108, 96, 82);
      } else {
        px(d, x, y, 164, 150, 132);
      }
    }
  }
}

function paintMonumentBase(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const frame = x < 3 || y < 3 || x >= TILE - 3 || y >= TILE - 3;
      const panel = x >= 7 && x < TILE - 7 && y >= 7 && y < TILE - 7;
      const n = h(x, y);
      if (frame) px(d, x, y, 96, 78, 118);
      else if (panel) px(d, x, y, 206 + n * 12, 196 + n * 8, 176);
      else px(d, x, y, 230, 218, 198);
    }
  }
}

function paintMonumentShaft(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const flute = x % 8;
      const n = h(x, y, 2);
      if (flute === 0) px(d, x, y, 118, 102, 136);
      else if (flute <= 2) px(d, x, y, 186, 170, 148);
      else px(d, x, y, 236 + n * 8, 226, 204);
    }
  }
}

function paintMonumentCrown(d: Uint8ClampedArray, _h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      if (y >= 12 && y <= 16) px(d, x, y, 214, 146, 62);
      else if (y >= 18 && y <= 20) px(d, x, y, 124, 102, 142);
      else px(d, x, y, 244, 232, 208);
    }
  }
}

function paintMud(d: Uint8ClampedArray, h: (x: number, y: number, s?: number) => number) {
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = h(x, y);
      const wet = h(x, y, 3);
      let r = 92;
      let g = 70;
      let b = 42;
      if (wet > 0.72) {
        r = 62;
        g = 74;
        b = 40;
      } else if (n > 0.8) {
        r = 118;
        g = 92;
        b = 58;
      } else if (n < 0.15) {
        r = 58;
        g = 44;
        b = 28;
      }
      px(d, x, y, r, g, b);
    }
  }
}

function drawGardenFlower(kind: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const iris = kind === 1;
  const cx = 16;
  for (let y = 14; y < TILE; y++) px(d, cx, y, 42, 120, 36);
  px(d, cx - 1, 20, 56, 150, 42);
  px(d, cx + 1, 22, 56, 150, 42);
  px(d, cx - 3, 21, 70, 168, 48);
  px(d, cx + 3, 23, 70, 168, 48);
  const petal = iris ? [122, 72, 196] : [244, 242, 232];
  const edge = iris ? [78, 42, 140] : [196, 190, 170];
  const heart = iris ? [236, 196, 64] : [232, 186, 48];
  for (let y = -5; y <= 4; y++) {
    for (let x = -5; x <= 5; x++) {
      const band = Math.abs(y) < 2 || Math.abs(x) < 2;
      if (!band && x * x + y * y > 22) continue;
      const col = x * x + y * y < 3 ? heart : Math.abs(x) + Math.abs(y) > 6 ? edge : petal;
      px(d, cx + x, 12 + y, col[0], col[1], col[2]);
    }
  }
  return img;
}

/** Cacho: one stem, compound leaves, then a single bunch of fruit. */
function drawTomatoCacho(stage: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const base = TILE - 1;
  const h = [4, 9, 13, 16, 18, 21, 23, 25][stage] ?? 9;
  const top = base - h;
  const cx = 16;
  for (let y = top; y <= base; y++) {
    px(d, cx, y, y % 2 ? 34 : 52, y % 2 ? 96 : 132, y % 2 ? 26 : 38);
    if (y % 3 === 0) px(d, cx + 1, y, 78, 164, 54);
  }
  if (stage <= 0) {
    paintDisc(d, cx - 3, top, 2, [78, 168, 48], [168, 220, 110], [40, 100, 24]);
    paintDisc(d, cx + 3, top, 2, [62, 146, 38], [140, 200, 90], [36, 90, 22]);
    return img;
  }
  const tier = stage < 3 ? 0 : stage < 5 ? 1 : 2;
  const leaves = Math.min(4, stage);
  for (let i = 0; i < leaves; i++) {
    const y = Math.min(base - 3, top + 2 + i * 4);
    const leafTier = stage >= 5 && i < 2 ? 2 : tier;
    paintTomatoLeaf(d, cx, y, i % 2 === 0 ? -1 : 1, leafTier);
  }
  const bunchY = Math.min(base - 7, top + 7);
  if (stage === 2 || stage === 3) {
    paintTomatoFlower(d, cx - 2, bunchY);
    if (stage === 3) paintTomatoFlower(d, cx + 3, bunchY + 3);
  }
  if (stage >= 4) {
    const ripe = stage >= 7 ? 2 : stage === 6 ? 3 : 0;
    const rad = stage >= 6 ? 3 : 2;
    paintTomatoFruit(d, cx - 4, bunchY, rad, ripe);
    paintTomatoFruit(d, cx + 3, bunchY + 1, rad, ripe);
    if (stage >= 5) paintTomatoFruit(d, cx, bunchY + 4, stage >= 7 ? 3 : 2, ripe);
    if (stage >= 7) paintTomatoFruit(d, cx + 5, bunchY + 5, 2, 2);
  }
  return img;
}

function drawCropTile(kind: number, stage: number): ImageData {
  if (kind === 2) return drawTomatoCacho(stage);
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const height = 8 + stage * 3;
  const cx = 15.5;
  const camapu = kind === 1;
  for (let y = 0; y < TILE; y++) {
    const fromBottom = TILE - 1 - y;
    if (fromBottom > height) continue;
    const t = fromBottom / Math.max(1, height);
    const spread = camapu ? 0.4 + stage * 0.08 : 1.2 + stage * 0.55;
    const stems = camapu ? 1 : stage < 2 ? 1 : 3;
    for (let s = 0; s < stems; s++) {
      const side = s === 0 ? 0 : s === 1 ? -1 : 1;
      const xMid = cx + side * spread * t;
      const width = camapu ? 1.15 : 1.3 + (1 - t) * 0.4;
      for (let x = 0; x < TILE; x++) {
        if (Math.abs(x - xMid) > width) continue;
        const edge = Math.abs(x - xMid) > width * 0.55;
        let r = edge ? 28 : 46;
        let g = edge ? 96 : 138;
        let b = edge ? 24 : 36;
        if (!camapu && stage >= 5 && fromBottom > height * 0.62 && hash3(x, y, 7) > 0.45) {
          r = 176;
          g = 48;
          b = 32;
        }
        if (camapu && stage >= 4 && fromBottom > height * 0.45 && fromBottom < height * 0.82) {
          const ly = height * 0.64;
          const lx = cx;
          const dx = (x - lx) / (3.2 + stage * 0.35);
          const dy = (fromBottom - ly) / (2.4 + stage * 0.28);
          if (dx * dx + dy * dy < 1) {
            r = stage >= 7 ? 214 : 168;
            g = stage >= 7 ? 138 : 150;
            b = stage >= 7 ? 48 : 62;
          }
        }
        px(d, x, y, r, g, b, 255);
      }
    }
  }
  return img;
}

function drawStemTile(kind: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const attached = kind === 8;
  const stage = attached ? 7 : kind;
  const height = 7 + stage * 3.4;
  const cx = 15.5;
  for (let y = 0; y < TILE; y++) {
    const fromBottom = TILE - 1 - y;
    if (fromBottom > height) continue;
    const t = fromBottom / Math.max(1, height);
    const lean = attached ? t * 11 : Math.sin(t * 4.2 + stage) * (1.2 + stage * 0.12);
    const xMid = cx + lean;
    const width = attached ? 1.6 + t * 0.6 : 1.1 + stage * 0.08;
    const brown = stage / 7;
    const r0 = mix(48, 92, brown);
    const g0 = mix(128, 96, brown);
    const b0 = mix(32, 28, brown);
    for (let x = 0; x < TILE; x++) {
      const dist = Math.abs(x - xMid);
      if (dist > width + 0.7) continue;
      let r = r0,
        g = g0,
        b = b0;
      if (dist > width * 0.45) {
        r *= 0.72;
        g *= 0.78;
        b *= 0.7;
      } else {
        r += 18;
        g += 14;
      }
      if (stage >= 4 && fromBottom > 6 && fromBottom % 6 === 0 && dist < 1.2) {
        const side = x > xMid ? 1 : -1;
        const lx = (xMid + side * (2.5 + (stage - 4))) | 0;
        if (Math.abs(x - lx) <= 1 && hash3(x, y, 40) > 0.25) {
          r = 56;
          g = 132;
          b = 36;
        }
      }
      px(d, x, y, r, g, b, 255);
    }
  }
  if (stage >= 2) {
    px(d, 14, TILE - 2, 70, 110, 32);
    px(d, 17, TILE - 2, 62, 102, 28);
  }
  return img;
}

function drawDroopWeed(): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const mask = [
    ".............ooooooo............",
    "...........oooooooooooo.........",
    ".........oooooo...ooooooo.......",
    ".......ooooo.........oooooo.....",
    ".....ooooo.............oooo.....",
    "....ooo..................ooo....",
    "...ooo....................oo....",
    "..ooo......oooooooo.......oo....",
    "..oo.....oooooooooooo....oo.....",
    ".oo.....oooo....ooooo...oo......",
    ".oo....ooo........ooo..oo.......",
    ".o....ooo..........oo..o........",
    ".o....oo............o..o........",
    "o....oo.............o..o........",
    "o...oo..............o..oo.......",
    "o...o...............o...oo......",
    "oo..................o....oo.....",
    "o...................oo....o.....",
  ];
  const pal: Record<string, [number, number, number]> = {
    o: [86, 168, 42],
    "#": [54, 122, 28],
  };
  const y0 = TILE - mask.length;
  for (let y = 0; y < mask.length; y++) {
    const row = mask[y] ?? "";
    for (let x = 0; x < TILE; x++) {
      const c = pal[row.charAt(x)];
      if (!c) continue;
      px(d, x, y0 + y, c[0], c[1], c[2]);
    }
  }
  return img;
}

function drawWeedTile(kind: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const blit = (mask: string[], pal: Record<string, [number, number, number]>) => {
    for (let y = 0; y < 16; y++) {
      const row = mask[y] ?? "";
      for (let x = 0; x < 16; x++) {
        const ch = row.charAt(x);
        if (!ch || ch === ".") continue;
        const c = pal[ch];
        if (!c) continue;
        px(d, x * 2, y * 2, c[0], c[1], c[2]);
        px(d, x * 2 + 1, y * 2, c[0], c[1], c[2]);
        px(d, x * 2, y * 2 + 1, c[0], c[1], c[2]);
        px(d, x * 2 + 1, y * 2 + 1, c[0], c[1], c[2]);
      }
    }
  };

  if (kind === 0) {
    blit(
      [
        "................",
        ".......#........",
        "..#....#....#...",
        "..#.#..#..#.#.#.",
        ".#..#.#.#.#..#..",
        ".#.#.#.#.#.#.#.#",
        "#..#.#o#.#.#..#.",
        ".#.#.#.#.#.#.#.#",
        "#.#o#.#.#o#.#.#.",
        ".#.#.#.#.#.#.#o#",
        "#.#.#o#.#.#.#.#.",
        "o#.#.#.#.#o#.#.#",
        ".#o#.#.#.#.#.#o.",
        "#.#.#o#.#.#o#.#.",
        ".#.#.#.#.#.#.#.#",
        "#o#.#.#o#.#.#o#.",
      ],
      { "#": [74, 162, 48], o: [40, 108, 28], "+": [148, 204, 76] },
    );
  } else if (kind === 1) {
    blit(
      [
        "..#..#.#.#..#...",
        ".#.#.#.#.#.#.#.+",
        ".#.#.#...#.#.#.#",
        "#..#.#.#.#.#..#.",
        "#.#.#o#.#.#.#.#.",
        ".#.#.#.#.#o#.#..",
        "#.#.#.#.#.#.#.#.",
        ".#o#.#..#.#.#o#.",
        "#.#.#.#.#.#.#.#.",
        ".#.#o#.#.#.#.#.+",
        "o#.#.#.#o#.#.#o.",
        ".#.#.#.#.#.#.#.#",
        "#o#.#o#.#.#o#.#o",
        ".#.#.#.#.#.#.#.#",
        "#.#o#.#.#o#.#.#.",
        ".#.#.#.#.#.#.#o#",
      ],
      { "#": [52, 140, 40], o: [28, 92, 26], "+": [176, 188, 72] },
    );
  } else if (kind === 2) {
    blit(
      [
        "................",
        "................",
        "........*.......",
        "....*...#..*....",
        "...*.#..#.#.*...",
        "....#.#.#.#.....",
        "..#..#.#.#..#...",
        "...#.#o#o#.#....",
        "..#.#.#.#.#.#...",
        ".#..#o#.#o#..#..",
        "..#.#.#.#.#.#...",
        ".#.#o#.#.#o#.#..",
        "..#.#.#.#.#.#...",
        ".#o#.#o#.#.#o#..",
        "..#.#.#.#.#.#...",
        ".#.#.#o#.#.#.#..",
      ],
      { "#": [186, 154, 48], o: [138, 108, 32], "*": [220, 196, 88] },
    );
  } else if (kind === 3) {
    blit(
      [
        ".##...#.#..##..#",
        ".##...#.#..##..#",
        ".j#...#j#..j#..#",
        ".##...#.#..##..j",
        ".##...j.#..##..#",
        ".##...#.#..##..#",
        ".#j...#.#..j#..#",
        ".##...#.#..##..j",
        "##....#j#..##..#",
        ".##...#.#..##..#",
        ".##...#.#..#j..#",
        ".##...j.#..##..#",
        ".##...#.#..##..j",
        ".j#...#.#..##..#",
        ".##...#o#..##..#",
        ".oo...#o#..oo..o",
      ],
      { "#": [64, 156, 52], o: [36, 96, 40], j: [226, 220, 150] },
    );
  } else if (kind === 4) {
    blit(
      [
        "................",
        "...#.......#....",
        "...##.....#.#...",
        "....#.#.#.#.....",
        ".....##.##......",
        "......#.#.......",
        ".....#.#.#......",
        "....#..#..#.....",
        ".......##.......",
        ".......##.......",
        ".......oo.......",
        ".......##.......",
        ".......oo.......",
        ".......oo.......",
        ".......oo.......",
        ".......oo.......",
      ],
      { "#": [128, 92, 40], o: [78, 54, 24] },
    );
  } else {
    blit(
      [
        "......+...+.....",
        "....#.+.#.+.#...",
        "..#.#.#.#.#.#..+",
        "..#..#.#.#..#.#.",
        ".#.#.#...#.#.#..",
        "#..#.#.#.#.#..#.",
        "#.#.#o#.#.#.#.#.",
        ".#.#.#.#.#o#.#..",
        "#.#.#.#.#.#.#.#.",
        ".#o#.#..#.#.#o#.",
        "#.#.#.#.#.#.#.#.",
        ".#.#o#.#.#.#.#.+",
        "o#.#.#.#o#.#.#o.",
        ".#.#.#.#.#.#.#.#",
        "#o#.#o#.#.#o#.#.",
        ".#.#.#.#.#.#.#.#",
      ],
      { "#": [48, 138, 40], o: [28, 92, 26], "+": [176, 188, 72] },
    );
  }
  return img;
}

/** 0 = trepadeira (Minecraft vine). 1 = jiboia, larger variegated leaves. */
function drawVineTile(kind: number): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const blit = (mask: string[], pal: Record<string, [number, number, number]>) => {
    for (let y = 0; y < 16; y++) {
      const row = mask[y] ?? "";
      for (let x = 0; x < 16; x++) {
        const ch = row.charAt(x);
        if (!ch || ch === ".") continue;
        const c = pal[ch];
        if (!c) continue;
        px(d, x * 2, y * 2, c[0], c[1], c[2]);
        px(d, x * 2 + 1, y * 2, c[0], c[1], c[2]);
        px(d, x * 2, y * 2 + 1, c[0], c[1], c[2]);
        px(d, x * 2 + 1, y * 2 + 1, c[0], c[1], c[2]);
      }
    }
  };
  if (kind === 0) {
    blit(
      [
        "....##..........",
        "...####.........",
        "..##..##........",
        ".##....#..##....",
        ".#......####....",
        "........#..#....",
        ".....##.........",
        "...#####........",
        "..##...##.......",
        ".##.....#.......",
        "#...............",
        ".......##.......",
        "......####......",
        ".....##..##.....",
        ".....#....#.....",
        "................",
      ],
      { "#": [48, 122, 34] },
    );
  } else {
    blit(
      [
        "................",
        "......##........",
        "....##oo##......",
        "...#oooooo#.....",
        "...#oo##oo#.....",
        "....#o##o#......",
        ".....##..#......",
        ".......#........",
        "......#.........",
        ".....##.........",
        "...##oo##.......",
        "..#oooooo#......",
        "..#oo##oo#......",
        "...#o##o#.......",
        "....#..#........",
        ".....#..........",
      ],
      { "#": [78, 150, 36], o: [214, 206, 78] },
    );
  }
  return img;
}

/** Musgo aquático dicotômico (Riccia), com pérolas de ar presas no talo. */
function drawRicciaTile(): ImageData {
  const img = new ImageData(TILE, TILE);
  const d = img.data;
  const forks: { x0: number; y0: number; x1: number; y1: number; x2: number; y2: number; x3: number; y3: number }[] = [
    { x0: 16, y0: 31, x1: 12, y1: 20, x2: 7, y2: 11, x3: 4, y3: 5 },
    { x0: 16, y0: 31, x1: 20, y1: 19, x2: 25, y2: 10, x3: 28, y3: 4 },
    { x0: 16, y0: 31, x1: 16, y1: 18, x2: 18, y2: 9, x3: 16, y3: 3 },
    { x0: 11, y0: 31, x1: 8, y1: 21, x2: 4, y2: 13, x3: 2, y3: 7 },
    { x0: 21, y0: 31, x1: 24, y1: 21, x2: 28, y2: 13, x3: 30, y3: 7 },
    { x0: 13, y0: 26, x1: 9, y1: 16, x2: 11, y2: 8, x3: 8, y3: 3 },
    { x0: 19, y0: 26, x1: 23, y1: 15, x2: 21, y2: 7, x3: 24, y3: 2 },
    { x0: 16, y0: 24, x1: 13, y1: 14, x2: 14, y2: 6, x3: 12, y3: 1 },
    { x0: 16, y0: 24, x1: 19, y1: 13, x2: 22, y2: 6, x3: 20, y3: 1 },
    { x0: 7, y0: 29, x1: 5, y1: 20, x2: 2, y2: 12, x3: 1, y3: 6 },
    { x0: 25, y0: 29, x1: 27, y1: 19, x2: 30, y2: 11, x3: 31, y3: 5 },
    { x0: 10, y0: 22, x1: 6, y1: 14, x2: 7, y2: 7, x3: 5, y3: 2 },
    { x0: 22, y0: 22, x1: 26, y1: 13, x2: 25, y2: 6, x3: 27, y3: 2 },
  ];
  const paint = (x: number, y: number, w: number, tip: number) => {
    for (let oy = -w; oy <= w; oy++) {
      for (let ox = -w; ox <= w; ox++) {
        if (ox * ox + oy * oy > w * w + 0.35) continue;
        const n = hash3(x + ox, y + oy, 404);
        let r = 72 + n * 50 + tip * 28;
        let g = 168 + n * 48 + tip * 32;
        let b = 42 + n * 24 + tip * 10;
        if (n < 0.18) {
          r = 36 + tip * 10;
          g = 112 + tip * 16;
          b = 32;
        } else if (n > 0.84) {
          r = 168;
          g = 232;
          b = 92;
        }
        px(d, x + ox, y + oy, r, g, b, 255);
      }
    }
  };
  const stroke = (ax: number, ay: number, bx: number, by: number, w0: number, w1: number) => {
    const steps = Math.max(7, Math.hypot(bx - ax, by - ay) * 1.55);
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = ax + (bx - ax) * t + Math.sin(t * 6.1 + ax) * 0.55;
      const y = ay + (by - ay) * t;
      paint(x | 0, y | 0, w0 + (w1 - w0) * t, t);
    }
  };
  for (const f of forks) {
    stroke(f.x0, f.y0, f.x1, f.y1, 1.55, 1.2);
    stroke(f.x1, f.y1, f.x2, f.y2, 1.2, 1.0);
    stroke(f.x2, f.y2, f.x3, f.y3, 1.0, 0.72);
  }
  const upright: [number, number, number, number][] = [
    [8, 24, 8, 3],
    [16, 26, 16, 1],
    [24, 24, 24, 4],
    [12, 20, 11, 2],
    [20, 20, 21, 2],
    [6, 18, 5, 6],
    [26, 18, 27, 5],
  ];
  for (const [ax, ay, bx, by] of upright) {
    stroke(ax, ay, bx, by, 1.35, 0.7);
  }
  const bars: [number, number, number][] = [
    [7, 10, 5],
    [18, 8, 5],
    [12, 14, 4],
    [22, 12, 4],
    [10, 6, 3],
  ];
  for (const [cx, cy, w] of bars) {
    stroke(cx - w, cy, cx + w, cy - 1, 0.9, 0.7);
  }
  for (let i = 0; i < 36; i++) {
    const x = (hash3(i, 9, 411) * 26 + 3) | 0;
    const y = (12 + hash3(i, 11, 412) * 16) | 0;
    if (hash3(x, y, 413) > 0.38) paint(x, y, 1.05, 0.45);
  }
  for (let y = 2; y < 30; y++) {
    for (let x = 2; x < 30; x++) {
      const i = (y * TILE + x) * 4;
      if (!d[i + 3]) continue;
      if (hash3(x, y, 420) > 0.94) {
        d[i + 3] = 0;
        d[i] = 0;
        d[i + 1] = 0;
        d[i + 2] = 0;
      }
    }
  }
  const trapped: [number, number][] = [
    [10, 17],
    [21, 14],
    [15, 8],
    [24, 19],
    [7, 21],
    [18, 11],
    [13, 20],
  ];
  for (const [x, y] of trapped) {
    px(d, x, y, 178, 193, 189, 169);
    px(d, x + 1, y, 153, 184, 178, 151);
    px(d, x, y + 1, 134, 172, 167, 137);
    px(d, x - 1, y, 164, 187, 182, 115);
  }
  return img;
}
