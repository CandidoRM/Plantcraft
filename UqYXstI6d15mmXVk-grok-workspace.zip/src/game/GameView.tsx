import { useEffect, useRef } from "react";
import { Overlay } from "./Overlay";
import { initialHud, useGame } from "./store";

export function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let disposed = false;
    let game: { dispose: () => void } | null = null;

    void import("./engine").then(({ createGame }) => {
      if (disposed || !canvasRef.current) return;
      game = createGame(canvasRef.current);
    });

    return () => {
      disposed = true;
      game?.dispose();
      useGame.setState({ hud: initialHud(), handle: null });
    };
  }, []);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-ink">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onContextMenu={(e) => e.preventDefault()}
      />
      <Overlay />
    </main>
  );
}
