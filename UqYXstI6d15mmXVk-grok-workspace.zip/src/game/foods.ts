import {
  FOOD_ACAI,
  FOOD_AVOCADO,
  FOOD_BANANA,
  FOOD_CASSAVA,
  FOOD_CASSAVA_RAW,
  FOOD_COCONUT,
  FOOD_CORN,
  FOOD_GUAVA,
  FOOD_MANGO,
  FOOD_ORANGE,
  FOOD_PINEAPPLE,
  FOOD_RICE,
  FOOD_URUCUM,
  FOOD_CAMAPU,
  FOOD_TOMATO,
  FOOD_PEACH,
  MELON_SLICE,
} from "./blocks";

export type FoodDef = { hunger: number; sat: number; seconds: number };

/** Hunger points are out of 20, like a full bar of 10 marks. */
export const FOODS: Record<number, FoodDef> = {
  [FOOD_ORANGE]: { hunger: 2, sat: 1.6, seconds: 1.1 },
  [FOOD_BANANA]: { hunger: 3, sat: 2.4, seconds: 1.15 },
  [FOOD_GUAVA]: { hunger: 3, sat: 2.4, seconds: 1.3 },
  [FOOD_CORN]: { hunger: 4, sat: 4.8, seconds: 1.4 },
  [FOOD_MANGO]: { hunger: 4, sat: 4.8, seconds: 1.6 },
  [FOOD_PINEAPPLE]: { hunger: 4, sat: 3.6, seconds: 1.6 },
  [FOOD_AVOCADO]: { hunger: 4, sat: 7.2, seconds: 1.6 },
  [FOOD_COCONUT]: { hunger: 5, sat: 6, seconds: 1.6 },
  [FOOD_CASSAVA]: { hunger: 5, sat: 6, seconds: 1.6 },
  [FOOD_RICE]: { hunger: 6, sat: 7.2, seconds: 1.6 },
  [FOOD_ACAI]: { hunger: 7, sat: 8.4, seconds: 1.6 },
  [FOOD_CASSAVA_RAW]: { hunger: 1, sat: 0.2, seconds: 1.6 },
  [MELON_SLICE]: { hunger: 2, sat: 1.2, seconds: 1 },
  [FOOD_URUCUM]: { hunger: 2, sat: 1.4, seconds: 1.1 },
  [FOOD_CAMAPU]: { hunger: 4, sat: 3.2, seconds: 1.3 },
  [FOOD_TOMATO]: { hunger: 3, sat: 2.2, seconds: 1.15 },
  [FOOD_PEACH]: { hunger: 4, sat: 2.4, seconds: 1.3 },
};

export function foodDef(id: number): FoodDef | null {
  return FOODS[id] ?? null;
}
