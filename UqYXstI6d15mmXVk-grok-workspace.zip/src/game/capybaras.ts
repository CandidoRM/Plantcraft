import * as THREE from "three";

const FUR = "#c48a4a";
const FUR_D = "#9a6434";
const FUR_L = "#d4a868";
const MUZZLE = "#6a4428";
const MUZZLE_D = "#4a2e18";
const NOSE = "#2a1a10";
const EYE_W = "#f2eee4";
const EYE_B = "#14110e";
const HOOF = "#4a3018";
const BELLY = "#d2b07a";

export type CapyConcept = {
  id: string;
  name: string;
  blurb: string;
};

export const CAPY_CONCEPTS: CapyConcept[] = [
  { id: "pao", name: "Pão", blurb: "Silhueta de pão: um bloco de corpo, cara na frente." },
  { id: "blocos", name: "Blocos", blurb: "Estilo animal do Minecraft: focinho largo na face." },
  { id: "degrau", name: "Degrau", blurb: "Cara em dois degraus, orelha miúda, perna curta." },
  { id: "sentada", name: "Sentada", blurb: "O pão sentado, o meme." },
  { id: "baixa", name: "Baixa", blurb: "Bem rente ao chão, corpo comprido e largo." },
  { id: "cria", name: "Cria", blurb: "Filhote: cabeça quase do tamanho do corpo." },
];

/** Guardado a pedido: o conceito Roedor da primeira leva, para usar depois. */
export const ROEDOR_CONCEPT: CapyConcept = {
  id: "roedor",
  name: "Roedor",
  blurb: "Corpo alongado, faixa no dorso, incisivos à mostra.",
};

export function makeConceptLabel(index: number, name: string): THREE.Mesh {
  const w = 256;
  const h = 128;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "rgba(18, 20, 16, 0.82)";
  ctx.beginPath();
  ctx.roundRect(8, 16, w - 16, h - 24, 16);
  ctx.fill();
  ctx.fillStyle = "#6ea35a";
  ctx.font = "700 56px Outfit, Segoe UI, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(String(index), w / 2, 48);
  ctx.fillStyle = "#e8e4d4";
  ctx.font = "600 28px Outfit, Segoe UI, sans-serif";
  ctx.fillText(name, w / 2, 92);
  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.needsUpdate = true;
  const mat = new THREE.MeshBasicMaterial({
    map,
    transparent: true,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.48), mat);
  return mesh;
}

function tex(paint: (ctx: CanvasRenderingContext2D, s: number) => void): THREE.CanvasTexture {
  const s = 16;
  const canvas = document.createElement("canvas");
  canvas.width = s;
  canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  paint(ctx, s);
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

function fill(ctx: CanvasRenderingContext2D, color: string, x: number, y: number, w: number, h: number) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function noiseFur(ctx: CanvasRenderingContext2D, s: number, base: string, dark: string) {
  fill(ctx, base, 0, 0, s, s);
  ctx.fillStyle = dark;
  for (let i = 0; i < 18; i++) {
    const x = (i * 7 + 3) % s;
    const y = (i * 11 + 5) % s;
    ctx.fillRect(x, y, 1, 1);
  }
}

function faceFront(): THREE.CanvasTexture {
  return tex((ctx, s) => {
    noiseFur(ctx, s, FUR, FUR_D);
    fill(ctx, MUZZLE, 1, 5, 14, 11);
    fill(ctx, MUZZLE_D, 2, 8, 12, 7);
    fill(ctx, NOSE, 5, 9, 2, 2);
    fill(ctx, NOSE, 9, 9, 2, 2);
    fill(ctx, NOSE, 6, 13, 4, 1);
  });
}

function faceSide(left: boolean): THREE.CanvasTexture {
  return tex((ctx, s) => {
    noiseFur(ctx, s, FUR, FUR_D);
    fill(ctx, MUZZLE, left ? 10 : 0, 6, 6, 10);
    const ex = left ? 9 : 4;
    fill(ctx, EYE_W, ex, 4, 3, 3);
    fill(ctx, EYE_B, ex + 1, 5, 2, 2);
  });
}

function faceTop(): THREE.CanvasTexture {
  return tex((ctx, s) => noiseFur(ctx, s, FUR, FUR_D));
}

function faceBack(): THREE.CanvasTexture {
  return tex((ctx, s) => noiseFur(ctx, s, FUR_D, FUR));
}

function faceBelly(): THREE.CanvasTexture {
  return tex((ctx, s) => noiseFur(ctx, s, BELLY, FUR_L));
}

function faceBody(): THREE.CanvasTexture {
  return tex((ctx, s) => {
    noiseFur(ctx, s, FUR, FUR_D);
    fill(ctx, BELLY, 0, 11, s, 5);
  });
}

function mats(kind: "head" | "body"): THREE.MeshLambertMaterial[] {
  const wrap = (map: THREE.CanvasTexture) =>
    new THREE.MeshLambertMaterial({ map });
  if (kind === "head") {
    return [
      wrap(faceSide(false)),
      wrap(faceSide(true)),
      wrap(faceTop()),
      wrap(faceBelly()),
      wrap(faceFront()),
      wrap(faceBack()),
    ];
  }
  const side = wrap(faceBody());
  const top = wrap(faceTop());
  const belly = wrap(faceBelly());
  return [side, side, top, belly, side, side];
}

function mesh(
  parent: THREE.Group,
  w: number,
  h: number,
  d: number,
  x: number,
  y: number,
  z: number,
  mat: THREE.Material | THREE.Material[],
) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  parent.add(m);
}

function solid(color: string): THREE.MeshLambertMaterial {
  return new THREE.MeshLambertMaterial({ color });
}

function legs(
  g: THREE.Group,
  ox: number,
  ozF: number,
  ozB: number,
  y: number,
  w: number,
  h: number,
  d: number,
) {
  const hoof = solid(HOOF);
  const fur = solid(FUR_D);
  for (const x of [-ox, ox]) {
    for (const z of [ozF, ozB]) {
      mesh(g, w, h, d, x, y, z, fur);
      mesh(g, w + 0.02, 0.07, d + 0.04, x, y - h / 2 + 0.035, z, hoof);
    }
  }
}

function ears(g: THREE.Group, x: number, y: number, z: number, s = 0.12) {
  const m = solid(FUR_D);
  mesh(g, s, s + 0.02, s * 0.7, x, y, z, m);
  mesh(g, s, s + 0.02, s * 0.7, -x, y, z, m);
}

export function buildCapyConcept(id: string): THREE.Group {
  const g = new THREE.Group();
  switch (id) {
    case "blocos":
      buildBlocos(g);
      break;
    case "degrau":
      buildDegrau(g);
      break;
    case "sentada":
      buildSentada(g);
      break;
    case "baixa":
      buildBaixa(g);
      break;
    case "cria":
      buildCria(g);
      break;
    case "roedor":
      buildRoedor(g);
      break;
    default:
      buildPao(g);
  }
  return g;
}

/** Adult in-game: #2 Blocos + focinho pintado do #1 Pão (sem a caixa extra). */
export function buildCapyAdult(): THREE.Group {
  const g = new THREE.Group();
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.84, 0.58, 1.12, 0, 0.5, -0.04, body);
  mesh(g, 0.72, 0.64, 0.64, 0, 0.56, 0.66, head);
  ears(g, 0.18, 0.94, 0.5, 0.12);
  legs(g, 0.26, 0.32, -0.38, 0.16, 0.2, 0.26, 0.2);
  return g;
}

/** Filhote in-game: conceito #6 Cria. */
export function buildCapyBaby(): THREE.Group {
  const g = new THREE.Group();
  buildCria(g);
  return g;
}

/** One loaf + one brick head. The internet capybara. */
function buildPao(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.92, 0.62, 1.05, 0, 0.46, -0.06, body);
  mesh(g, 0.78, 0.62, 0.7, 0, 0.5, 0.58, head);
  ears(g, 0.2, 0.88, 0.42, 0.13);
  legs(g, 0.28, 0.28, -0.34, 0.14, 0.2, 0.22, 0.2);
}

/** Minecraft animal: cow/pig rig, but muzzle is the whole face. */
function buildBlocos(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.84, 0.58, 1.12, 0, 0.5, -0.04, body);
  mesh(g, 0.72, 0.64, 0.64, 0, 0.56, 0.66, head);
  mesh(g, 0.74, 0.42, 0.12, 0, 0.46, 1.0, solid(MUZZLE));
  ears(g, 0.18, 0.94, 0.5, 0.12);
  legs(g, 0.26, 0.32, -0.38, 0.16, 0.2, 0.26, 0.2);
}

/** Stepped voxel: cranium then a wide muzzle step. */
function buildDegrau(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.96, 0.66, 0.92, 0, 0.48, -0.12, body);
  mesh(g, 0.72, 0.5, 0.4, 0, 0.58, 0.46, head);
  mesh(g, 0.8, 0.44, 0.38, 0, 0.42, 0.78, head);
  ears(g, 0.18, 0.88, 0.38, 0.11);
  legs(g, 0.3, 0.22, -0.36, 0.13, 0.22, 0.18, 0.2);
}

/** Sitting loaf — the meme. */
function buildSentada(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.88, 0.78, 0.8, 0, 0.47, -0.08, body);
  mesh(g, 0.74, 0.58, 0.62, 0, 0.72, 0.42, head);
  mesh(g, 0.76, 0.36, 0.1, 0, 0.6, 0.74, solid(MUZZLE));
  ears(g, 0.18, 1.06, 0.28, 0.12);
  mesh(g, 0.22, 0.28, 0.22, 0.26, 0.16, 0.22, solid(FUR_D));
  mesh(g, 0.22, 0.28, 0.22, -0.26, 0.16, 0.22, solid(FUR_D));
  mesh(g, 0.24, 0.18, 0.28, 0.26, 0.1, -0.28, solid(FUR_D));
  mesh(g, 0.24, 0.18, 0.28, -0.26, 0.1, -0.28, solid(FUR_D));
  mesh(g, 0.24, 0.07, 0.26, 0.26, 0.04, 0.24, solid(HOOF));
  mesh(g, 0.24, 0.07, 0.26, -0.26, 0.04, 0.24, solid(HOOF));
}

/** Extra low and long, like a real adult. */
function buildBaixa(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 1.05, 0.52, 1.28, 0, 0.4, -0.08, body);
  mesh(g, 0.82, 0.52, 0.62, 0, 0.44, 0.68, head);
  mesh(g, 0.84, 0.34, 0.1, 0, 0.36, 1.0, solid(MUZZLE));
  ears(g, 0.22, 0.76, 0.52, 0.11);
  legs(g, 0.34, 0.36, -0.44, 0.12, 0.22, 0.16, 0.2);
}

/** Pup: head almost equals the potato. */
function buildCria(g: THREE.Group) {
  const body = mats("body");
  const head = mats("head");
  mesh(g, 0.7, 0.48, 0.7, 0, 0.38, -0.12, body);
  mesh(g, 0.78, 0.64, 0.7, 0, 0.52, 0.38, head);
  mesh(g, 0.8, 0.4, 0.1, 0, 0.42, 0.74, solid(MUZZLE));
  ears(g, 0.2, 0.9, 0.22, 0.14);
  legs(g, 0.22, 0.22, -0.26, 0.12, 0.18, 0.16, 0.18);
}

/** Conceito Roedor da primeira leva — guardado para uso futuro. */
export function buildRoedor(g: THREE.Group) {
  const fur = 0x8a6238;
  const dark = 0x5c3d22;
  const belly = 0xc4a06a;
  const snout = 0xd2b08a;
  const nose = 0x2a1c12;
  const eye = 0x1a120c;
  const tooth = 0xece6d8;
  const stripe = 0x4a3018;
  const col = (c: number) => new THREE.MeshLambertMaterial({ color: c });
  mesh(g, 0.56, 0.44, 1.12, 0, 0.42, 0, col(fur));
  mesh(g, 0.48, 0.12, 0.7, 0, 0.22, 0.04, col(belly));
  mesh(g, 0.3, 0.1, 0.7, 0, 0.66, -0.06, col(stripe));
  mesh(g, 0.42, 0.36, 0.44, 0, 0.5, 0.62, col(fur));
  mesh(g, 0.3, 0.2, 0.22, 0, 0.4, 0.88, col(snout));
  mesh(g, 0.1, 0.08, 0.06, 0, 0.44, 1.0, col(nose));
  mesh(g, 0.06, 0.12, 0.06, 0.05, 0.3, 0.96, col(tooth));
  mesh(g, 0.06, 0.12, 0.06, -0.05, 0.3, 0.96, col(tooth));
  mesh(g, 0.1, 0.12, 0.08, 0.12, 0.72, 0.58, col(dark));
  mesh(g, 0.1, 0.12, 0.08, -0.12, 0.72, 0.58, col(dark));
  mesh(g, 0.16, 0.22, 0.16, 0.16, 0.11, -0.38, col(dark));
  mesh(g, 0.16, 0.22, 0.16, -0.16, 0.11, -0.38, col(dark));
  mesh(g, 0.16, 0.22, 0.16, 0.16, 0.11, 0.32, col(dark));
  mesh(g, 0.16, 0.22, 0.16, -0.16, 0.11, 0.32, col(dark));
  mesh(g, 0.08, 0.08, 0.06, 0.12, 0.52, 0.82, col(eye));
  mesh(g, 0.08, 0.08, 0.06, -0.12, 0.52, 0.82, col(eye));
}
