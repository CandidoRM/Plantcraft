import * as THREE from "three";
import { buildBird, birdStats, isBirdKind, type BirdKind } from "./birds";
import { buildCapyAdult, buildCapyBaby } from "./capybaras";
import { buildFish, fishStats, isFishKind, type FishKind } from "./fishes";
import { buildRanch, isRanchKind, ranchStats, type RanchKind } from "./ranch";
import { buildRare, isRareKind, rareStats, type RareKind } from "./rares";
import { buildVillager, villagerName, type VillagerRole } from "./villagers";
import { moveAABB } from "./physics";
import type { FluidKind } from "./blocks";
import {
  AIR,
  FARMLAND,
  MELON,
  MELON_SLICE,
  MELON_STEM,
  STEM_DIRS,
  attachFacing,
  isMelonAttach,
  isPlant,
  isRipeCrop,
  isDoor,
  isDoorOpen,
  isGate,
  isGateOpen,
  isLog,
  PLANKS,
  cropFromStage,
  cropKind,
  cropFood,
  isLeaves,
  isSolid,
  isWater,
  isWeed,
  stemFromStage,
} from "./blocks";
import type { World } from "./world";
import { foodDef } from "./foods";

type VillagerHabit = "ceu" | "planta" | "sombra" | "agua" | "pedra" | "seguir" | "espreguicar" | "bicho";

function box(
  parent: THREE.Object3D,
  w: number,
  h: number,
  d: number,
  x: number,
  y: number,
  z: number,
  color: number,
  part?: string,
): THREE.Mesh {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color }),
  );
  mesh.position.set(x, y, z);
  if (part) mesh.userData.part = part;
  parent.add(mesh);
  return mesh;
}

function partGroup(parent: THREE.Object3D, x: number, y: number, z: number, part: string) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.userData.part = part;
  parent.add(g);
  return g;
}

function setEmissive(mesh: THREE.Mesh, hex: number) {
  const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  for (const m of list) {
    const mat = m as THREE.MeshLambertMaterial;
    if (mat.emissive) mat.emissive.setHex(hex);
  }
}

export type CreatureKind = "capivara" | "murcha" | "beholder" | "aldeao" | "louva" | FishKind | RanchKind | RareKind | BirdKind;
export type CreatureStage = "adult" | "baby";

const GROW_S = 90;

export function isFish(kind: CreatureKind): kind is FishKind {
  return isFishKind(kind);
}
export function isRanch(kind: CreatureKind): kind is RanchKind {
  return isRanchKind(kind);
}
export function isRare(kind: CreatureKind): kind is RareKind {
  return isRareKind(kind);
}
export function isBird(kind: CreatureKind): kind is BirdKind {
  return isBirdKind(kind);
}
export function isMonster(kind: CreatureKind): boolean {
  return kind === "murcha" || kind === "beholder";
}

/** Monsters wander and still burn at dawn, but do not chase or hit the player. */
export const MONSTERS_NEUTRAL = true;

export class Creature {
  kind: CreatureKind;
  stage: CreatureStage;
  group: THREE.Group;
  x: number;
  y: number;
  z: number;
  yaw = 0;
  vx = 0;
  vy = 0;
  vz = 0;
  hp = 0;
  maxHp = 0;
  w = 0.5;
  h = 0.5;
  d = 0.5;
  hurtT = 0;
  wanderT = 0;
  tx = 0;
  tz = 0;
  ty = 0;
  growT = 0;
  swimT = Math.random() * 12;
  dashT = 0;
  restT = 0;
  turnLock = 0;
  cruiseT = 0;
  cruiseWait = 8 + Math.random() * 4;
  cruiseMul = 1;
  dryT = 0;
  walkT = Math.random() * 8;
  grazeT = 0;
  hopT = 0;
  flapT = 0;
  perchT = 0;
  pitch = 0;
  bank = 0;
  flying = false;
  homeX = 0;
  homeY = 0;
  homeZ = 0;
  speed = 1;
  alive = true;
  dying = false;
  grounded = false;
  quake = false;
  crushAcc = 0;
  role: VillagerRole = "jardineiro";
  greetT = 0;
  danceT = 0;
  talkT = 0;
  humT = 2;
  lookT = 0;
  lookCd = 2;
  scared = false;
  meetX = 0;
  meetZ = 0;
  food = 0;
  seeds = 0;
  hunger = 16 + Math.random() * 4;
  sat = 3;
  hungerAcc = Math.random() * 8;
  bag: { id: number; n: number }[] = [];
  eatT = 0;
  eating = 0;
  forageT = 4 + Math.random() * 10;
  hungerFill: THREE.Mesh | null = null;
  heldDoor: { x: number; y: number; z: number } | null = null;
  farmT = 1;
  breedT = 8;
  farmMode: "" | "harvest" | "plant" | "share" = "";
  farmX = 0;
  farmY = 0;
  farmZ = 0;
  farmed: "" | "harvest" | "plant" = "";
  paceMul = 1;
  paced = false;
  habit: VillagerHabit = "ceu";
  habitT = 2;
  habitLeft = 0;
  habitX = 0;
  habitZ = 0;
  habitPose: "" | "up" | "crouch" | "peer" | "lean" = "";
  gazeT = 0;
  gazeX = 0;
  gazeZ = 0;
  wary = false;
  curious = false;
  fishing = false;
  willSwim = false;
  repairT = 12;
  buildQueue: { x: number; y: number; z: number; id: number }[] | null = null;
  buildAt = 0;
  needsPlot = false;
  plotCheck = 2;
  wantChild = false;
  childX = 0;
  childZ = 0;
  dieT = 0;
  huntT = 0;
  attackT = 0;
  attackStyle = 0;
  attackLanded = false;
  summonT = 0;
  hoverT = Math.random() * 12;
  idleLookT = Math.random() * 8;
  blinkWait = 2 + Math.random() * 3.5;
  blinkLeft = 0;
  blinkPhase = 0;
  playerHit = 0;
  witnessed = false;
  dieStarted = false;
  fluid: FluidKind | null = null;
  wasFluid: FluidKind | null = null;
  inLeaves = false;
  wasLeaves = false;
  flash: THREE.Mesh[] = [];

  constructor(kind: CreatureKind, x: number, y: number, z: number, stage: CreatureStage = "adult") {
    this.kind = kind;
    this.stage = isMonster(kind) ? "adult" : stage;
    this.x = x;
    this.y = y;
    this.z = z;
    this.group = new THREE.Group();
    this.applyStats();
    this.buildMesh();
    this.homeX = x; this.homeY = y; this.homeZ = z;
    this.tx = x; this.ty = y; this.tz = z;
    this.rollPace();
    if (isBird(kind)) {
      this.flying = kind !== "joaobarro";
      this.perchT = kind === "joaobarro" ? 2 + Math.random() * 3 : 0.4 + Math.random();
    }
    this.sync();
  }

  setHome(x: number, y: number, z: number) {
    this.homeX = x; this.homeY = y; this.homeZ = z;
  }

  setRole(role: VillagerRole) {
    this.role = role;
    if (role === "crianca") this.stage = "baby";
    if (role === "jardineiro") this.seeds = Math.max(this.seeds, 4);
    this.rollPace();
    this.rollHabit();
    this.applyStats();
    this.buildMesh();
    this.sync();
  }

  get baby() {
    return this.stage === "baby";
  }

  get fish() {
    return isFish(this.kind);
  }
  get ranch() {
    return isRanch(this.kind);
  }
  get rare() {
    return isRare(this.kind);
  }
  get bird() {
    return isBird(this.kind);
  }

  label() {
    if (this.kind === "capivara") return this.baby ? "Capivara (filhote)" : "Capivara";
    if (this.kind === "murcha") return "Murcha";
    if (this.kind === "beholder") return "Beholder";
    if (this.kind === "louva") return "Louva-a-deus";
    if (this.kind === "aldeao") return villagerName(this.role, this.baby);
    if (isRanch(this.kind)) return ranchStats(this.kind, this.baby).name;
    if (isRare(this.kind)) return rareStats(this.kind, this.baby).name;
    if (isBird(this.kind)) return birdStats(this.kind, this.baby).name;
    return fishStats(this.kind, this.baby).name;
  }

  private applyStats() {
    if (this.kind === "capivara") {
      if (this.baby) {
        this.w = 0.42;
        this.h = 0.36;
        this.d = 0.35;
        this.hp = this.maxHp = 4;
        this.speed = 0.95;
      } else {
        this.w = 0.9;
        this.h = 0.72;
        this.d = 0.7;
        this.hp = this.maxHp = 8;
        this.speed = 1.15;
      }
    } else if (this.kind === "murcha") {
      this.w = 0.62;
      this.h = 1.88;
      this.d = 0.5;
      this.hp = this.maxHp = 12;
      this.speed = 1.35;
    } else if (this.kind === "beholder") {
      this.w = 0.9;
      this.h = 1.02;
      this.d = 0.9;
      this.hp = this.maxHp = 10;
      this.speed = 0.92;
    } else if (this.kind === "louva") {
      this.w = 0.38;
      this.h = 0.72;
      this.d = 0.32;
      this.hp = this.maxHp = 4;
      this.speed = 0.72;
    } else if (this.kind === "aldeao") {
      if (this.baby || this.role === "crianca") {
        this.w = 0.42;
        this.h = 0.95;
        this.d = 0.42;
        this.hp = this.maxHp = 6;
        this.speed = 1.45;
      } else {
        this.w = 0.6;
        this.h = 1.9;
        this.d = 0.6;
        this.hp = this.maxHp = 10;
        this.speed = 1.05;
      }
    } else if (isRanch(this.kind)) {
      const s = ranchStats(this.kind, this.baby);
      this.w = s.w; this.h = s.h; this.d = s.d; this.hp = this.maxHp = s.hp; this.speed = s.speed;
    } else if (isRare(this.kind)) {
      const s = rareStats(this.kind, this.baby);
      this.w = s.w; this.h = s.h; this.d = s.d; this.hp = this.maxHp = s.hp; this.speed = s.speed;
    } else if (isBird(this.kind)) {
      const s = birdStats(this.kind, this.baby);
      this.w = s.w; this.h = s.h; this.d = s.d; this.hp = this.maxHp = s.hp; this.speed = s.speed;
    } else {
      const s = fishStats(this.kind, this.baby);
      this.w = s.w;
      this.h = s.h;
      this.d = s.d;
      this.hp = this.maxHp = s.hp;
      this.speed = s.speed;
    }
  }

  private clearMesh() {
    while (this.group.children.length) {
      const child = this.group.children[0]!;
      child.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.geometry.dispose();
          const list = Array.isArray(o.material) ? o.material : [o.material];
          for (const m of list) m.dispose();
        }
      });
      this.group.remove(child);
    }
    this.flash = [];
  }

  private buildMesh() {
    this.clearMesh();
    if (this.kind === "capivara") {
      const model = this.baby ? buildCapyBaby() : buildCapyAdult();
      if (this.baby) model.scale.setScalar(0.5);
      this.group.add(model);
    } else if (this.kind === "murcha") {
      this.buildMurcha();
      this.group.scale.setScalar(1);
    } else if (this.kind === "beholder") {
      this.group.add(this.buildBeholder());
    } else if (this.kind === "louva") {
      this.group.add(this.buildLouva());
    } else if (this.kind === "aldeao") {
      this.group.add(buildVillager(this.baby ? "crianca" : this.role, this.baby || this.role === "crianca"));
      if (this.role === "pescador") {
        let arm: THREE.Object3D | null = null;
        this.group.traverse((o) => {
          if (o.userData.part === "armR") arm = o;
        });
        const line = new THREE.Mesh(
          new THREE.BoxGeometry(0.012, 0.012, 1),
          new THREE.MeshLambertMaterial({ color: 0xe7e2d4 }),
        );
        line.name = "fishline";
        line.visible = false;
        (arm ?? this.group).add(line);
      }
      const back = new THREE.Mesh(
        new THREE.BoxGeometry(0.48, 0.07, 0.04),
        new THREE.MeshBasicMaterial({ color: 0x24160e }),
      );
      back.position.set(0, this.h + 0.28, 0);
      back.name = "hungerBack";
      const fill = new THREE.Mesh(
        new THREE.BoxGeometry(0.44, 0.045, 0.05),
        new THREE.MeshBasicMaterial({ color: 0xf08a1a }),
      );
      fill.position.set(0, this.h + 0.28, 0.012);
      fill.name = "hungerFill";
      this.group.add(back, fill);
      this.hungerFill = fill;
    } else if (isRanch(this.kind)) {
      this.group.add(buildRanch(this.kind));
      this.group.scale.setScalar(this.baby ? 0.5 : 1);
    } else if (isRare(this.kind)) {
      this.group.add(buildRare(this.kind));
      this.group.scale.setScalar(this.baby ? 0.5 : 1);
    } else if (isBird(this.kind)) {
      this.group.add(buildBird(this.kind));
      const s = this.baby ? 0.55 : 1;
      this.group.scale.setScalar(this.kind === "beijaflor" ? s * 1.5 : s);
    } else {
      this.group.add(buildFish(this.kind));
      if (this.baby) this.group.scale.setScalar(0.55);
      else this.group.scale.setScalar(1);
    }
    this.flash = [];
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) this.flash.push(o);
    });
  }

  private buildLouva(): THREE.Group {
    const g = new THREE.Group();
    const body = partGroup(g, 0, 0.34, 0, "torso");
    box(body, 0.12, 0.28, 0.1, 0, 0, 0, 0x3e9a32);
    const head = partGroup(g, 0, 0.56, 0.06, "head");
    box(head, 0.12, 0.1, 0.1, 0, 0, 0, 0x4cb83c, "head");
    box(head, 0.04, 0.05, 0.02, -0.04, 0.02, 0.05, 0x1a1a18);
    box(head, 0.04, 0.05, 0.02, 0.04, 0.02, 0.05, 0x1a1a18);
    const armL = partGroup(g, -0.08, 0.46, 0.04, "legFL");
    box(armL, 0.04, 0.16, 0.04, 0, -0.06, 0, 0x2f7a28);
    const armR = partGroup(g, 0.08, 0.46, 0.04, "legFR");
    box(armR, 0.04, 0.16, 0.04, 0, -0.06, 0, 0x2f7a28);
    const legL = partGroup(g, -0.05, 0.22, -0.02, "legBL");
    box(legL, 0.03, 0.2, 0.03, 0, -0.08, 0, 0x246824);
    const legR = partGroup(g, 0.05, 0.22, -0.02, "legBR");
    box(legR, 0.03, 0.2, 0.03, 0, -0.08, 0, 0x246824);
    return g;
  }

  private buildMurcha() {
    const g = this.group;
    const skin = 0x3d4a26;
    const moss = 0x455530;
    const rot = 0x2a2216;
    const dry = 0x6b5a32;
    const vein = 0x1c2410;
    const eye = 0xd8ee6a;
    const claw = 0x1c1810;

    const torso = partGroup(g, 0, 1.04, 0.02, "torso");
    box(torso, 0.5, 0.74, 0.34, 0, 0, 0, skin);
    box(torso, 0.54, 0.14, 0.38, 0, 0.32, 0, dry);
    box(torso, 0.18, 0.3, 0.08, 0, -0.02, 0.18, vein);
    box(torso, 0.12, 0.2, 0.06, 0.16, 0.06, 0.18, 0x243018);

    const head = partGroup(torso, 0, 0.4, 0.04, "head");
    head.rotation.x = 0.28;
    box(head, 0.46, 0.46, 0.46, 0, 0.2, 0, moss);
    box(head, 0.5, 0.08, 0.5, 0, 0.42, 0, rot);
    const eyeL = box(head, 0.12, 0.1, 0.08, 0.13, 0.24, 0.22, eye);
    const eyeR = box(head, 0.12, 0.1, 0.08, -0.13, 0.24, 0.22, eye);
    eyeL.userData.glow = 0x88aa22;
    eyeR.userData.glow = 0x88aa22;
    (eyeL.material as THREE.MeshLambertMaterial).emissive.setHex(0x88aa22);
    (eyeR.material as THREE.MeshLambertMaterial).emissive.setHex(0x88aa22);
    box(head, 0.08, 0.04, 0.04, 0.13, 0.3, 0.26, 0x0c1008);
    box(head, 0.08, 0.04, 0.04, -0.13, 0.3, 0.26, 0x0c1008);
    box(head, 0.24, 0.1, 0.14, 0, 0.06, 0.2, 0x1a140c);
    box(head, 0.08, 0.18, 0.08, 0.22, 0.4, -0.02, rot);
    box(head, 0.08, 0.18, 0.08, -0.22, 0.4, -0.02, rot);
    box(head, 0.16, 0.2, 0.06, 0, 0.28, -0.24, dry);

    const armL = partGroup(torso, 0.36, 0.26, 0, "armL");
    armL.rotation.x = 0.52;
    box(armL, 0.16, 0.76, 0.16, 0.02, -0.3, 0, rot);
    box(armL, 0.12, 0.22, 0.12, 0.02, -0.74, 0.04, dry);
    box(armL, 0.06, 0.18, 0.06, -0.04, -0.88, 0.1, claw);
    box(armL, 0.06, 0.2, 0.06, 0.08, -0.9, 0.1, claw);
    box(armL, 0.06, 0.16, 0.06, 0.02, -0.86, 0.16, claw);

    const armR = partGroup(torso, -0.36, 0.26, 0, "armR");
    armR.rotation.x = 0.52;
    box(armR, 0.16, 0.76, 0.16, -0.02, -0.3, 0, rot);
    box(armR, 0.12, 0.22, 0.12, -0.02, -0.74, 0.04, dry);
    box(armR, 0.06, 0.18, 0.06, 0.04, -0.88, 0.1, claw);
    box(armR, 0.06, 0.2, 0.06, -0.08, -0.9, 0.1, claw);
    box(armR, 0.06, 0.16, 0.06, -0.02, -0.86, 0.16, claw);

    const legL = partGroup(g, 0.14, 0.66, 0, "legL");
    box(legL, 0.18, 0.68, 0.18, 0, -0.34, 0, rot);
    box(legL, 0.22, 0.08, 0.3, 0, -0.68, 0.05, dry);

    const legR = partGroup(g, -0.14, 0.66, 0, "legR");
    box(legR, 0.18, 0.68, 0.18, 0, -0.34, 0, rot);
    box(legR, 0.22, 0.08, 0.3, 0, -0.68, 0.05, dry);
  }

  private buildBeholder(): THREE.Group {
    const g = new THREE.Group();
    g.userData.part = "eyeRoot";

    const sclera = new THREE.Mesh(
      new THREE.SphereGeometry(0.44, 18, 14),
      new THREE.MeshLambertMaterial({ color: 0xf3ece1, emissive: 0x181018 }),
    );
    sclera.position.y = 0.48;
    g.add(sclera);

    const gaze = partGroup(g, 0, 0.48, 0, "gaze");
    const iris = new THREE.Mesh(
      new THREE.CircleGeometry(0.24, 18),
      new THREE.MeshLambertMaterial({ color: 0x5c1a86, emissive: 0x3a0870, side: THREE.DoubleSide }),
    );
    iris.position.set(0, 0.02, 0.42);
    iris.userData.part = "iris";
    iris.userData.glow = 0x3a0870;
    gaze.add(iris);

    const pupil = new THREE.Mesh(
      new THREE.CircleGeometry(0.11, 14),
      new THREE.MeshLambertMaterial({ color: 0x08060c, emissive: 0x120418, side: THREE.DoubleSide }),
    );
    pupil.position.set(0, 0.02, 0.43);
    pupil.userData.part = "pupil";
    pupil.userData.glow = 0x120418;
    gaze.add(pupil);

    const shine = new THREE.Mesh(
      new THREE.CircleGeometry(0.035, 8),
      new THREE.MeshLambertMaterial({ color: 0xfff8ee, emissive: 0x887060, side: THREE.DoubleSide }),
    );
    shine.position.set(0.07, 0.08, 0.44);
    shine.userData.glow = 0x887060;
    gaze.add(shine);

    const lid = new THREE.MeshLambertMaterial({ color: 0x2c1c2a });
    box(g, 0.86, 0.14, 0.58, 0, 0.86, 0.06, 0x2c1c2a);
    box(g, 0.84, 0.12, 0.54, 0, 0.14, 0.04, 0x2c1c2a);
    const lidTop = partGroup(g, 0, 0.62, 0.02, "lidTop");
    const topLid = new THREE.Mesh(
      new THREE.SphereGeometry(0.45, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.28),
      lid,
    );
    topLid.rotation.x = -0.18;
    lidTop.add(topLid);
    const lidBot = partGroup(g, 0, 0.32, 0.02, "lidBot");
    const botLid = new THREE.Mesh(
      new THREE.SphereGeometry(0.45, 12, 8, 0, Math.PI * 2, Math.PI * 0.74, Math.PI * 0.26),
      lid,
    );
    botLid.rotation.x = 0.14;
    lidBot.add(botLid);

    const vein = new THREE.MeshLambertMaterial({ color: 0xb05060 });
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2 + 0.3;
      const v = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 0.28), vein);
      v.position.set(Math.cos(a) * 0.32, 0.48 + Math.sin(a * 1.7) * 0.1, Math.sin(a) * 0.26);
      v.lookAt(0, 0.48, 0);
      g.add(v);
    }

    const plate = new THREE.MeshLambertMaterial({ color: 0x4a3048 });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.1, 0.08), plate);
      p.position.set(Math.cos(a) * 0.4, 0.48, Math.sin(a) * 0.4);
      p.lookAt(0, 0.48, 0);
      g.add(p);
    }

    const stalkMat = new THREE.MeshLambertMaterial({ color: 0x6a4860 });
    const tinyIris = new THREE.MeshLambertMaterial({ color: 0xc8d48a, emissive: 0x304818 });
    const stalks: [number, number, number, number][] = [
      [0.38, 0.78, 0.12, 0.35],
      [-0.36, 0.8, 0.08, -0.4],
      [0.2, 0.9, -0.22, 0.15],
      [-0.16, 0.86, -0.28, -0.2],
      [0.02, 0.22, -0.38, 0],
    ];
    stalks.forEach(([sx, sy, sz, tilt], i) => {
      const stg = partGroup(g, sx, sy, sz, `stalk${i}`);
      stg.rotation.z = tilt;
      const st = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.28, 0.07), stalkMat);
      st.position.y = 0;
      stg.add(st);
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.085, 8, 6), tinyIris);
      e.position.set(Math.sin(tilt) * 0.02, 0.18, 0.05);
      e.userData.glow = 0x304818;
      stg.add(e);
    });
    return g;
  }

  growUp() {
    if (!this.baby) return;
    if (this.kind === "aldeao") {
      const jobs: VillagerRole[] = ["jardineiro", "contador", "vigia", "palerma"];
      this.role = jobs[(Math.random() * jobs.length) | 0]!;
      if (this.role === "jardineiro") this.seeds = Math.max(this.seeds, 3);
      this.rollHabit();
    }
    this.stage = "adult";
    this.growT = 0;
    this.applyStats();
    this.buildMesh();
  }

  sync() {
    this.group.position.set(this.x, this.y, this.z);
    this.group.rotation.y = this.yaw;
    if (this.bird) {
      this.group.rotation.x = this.pitch;
      this.group.rotation.z = this.bank;
    }
    if (this.hungerFill) {
      const k = Math.max(0, Math.min(1, this.hunger / 20));
      this.hungerFill.scale.x = Math.max(0.04, k);
      this.hungerFill.position.x = -0.22 * (1 - k);
      const mat = this.hungerFill.material as THREE.MeshBasicMaterial;
      mat.color.setHex(this.hunger <= 6 ? 0xd24a2a : 0xf08a1a);
    }
  }

  aabb() {
    return { x: this.x - this.w / 2, y: this.y, z: this.z - this.d / 2, w: this.w, h: this.h, d: this.d };
  }

  hitByRay(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number): number | null {
    const a = this.aabb();
    const tmin = [
      (a.x - ox) / (dx || 1e-8),
      (a.y - oy) / (dy || 1e-8),
      (a.z - oz) / (dz || 1e-8),
    ];
    const tmax = [
      (a.x + a.w - ox) / (dx || 1e-8),
      (a.y + a.h - oy) / (dy || 1e-8),
      (a.z + a.d - oz) / (dz || 1e-8),
    ];
    let t0 = 0;
    let t1 = max;
    for (let i = 0; i < 3; i++) {
      const lo = Math.min(tmin[i]!, tmax[i]!);
      const hi = Math.max(tmin[i]!, tmax[i]!);
      t0 = Math.max(t0, lo);
      t1 = Math.min(t1, hi);
      if (t0 > t1) return null;
    }
    return t0;
  }

  damage(n: number) {
    if (this.dying) return;
    this.hp -= n;
    this.hurtT = 0.18;
    if (this.hp <= 0) this.beginDie();
  }

  beginDie() {
    if (this.dying) return;
    this.dying = true;
    this.dieStarted = true;
    this.dieT = 0;
    this.vx = 0;
    this.vz = 0;
  }

  private headBlocked(world: World): boolean {
    const x = Math.floor(this.x);
    const z = Math.floor(this.z);
    const y = Math.floor(this.y + this.h);
    const id = world.getBlock(x, y, z);
    return isSolid(id) && !isLeaves(id);
  }

  /** Jump only to climb one block, and only when the ceiling above is clear. */
  private canHopStep(world: World, wishX: number, wishZ: number): boolean {
    const sx = Math.abs(wishX) > 0.2 ? Math.sign(wishX) : 0;
    const sz = Math.abs(wishZ) > 0.2 ? Math.sign(wishZ) : 0;
    if (sx === 0 && sz === 0) return false;
    const ix = Math.floor(this.x + sx * 0.62);
    const iz = Math.floor(this.z + sz * 0.62);
    const iy = Math.floor(this.y + 0.05);
    const solid = (x: number, y: number, z: number) => {
      const id = world.getBlock(x, y, z);
      return isSolid(id) && !isLeaves(id);
    };
    if (!solid(ix, iy, iz) || solid(ix, iy + 1, iz)) return false;
    const hx = Math.floor(this.x);
    const hz = Math.floor(this.z);
    if (solid(hx, Math.floor(this.y + this.h + 0.2), hz)) return false;
    return true;
  }

  private swimAround(world: World, tx: number, tz: number): { x: number; z: number } | null {
    const ix = Math.floor(this.x);
    const iz = Math.floor(this.z);
    const iy = Math.floor(this.y + this.h * 0.65);
    let best: { x: number; z: number; d: number } | null = null;
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
      [1, 1],
      [1, -1],
      [-1, 1],
      [-1, -1],
    ];
    for (const [dx, dz] of dirs) {
      const x = ix + dx;
      const z = iz + dz;
      const head = world.getBlock(x, iy, z);
      if (isSolid(head) && !isLeaves(head)) continue;
      const d = (x + 0.5 - tx) * (x + 0.5 - tx) + (z + 0.5 - tz) * (z + 0.5 - tz);
      if (!best || d < best.d) best = { x: x + 0.5, z: z + 0.5, d };
    }
    return best;
  }

  private nearestShore(world: World): { x: number; z: number } | null {
    const ix = Math.floor(this.x);
    const iz = Math.floor(this.z);
    let best: { x: number; z: number; d: number } | null = null;
    for (let dz = -8; dz <= 8; dz++) {
      for (let dx = -8; dx <= 8; dx++) {
        if (dx === 0 && dz === 0) continue;
        const sy = world.spawnY(ix + dx, iz + dz);
        if (sy == null) continue;
        if (world.fluidAt(ix + dx + 0.5, sy + 0.4, iz + dz + 0.5)) continue;
        const above = world.getBlock(ix + dx, sy + 1, iz + dz);
        if (isSolid(above) && !isLeaves(above)) continue;
        if (Math.abs(sy - this.y) > 5) continue;
        const d = dx * dx + dz * dz;
        if (!best || d < best.d) best = { x: ix + dx + 0.5, z: iz + dz + 0.5, d };
      }
    }
    return best;
  }

  private nearestHole(world: World): { x: number; z: number; d: number } | null {
    let best: { x: number; z: number; d: number } | null = null;
    for (const h of world.holes) {
      const d = Math.hypot(h.x - this.x, h.z - this.z);
      if (!best || d < best.d) best = { x: h.x, z: h.z, d };
    }
    return best;
  }

  private aldeaoCount(herd: Creature[]) {
    let n = 0;
    for (const o of herd) if (o.alive && o.kind === "aldeao") n++;
    return n;
  }

  private rollPace() {
    if (this.kind !== "aldeao" || this.paced) return;
    this.paced = true;
    const r = Math.random();
    this.paceMul = r < 1 / 3 ? 0.85 : r < 2 / 3 ? 1 : 1.15;
    this.habitT = 2 + Math.random() * 8;
    this.wary = Math.random() < 0.75;
    this.curious = Math.random() < 0.7;
  }

  private rollHabit() {
    if (this.kind !== "aldeao") return;
    const table: Record<VillagerRole, VillagerHabit[]> = {
      jardineiro: ["planta", "pedra", "agua"],
      contador: ["ceu", "seguir", "espreguicar"],
      vigia: ["sombra", "agua", "ceu"],
      palerma: ["espreguicar", "pedra", "sombra"],
      pescador: ["agua", "ceu", "seguir"],
      crianca: ["seguir", "pedra", "planta"],
    };
    const list = table[this.role];
    this.habit = list[(Math.random() * list.length) | 0]!;
  }

  private nearbySpot(world: World, radius: number, pred: (x: number, y: number, z: number) => boolean): { x: number; z: number } | null {
    const sx = Math.floor(this.x);
    const sz = Math.floor(this.z);
    let best: { x: number; z: number; d: number } | null = null;
    for (let dz = -radius; dz <= radius; dz++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const x = sx + dx;
        const z = sz + dz;
        const y = world.surfaceY(x, z);
        if (!pred(x, y, z)) continue;
        const d = dx * dx + dz * dz;
        if (!best || d < best.d) best = { x: x + 0.5, z: z + 0.5, d };
      }
    }
    return best ? { x: best.x, z: best.z } : null;
  }

  private tryStartHabit(
    dt: number,
    world: World,
    player: { x: number; z: number },
    herd: Creature[],
    night: boolean,
    busy: boolean,
  ) {
    if (this.habitLeft > 0) return;
    if (!night && !this.scared && !this.quake) {
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive || o.habitPose !== "up") continue;
        if (Math.hypot(o.x - this.x, o.z - this.z) > 3.2) continue;
        if (Math.random() < dt * 0.4) {
          this.habitLeft = 1.6;
          this.habitPose = "up";
          this.habitX = this.x;
          this.habitZ = this.z;
          return;
        }
      }
    }
    if (this.habitT > 0 || busy || night || this.scared || this.quake) return;
    const child = this.baby || this.role === "crianca";
    if (Math.random() < (child ? 0.22 : 0.08)) {
      let animal: Creature | null = null;
      let best = 18;
      for (const o of herd) {
        if (!o.alive || !isRanch(o.kind)) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < best) {
          best = d;
          animal = o;
        }
      }
      if (animal) {
        this.habit = "bicho";
        this.habitT = child ? 16 + Math.random() * 12 : 30 + Math.random() * 24;
        this.habitLeft = (child ? 2.6 : 4) + Math.random() * 2.2;
        this.habitX = animal.x;
        this.habitZ = animal.z;
        this.habitPose = "";
        return;
      }
    }
    this.habitT = 9 + Math.random() * 12;
    const h = this.habit;
    if (h === "ceu" || h === "espreguicar" || h === "pedra") {
      this.habitLeft = 2.2 + Math.random() * 2.2;
      this.habitPose = h === "pedra" ? "crouch" : "up";
      this.habitX = this.x;
      this.habitZ = this.z;
      return;
    }
    if (h === "seguir") {
      if (Math.hypot(player.x - this.x, player.z - this.z) > 14) {
        this.habitT = 4;
        return;
      }
      this.habitLeft = 5 + Math.random() * 4;
      this.habitPose = "";
      return;
    }
    const spot =
      h === "planta"
        ? this.nearbySpot(world, 7, (x, y, z) => {
            const id = world.getBlock(x, y, z);
            return isPlant(id) || isWeed(id);
          })
        : h === "agua"
          ? this.nearbySpot(world, 8, (x, y, z) => isWater(world.getBlock(x, y, z)) || isWater(world.getBlock(x, y - 1, z)))
          : this.nearbySpot(world, 8, (x, y, z) => !!world.leavesAt(x + 0.5, y + 1.4, z + 0.5));
    if (!spot) {
      this.habitT = 4;
      return;
    }
    this.habitX = spot.x;
    this.habitZ = spot.z;
    this.habitLeft = 6 + Math.random() * 3;
    this.habitPose = "";
  }

  private stash(id: number, n: number) {
    if (n <= 0) return;
    const slot = this.bag.find((s) => s.id === id);
    if (slot) slot.n += n;
    else if (this.bag.length < 8) this.bag.push({ id, n });
    else if (foodDef(id)) this.beginEat();
  }

  private edibleCount(): number {
    let n = 0;
    for (const s of this.bag) if (foodDef(s.id)) n += s.n;
    return n;
  }

  /** Whole melon is not a meal. Cut it into slices first. */
  private breakWholeFoods() {
    for (let i = this.bag.length - 1; i >= 0; i--) {
      const s = this.bag[i]!;
      if (s.id !== MELON || s.n <= 0) continue;
      const slices = s.n * (3 + ((Math.random() * 5) | 0));
      this.bag.splice(i, 1);
      this.stash(MELON_SLICE, slices);
    }
  }

  private takeEdible(n: number): { id: number; n: number } | null {
    this.breakWholeFoods();
    for (const s of this.bag) {
      if (!foodDef(s.id) || s.n <= 0) continue;
      const take = Math.min(n, s.n);
      s.n -= take;
      if (s.n <= 0) this.bag = this.bag.filter((x) => x.n > 0);
      return { id: s.id, n: take };
    }
    return null;
  }

  private needyVillager(herd: Creature[]): Creature | null {
    let best: Creature | null = null;
    let score = 15;
    for (const o of herd) {
      if (o === this || o.kind !== "aldeao" || !o.alive) continue;
      if (o.hunger >= score || o.hunger >= this.hunger) continue;
      score = o.hunger;
      best = o;
    }
    return best;
  }

  private cottageStands(world: World): boolean {
    const hx = Math.floor(this.homeX);
    const hz = Math.floor(this.homeZ);
    const hy = Math.floor(this.homeY);
    let wood = 0;
    let door = false;
    for (let z = hz - 3; z <= hz + 3; z++) {
      for (let x = hx - 3; x <= hx + 3; x++) {
        for (let y = hy - 1; y <= hy + 3; y++) {
          const id = world.getBlock(x, y, z);
          if (isDoor(id)) door = true;
          if (y >= hy && (id === PLANKS || isLog(id))) wood++;
        }
      }
    }
    return door || wood >= 10;
  }

  private shouldSettle(world: World): boolean {
    const farHome = Math.hypot(this.x - this.homeX, this.z - this.homeZ) > 34;
    if (world.farFromVillage(this.x, this.z) && farHome) return true;
    return !this.cottageStands(world);
  }

  private beginEat() {
    if (this.eatT > 0) return;
    this.breakWholeFoods();
    const slot = this.bag.find((s) => s.n > 0 && foodDef(s.id));
    if (!slot) return;
    this.eating = slot.id;
    this.eatT = foodDef(slot.id)?.seconds ?? 1.1;
    this.farmMode = "";
    this.habitLeft = 0;
    this.habitPose = "";
  }

  private finishEat() {
    const bite = this.takeEdible(1);
    const def = bite ? foodDef(bite.id) : null;
    if (def) {
      this.hunger = Math.min(20, this.hunger + def.hunger);
      this.sat = Math.min(this.hunger, this.sat + def.sat);
      if (this.hunger >= 16) this.food = Math.min(20, this.food + 2);
    }
    this.eating = 0;
    this.eatT = 0;
  }

  private tickHunger(dt: number) {
    const moving = Math.hypot(this.vx, this.vz) > 0.2;
    this.hungerAcc += dt * (moving ? 1.15 : 0.45);
    if (this.hungerAcc >= 22) {
      this.hungerAcc = 0;
      if (this.sat > 0) this.sat = Math.max(0, this.sat - 1);
      else this.hunger = Math.max(0, this.hunger - 1);
    }
    if (this.eatT > 0) {
      this.eatT -= dt;
      if (this.eatT <= 0) this.finishEat();
      return;
    }
    if (this.hunger <= 14 && this.farmMode !== "harvest" && this.farmMode !== "share") this.beginEat();
  }

  /** Hungry children pick food off the ground. They never harvest. */
  private stepScrap(world: World, child: boolean): { x: number; z: number } | null {
    if (!child || this.hunger > 14 || this.eatT > 0 || this.edibleCount() > 0) return null;
    let best = 12;
    let pick: { x: number; z: number; id: number; n: number; tag: number } | null = null;
    for (const g of world.groundFood) {
      if (!foodDef(g.id) && g.id !== MELON) continue;
      const d = Math.hypot(g.x - this.x, g.z - this.z);
      if (d >= best) continue;
      best = d;
      pick = g;
    }
    if (!pick) return null;
    if (best < 1.15) {
      const got = world.claimGroundFood(pick.tag);
      if (got) {
        this.stash(got.id, got.n);
        this.breakWholeFoods();
        this.beginEat();
      }
      return null;
    }
    return { x: pick.x, z: pick.z };
  }

  /** Farmer loop: pick ripe melons, replant, throw spare food, then breed. */
  private stepFarm(world: World, herd: Creature[], child: boolean, night: boolean, meet: boolean): { x: number; z: number } | null {
    if (child || night || meet || this.quake || this.hurtT > 0 || this.greetT > 0 || this.scared || this.fluid || this.eatT > 0) {
      if (this.eatT > 0) this.farmMode = "";
      return null;
    }
    const farmer = this.role === "jardineiro";
    if (this.farmMode === "share") {
      const mate = this.needyVillager(herd);
      if (!mate || this.edibleCount() <= 0) {
        this.farmMode = "";
      } else if (Math.hypot(mate.x - this.x, mate.z - this.z) < 1.7) {
        const gift = this.takeEdible(this.hunger < 12 ? 1 : 2 + ((Math.random() * 2) | 0));
        if (gift) mate.stash(gift.id, gift.n);
        this.farmed = "harvest";
        this.farmMode = "";
        this.farmT = 1.2;
      } else return { x: mate.x, z: mate.z };
    }
    if (this.farmMode === "harvest" || this.farmMode === "plant") {
      const d = Math.hypot(this.farmX + 0.5 - this.x, this.farmZ + 0.5 - this.z);
      if (d < 1.65) {
        if (this.farmMode === "harvest" && world.getBlock(this.farmX, this.farmY, this.farmZ) === MELON) {
          world.setBlock(this.farmX, this.farmY, this.farmZ, AIR);
          for (const [dx, dz] of STEM_DIRS) {
            const id = world.getBlock(this.farmX - dx, this.farmY, this.farmZ - dz);
            if (isMelonAttach(id) && attachFacing(id) === STEM_DIRS.findIndex(([sx, sz]) => sx === dx && sz === dz)) {
              world.setBlock(this.farmX - dx, this.farmY, this.farmZ - dz, stemFromStage(7));
            }
          }
          this.stash(MELON_SLICE, 3 + ((Math.random() * 5) | 0));
          this.seeds += 1;
          this.farmed = "harvest";
          this.breakWholeFoods();
          const roll = Math.random();
          const needy = this.needyVillager(herd);
          if (this.hunger <= 12 || roll < 0.34) this.beginEat();
          else if (needy && roll < 0.67 && this.edibleCount() > 0) {
            this.farmMode = "share";
            this.farmT = 0;
            return { x: needy.x, z: needy.z };
          }
        } else if (this.farmMode === "harvest" && isRipeCrop(world.getBlock(this.farmX, this.farmY, this.farmZ))) {
          const id = world.getBlock(this.farmX, this.farmY, this.farmZ);
          const food = cropFood(id);
          world.setBlock(this.farmX, this.farmY, this.farmZ, cropFromStage(cropKind(id), 0));
          this.stash(food, 1 + ((Math.random() * 2) | 0));
          this.farmed = "harvest";
          if (this.hunger <= 12 || Math.random() < 0.34) this.beginEat();
        } else if (this.farmMode === "plant" && this.seeds > 0) {
          const here = world.getBlock(this.farmX, this.farmY, this.farmZ);
          if (here === AIR && world.getBlock(this.farmX, this.farmY - 1, this.farmZ) === FARMLAND) {
            const roll = Math.random();
            world.setBlock(
              this.farmX,
              this.farmY,
              this.farmZ,
              roll < 0.25
                ? cropFromStage("urucum", 0)
                : roll < 0.5
                  ? cropFromStage("camapu", 0)
                  : roll < 0.75
                    ? cropFromStage("tomate", 0)
                    : MELON_STEM,
            );
            if (roll >= 0.75) this.seeds -= 1;
            this.farmed = "plant";
          }
        }
        this.farmMode = "";
        this.farmT = 1.1;
        if (!farmer) this.forageT = 8 + Math.random() * 14;
      } else return { x: this.farmX + 0.5, z: this.farmZ + 0.5 };
    }
    if (this.farmT > 0) return null;
    if (!farmer && this.forageT > 0 && this.hunger > 12) return null;
    const ix = Math.floor(this.x);
    const iz = Math.floor(this.z);
    const y0 = Math.floor(this.y);
    let plant: { x: number; y: number; z: number } | null = null;
    for (let dz = -6; dz <= 6; dz++) {
      for (let dx = -6; dx <= 6; dx++) {
        for (let dy = -2; dy <= 2; dy++) {
          const x = ix + dx;
          const y = y0 + dy;
          const z = iz + dz;
          if (world.getBlock(x, y, z) !== MELON && !isRipeCrop(world.getBlock(x, y, z))) continue;
          this.farmMode = "harvest";
          this.farmX = x;
          this.farmY = y;
          this.farmZ = z;
          return { x: x + 0.5, z: z + 0.5 };
        }
      }
    }
    if (!farmer) {
      this.forageT = 8 + Math.random() * 14;
      return null;
    }
    if (this.seeds <= 0) return null;
    for (let dz = -5; dz <= 5 && !plant; dz++) {
      for (let dx = -5; dx <= 5 && !plant; dx++) {
        const x = Math.floor(this.homeX) + dx;
        const z = Math.floor(this.homeZ) + dz;
        const y = world.surfaceY(x, z);
        if (Math.abs(y - this.y) > 2) continue;
        if (world.getBlock(x, y, z) !== AIR) continue;
        if (world.getBlock(x, y - 1, z) !== FARMLAND) continue;
        plant = { x, y, z };
      }
    }
    if (!plant) return null;
    this.farmMode = "plant";
    this.farmX = plant.x;
    this.farmY = plant.y;
    this.farmZ = plant.z;
    return { x: plant.x + 0.5, z: plant.z + 0.5 };
  }

  private tickAldeao(
    dt: number,
    world: World,
    player: { x: number; y: number; z: number; vy?: number },
    night: boolean,
    herd: Creature[],
    meet: boolean,
    clock: number,
  ) {
    this.greetT = Math.max(0, this.greetT - dt);
    this.danceT = Math.max(0, this.danceT - dt);
    this.talkT = Math.max(0, this.talkT - dt);
    this.humT -= dt;
    this.habitT = Math.max(0, this.habitT - dt);
    this.habitLeft = Math.max(0, this.habitLeft - dt);
    this.gazeT = Math.max(0, this.gazeT - dt);
    if (this.habitLeft <= 0) this.habitPose = "";
    if (this.fluid) {
      this.vy -= 6 * dt;
      this.vy *= Math.pow(0.8, dt * 20);
    } else {
      this.vy -= 28 * dt;
    }
    const px = player.x - this.x;
    const pz = player.z - this.z;
    const dist = Math.hypot(px, pz);
    const hx = this.homeX - this.x;
    const hz = this.homeZ - this.z;
    const homeD = Math.hypot(hx, hz);
    const child = this.baby || this.role === "crianca";
    if ((player.vy ?? 0) > 3.2 && dist < 6 && !night) this.danceT = 1.4;
    this.repairT = Math.max(0, this.repairT - dt);
    if (!child) {
      if (this.buildQueue) this.needsPlot = true;
      else {
        this.plotCheck -= dt;
        if (this.plotCheck <= 0) {
          this.plotCheck = 4;
          this.needsPlot = this.shouldSettle(world);
        }
      }
    } else this.needsPlot = false;
    this.farmT -= dt;
    this.forageT = Math.max(0, this.forageT - dt);
    this.tickHunger(dt);
    const hole = this.nearestHole(world);
    const noticeHole = !!this.quake && !!hole && hole.d < 2.8 && (this.wary || hole.d < 2.2);
    this.breedT = Math.max(0, this.breedT - dt);
    if (!child && !night && !this.quake && this.breedT <= 0 && this.food >= 12 && !this.wantChild && this.aldeaoCount(herd) < 8) {
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive || o.baby || o.role === "crianca") continue;
        if (o.food < 12 || o.breedT > 0 || o.wantChild) continue;
        if (Math.hypot(o.x - this.x, o.z - this.z) > 3.2) continue;
        this.food -= 6;
        o.food -= 6;
        this.breedT = 28;
        o.breedT = 28;
        this.wantChild = true;
        this.childX = (this.x + o.x) / 2;
        this.childZ = (this.z + o.z) / 2;
        this.greetT = Math.max(this.greetT, 1.4);
        o.greetT = Math.max(o.greetT, 1.4);
        break;
      }
    }
    const farmTarget = this.needsPlot ? null : this.stepFarm(world, herd, child, night, meet);
    const scrapTarget = this.stepScrap(world, child);

    let partner: Creature | null = null;
    if (!child && !night && this.greetT <= 0 && this.hurtT <= 0 && !this.quake) {
      let best = 3;
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive || o.baby || o.role === "crianca") continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < best) {
          best = d;
          partner = o;
        }
      }
      if (partner && best < 2.6) this.talkT = Math.max(this.talkT, 4);
    }

    let threat: Creature | null = null;
    let threatD = 9;
    for (const o of herd) {
      if (!o.alive || !isMonster(o.kind)) continue;
      const d = Math.hypot(o.x - this.x, o.z - this.z);
      if (d < threatD) {
        threatD = d;
        threat = o;
      }
    }
    this.scared = this.hurtT > 0 || !!threat || this.quake;
    this.lookCd = Math.max(0, this.lookCd - dt);
    this.lookT = Math.max(0, this.lookT - dt);
    if (dist < 4.4 && this.lookT <= 0 && this.lookCd <= 0 && !night && !this.quake && !threat && this.hurtT <= 0) {
      this.lookT = 2.6;
      this.lookCd = 7;
    }
    const sleepy = !this.fluid && (night || (this.role === "palerma" && clock > 0.36 && clock < 0.92));
    const headWet = !!world.fluidAt(this.x, this.y + Math.min(this.h * 0.82, this.h - 0.05), this.z);
    const dock = world.fishDock;
    const onDock =
      this.role === "pescador" &&
      !!dock &&
      !headWet &&
      Math.hypot(dock.x - this.x, dock.z - this.z) < 1.5;
    const swim = !!this.fluid && !onDock;
    const busy =
      !!farmTarget ||
      !!scrapTarget ||
      meet ||
      this.greetT > 0 ||
      this.danceT > 0 ||
      sleepy ||
      swim ||
      !!this.fluid ||
      this.quake ||
      this.eatT > 0 ||
      noticeHole ||
      !!threat ||
      this.hurtT > 0;
    if (swim || this.quake || noticeHole || threat || this.hurtT > 0 || sleepy) {
      this.habitLeft = 0;
      this.habitPose = "";
      this.gazeT = 0;
      this.farmMode = "";
    }
    this.tryStartHabit(dt, world, player, herd, night, busy);
    if (this.gazeT <= 0 && !night && !this.scared && this.habitLeft <= 0 && !farmTarget && !sleepy) {
      let best = 6;
      let gx = 0;
      let gz = 0;
      let found = false;
      for (const o of herd) {
        if (!o.alive || o === this || o.kind === "aldeao" || isMonster(o.kind)) continue;
        const ranch = isRanch(o.kind);
        if (child && !ranch) continue;
        if (!child && ranch) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < best) {
          best = d;
          gx = o.x;
          gz = o.z;
          found = true;
        }
      }
      if (found && Math.random() < dt * (child ? 0.07 : 0.15)) {
        this.gazeT = 1.5 + Math.random() * 1.6;
        this.gazeX = gx;
        this.gazeZ = gz;
      }
    }

    let wishX = 0;
    let wishZ = 0;
    let speed = this.speed;
    let sleeping = false;
    this.fishing = false;
    if (swim) {
      const blocked = this.headBlocked(world);
      const exit = this.nearestShore(world);
      let tx = exit ? exit.x : this.homeX;
      let tz = exit ? exit.z : this.homeZ;
      if (blocked) {
        const side = this.swimAround(world, tx, tz);
        if (side) {
          tx = side.x;
          tz = side.z;
        }
        this.vy = Math.min(this.vy, 0.15);
      } else {
        this.vy = Math.max(this.vy, 4.2);
      }
      const dx = tx - this.x;
      const dz = tz - this.z;
      const al = Math.hypot(dx, dz) || 1;
      wishX = dx / al;
      wishZ = dz / al;
      speed = 1.55;
      this.yaw = Math.atan2(wishX, wishZ);
    } else if ((this.hurtT > 0 && dist > 0.2) || threat) {
      const ax = threat ? this.x - threat.x : -px;
      const az = threat ? this.z - threat.z : -pz;
      const al = Math.hypot(ax, az) || 1;
      wishX = ax / al;
      wishZ = az / al;
      speed = child ? 2.4 : 2.8;
      this.yaw = Math.atan2(wishX, wishZ);
    } else if (noticeHole && hole) {
      const ax = this.x - hole.x;
      const az = this.z - hole.z;
      const al = Math.hypot(ax, az) || 1;
      wishX = ax / al;
      wishZ = az / al;
      speed = 1.05;
      this.yaw = Math.atan2(wishX, wishZ);
    } else if (this.eatT > 0) {
      speed = 0;
    } else if (this.quake && !this.fluid) {
      this.yaw = Math.atan2(player.x - this.x, player.z - this.z);
    } else if (sleepy) {
      if (homeD > 0.8) {
        wishX = hx / homeD;
        wishZ = hz / homeD;
        speed = 1.15;
        this.yaw = Math.atan2(wishX, wishZ);
      } else sleeping = true;
    } else if (this.greetT > 0) {
      this.yaw = Math.atan2(px, pz);
    } else if (this.danceT > 0) {
      this.yaw += dt * 2.4;
      if (this.grounded && Math.random() < dt * 3) this.vy = 4.2;
    } else if (scrapTarget) {
      const dx = scrapTarget.x - this.x;
      const dz = scrapTarget.z - this.z;
      const len = Math.hypot(dx, dz) || 1;
      wishX = dx / len;
      wishZ = dz / len;
      speed = 1.35;
      this.yaw = Math.atan2(wishX, wishZ);
    } else if (farmTarget) {
      const dx = farmTarget.x - this.x;
      const dz = farmTarget.z - this.z;
      const len = Math.hypot(dx, dz);
      if (len > 0.85) {
        wishX = dx / len;
        wishZ = dz / len;
        speed = 1.15;
        this.yaw = Math.atan2(wishX, wishZ);
      }
    } else if (this.role === "pescador" && world.fishDock && !this.fluid && !night && !this.quake && !this.needsPlot) {
      const dock = world.fishDock;
      const dx = dock.x - this.x;
      const dz = dock.z - this.z;
      const len = Math.hypot(dx, dz);
      if (len > 0.8) {
        wishX = dx / len;
        wishZ = dz / len;
        speed = this.speed;
        this.yaw = Math.atan2(wishX, wishZ);
        this.fishing = false;
      } else {
        this.fishing = true;
        this.yaw = Math.atan2(0, -1);
        speed = 0;
      }
    } else if (!child && this.repairT <= 0 && !night && !this.quake && !this.scared && this.needsPlot) {
      if (!this.buildQueue) {
        const site = world.findHomesite(this.x, this.z);
        this.repairT = 18 + Math.random() * 22;
        if (site) {
          this.buildQueue = world.cottageBlueprint(site.x, site.floor, site.z);
          this.buildAt = 0;
          this.homeX = site.x + 1.5;
          this.homeY = site.floor + 1;
          this.homeZ = site.z + 1.5;
          wishX = 0;
          wishZ = 0;
        }
      } else {
        while (this.buildAt < this.buildQueue.length && world.getBlock(this.buildQueue[this.buildAt]!.x, this.buildQueue[this.buildAt]!.y, this.buildQueue[this.buildAt]!.z) === this.buildQueue[this.buildAt]!.id) {
          this.buildAt++;
        }
        const job = this.buildQueue[this.buildAt];
        if (!job) {
          this.buildQueue = null;
          this.repairT = 18 + Math.random() * 22;
        } else {
          const dx = job.x + 0.5 - this.x;
          const dz = job.z + 0.5 - this.z;
          const len = Math.hypot(dx, dz);
          if (len > 1.35) {
            wishX = dx / len;
            wishZ = dz / len;
            speed = this.speed;
            this.yaw = Math.atan2(wishX, wishZ);
          } else {
            world.setBlock(job.x, job.y, job.z, job.id);
            world.repairs.push(job);
            this.buildAt++;
            if (this.buildAt >= this.buildQueue.length) this.buildQueue = null;
            this.repairT = 18 + Math.random() * 22;
          }
        }
      }
    } else if (!child && this.repairT <= 0 && !night && !this.quake && !this.scared) {
      const job = world.nearestBroken(this.x, this.z, 48);
      if (job) {
        const dx = job.x + 0.5 - this.x;
        const dz = job.z + 0.5 - this.z;
        const len = Math.hypot(dx, dz);
        if (len > 1.25) {
          wishX = dx / len;
          wishZ = dz / len;
          speed = this.speed;
          this.yaw = Math.atan2(wishX, wishZ);
        } else {
          world.setBlock(job.x, job.y, job.z, job.id);
          this.repairT = 18 + Math.random() * 22;
        }
      } else this.repairT = 14 + Math.random() * 10;
    } else if (meet && !child) {
      const mx = (this.meetX || this.homeX) - this.x;
      const mz = (this.meetZ || this.homeZ) - this.z;
      const md = Math.hypot(mx, mz);
      if (md > 1.6) {
        wishX = mx / md;
        wishZ = mz / md;
        speed = 1.1;
        this.yaw = Math.atan2(wishX, wishZ);
      } else if (partner) {
        this.yaw = Math.atan2(partner.x - this.x, partner.z - this.z);
      }
    } else if (this.lookT > 0 && !farmTarget) {
      this.yaw = Math.atan2(px, pz);
    } else if (this.gazeT > 0) {
      this.yaw = Math.atan2(this.gazeX - this.x, this.gazeZ - this.z);
    } else if (this.habitLeft > 0) {
      if (this.habit === "seguir") {
        const d = dist || 1;
        this.yaw = Math.atan2(px, pz);
        if (d > 3.1) {
          wishX = px / d;
          wishZ = pz / d;
          speed = this.speed;
        }
      } else if (this.habit === "bicho") {
        const dx = this.habitX - this.x;
        const dz = this.habitZ - this.z;
        const d = Math.hypot(dx, dz) || 1;
        const watch = child ? 2.5 : 1.25;
        if (d > watch) {
          wishX = dx / d;
          wishZ = dz / d;
          speed = this.speed * 0.8;
          this.yaw = Math.atan2(wishX, wishZ);
        } else {
          this.yaw = Math.atan2(dx, dz);
          this.habitPose = child ? "peer" : "crouch";
        }
      } else if (this.habit === "planta" || this.habit === "agua" || this.habit === "sombra") {
        const dx = this.habitX - this.x;
        const dz = this.habitZ - this.z;
        const d = Math.hypot(dx, dz);
        if (d > 1.2) {
          wishX = dx / d;
          wishZ = dz / d;
          speed = this.speed * 0.85;
          this.yaw = Math.atan2(wishX, wishZ);
        } else {
          this.habitPose = this.habit === "agua" ? "peer" : this.habit === "planta" ? "crouch" : "lean";
          this.yaw = Math.atan2(dx, dz);
        }
      }
    } else if (child) {
      let fisher: Creature | null = null;
      let fd = 8;
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive || !o.fishing) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < fd) {
          fd = d;
          fisher = o;
        }
      }
      if (fisher && this.curious) {
        this.yaw = Math.atan2(fisher.x - this.x, fisher.z - this.z);
        if (fd > 2.2) {
          wishX = (fisher.x - this.x) / fd;
          wishZ = (fisher.z - this.z) / fd;
          speed = 1.5;
        }
      } else {
      let pal: Creature | null = null;
      let pd = 8;
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive) continue;
        if (!(o.baby || o.role === "crianca")) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < pd) {
          pd = d;
          pal = o;
        }
      }
      if (dist > 2.6 && dist < 8 && Math.sin(this.walkT * 0.17) > 0.55) {
        wishX = px / (dist || 1);
        wishZ = pz / (dist || 1);
        speed = 1.7;
        this.yaw = Math.atan2(wishX, wishZ);
      } else if (pal && pd > 0.8 && pd < 7) {
        wishX = (pal.x - this.x) / pd;
        wishZ = (pal.z - this.z) / pd;
        speed = 1.7;
        this.yaw = Math.atan2(wishX, wishZ);
        if (this.grounded && pd < 1.6 && Math.random() < dt * 2) this.vy = 4.6;
      } else if (homeD > 6) {
        wishX = hx / (homeD || 1);
        wishZ = hz / (homeD || 1);
        this.yaw = Math.atan2(wishX, wishZ);
      }
      }
    } else if (partner && this.talkT > 0) {
      this.yaw = Math.atan2(partner.x - this.x, partner.z - this.z);
      if (this.role === "contador") {
        const pxw = Math.cos(this.walkT * 0.6);
        const pzw = Math.sin(this.walkT * 0.6);
        const ahead = world.getBlock(Math.floor(this.x + pxw * 0.7), Math.floor(this.y + 0.2), Math.floor(this.z + pzw * 0.7));
        const roof = world.getBlock(Math.floor(this.x), Math.floor(this.y + this.h + 0.05), Math.floor(this.z));
        if (!(isSolid(ahead) && !isLeaves(ahead)) && !(isSolid(roof) && !isLeaves(roof))) {
          wishX = pxw * 0.7;
          wishZ = pzw * 0.7;
          speed = this.speed * 0.35;
        }
      }
    } else {
      if (homeD > 8 || this.wanderT <= 0) {
        this.wanderT = 2 + Math.random() * 3;
        const a = Math.random() * Math.PI * 2;
        const r = 2 + Math.random() * 4;
        this.tx = this.homeX + Math.cos(a) * r;
        this.tz = this.homeZ + Math.sin(a) * r;
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const len = Math.hypot(dx, dz);
      if (len > 0.4) {
        wishX = dx / len;
        wishZ = dz / len;
        this.yaw = Math.atan2(wishX, wishZ);
        if (this.role === "jardineiro" && Math.random() < dt * 0.15) speed = 0;
      } else if (this.role === "vigia") {
        this.yaw += dt * 0.4;
      }
    }

    if (!sleeping) {
      for (const o of herd) {
        if (o === this || o.kind !== "aldeao" || !o.alive) continue;
        const dx = this.x - o.x;
        const dz = this.z - o.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.02 && d < 0.72) {
          wishX += (dx / d) * 1.15;
          wishZ += (dz / d) * 1.15;
        }
      }
      const wl = Math.hypot(wishX, wishZ);
      if (wl > 1) {
        wishX /= wl;
        wishZ /= wl;
      }
    }
    speed *= this.paceMul;

    this.vx = wishX * speed;
    this.vz = wishZ * speed;
    this.touchPassage(world, wishX, wishZ);
    this.applyMove(dt, world, wishX, wishZ, false);
    const moving = Math.hypot(this.vx, this.vz) > 0.12 && !sleeping;
    this.walkT += dt * (moving ? 8 : 1.4);
    const swing = moving ? Math.sin(this.walkT) * 0.7 : 0;
    const wave = this.greetT > 0 ? Math.sin(this.greetT * 10) * 0.9 : 0;
    const work = this.role === "jardineiro" && !moving && !sleeping && !this.quake && this.greetT <= 0;
    const pose = this.habitPose;
    const toss = this.habit === "pedra" && this.habitLeft > 0 && this.habitLeft < 0.55;
    this.group.traverse((o) => {
      const p = o.userData.part as string | undefined;
      if (p === "armL") o.rotation.x = sleeping ? 0.4 : pose === "up" ? -2.7 : work ? 0.9 : wave ? -2.2 : swing;
      else if (p === "armR") {
        o.rotation.x = sleeping
          ? 0.4
          : this.eatT > 0
            ? -1.35
            : this.fishing
            ? -1.25 + Math.sin(this.walkT * 1.6) * 0.06
            : toss
              ? -2.5
              : this.habit === "bicho" && pose === "crouch"
              ? -1.15
              : pose === "up"
                ? -2.7
                : this.quake
                  ? -2.4
                  : work
                    ? 1.1
                    : -swing;
      }
      else if (p === "legL") o.rotation.x = sleeping ? 0.2 : swing;
      else if (p === "legR") o.rotation.x = sleeping ? -0.2 : -swing;
      else if (p === "head") {
        o.rotation.y = this.greetT > 0 ? Math.sin(this.greetT * 6) * 0.3 : Math.sin(this.walkT * 0.35) * 0.2;
        o.rotation.x = sleeping
          ? 0.4
          : pose === "up"
            ? -0.75
            : pose === "peer" || pose === "crouch"
              ? 0.7
              : work
                ? 0.45
                : this.lookT > 0 || this.gazeT > 0
                  ? 0.12
                  : 0;
      } else if (p === "torso") {
        o.rotation.x = sleeping ? 0 : pose === "crouch" || pose === "peer" ? 0.55 : work ? 0.35 : 0;
        o.rotation.z = pose === "lean" && !sleeping ? 0.28 : 0;
      } else if (p === "eyeL" || p === "eyeR") {
        const blink = Math.sin(this.walkT * 0.7) > 0.97 ? 0.15 : 1;
        o.scale.y = blink;
      }
    });
    const line = this.group.getObjectByName("fishline");
    if (line) {
      line.visible = this.fishing;
      if (this.fishing) {
        const len = 2.8;
        line.scale.set(1, 1, len);
        line.rotation.set(Math.PI / 2, 0, Math.sin(this.walkT * 1.4) * 0.04);
        line.position.set(0.02, -0.9 - len * 0.5, 0.16);
      }
    }
    this.paintHurt(night);
    this.sync();
    if (sleeping) {
      this.group.rotation.x = 1.15;
      this.group.position.y = this.y + 0.15;
    } else if (this.quake || this.scared) {
      this.group.rotation.z = Math.sin(this.walkT * (this.quake ? 18 : 22)) * (this.quake ? 0.08 : 0.06);
    } else {
      this.group.rotation.x = 0;
      this.group.rotation.z = 0;
    }
  }

  tick(
    dt: number,
    world: World,
    player: { x: number; y: number; z: number; vy?: number },
    night: boolean,
    herd: Creature[],
    meet = false,
    clock = 0,
  ) {
    this.hurtT = Math.max(0, this.hurtT - dt);
    this.wanderT -= dt;
    this.playerHit = 0;
    this.witnessed = false;
    this.wasFluid = this.fluid;
    this.wasLeaves = this.inLeaves;
    this.fluid =
      world.fluidAt(this.x, this.y + 0.18, this.z) ??
      world.fluidAt(this.x, this.y + this.h * 0.45, this.z);
    this.inLeaves =
      !this.fluid &&
      !!(
        world.leavesAt(this.x, this.y + 0.18, this.z) ??
        world.leavesAt(this.x, this.y + this.h * 0.45, this.z) ??
        world.leavesAt(this.x, this.y + this.h * 0.85, this.z)
      );
    if (this.baby && this.kind === "aldeao") {
      this.growT += dt;
      if (this.growT >= 150) this.growUp();
    } else if (this.baby) {
      this.growT += dt;
      if (this.growT >= GROW_S) this.growUp();
    }

    if (isMonster(this.kind) && !night && !this.dying) this.beginDie();
    if (this.dying) {
      this.tickDie(dt);
      return;
    }

    if (this.kind === "aldeao") {
      this.tickAldeao(dt, world, player, night, herd, meet, clock);
      return;
    }

    if (this.fish) {
      this.tickFish(dt, world, player, herd);
      return;
    }
    if (this.bird) {
      this.tickBird(dt, world, player, herd);
      return;
    }
    if (this.kind === "beholder") {
      this.tickBeholder(dt, world, player, herd);
      return;
    }

    if (this.fluid === "mud") {
      this.vy -= 16 * dt;
      this.vy *= Math.pow(0.45, dt * 20);
    } else if (this.fluid) {
      this.vy -= 6 * dt;
      this.vy *= Math.pow(0.8, dt * 20);
    } else if (this.inLeaves) {
      this.vy -= 6 * dt;
      this.vy *= Math.pow(0.8, dt * 20);
    } else {
      this.vy -= 28 * dt;
    }

    const px = player.x - this.x;
    const pz = player.z - this.z;
    const dist = Math.hypot(px, pz);

    let wishX = 0;
    let wishZ = 0;
    let speed = this.speed;
    if (this.fluid === "mud") speed *= 0.22;
    else if (this.fluid || this.inLeaves) speed *= 0.55;

    if (this.hurtT > 0 && dist > 0.01 && !isMonster(this.kind)) {
      wishX = -px / dist;
      wishZ = -pz / dist;
      speed = this.baby ? 2.4 : 3.2;
      this.yaw = Math.atan2(wishX, wishZ);
    } else if (this.baby) {
      let parent: Creature | null = null;
      let best = 40;
      for (const o of herd) {
        if (o === this || !o.alive || o.kind !== this.kind || o.baby) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < best) {
          best = d;
          parent = o;
        }
      }
      if (parent && best > 1.15) {
        wishX = (parent.x - this.x) / best;
        wishZ = (parent.z - this.z) / best;
        this.yaw = Math.atan2(wishX, wishZ);
      }
    } else if (this.kind === "murcha") {
      this.attackT = Math.max(0, this.attackT - dt);
      this.huntT = MONSTERS_NEUTRAL ? 0 : Math.max(0, this.huntT - dt);
      const angry = !MONSTERS_NEUTRAL && (this.huntT > 0 || dist < 11);
      const swinging = !MONSTERS_NEUTRAL && this.attackT > 0;
      if (swinging && dist > 0.12) {
        wishX = px / dist;
        wishZ = pz / dist;
        const t = 1 - this.attackT / 1.12;
        if (t < 0.28) speed = 0.55;
        else if (t < 0.52) speed = this.attackStyle === 1 ? 3.6 : 3.15;
        else speed = 0.7;
        this.yaw = Math.atan2(wishX, wishZ);
        if (!this.attackLanded && t >= 0.32 && t <= 0.52 && dist < 2.05 && Math.abs(player.y - this.y) < 2.4) {
          this.attackLanded = true;
          this.playerHit = 1;
          this.vy = Math.max(this.vy, this.attackStyle === 1 ? 6.4 : 4.2);
        }
      } else if (angry && dist > 0.12) {
        wishX = px / dist;
        wishZ = pz / dist;
        speed = this.huntT > 0 ? 2.35 : 1.62;
        this.yaw = Math.atan2(wishX, wishZ);
        if (dist < 1.7 && Math.abs(player.y - this.y) < 2.2 && this.attackT <= 0) {
          this.attackT = 1.12;
          this.attackLanded = false;
          this.attackStyle = dist < 1.25 && Math.random() < 0.5 ? 1 : Math.random() < 0.5 ? 0 : 2;
        }
      } else if (this.wanderT <= 0) {
        this.wanderT = 2 + Math.random() * 4;
        const a = Math.random() * Math.PI * 2;
        this.tx = this.x + Math.cos(a) * (4 + Math.random() * 6);
        this.tz = this.z + Math.sin(a) * (4 + Math.random() * 6);
      } else {
        const dx = this.tx - this.x;
        const dz = this.tz - this.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.4) {
          wishX = dx / d;
          wishZ = dz / d;
          this.yaw = Math.atan2(wishX, wishZ);
        }
      }
    } else if (isRanch(this.kind) || this.kind === "tamandua" || this.kind === "louva") {
      this.grazeT = Math.max(0, this.grazeT - dt);
      if (this.grazeT > 0) speed = 0;
      else if (this.wanderT <= 0) {
        if (Math.random() < (this.kind === "tamandua" ? 0.55 : this.kind === "louva" ? 0.62 : 0.42)) {
          this.grazeT = 1.5 + Math.random() * 3.2;
          speed = 0;
        } else {
          this.wanderT = 1.6 + Math.random() * 3.4;
          const a = Math.random() * Math.PI * 2;
          const reach = this.kind === "louva" ? 2 + Math.random() * 3 : 3 + Math.random() * 5;
          this.tx = this.x + Math.cos(a) * reach;
          this.tz = this.z + Math.sin(a) * reach;
        }
      }
      if (this.grazeT <= 0) {
        const dx = this.tx - this.x;
        const dz = this.tz - this.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.4) {
          wishX = dx / d; wishZ = dz / d;
          this.yaw = Math.atan2(wishX, wishZ);
        }
      }
    } else if (this.kind === "tucano") {
      if (dist < 7.5 && dist > 0.2) {
        wishX = -px / dist; wishZ = -pz / dist;
        speed = this.baby ? 1.7 : 1.55;
        this.yaw = Math.atan2(wishX, wishZ);
      } else if (this.wanderT <= 0) {
        this.wanderT = 1.1 + Math.random() * 2.4;
        const a = Math.random() * Math.PI * 2;
        this.tx = this.x + Math.cos(a) * (2 + Math.random() * 4);
        this.tz = this.z + Math.sin(a) * (2 + Math.random() * 4);
      } else {
        const dx = this.tx - this.x;
        const dz = this.tz - this.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.35) {
          wishX = dx / d; wishZ = dz / d;
          this.yaw = Math.atan2(wishX, wishZ);
        }
      }
    } else {
      if (this.wanderT <= 0) {
        this.wanderT = 2 + Math.random() * 4;
        const a = Math.random() * Math.PI * 2;
        this.tx = this.x + Math.cos(a) * (4 + Math.random() * 6);
        this.tz = this.z + Math.sin(a) * (4 + Math.random() * 6);
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.4) {
        wishX = dx / d; wishZ = dz / d;
        this.yaw = Math.atan2(wishX, wishZ);
      }
    }

    this.vx = wishX * speed;
    this.vz = wishZ * speed;
    if (this.fluid) {
      const [cx, cy, cz] = world.waterCurrent(Math.floor(this.x), Math.floor(this.y + 0.2), Math.floor(this.z));
      this.vx += cx; this.vz += cz;
      if (cy < 0) this.vy += cy * 2.2 * dt;
    }
    this.applyMove(dt, world, wishX, wishZ, false);
    if (this.kind === "tucano" && (wishX !== 0 || wishZ !== 0) && !this.fluid && !this.inLeaves) {
      this.hopT += dt;
      if (this.hopT > 0.32 && Math.abs(this.vy) < 0.8) { this.vy = 5.4; this.hopT = 0; }
    }
    this.animateBody(dt, Math.hypot(this.vx, this.vz) > 0.08 && !this.fluid);
    this.paintHurt(night);
    this.sync();
  }

  private tickDie(dt: number) {
    this.dieT += dt;
    const dur = this.kind === "beholder" ? 1.15 : 1.55;
    const t = Math.min(1, this.dieT / dur);
    if (this.kind === "murcha") {
      this.group.scale.set(1 + t * 0.18, Math.max(0.06, 1 - t * 0.94), 1 + t * 0.18);
      this.group.rotation.x = t * 1.15;
      this.group.rotation.z = Math.sin(this.dieT * 9) * t * 0.18;
      this.group.position.set(this.x, this.y - t * 0.85, this.z);
      this.group.rotation.y = this.yaw + t * 1.1;
      this.group.traverse((o) => {
        const p = o.userData.part as string | undefined;
        if (p === "armL") o.rotation.z = t * 1.05;
        else if (p === "armR") o.rotation.z = -t * 1.05;
        else if (p === "head") o.rotation.x = 0.28 + t * 0.9;
        else if (p === "torso") o.rotation.x = t * 0.45;
        else if (p === "legL") o.rotation.x = t * 0.4;
        else if (p === "legR") o.rotation.x = -t * 0.35;
      });
      for (const m of this.flash) {
        setEmissive(m, t < 0.62 ? 0xee6620 : 0x3a1408);
        const mat = (Array.isArray(m.material) ? m.material[0] : m.material) as THREE.MeshLambertMaterial;
        if (mat) {
          mat.transparent = true;
          mat.opacity = 1 - t * 0.7;
        }
      }
    } else {
      this.vy -= 16 * dt;
      this.y += this.vy * dt;
      this.group.scale.setScalar(Math.max(0.04, 1 - t * 0.9));
      this.group.rotation.x = t * 1.55;
      this.group.rotation.z = Math.sin(this.dieT * 10) * t * 0.55;
      this.group.position.set(this.x, this.y, this.z);
      for (const m of this.flash) {
        setEmissive(m, t < 0.5 ? 0x7a28b0 : 0x2a0838);
        const mat = (Array.isArray(m.material) ? m.material[0] : m.material) as THREE.MeshLambertMaterial;
        if (mat) {
          mat.transparent = true;
          mat.opacity = 1 - t * 0.65;
        }
      }
    }
    if (this.dieT >= dur) this.alive = false;
  }

  private tickBeholder(dt: number, world: World, player: { x: number; y: number; z: number }, herd: Creature[]) {
    this.hoverT += dt;
    this.idleLookT += dt;
    this.summonT = Math.max(0, this.summonT - dt);
    const focusing = this.summonT > 5.55;
    const ground = world.heightAt(Math.floor(this.x), Math.floor(this.z)) + 1;
    const floatAmp = focusing ? 0.08 : 0.22;
    const wantY = ground + 1.55 + Math.sin(this.hoverT * (focusing ? 1.1 : 1.7)) * floatAmp;
    this.vy += (wantY - this.y) * 5.5 * dt;
    this.vy *= Math.pow(0.78, dt * 20);
    const px = player.x - this.x;
    const py = player.y + 1.4 - this.y;
    const pz = player.z - this.z;
    const dist = Math.hypot(px, pz);
    let wishX = 0;
    let wishZ = 0;
    let speed = this.speed;
    if (focusing && !MONSTERS_NEUTRAL) {
      speed = 0.12;
      if (dist > 0.4) {
        wishX = px / dist * 0.15;
        wishZ = pz / dist * 0.15;
      }
    } else if (!MONSTERS_NEUTRAL && dist > 7.2 && dist < 28) {
      wishX = px / dist;
      wishZ = pz / dist;
    } else if (!MONSTERS_NEUTRAL && dist <= 7.2 && dist > 0.2) {
      wishX = (-pz / dist) * 0.45 + (px / dist) * 0.08;
      wishZ = (px / dist) * 0.45 + (pz / dist) * 0.08;
      speed = 0.55;
    } else if (this.wanderT <= 0) {
      this.wanderT = 1.8 + Math.random() * 2.5;
      const a = Math.random() * Math.PI * 2;
      this.tx = this.x + Math.cos(a) * 4;
      this.tz = this.z + Math.sin(a) * 4;
    } else {
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.4) {
        wishX = dx / d;
        wishZ = dz / d;
        speed = 0.5;
      }
    }
    if (focusing || dist < 12) {
      if (dist > 0.2) this.yaw = Math.atan2(px, pz);
    } else {
      const scan = Math.sin(this.idleLookT * 0.55) * 0.85;
      const face = dist > 0.2 ? Math.atan2(px, pz) : this.yaw;
      let dy = scan + face * 0.15 - this.yaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      this.yaw += THREE.MathUtils.clamp(dy, -1.8 * dt, 1.8 * dt);
    }
    this.vx = wishX * speed;
    this.vz = wishZ * speed;
    this.applyMove(dt, world, wishX, wishZ, true);
    if (this.y < ground + 0.55) this.y = ground + 0.55;
    if (this.y > ground + 2.6) this.y = ground + 2.6;
    if (dist < 9 && this.summonT <= 0 && !MONSTERS_NEUTRAL) {
      this.summonT = 7.5;
      this.witnessed = true;
      this.blinkLeft = 0;
      this.blinkPhase = 0;
      for (const o of herd) {
        if (o === this || !o.alive || o.dying || !isMonster(o.kind) || o.kind === "beholder") continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d <= 20) o.huntT = Math.max(o.huntT, 16);
      }
    }
    const moving = Math.hypot(this.vx, this.vz) > 0.12 && !focusing;
    const lookX = Math.atan2(py, Math.max(0.4, dist));
    this.paintHurt(true);
    this.sync();
    this.animateBeholder(dt, moving, focusing, THREE.MathUtils.clamp(lookX, -0.45, 0.4));
  }

  private animateBeholder(dt: number, moving: boolean, focusing: boolean, lookX: number) {
    if (focusing) {
      this.blinkLeft = 0;
      this.blinkPhase = 0;
    } else if (this.blinkLeft > 0) {
      this.blinkPhase += dt * 5.6;
      if (this.blinkPhase >= 1) {
        this.blinkPhase = 0;
        this.blinkLeft -= 1;
        if (this.blinkLeft <= 0) this.blinkWait = 2.4 + Math.random() * 4.2;
      }
    } else {
      this.blinkWait -= dt;
      if (this.blinkWait <= 0) {
        this.blinkLeft = 2 + ((Math.random() * 3) | 0);
        this.blinkPhase = 0;
      }
    }

    const blinkAmt = this.blinkLeft > 0 ? Math.sin(this.blinkPhase * Math.PI) : 0;
    const bob = Math.sin(this.hoverT * (moving ? 3.6 : focusing ? 1.15 : 2.1));
    const bob2 = Math.sin(this.hoverT * (moving ? 5.4 : 3.2));
    const sy = focusing ? 1.04 : moving ? 1 + bob * 0.07 : 1 + bob * 0.03;
    this.group.scale.set(1 / Math.sqrt(sy), sy, 1 / Math.sqrt(sy));
    this.group.rotation.x = lookX + (focusing ? 0.16 : moving ? bob2 * 0.08 : 0);
    this.group.rotation.z = focusing ? 0 : moving ? bob * 0.14 : Math.sin(this.hoverT * 0.9) * 0.04;
    this.group.position.y = this.y + bob * (moving ? 0.14 : focusing ? 0.04 : 0.07);

    const lookSide = focusing ? 0 : Math.sin(this.idleLookT * 0.7) * 0.62 + Math.sin(this.idleLookT * 0.23) * 0.22;
    const lookUp = focusing ? 0.05 : Math.sin(this.idleLookT * 0.41) * 0.14;
    const focusPulse = focusing ? 0.5 + 0.5 * Math.sin(this.hoverT * 8.5) : 0;

    this.group.traverse((o) => {
      const p = o.userData.part as string | undefined;
      if (!p) return;
      if (p === "gaze") {
        o.rotation.y = lookSide;
        o.rotation.x = lookUp;
      } else if (p === "iris") {
        const s = focusing ? 1.28 + focusPulse * 0.08 : 1;
        o.scale.setScalar(s);
      } else if (p === "pupil") {
        const s = focusing ? 0.52 + focusPulse * 0.18 : 1;
        o.scale.setScalar(s);
      } else if (p === "lidTop") {
        o.rotation.x = focusing ? -0.22 : blinkAmt * 0.92;
      } else if (p === "lidBot") {
        o.rotation.x = focusing ? 0.16 : -blinkAmt * 0.78;
      } else if (p.startsWith("stalk")) {
        const i = Number(p.slice(5)) || 0;
        const base = [0.35, -0.4, 0.15, -0.2, 0][i] ?? 0;
        o.rotation.z = base + Math.sin(this.hoverT * 2.4 + i * 1.1) * (moving ? 0.28 : 0.1);
        o.rotation.x = focusing ? -0.45 : Math.sin(this.hoverT * 1.7 + i) * (moving ? 0.22 : 0.08);
      }
    });
  }

  private tickBird(dt: number, world: World, player: { x: number; y: number; z: number }, herd: Creature[]) {
    this.flapT += dt;
    this.perchT = Math.max(0, this.perchT - dt);
    const kind = this.kind as BirdKind;
    const px = player.x - this.x;
    const pz = player.z - this.z;
    const distP = Math.hypot(px, pz);
    if (this.fluid) { this.flying = true; this.vy = Math.max(this.vy, 4.5); }
    if (this.baby) {
      let parent: Creature | null = null; let best = 28;
      for (const o of herd) {
        if (o === this || !o.alive || o.kind !== this.kind || o.baby) continue;
        const d = Math.hypot(o.x - this.x, o.y - this.y, o.z - this.z);
        if (d < best) { best = d; parent = o; }
      }
      if (parent && best > (kind === "beijaflor" ? 1.4 : 2.4)) {
        this.tx = parent.x; this.ty = parent.y + 0.15; this.tz = parent.z; this.flying = true;
      }
    }
    if (this.hurtT > 0 && distP > 0.2) {
      this.flying = true;
      this.tx = this.x - (px / distP) * 6; this.ty = this.y + 2.2; this.tz = this.z - (pz / distP) * 6;
      this.perchT = 0;
    }
    if (kind === "beijaflor") {
      if (this.perchT <= 0) {
        this.wanderT -= dt;
        if (this.wanderT <= 0) {
          this.wanderT = 0.35 + Math.random() * 0.9; this.flying = true;
          if (Math.random() < 0.28) { this.tx = this.homeX; this.ty = this.homeY + 0.12; this.tz = this.homeZ; }
          else {
            const a = Math.random() * Math.PI * 2; const r = 1.2 + Math.random() * 4.5;
            this.tx = this.homeX + Math.cos(a) * r; this.tz = this.homeZ + Math.sin(a) * r;
            const ground = world.surfaceY(Math.floor(this.tx), Math.floor(this.tz));
            this.ty = Math.max(ground + 0.6, Math.min(ground + 7.5, this.homeY + (Math.random() - 0.35) * 2.4));
          }
        }
      }
    } else if (kind === "arara") {
      if (!this.flying) { if (this.perchT <= 0) { this.flying = true; this.wanderT = 0; } }
      else {
        this.wanderT -= dt;
        if (this.wanderT <= 0) {
          this.wanderT = 2.4 + Math.random() * 3.5;
          if (Math.random() < 0.32) { this.tx = this.homeX; this.ty = this.homeY + 0.2; this.tz = this.homeZ; }
          else {
            const a = Math.random() * Math.PI * 2; const r = 6 + Math.random() * 14;
            this.tx = this.homeX + Math.cos(a) * r; this.tz = this.homeZ + Math.sin(a) * r;
            this.ty = world.surfaceY(Math.floor(this.tx), Math.floor(this.tz)) + 4.5 + Math.random() * 5.5;
          }
        }
      }
    } else if (!this.flying && this.perchT <= 0) {
      if (Math.random() < 0.55) { this.flying = true; this.tx = this.homeX; this.ty = this.homeY + 0.25; this.tz = this.homeZ; }
      else {
        const a = Math.random() * Math.PI * 2; const r = 3 + Math.random() * 6;
        this.tx = this.x + Math.cos(a) * r; this.tz = this.z + Math.sin(a) * r;
        this.ty = world.surfaceY(Math.floor(this.tx), Math.floor(this.tz)) + 1.8; this.flying = true;
      }
    }
    const dx = this.tx - this.x; const dy = this.ty - this.y; const dz = this.tz - this.z;
    const dist = Math.hypot(dx, dy, dz) || 1;
    if (this.flying) {
      const cruise = this.speed * (kind === "beijaflor" ? 1 : kind === "arara" ? 0.85 : 0.7);
      const near = dist < (kind === "beijaflor" ? 0.55 : 0.85);
      const wantX = near && kind === "beijaflor" ? 0 : (dx / dist) * cruise;
      const wantZ = near && kind === "beijaflor" ? 0 : (dz / dist) * cruise;
      let wantY = (dy / dist) * cruise * (kind === "beijaflor" ? 0.85 : 0.55);
      if (kind === "beijaflor") {
        wantY += Math.sin(this.flapT * 18) * 0.35;
        if (near) {
          this.vx *= Math.pow(0.12, dt * 8); this.vz *= Math.pow(0.12, dt * 8);
          this.vy += (this.ty + Math.sin(this.flapT * 14) * 0.05 - this.y) * 10 * dt;
        } else {
          this.vx += (wantX - this.vx) * Math.min(1, dt * 9);
          this.vz += (wantZ - this.vz) * Math.min(1, dt * 9);
          this.vy += (wantY - this.vy) * Math.min(1, dt * 8);
        }
      } else if (kind === "arara") {
        const glide = Math.sin(this.flapT * 1.4) > 0.35;
        const k = glide ? 2.1 : 5.5;
        this.vx += (wantX - this.vx) * Math.min(1, dt * k);
        this.vz += (wantZ - this.vz) * Math.min(1, dt * k);
        this.vy += (wantY - this.vy) * Math.min(1, dt * 3.2);
        this.vy -= 1.6 * dt;
      } else {
        this.vx += (wantX - this.vx) * Math.min(1, dt * 4.5);
        this.vz += (wantZ - this.vz) * Math.min(1, dt * 4.5);
        this.vy += (wantY - this.vy) * Math.min(1, dt * 4);
        this.vy -= 4.5 * dt;
      }
      const spd = Math.hypot(this.vx, this.vz);
      if (spd > 0.12) this.turnToward(Math.atan2(this.vx, this.vz), dt, kind === "beijaflor" ? 14 : kind === "arara" ? 3.6 : 6);
      const lookY = Math.atan2(this.vy, Math.max(0.4, spd));
      this.pitch += (THREE.MathUtils.clamp(lookY, -0.45, 0.4) - this.pitch) * Math.min(1, dt * 6);
      const side = Math.sin(this.yaw) * this.vz - Math.cos(this.yaw) * this.vx;
      this.bank += (THREE.MathUtils.clamp(side * 0.22, -0.65, 0.65) - this.bank) * Math.min(1, dt * 5);
      this.applyMove(dt, world, this.vx, this.vz, true);
      if (dist < 0.7 && this.perchT <= 0 && kind !== "beijaflor") {
        this.flying = false; this.perchT = kind === "arara" ? 3 + Math.random() * 5 : 2.2 + Math.random() * 4;
        this.vx = 0; this.vz = 0; this.vy = 0;
      }
    } else {
      this.vy -= 28 * dt;
      this.pitch += (0 - this.pitch) * Math.min(1, dt * 8);
      this.bank += (0 - this.bank) * Math.min(1, dt * 8);
      if (kind === "joaobarro") {
        if (this.wanderT <= 0) {
          this.wanderT = 1.2 + Math.random() * 2.2;
          const a = Math.random() * Math.PI * 2;
          this.tx = this.x + Math.cos(a) * (1.5 + Math.random() * 3);
          this.tz = this.z + Math.sin(a) * (1.5 + Math.random() * 3);
        }
        const gx = this.tx - this.x; const gz = this.tz - this.z; const gd = Math.hypot(gx, gz);
        let wishX = 0, wishZ = 0;
        if (gd > 0.3) { wishX = gx / gd; wishZ = gz / gd; this.turnToward(Math.atan2(wishX, wishZ), dt, 8); }
        this.vx = wishX * this.speed * 0.45; this.vz = wishZ * this.speed * 0.45;
        this.hopT += dt;
        if (this.hopT > 0.28 && Math.abs(this.vy) < 0.5 && gd > 0.3) { this.vy = 3.8; this.hopT = 0; }
      } else { this.vx *= Math.pow(0.08, dt * 8); this.vz *= Math.pow(0.08, dt * 8); }
      this.applyMove(dt, world, this.vx, this.vz, false);
    }
    let flap = 0;
    if (kind === "beijaflor") flap = Math.sin(this.flapT * 52) * (this.flying ? 1.15 : 0.55);
    else if (kind === "arara") {
      const cycle = (this.flapT % 0.92) / 0.92;
      const beating = this.flying && cycle < 0.38;
      flap = beating ? Math.sin((cycle / 0.38) * Math.PI) * 1.05 : this.flying ? 0.12 : 0.04;
    } else {
      flap = this.flying ? Math.sin(this.flapT * 16) * 0.85 : Math.sin(this.walkT * 10) * 0.08;
      this.walkT += dt * (this.flying ? 2 : Math.hypot(this.vx, this.vz) > 0.08 ? 10 : 1.2);
    }
    this.group.traverse((o) => {
      const p = o.userData.part as string | undefined;
      if (!p) return;
      if (p === "wingL") { o.rotation.z = flap; o.rotation.y = kind === "beijaflor" ? Math.sin(this.flapT * 48) * 0.25 : 0; }
      else if (p === "wingR") { o.rotation.z = -flap; o.rotation.y = kind === "beijaflor" ? -Math.sin(this.flapT * 48) * 0.25 : 0; }
      else if (p === "head") o.rotation.x = this.flying ? -this.pitch * 0.25 : Math.sin(this.flapT * 1.4) * 0.08;
      else if (p === "tail") o.rotation.x = this.flying ? THREE.MathUtils.clamp(-this.vy * 0.08, -0.35, 0.25) : 0.05;
    });
    this.paintHurt(false);
    this.sync();
  }

  private animateBody(dt: number, moving: boolean) {
    if (this.kind === "murcha") {
      this.walkT += dt * (moving && this.attackT <= 0 ? 8.4 : 1.5);
      const amp = moving && this.attackT <= 0 ? 0.55 : 0.08;
      const atk = this.attackT;
      const t = atk > 0 ? 1 - atk / 1.12 : -1;
      const style = this.attackStyle;
      let armLx = 0.52 + Math.sin(this.walkT) * (moving && atk <= 0 ? 0.7 : 0.1);
      let armRx = 0.52 - Math.sin(this.walkT) * (moving && atk <= 0 ? 0.7 : 0.1);
      let armLz = 0;
      let armRz = 0;
      let headX = 0.28 + Math.sin(this.walkT * 0.7) * 0.08;
      let headY = 0;
      let torsoX = 0;
      let torsoZ = 0;
      if (t >= 0 && t < 0.28) {
        const e = (t / 0.28) * (t / 0.28);
        if (style === 1) {
          armLx = 0.52 - e * 2.45;
          armRx = 0.52 - e * 2.45;
          headX = 0.28 - e * 0.4;
          torsoX = -e * 0.32;
        } else if (style === 2) {
          armRx = 0.52 + e * 0.95;
          armRz = -e * 0.6;
          armLx = 0.52 - e * 0.35;
          headY = -e * 0.28;
          torsoZ = -e * 0.22;
        } else {
          armLx = 0.52 + e * 0.95;
          armLz = e * 0.6;
          armRx = 0.52 - e * 0.35;
          headY = e * 0.28;
          torsoZ = e * 0.22;
        }
      } else if (t >= 0.28 && t < 0.52) {
        const u = (t - 0.28) / 0.24;
        const e = 1 - (1 - u) * (1 - u);
        if (style === 1) {
          armLx = -1.93 + e * 2.85;
          armRx = -1.93 + e * 2.85;
          headX = -0.12 + e * 0.78;
          torsoX = -0.32 + e * 0.82;
        } else if (style === 2) {
          armRx = 1.47 - e * 2.75;
          armRz = -0.6 + e * 1.05;
          armLx = 0.17 + e * 0.2;
          headY = -0.28 + e * 0.5;
          torsoZ = -0.22 + e * 0.5;
        } else {
          armLx = 1.47 - e * 2.75;
          armLz = 0.6 - e * 1.05;
          armRx = 0.17 + e * 0.2;
          headY = 0.28 - e * 0.5;
          torsoZ = 0.22 - e * 0.5;
        }
      } else if (t >= 0.52) {
        const u = (t - 0.52) / 0.48;
        const e = u * u;
        if (style === 1) {
          armLx = 0.92 * (1 - e) + 0.52 * e;
          armRx = 0.92 * (1 - e) + 0.52 * e;
          headX = 0.66 * (1 - e) + 0.28 * e;
          torsoX = 0.5 * (1 - e);
        } else if (style === 2) {
          armRx = -1.28 * (1 - e) + 0.52 * e;
          armRz = 0.45 * (1 - e);
          headY = 0.22 * (1 - e);
          torsoZ = 0.28 * (1 - e);
        } else {
          armLx = -1.28 * (1 - e) + 0.52 * e;
          armLz = -0.45 * (1 - e);
          headY = -0.22 * (1 - e);
          torsoZ = -0.28 * (1 - e);
        }
      }
      this.group.traverse((o) => {
        const p = o.userData.part as string | undefined;
        if (!p) return;
        if (p === "legL") o.rotation.x = Math.sin(this.walkT) * amp + (t >= 0.28 && t < 0.52 ? 0.35 : 0);
        else if (p === "legR") o.rotation.x = -Math.sin(this.walkT) * amp + (t >= 0.28 && t < 0.52 ? -0.2 : 0);
        else if (p === "armL") {
          o.rotation.x = armLx;
          o.rotation.z = armLz;
        } else if (p === "armR") {
          o.rotation.x = armRx;
          o.rotation.z = armRz;
        } else if (p === "head") {
          o.rotation.x = headX;
          o.rotation.y = headY;
        } else if (p === "torso") {
          o.rotation.x = torsoX;
          o.rotation.z = torsoZ;
        }
      });
      return;
    }
    if (this.kind === "louva") {
      this.walkT += dt * (moving ? 9 : 1.4);
      const amp = moving ? 0.55 : 0.08;
      this.group.traverse((o) => {
        const p = o.userData.part as string | undefined;
        if (p === "legFL" || p === "legBR") o.rotation.x = Math.sin(this.walkT) * amp;
        else if (p === "legFR" || p === "legBL") o.rotation.x = -Math.sin(this.walkT) * amp;
        else if (p === "head") o.rotation.y = Math.sin(this.walkT * 0.6) * 0.25;
      });
      return;
    }
    if (!this.ranch && !this.rare) return;
    const pace = this.kind === "porco" ? 10.5 : this.kind === "ovelha" ? 8.6 : this.kind === "tucano" ? 12 : this.kind === "tamandua" ? 6.2 : 7.2;
    this.walkT += dt * (moving ? pace : 1.5);
    const amp = moving ? (this.kind === "porco" ? 0.62 : this.kind === "tucano" ? 0.72 : this.kind === "tamandua" ? 0.38 : 0.5) : 0.04;
    const graze = this.grazeT > 0.15;
    this.group.traverse((o) => {
      const p = o.userData.part as string | undefined;
      if (!p) return;
      if (this.kind === "tucano" && (p === "legFL" || p === "legFR")) o.rotation.x = Math.sin(this.walkT) * amp;
      else if (p === "legFL" || p === "legBR") o.rotation.x = Math.sin(this.walkT) * amp;
      else if (p === "legFR" || p === "legBL") o.rotation.x = -Math.sin(this.walkT) * amp;
      else if (p === "head") {
        const nod = moving ? Math.sin(this.walkT * 0.5) * 0.08 : Math.sin(this.walkT * 0.65) * 0.05;
        o.rotation.x = graze ? (this.kind === "tamandua" ? 0.72 : 0.58) + Math.sin(this.walkT * 0.9) * 0.07 : nod;
        o.rotation.y = graze ? Math.sin(this.walkT * 0.4) * 0.08 : Math.sin(this.walkT * 0.32) * 0.12;
      } else if (p === "tail") {
        o.rotation.y = Math.sin(this.walkT * (this.kind === "porco" ? 5.2 : 2.2)) * (this.kind === "porco" ? 0.85 : 0.38);
      } else if (p === "wingL") o.rotation.z = moving ? 0.45 + Math.sin(this.walkT * 2.2) * 0.55 : 0.12;
      else if (p === "wingR") o.rotation.z = moving ? -0.45 - Math.sin(this.walkT * 2.2) * 0.55 : -0.12;
    });
  }

  private tickFish(dt: number, world: World, player: { x: number; y: number; z: number }, herd: Creature[]) {
    this.swimT += dt;
    this.dashT = Math.max(0, this.dashT - dt);
    const wasResting = this.restT > 0;
    this.restT = Math.max(0, this.restT - dt);
    this.turnLock = Math.max(0, this.turnLock - dt);
    const col =
      world.waterColumn(Math.floor(this.x), Math.floor(this.z)) ??
      world.waterColumn(Math.floor(this.x + 0.3), Math.floor(this.z)) ??
      world.waterColumn(Math.floor(this.x - 0.3), Math.floor(this.z)) ??
      world.waterColumn(Math.floor(this.x), Math.floor(this.z + 0.3)) ??
      world.waterColumn(Math.floor(this.x), Math.floor(this.z - 0.3));
    const inW =
      !!col && this.y < col.top + 0.9 && this.y + this.h * 0.2 > col.bed - 0.05;
    this.fluid = inW ? "water" : this.fluid && !col ? null : this.fluid;
    const px = player.x - this.x;
    const pz = player.z - this.z;
    const dist = Math.hypot(px, pz);

    if (!inW) {
      this.hopT -= dt;
      this.vy -= 28 * dt;
      if (this.hopT <= 0 && this.vy > -2 && this.vy < 1.4) {
        const spot = this.nearestWater(world, 5);
        const dx = spot ? spot.x + 0.5 - this.x : 0;
        const dz = spot ? spot.z + 0.5 - this.z : 0;
        const d = Math.hypot(dx, dz);
        if (spot && d > 0.2) {
          const hop = Math.min(3.6, 1.7 + d * 0.5);
          this.vx = (dx / d) * hop;
          this.vz = (dz / d) * hop;
          this.vy = Math.min(6.4, 3.5 + d * 0.32);
          this.yaw = Math.atan2(this.vx, this.vz);
        } else {
          this.vx = Math.sin(this.swimT * 13) * 1.1;
          this.vz = Math.cos(this.swimT * 11) * 1.1;
          this.vy = 3.4;
          this.yaw += 1.4;
        }
        this.hopT = 0.42;
      } else {
        this.vx *= 0.98;
        this.vz *= 0.98;
      }
      this.group.rotation.z = Math.sin(this.swimT * 16) * 0.75;
      this.group.rotation.x = 0.35;
      this.applyMove(dt, world, this.vx, this.vz, true);
      this.paintHurt(false);
      this.group.position.set(this.x, this.y, this.z);
      this.group.rotation.y = this.yaw;
      return;
    }

    this.group.rotation.z = this.kind === "cascudo"
      ? Math.sin(this.swimT * 0.55) * 0.015
      : Math.sin(this.swimT * (this.kind === "tucunare" || this.kind === "traira" ? 4.2 : 6.5)) * (this.kind === "tucunare" || this.kind === "traira" ? 0.06 : 0.12);
    this.group.rotation.x = this.kind === "cascudo"
      ? 0.05
      : Math.sin(this.swimT * (this.kind === "tucunare" || this.kind === "traira" ? 3.4 : 5.2)) * (this.kind === "tucunare" || this.kind === "traira" ? 0.03 : 0.06);

    if (col) {
      const span = Math.max(0.2, col.top + 0.7 - col.bed);
      let prefer = this.y;
      if (this.kind === "cascudo") prefer = col.bed + 0.02;
      else if (this.kind === "lambari") prefer = col.bed + span * (0.28 + 0.18 * Math.sin(this.swimT * 0.8 + this.x));
      else if (this.kind === "traira") prefer = col.bed + span * (0.18 + 0.1 * Math.sin(this.swimT * 0.45));
      else if (this.kind === "branco") prefer = col.bed + span * (0.52 + 0.16 * Math.sin(this.swimT * 0.7));
      else prefer = col.bed + Math.min(span * 0.38, Math.max(0.12, span - this.h - 0.2));
      const maxY = col.top + 0.62 - this.h;
      prefer = Math.min(maxY, Math.max(col.bed + 0.02, prefer));
      this.vy += (prefer - this.y) * 3.6 * dt;
      if (this.y > maxY) {
        this.y = maxY;
        this.vy = Math.min(0, this.vy);
      }
    }
    this.vy *= Math.pow(0.72, dt * 20);

    let wishX = 0;
    let wishZ = 0;
    let speed = this.speed;

    if (this.hurtT > 0 && dist > 0.01) {
      wishX = -px / dist;
      wishZ = -pz / dist;
      speed *= 1.8;
    } else if (this.kind === "lambari") {
      let sx = 0;
      let sz = 0;
      let n = 0;
      for (const o of herd) {
        if (o === this || !o.alive || o.kind !== "lambari") continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < 3.2 && d > 0.15) {
          sx += (o.x - this.x) / d;
          sz += (o.z - this.z) / d;
          n++;
        }
      }
      if (this.wanderT <= 0) {
        this.wanderT = 0.45 + Math.random() * 0.7;
        this.pickWaterTarget(world, 1.4 + Math.random() * 2.4);
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz) || 1;
      wishX = dx / d;
      wishZ = dz / d;
      if (n > 0) {
        wishX = wishX * 0.55 + (sx / n) * 0.45;
        wishZ = wishZ * 0.55 + (sz / n) * 0.45;
      }
      if (dist < 2.4 && dist > 0.01) {
        wishX -= (px / dist) * 0.55;
        wishZ -= (pz / dist) * 0.55;
      }
      speed *= 0.85 + 0.45 * Math.abs(Math.sin(this.swimT * 3.4));
    } else if (this.kind === "cascudo") {
      const hx = this.homeX - this.x;
      const hz = this.homeZ - this.z;
      const hd = Math.hypot(hx, hz);
      if (wasResting && this.restT <= 0 && hd <= 1.8) {
        this.wanderT = 1.5 + Math.random() * 2.4;
        const a = Math.random() * Math.PI * 2;
        const r = 0.5 + Math.random() * 1.1;
        this.tx = this.homeX + Math.cos(a) * r;
        this.tz = this.homeZ + Math.sin(a) * r;
      }
      if (hd > 1.8) {
        wishX = hx / hd;
        wishZ = hz / hd;
      } else if (this.restT > 0) {
        speed = 0;
      } else if (this.wanderT > 0) {
        const dx = this.tx - this.x;
        const dz = this.tz - this.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.12) {
          wishX = dx / d;
          wishZ = dz / d;
        } else {
          this.wanderT = 0;
          this.restT = 6 + Math.random() * 10;
          speed = 0;
        }
      } else {
        this.restT = 6 + Math.random() * 10;
        speed = 0;
      }
    } else if (this.kind === "traira") {
      let near = 0;
      let ax = 0;
      let az = 0;
      for (const o of herd) {
        if (o === this || !o.alive || o.kind !== "traira") continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < 5.5 && d > 0.1) {
          ax += (this.x - o.x) / d;
          az += (this.z - o.z) / d;
          near++;
        }
      }
      if (this.wanderT <= 0) {
        this.wanderT = 2.8 + Math.random() * 4.2;
        this.pickWaterTarget(world, 2.4 + Math.random() * 3.6);
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.28) {
        wishX = dx / d;
        wishZ = dz / d;
      }
      if (near > 0) {
        wishX = wishX * 0.35 + ax * 0.65;
        wishZ = wishZ * 0.35 + az * 0.65;
      }
      if (dist < 2.8 && dist > 0.2) {
        wishX -= (px / dist) * 0.35;
        wishZ -= (pz / dist) * 0.35;
      }
      speed *= 0.72 + 0.18 * Math.abs(Math.sin(this.swimT * 1.6));
    } else if (this.kind === "branco") {
      if (this.wanderT <= 0) {
        this.wanderT = 1.6 + Math.random() * 2.4;
        this.pickWaterTarget(world, 1.8 + Math.random() * 2.8);
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.22) {
        wishX = dx / d;
        wishZ = dz / d;
      }
      if (dist < 5.5 && dist > 0.05) {
        wishX -= (px / dist) * 1.15;
        wishZ -= (pz / dist) * 1.15;
        speed *= 1.25;
      } else {
        speed *= 0.78 + 0.22 * Math.abs(Math.sin(this.swimT * 2.4));
      }
    } else {
      if (this.wanderT <= 0) {
        this.wanderT = 2.4 + Math.random() * 3.2;
        this.pickWaterTarget(world, 2.2 + Math.random() * 4.5);
      }
      const dx = this.tx - this.x;
      const dz = this.tz - this.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.45) this.wanderT = 0;
      if (d > 0.28) {
        wishX = dx / d;
        wishZ = dz / d;
      }
      const roomy = this.swimRoom(world) >= 6;
      if (roomy && dist < 4.2 && dist > 0.45) {
        if (dist < 1.7 && this.dashT <= 0) this.dashT = 1.35;
        if (this.dashT > 0.75) {
          wishX = px / dist;
          wishZ = pz / dist;
          speed *= 1.35;
        } else if (this.dashT > 0) {
          wishX = -px / dist;
          wishZ = -pz / dist;
          speed *= 0.9;
        }
      }
    }

    if (this.kind !== "cascudo") {
      if (this.cruiseT > 0) {
        this.cruiseT -= dt;
        if (this.cruiseT <= 0) {
          this.cruiseMul = 1;
          this.cruiseWait = 8 + Math.random() * 4;
        }
      } else if (this.cruiseWait > 0) {
        this.cruiseWait -= dt;
        if (this.cruiseWait <= 0) {
          this.cruiseMul = Math.random() < 0.5 ? 1.2 : 0.8;
          this.cruiseT = 4 + Math.random() * 3;
        }
      }
      speed *= this.cruiseMul;
    }

    if (this.baby && this.kind !== "lambari") {
      let parent: Creature | null = null;
      let best = 18;
      for (const o of herd) {
        if (o === this || !o.alive || o.kind !== this.kind || o.baby) continue;
        const d = Math.hypot(o.x - this.x, o.z - this.z);
        if (d < best) {
          best = d;
          parent = o;
        }
      }
      if (parent && best > 1.4) {
        wishX = (parent.x - this.x) / best;
        wishZ = (parent.z - this.z) / best;
      }
    }

    const steered = this.steerInWater(world, wishX, wishZ);
    wishX = steered[0];
    wishZ = steered[1];
    const len = Math.hypot(wishX, wishZ);
    if (len > 0.04) {
      wishX /= len;
      wishZ /= len;
      const turn = this.kind === "tucunare" ? 2.4 : this.kind === "cascudo" ? 0.65 : this.kind === "traira" ? 2.1 : this.kind === "branco" ? 3.6 : 7.5;
      this.turnToward(Math.atan2(wishX, wishZ), dt, turn);
    }

    this.vx = Math.sin(this.yaw) * speed * (len > 0.04 ? 1 : 0.2);
    this.vz = Math.cos(this.yaw) * speed * (len > 0.04 ? 1 : 0.2);
    const [cx, cy, cz] = world.waterCurrent(Math.floor(this.x), Math.floor(this.y + 0.15), Math.floor(this.z));
    const drift = this.kind === "cascudo" ? 0.08 : 0.35;
    this.vx += cx * drift;
    this.vz += cz * drift;
    if (cy < 0) this.vy += cy * 1.2 * dt;

    this.applyMove(dt, world, wishX, wishZ, true);
    if (col && this.y < col.bed + 0.01) {
      this.y = col.bed + 0.01;
      this.vy = Math.max(0, this.vy);
    }
    const resting = this.kind === "cascudo" && this.restT > 0;
    const wag = this.kind === "cascudo" ? (resting ? 1.1 : 2.2) : this.kind === "lambari" ? 12 : this.kind === "traira" ? 5.4 : this.kind === "branco" ? 9.4 : 7.2;
    const amp = this.kind === "cascudo" ? (resting ? 0.04 : 0.1) : this.kind === "tucunare" ? 0.28 : this.kind === "traira" ? 0.22 : this.kind === "branco" ? 0.38 : 0.42;
    for (const m of this.flash) {
      if (m.userData.part === "tail") m.rotation.y = Math.sin(this.swimT * wag) * amp;
    }
    this.paintHurt(false);
    this.sync();
  }

  private nearestWater(world: World, r: number): { x: number; z: number } | null {
    const ix = Math.floor(this.x);
    const iz = Math.floor(this.z);
    let best: { x: number; z: number; d: number } | null = null;
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        if (dx * dx + dz * dz > r * r) continue;
        if (!world.waterColumn(ix + dx, iz + dz)) continue;
        const d = dx * dx + dz * dz;
        if (!best || d < best.d) best = { x: ix + dx, z: iz + dz, d };
      }
    }
    return best;
  }

  private swimRoom(world: World): number {
    let n = 0;
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (world.waterColumn(Math.floor(this.x) + dx, Math.floor(this.z) + dz)) n++;
      }
    }
    return n;
  }

  private steerInWater(world: World, wishX: number, wishZ: number): [number, number] {
    const y = this.y + this.h * 0.35;
    const probes: [number, number][] = [];
    if (Math.hypot(wishX, wishZ) > 0.04) probes.push([wishX, wishZ]);
    const fx = Math.sin(this.yaw);
    const fz = Math.cos(this.yaw);
    probes.push([fx, fz], [fx + fz, fz - fx], [fx - fz, fz + fx], [fz, -fx], [-fz, fx], [-fx, -fz]);
    for (const [sx, sz] of probes) {
      const len = Math.hypot(sx, sz) || 1;
      const reach = this.kind === "tucunare" ? 0.7 : 0.55;
      const lx = this.x + (sx / len) * reach;
      const lz = this.z + (sz / len) * reach;
      if (world.fluidAt(lx, y, lz) || world.fluidAt(lx, this.y + 0.08, lz) || world.waterColumn(Math.floor(lx), Math.floor(lz))) {
        return [sx / len, sz / len];
      }
    }
    return [0, 0];
  }

  private turnToward(target: number, dt: number, rate: number) {
    let diff = target - this.yaw;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    const max = rate * dt;
    this.yaw += Math.max(-max, Math.min(max, diff));
  }

  private pickWaterTarget(world: World, radius: number) {
    const tries = this.kind === "tucunare" ? 14 : 8;
    for (let i = 0; i < tries; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = 0.6 + Math.random() * radius;
      const nx = this.x + Math.cos(a) * r;
      const nz = this.z + Math.sin(a) * r;
      if (world.waterColumn(Math.floor(nx), Math.floor(nz))) {
        this.tx = nx;
        this.tz = nz;
        return;
      }
    }
    this.tx = this.x;
    this.tz = this.z;
  }

  private touchPassage(world: World, wishX: number, wishZ: number) {
    if (this.heldDoor) {
      const d = Math.hypot(this.heldDoor.x + 0.5 - this.x, this.heldDoor.z + 0.5 - this.z);
      if (d > 1.45) {
        const id = world.getBlock(this.heldDoor.x, this.heldDoor.y, this.heldDoor.z);
        if ((isDoor(id) && isDoorOpen(id)) || (isGate(id) && isGateOpen(id))) {
          world.togglePassage(this.heldDoor.x, this.heldDoor.y, this.heldDoor.z);
        }
        this.heldDoor = null;
      }
    }
    if (Math.hypot(wishX, wishZ) < 0.15) return;
    const ix = Math.floor(this.x + wishX * 0.8);
    const iz = Math.floor(this.z + wishZ * 0.8);
    const iy = Math.floor(this.y + 0.1);
    for (const y of [iy, iy + 1]) {
      const id = world.getBlock(ix, y, iz);
      const shut = (isDoor(id) && !isDoorOpen(id)) || (isGate(id) && !isGateOpen(id));
      if (!shut) continue;
      world.togglePassage(ix, y, iz);
      this.heldDoor = { x: ix, y, z: iz };
      return;
    }
  }

  private applyMove(dt: number, world: World, wishX: number, wishZ: number, fish: boolean) {
    if (this.quake && this.grounded && !this.fluid && this.vy < 1.5) {
      this.vx *= 0.75;
      this.vz *= 0.75;
    }
    const moved = moveAABB(
      world,
      this.x - this.w / 2,
      this.y,
      this.z - this.d / 2,
      this.w,
      this.h,
      this.d,
      this.vx,
      this.vy,
      this.vz,
      dt,
      fish ? 0.4 : 1.05,
      this.kind === "aldeao",
    );
    this.x = moved.x + this.w / 2;
    this.y = moved.y;
    this.z = moved.z + this.d / 2;
    this.vy = moved.vy;
    this.grounded = moved.onGround && !this.fluid;
    if (moved.vx === 0 && moved.vz === 0 && (wishX !== 0 || wishZ !== 0)) {
      if (fish) {
        if (this.turnLock <= 0) {
          this.turnLock = 0.4;
          this.wanderT = 0;
          this.yaw += (Math.random() < 0.5 ? 1 : -1) * 1.05;
        }
      } else if (moved.onGround && this.turnLock <= 0 && this.canHopStep(world, wishX, wishZ)) {
        this.vy = 5.4;
        this.turnLock = 0.7;
      } else if (this.kind === "aldeao") {
        this.wanderT = 0;
        this.tx = this.x - wishX;
        this.tz = this.z - wishZ;
      }
    }
  }


  private paintHurt(night: boolean) {
    for (const m of this.flash) {
      if (this.hurtT > 0) setEmissive(m, 0x662222);
      else if (this.kind === "murcha") {
        if (typeof m.userData.glow === "number") setEmissive(m, m.userData.glow);
        else setEmissive(m, night ? 0x1a2208 : 0x000000);
      }
      else if (this.kind === "beholder") {
        if (this.summonT > 5.55) setEmissive(m, 0x8a3ad0);
        else if (typeof m.userData.glow === "number") setEmissive(m, m.userData.glow);
        else setEmissive(m, 0x140818);
      } else setEmissive(m, 0x000000);
    }
  }

  dispose() {
    this.clearMesh();
  }
}
