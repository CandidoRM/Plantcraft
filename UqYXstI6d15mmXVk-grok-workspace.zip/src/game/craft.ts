import {
  AIR,
  ARAU_LOG,
  BIRCH_LOG,
  CRAFTING_TABLE,
  DARK_LOG,
  DOOR,
  FENCE,
  LOG,
  PLANKS,
  SHOVEL,
  STICK,
  type BlockId,
} from "./blocks";
import type { Slot } from "./store";

type Ing = number | number[];

type Recipe =
  | { kind: "shapeless"; input: Ing[]; out: number; n: number }
  | { kind: "shaped"; rows: Ing[][]; out: number; n: number };

const LOGS: number[] = [LOG, BIRCH_LOG, DARK_LOG, ARAU_LOG];

const RECIPES: Recipe[] = [
  { kind: "shapeless", input: [LOGS], out: PLANKS, n: 4 },
  { kind: "shaped", rows: [[PLANKS], [PLANKS]], out: STICK, n: 4 },
  {
    kind: "shaped",
    rows: [
      [PLANKS, PLANKS],
      [PLANKS, PLANKS],
    ],
    out: CRAFTING_TABLE,
    n: 1,
  },
  {
    kind: "shaped",
    rows: [
      [PLANKS, STICK, PLANKS],
      [PLANKS, STICK, PLANKS],
    ],
    out: FENCE,
    n: 3,
  },
  {
    kind: "shaped",
    rows: [
      [PLANKS, PLANKS],
      [PLANKS, PLANKS],
      [PLANKS, PLANKS],
    ],
    out: DOOR,
    n: 3,
  },
  { kind: "shaped", rows: [[PLANKS], [STICK], [STICK]], out: SHOVEL, n: 1 },
];

function same(id: number, ing: Ing): boolean {
  return Array.isArray(ing) ? ing.includes(id) : id === ing;
}

function gridIds(grid: Slot[], size: 2 | 3): number[][] {
  const g: number[][] = [];
  for (let r = 0; r < size; r++) {
    const row: number[] = [];
    for (let c = 0; c < size; c++) {
      const s = grid[r * 3 + c];
      row.push(s && s.count > 0 ? s.id : AIR);
    }
    g.push(row);
  }
  return g;
}

function bbox(g: number[][]): { r0: number; c0: number; r1: number; c1: number } | null {
  let r0 = 99;
  let c0 = 99;
  let r1 = -1;
  let c1 = -1;
  for (let r = 0; r < g.length; r++) {
    for (let c = 0; c < g[r]!.length; c++) {
      if (!g[r]![c]) continue;
      r0 = Math.min(r0, r);
      c0 = Math.min(c0, c);
      r1 = Math.max(r1, r);
      c1 = Math.max(c1, c);
    }
  }
  if (r1 < 0) return null;
  return { r0, c0, r1, c1 };
}

function shaped(g: number[][], rows: Ing[][], mirror: boolean): boolean {
  const box = bbox(g);
  if (!box) return false;
  const h = box.r1 - box.r0 + 1;
  const w = box.c1 - box.c0 + 1;
  if (h !== rows.length || w !== rows[0]!.length) return false;
  for (let r = 0; r < h; r++) {
    if (rows[r]!.length !== w) return false;
    for (let c = 0; c < w; c++) {
      const ing = rows[r]![mirror ? w - 1 - c : c]!;
      const id = g[box.r0 + r]![box.c0 + c]!;
      if (!id || !same(id, ing)) return false;
    }
  }
  return true;
}

function shapeless(g: number[][], input: Ing[]): boolean {
  const ids: number[] = [];
  for (const row of g) for (const id of row) if (id) ids.push(id);
  if (ids.length !== input.length) return false;
  const used = new Array(input.length).fill(false);
  for (const id of ids) {
    const i = input.findIndex((ing, k) => !used[k] && same(id, ing));
    if (i < 0) return false;
    used[i] = true;
  }
  return true;
}

export function matchCraft(grid: Slot[], size: 2 | 3): { id: BlockId; n: number } | null {
  const g = gridIds(grid, size);
  for (const recipe of RECIPES) {
    if (recipe.kind === "shapeless") {
      if (shapeless(g, recipe.input)) return { id: recipe.out, n: recipe.n };
    } else if (shaped(g, recipe.rows, false) || shaped(g, recipe.rows, true)) {
      return { id: recipe.out, n: recipe.n };
    }
  }
  return null;
}
