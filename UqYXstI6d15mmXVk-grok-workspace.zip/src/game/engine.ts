import * as THREE from "three";
import { GameAudio } from "./audio";
import {
  ACID,
  AIR,
  BLOCK_COLOR,
  BLOCK_NAME,
  CARPET_H,
  CERRADO_CARPET,
  CERRADO_CARPET_WET,
  DIRT,
  CANDLE,
  CANDLE_LIT,
  COMODA,
  CRAFTING_TABLE,
  DOOR,
  FARMLAND,
  FOOD_ACAI,
  FOOD_AVOCADO,
  FOOD_BANANA,
  FOOD_CASSAVA,
  FOOD_CASSAVA_RAW,
  FOOD_COCONUT,
  FOOD_CORN,
  FOOD_GUAVA,
  FOOD_MANGO,
  FOOD_ORANGE,
  FOOD_PINEAPPLE,
  FOOD_RICE,
  GRASS_CARPET,
  GRASS_CARPET_WET,
  MELON,
  MELON_ATTACH,
  MELON_SEEDS,
  MELON_SLICE,
  MELON_STEM,
  PATH,
  PEACH,
  PEACH_LEAVES,
  FOOD_PEACH,
  RED_CARPET,
  RICCIA,
  SHOVEL,
  VARZEA_CARPET,
  VARZEA_GRASS,
  WATER,
  canSupportCarpet,
  canHoldFruit,
  dropsFrom,
  aimBox,
  fluidFill,
  fluidKind,
  hardness,
  isBreakable,
  isCandle,
  isDoor,
  isGate,
  isGardenFlower,
  isCrop,
  isStem,
  isCarpet,
  isCerradoCarpet,
  isFloorCarpet,
  isFluid,
  isGrassCarpet,
  isItemOnly,
  isLeaves,
  isLog,
  isPlant,
  isRiccia,
  isSoil,
  isSolid,
  isTarget,
  isVine,
  isWater,
  isWeed,
  isFood,
  leafAtlasTile,
  stemFromStage,
  STEM_DIRS,
  vineFace,
  vineFaceFromNormal,
  vineId,
  vineSpecies,
  type FluidKind,
} from "./blocks";
import { buildNest, type BirdKind } from "./birds";
import { Creature, isFish } from "./creatures";
import { type FishKind } from "./fishes";
import { Input } from "./input";
import { rand2 } from "./noise";
import { tileUv } from "./textures";
import { moveAABB, overlapsBlock, voxelRaycast } from "./physics";
import { clearSave, INV_REV, loadSave, writeSave, type SaveData } from "./save";
import { useGame, packSlots, emptySlot, starterSlots, HOTBAR_LEN, type GameHandle, type Phase, type Slot } from "./store";
import { matchCraft } from "./craft";
import { foodDef } from "./foods";
import { villagerLine } from "./villagers";
import { CHUNK, HEIGHT, WORLD_LIFT, World, type FissureCol } from "./world";
import { leafUv } from "./textures";

const EYE = 1.7;
const PW = 0.6;
const PH = 2;
const PD = 0.6;
const GRAVITY = 28;
const JUMP = 8.6;
const WALK = 4.4;
const SPRINT = 6.1;
const SENS = 0.00215;
const REACH = 6;
const PARTICLE_CAP = 140;

const PART_GEO = {
  burst: new THREE.BoxGeometry(0.12, 0.12, 0.12),
  splash: new THREE.BoxGeometry(0.07, 0.07, 0.07),
  bubble: new THREE.BoxGeometry(0.07, 0.07, 0.07),
  wake: new THREE.BoxGeometry(0.09, 0.03, 0.09),
  drip: new THREE.BoxGeometry(0.045, 0.09, 0.045),
};

const STONE_PEBBLE_GEO = (() => {
  const g = new THREE.BoxGeometry(0.12, 0.12, 0.12);
  const uv = tileUv(3);
  const attr = g.getAttribute("uv") as THREE.BufferAttribute;
  for (let i = 0; i < attr.count; i++) {
    const u = attr.getX(i);
    const v = attr.getY(i);
    attr.setXY(i, uv.u0 + u * (uv.u1 - uv.u0), uv.v0 + v * (uv.v1 - uv.v0));
  }
  attr.needsUpdate = true;
  return g;
})();

const LEAF_GEO = [0, 1, 2, 3, 4].map((tile) => {
  const g = new THREE.PlaneGeometry(0.16, 0.16);
  const uv = leafUv(tile);
  const attr = g.getAttribute("uv") as THREE.BufferAttribute;
  for (let i = 0; i < attr.count; i++) {
    attr.setXY(i, attr.getX(i) > 0.5 ? uv.u1 : uv.u0, attr.getY(i) > 0.5 ? uv.v1 : uv.v0);
  }
  attr.needsUpdate = true;
  return g;
});

type Particle = {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  mode: "burst" | "splash" | "bubble" | "wake" | "trapped" | "leaf" | "drip";
  kind?: FluidKind;
  baseOp: number;
  homeX?: number;
  homeY?: number;
  homeZ?: number;
  wobble?: number;
  slow?: boolean;
  huge?: boolean;
  /** Pebble tossed in an arc onto a neighboring block. */
  arc?: boolean;
  /** Seconds left while a huge bubble is being inhaled. */
  sip?: number;
  stickKey?: string;
  spinX?: number;
  spinY?: number;
  spinZ?: number;
};

export type Game = {
  dispose: () => void;
};

export function createGame(canvas: HTMLCanvasElement): Game {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    powerPreference: "high-performance",
    alpha: false,
  });
  renderer.setPixelRatio(1);
  renderer.setSize(canvas.clientWidth || window.innerWidth, canvas.clientHeight || window.innerHeight, false);
  renderer.setClearColor(0x87b4d6);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.autoClear = false;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x87b4d6, 0.012);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.08, 220);
  const hemi = new THREE.HemisphereLight(0xb8d4ff, 0x3d4a28, 0.7);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff2d0, 1.1);
  sun.position.set(40, 80, 20);
  scene.add(sun);

  const input = new Input();
  input.enabled = false;
  input.attach(canvas);

  const audio = new GameAudio();

  let seed = (Math.random() * 1e9) | 0;
  let world = new World(seed);
  scene.add(world.group);

  const highlight = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002, 1.002, 1.002)),
    new THREE.LineBasicMaterial({ color: 0x1a1a14 }),
  );
  highlight.visible = false;
  scene.add(highlight);

  const hand = new THREE.Mesh(
    new THREE.BoxGeometry(0.28, 0.28, 0.28),
    new THREE.MeshLambertMaterial({ color: 0x5a9a45 }),
  );
  hand.position.set(0.38, -0.32, -0.62);
  camera.add(hand);
  scene.add(camera);

  const skinMat = new THREE.MeshLambertMaterial({ color: 0xc48a62 });
  const clothMat = new THREE.MeshLambertMaterial({ color: 0x2f6a48 });
  const shoeMat = new THREE.MeshLambertMaterial({ color: 0x241c14 });
  const playerMesh = new THREE.Group();
  const addLimb = (parent: THREE.Object3D, w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  };
  const torso = new THREE.Group();
  torso.position.y = 0.98;
  addLimb(torso, 0.52, 0.56, 0.28, clothMat, 0, 0, 0);
  const headPivot = new THREE.Group();
  headPivot.position.set(0, 0.3, 0);
  addLimb(headPivot, 0.44, 0.42, 0.42, skinMat, 0, 0.21, 0);
  torso.add(headPivot);
  const armL = new THREE.Group();
  armL.position.set(0.38, 0.18, 0);
  addLimb(armL, 0.14, 0.52, 0.14, skinMat, 0, -0.22, 0);
  torso.add(armL);
  const armR = new THREE.Group();
  armR.position.set(-0.38, 0.18, 0);
  addLimb(armR, 0.14, 0.52, 0.14, skinMat, 0, -0.22, 0);
  torso.add(armR);
  playerMesh.add(torso);
  const legL = new THREE.Group();
  legL.position.set(0.12, 0.7, 0);
  addLimb(legL, 0.16, 0.52, 0.16, clothMat, 0, -0.24, 0);
  addLimb(legL, 0.18, 0.08, 0.22, shoeMat, 0, -0.52, 0.02);
  playerMesh.add(legL);
  const legR = new THREE.Group();
  legR.position.set(-0.12, 0.7, 0);
  addLimb(legR, 0.16, 0.52, 0.16, clothMat, 0, -0.24, 0);
  addLimb(legR, 0.18, 0.08, 0.22, shoeMat, 0, -0.52, 0.02);
  playerMesh.add(legR);
  playerMesh.visible = false;
  scene.add(playerMesh);

  let x = 0.5;
  let y = 30;
  let z = 0.5;
  let yaw = 0;
  let pitch = 0;
  const COMPASS_BIOMES = [
    { name: "Floresta", x: 0, z: 0 },
    { name: "Cerrado", x: -160, z: 0 },
    { name: "Caatinga", x: 20, z: 160 },
    { name: "Pátio de Mármore", x: 180, z: 0 },
    { name: "Brejo", x: 0, z: -160 },
  ];
  let compassI = 0;
  let compassWas = false;
  let vx = 0;
  let vy = 0;
  let vz = 0;
  let onGround = false;
  let coyote = 0;
  let jumpBuf = 0;
  let health = 10;
  const maxHealth = 10;
  let hunger = 20;
  let sat = 5;
  let exhaust = 0;
  let starveT = 0;
  let regenT = 0;
  let eatT = 0;
  let eatId = 0;
  let oxygen = 100;
  let invuln = 0;
  let slots: Slot[] = starterSlots();
  let selected = 0;
  let inventoryOpen = false;
  let craftSize: 2 | 3 = 2;
  const craft: Slot[] = Array.from({ length: 9 }, emptySlot);
  let craftOut: Slot = emptySlot();
  let third = false;
  let sneaking = false;
  let cursor: Slot = emptySlot();
  let hadLock = false;
  let relockAt = 0;
  let time = 0.22;
  let phase: Phase = "menu";
  let mine = 0;
  let mineKey = "";
  let swing = 0;
  let bob = 0;
  let stepT = 0;
  let saveAcc = 0;
  let hudAcc = 0;
  let hurtFlash = 0;
  let creatures: Creature[] = [];
  const nests: THREE.Group[] = [];
  const particles: Particle[] = [];
  type Floater = {
    mesh: THREE.Mesh;
    x: number;
    y: number;
    z: number;
    vx: number;
    vy: number;
    vz: number;
    id: number;
    n: number;
    life: number;
    tag: number;
    claimed: boolean;
  };
  const floaters: Floater[] = [];
  let floaterTag = 1;
  let submerged = false;
  let waterClock = 0;
  let wasFluid: FluidKind | null = null;
  let wasLiquidBlock: FluidKind | null = null;
  let wasLeaves = false;
  let eyeFluid: FluidKind | null = null;
  let splashAcc = 0;
  let bubbleAcc = 0;
  let ricciaAcc = 0;
  let aquiferAcc = 0;
  let fishScanAcc = 0;
  let wasNight = false;
  let hovering = false;
  let hoverY = 0;
  let breathing = false;
  let hintT = 0;
  let shownTarget = "";
  let shownHint = "";
  let quakeWait = 52 + Math.random() * 40;
  let quakeStage = 0;
  let quakeLeft = 0;
  let quakeLen = 1;
  let quakeAmp = 0;
  let quakeJolt = 0;
  let jobs: { cols: FissureCol[]; age: number; seeped: boolean; started: boolean; mode: "open" | "close" }[] = [];
  const openDitches: FissureCol[][] = [];
  const graves: FissureCol[][] = [];
  const ricciaStuck = new Map<string, number>();
  const seededLakes = new Set<string>();
  const FISH_CAP = 80;

  const addCreature = (kind: Creature["kind"], x: number, y: number, z: number, stage: Creature["stage"] = "adult") => {
    const c = new Creature(kind, x, y, z, stage);
    creatures.push(c);
    scene.add(c.group);
    return c;
  };

  const spawnCreatures = () => {
    for (const c of creatures) {
      scene.remove(c.group);
      c.dispose();
    }
    creatures = [];
    for (const n of nests) {
      scene.remove(n);
      n.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.geometry.dispose();
          const list = Array.isArray(o.material) ? o.material : [o.material];
          for (const m of list) m.dispose();
        }
      });
    }
    nests.length = 0;
    seededLakes.clear();
    wasNight = false;
    const spots: { x: number; z: number; kind: Creature["kind"]; stage: Creature["stage"] }[] = [
      { x: 8, z: 6, kind: "capivara", stage: "adult" },
      { x: 9.2, z: 6.7, kind: "capivara", stage: "baby" },
      { x: -10, z: 12, kind: "capivara", stage: "adult" },
      { x: -6, z: 10, kind: "vaca", stage: "adult" },
      { x: -5.1, z: 10.7, kind: "vaca", stage: "baby" },
      { x: 14, z: 8, kind: "porco", stage: "adult" },
      { x: 14.8, z: 8.6, kind: "porco", stage: "baby" },
      { x: 6, z: -16, kind: "ovelha", stage: "adult" },
      { x: 6.9, z: -15.3, kind: "ovelha", stage: "baby" },
      { x: -32, z: 8, kind: "tamandua", stage: "adult" },
      { x: -31.2, z: 8.7, kind: "tamandua", stage: "baby" },
      { x: 24, z: 16, kind: "tucano", stage: "adult" },
      { x: 24.7, z: 16.6, kind: "tucano", stage: "baby" },
    ];
    for (const s of spots) {
      world.ensureChunk(Math.floor(s.x / CHUNK), Math.floor(s.z / CHUNK));
      const pos = findCreatureGround(s.x, s.z);
      addCreature(s.kind, pos.x, pos.y, pos.z, s.stage);
    }
    spawnBirds();
    spawnDitchFish();
    spawnVillage();
    const kinds = ["lambari", "tucunare", "traira", "cascudo"] as const;
    world.fishPool.forEach((p, i) => {
      if (i % 2 === 0) addCreature(kinds[i % kinds.length]!, p.x, p.y, p.z, "adult");
    });
    for (const a of world.penSpawns) addCreature(a.kind, a.x, a.y, a.z, "adult");
    seedLakesNear(0, 0);
  };

  function addNest(kind: BirdKind, x: number, y: number, z: number) {
    const n = buildNest(kind);
    n.position.set(x, y, z);
    scene.add(n);
    nests.push(n);
  }

  function ensureAround(wx: number, wz: number, r: number) {
    const minCx = Math.floor((wx - r) / CHUNK);
    const maxCx = Math.floor((wx + r) / CHUNK);
    const minCz = Math.floor((wz - r) / CHUNK);
    const maxCz = Math.floor((wz + r) / CHUNK);
    for (let cx = minCx; cx <= maxCx; cx++) {
      for (let cz = minCz; cz <= maxCz; cz++) world.ensureChunk(cx, cz);
    }
    spawnMantises(wx, wz);
  }

  function spawnMantises(px: number, pz: number) {
    for (const n of world.mantisNests) {
      if (n.used) continue;
      if (Math.hypot(n.x - px, n.z - pz) > 36) continue;
      n.used = true;
      world.ensureChunk(Math.floor(n.x / CHUNK), Math.floor(n.z / CHUNK));
      const pos = findCreatureGround(Math.floor(n.x), Math.floor(n.z));
      const m = addCreature("louva", pos.x, pos.y, pos.z, "adult");
      m.setHome(pos.x, pos.y, pos.z);
    }
  }

  function nestAir(id: number) {
    return id === AIR || isPlant(id) || isCarpet(id);
  }

  function scanTreeSeat(sx: number, sz: number, used: Set<string>): { x: number; y: number; z: number } | null {
    const radius = 16;
    ensureAround(sx, sz, radius + 4);
    const ix = Math.floor(sx);
    const iz = Math.floor(sz);
    const trunks: { x: number; z: number; top: number }[] = [];
    for (let dx = -radius; dx <= radius; dx++) {
      for (let dz = -radius; dz <= radius; dz++) {
        const x = ix + dx;
        const z = iz + dz;
        let logTop = -1;
        for (let y = 3; y < HEIGHT - 2; y++) {
          if (isLog(world.getBlock(x, y, z))) logTop = y;
        }
        if (logTop >= 4) trunks.push({ x, z, top: logTop });
      }
    }
    trunks.sort((a, b) => (a.x - ix) ** 2 + (a.z - iz) ** 2 - ((b.x - ix) ** 2 + (b.z - iz) ** 2));
    for (const t of trunks.slice(0, 10)) {
      let best: { x: number; y: number; z: number; score: number } | null = null;
      for (let dx = -3; dx <= 3; dx++) {
        for (let dz = -3; dz <= 3; dz++) {
          if (dx === 0 && dz === 0) continue;
          const x = t.x + dx;
          const z = t.z + dz;
          for (let y = t.top - 2; y <= t.top + 4; y++) {
            if (y < 2 || y >= HEIGHT - 2) continue;
            const id = world.getBlock(x, y, z);
            if (!isLeaves(id) && !isLog(id)) continue;
            let top = y;
            while (top < HEIGHT - 2 && isLeaves(world.getBlock(x, top + 1, z))) top++;
            if (!nestAir(world.getBlock(x, top + 1, z))) continue;
            if (isSolid(world.getBlock(x, top + 2, z)) && !isLeaves(world.getBlock(x, top + 2, z))) continue;
            const key = `${x},${top + 1},${z}`;
            if (used.has(key)) continue;
            const score = (isLeaves(world.getBlock(x, top, z)) ? 5 : 1) + Math.abs(dx) + Math.abs(dz) * 0.35;
            if (!best || score > best.score) best = { x, y: top + 1, z, score };
          }
        }
      }
      if (best) {
        used.add(`${best.x},${best.y},${best.z}`);
        return { x: best.x + 0.5, y: best.y, z: best.z + 0.5 };
      }
    }
    return null;
  }

  function findTreeNestSeat(sx: number, sz: number, used: Set<string>) {
    const tries: [number, number][] = [
      [sx, sz],
      [sx + 8, sz],
      [sx - 8, sz],
      [sx, sz + 8],
      [sx, sz - 8],
      [sx + 12, sz + 6],
      [sx - 10, sz + 10],
      [sx + 16, sz - 8],
    ];
    for (const [tx, tz] of tries) {
      const found = scanTreeSeat(tx, tz, used);
      if (found) return found;
    }
    return null;
  }

  function spawnVillage() {
    const spots = world.placeHamlet();
    for (const s of spots) {
      world.ensureChunk(Math.floor(s.x / CHUNK), Math.floor(s.z / CHUNK));
      const v = addCreature("aldeao", s.x, s.y, s.z, s.role === "crianca" ? "baby" : "adult");
      v.setRole(s.role);
      v.setHome(s.x, s.y, s.z);
      v.meetX = world.hamletMeet.x;
      v.meetZ = world.hamletMeet.z;
    }
  }

  function spawnBirds() {
    const used = new Set<string>();
    const placeTree = (kind: BirdKind, sx: number, sz: number) => {
      const seat = findTreeNestSeat(sx, sz, used);
      if (!seat) {
        const pos = findCreatureGround(sx, sz);
        const adult = addCreature(kind, pos.x, pos.y + 0.35, pos.z, "adult");
        adult.setHome(pos.x, pos.y + 0.4, pos.z);
        const baby = addCreature(kind, pos.x + 0.4, pos.y + 0.2, pos.z - 0.2, "baby");
        baby.setHome(pos.x, pos.y + 0.4, pos.z);
        return;
      }
      addNest(kind, seat.x, seat.y, seat.z);
      const adult = addCreature(kind, seat.x, seat.y + 0.16, seat.z, "adult");
      adult.setHome(seat.x, seat.y + 0.12, seat.z);
      const baby = addCreature(kind, seat.x + 0.32, seat.y + 0.18, seat.z - 0.22, "baby");
      baby.setHome(seat.x, seat.y + 0.12, seat.z);
    };
    const placeGround = (kind: BirdKind, sx: number, sz: number) => {
      const pos = findCreatureGround(sx, sz);
      const by = Math.floor(pos.y);
      const nestY = isCarpet(world.getBlock(Math.floor(pos.x), by, Math.floor(pos.z))) ? pos.y + CARPET_H : pos.y;
      addNest(kind, pos.x, nestY, pos.z);
      const adult = addCreature(kind, pos.x, nestY + 0.12, pos.z, "adult");
      adult.setHome(pos.x, nestY + 0.08, pos.z);
      const baby = addCreature(kind, pos.x + 0.32, nestY + 0.05, pos.z - 0.22, "baby");
      baby.setHome(pos.x, nestY + 0.08, pos.z);
    };
    placeTree("beijaflor", 8.6, 18.4);
    placeTree("arara", 16, -12);
    placeGround("joaobarro", 4, 14);
  }

  function spawnDitchFish() {
    world.ensureChunk(0, -1);
    const places: { kind: FishKind; x: number; z: number; stage: Creature["stage"] }[] = [
      { kind: "lambari", x: -1.15, z: -7.25, stage: "adult" },
      { kind: "lambari", x: -0.15, z: -7.65, stage: "adult" },
      { kind: "lambari", x: 0.55, z: -7.2, stage: "baby" },
      { kind: "cascudo", x: 1.35, z: -7.55, stage: "adult" },
      { kind: "tucunare", x: -1.55, z: -8.25, stage: "adult" },
    ];
    for (const p of places) {
      const col = world.waterColumn(Math.floor(p.x), Math.floor(p.z));
      if (!col) continue;
      let y = col.bed + 0.08;
      if (p.kind === "lambari") y = col.bed + 0.35;
      else if (p.kind === "tucunare") y = col.bed + 0.45;
      addCreature(p.kind, p.x, y, p.z, p.stage);
    }
    seededLakes.add("0,-1");
  }

  function fishCount() {
    let n = 0;
    for (const c of creatures) if (c.alive && c.fish) n++;
    return n;
  }

  function seedLakesNear(px: number, pz: number) {
    if (fishCount() >= FISH_CAP) return;
    const r = 22;
    const ox = Math.floor(px);
    const oz = Math.floor(pz);
    type Cell = { x: number; z: number; bed: number; top: number };
    const cells: Cell[] = [];
    for (let x = ox - r; x <= ox + r; x++) {
      for (let z = oz - r; z <= oz + r; z++) {
        const col = world.waterColumn(x, z);
        if (!col || world.biomeAt(x, z) === "marble") continue;
        cells.push({ x, z, bed: col.bed, top: col.top });
      }
    }
    const keyOf = (x: number, z: number) => `${x},${z}`;
    const map = new Map(cells.map((c) => [keyOf(c.x, c.z), c]));
    const seen = new Set<string>();
    for (const c of cells) {
      const start = keyOf(c.x, c.z);
      if (seen.has(start)) continue;
      const q = [c];
      seen.add(start);
      const group: Cell[] = [];
      while (q.length) {
        const cur = q.pop()!;
        group.push(cur);
        for (const [dx, dz] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ] as const) {
          const nk = keyOf(cur.x + dx, cur.z + dz);
          if (seen.has(nk) || !map.has(nk)) continue;
          seen.add(nk);
          q.push(map.get(nk)!);
        }
      }
      let sx = 0;
      let sz = 0;
      for (const g of group) {
        sx += g.x;
        sz += g.z;
      }
      const cx = (sx / group.length) | 0;
      const cz = (sz / group.length) | 0;
      const extremeWet = !!(world.basinAt(cx, cz)?.extreme && !world.basinAt(cx, cz)?.dry);
      if (group.length < 8 && !extremeWet) continue;
      const lk = `${Math.floor(cx / 8)},${Math.floor(cz / 8)}`;
      if (seededLakes.has(lk)) continue;
      seededLakes.add(lk);
      spawnFishInBody(group, cx, cz);
      if (fishCount() >= FISH_CAP) return;
    }
  }

  function spawnFishInBody(group: { x: number; z: number; bed: number; top: number }[], cx: number, cz: number) {
    const depth = group.reduce((m, g) => Math.max(m, g.top - g.bed + 1), 0);
    const n = group.length;
    const basin = world.basinAt(cx, cz);
    const extreme = !!(basin && basin.extreme && !basin.dry) || depth >= 9;
    const pick = (salt: number) => group[(rand2(cx + salt, cz, seed + 601) * group.length) | 0]!;
    const put = (kind: FishKind, cell: { x: number; z: number; bed: number; top: number }, yOff: number, stage: Creature["stage"] = "adult") => {
      if (fishCount() >= FISH_CAP) return;
      if (world.biomeAt(cell.x, cell.z) === "marble") return;
      const span = Math.max(0.12, cell.top - cell.bed);
      const y = cell.bed + Math.min(span - 0.05, Math.max(0.04, yOff));
      addCreature(kind, cell.x + 0.5, y, cell.z + 0.5, stage);
    };

    const lambariN = extreme ? Math.min(16, 10 + ((n / 18) | 0)) : Math.min(6, 2 + ((n / 28) | 0));
    for (let i = 0; i < lambariN; i++) {
      const cell = pick(i);
      const y = 0.25 + rand2(cell.x, cell.z, seed + 611) * Math.max(0.15, cell.top - cell.bed - 0.2);
      put("lambari", cell, y, rand2(cell.x, cell.z, seed + 621) > 0.72 ? "baby" : "adult");
    }

    const cascudoN = extreme ? 3 + (n > 40 ? 2 : 1) : rand2(cx, cz, seed + 501) > 0.62 ? 1 + (n > 80 && rand2(cx, cz, seed + 511) > 0.7 ? 1 : 0) : 0;
    for (let i = 0; i < cascudoN; i++) {
      const cell = pick(30 + i);
      put("cascudo", cell, 0.03, rand2(cell.x, cell.z, seed + 531) > 0.82 ? "baby" : "adult");
    }

    const tucuN = extreme ? 2 + (n > 50 ? 1 : 0) : depth >= 2 && n >= 18 && rand2(cx, cz, seed + 502) > 0.88 ? 1 : 0;
    for (let i = 0; i < tucuN; i++) {
      const deep = group.filter((g) => g.top - g.bed >= 1);
      const cell = (deep.length ? deep : group)[(rand2(cx + i, cz, seed + 541) * (deep.length || group.length)) | 0]!;
      put("tucunare", cell, 0.4, "adult");
      if (!extreme && rand2(cx, cz, seed + 551) > 0.78) put("tucunare", cell, 0.35, "baby");
    }

    const trairaN = extreme ? 2 + (n > 60 ? 1 : 0) : n >= 12 && rand2(cx, cz, seed + 561) > 0.55 ? 1 : 0;
    for (let i = 0; i < trairaN; i++) {
      const cell = pick(80 + i * 11);
      put("traira", cell, 0.18 + (cell.top - cell.bed) * 0.2, "adult");
    }

    const brancoN = extreme ? 1 + (n > 70 && rand2(cx, cz, seed + 571) > 0.45 ? 1 : 0) : n >= 28 && rand2(cx, cz, seed + 572) > 0.97 ? 1 : 0;
    for (let i = 0; i < brancoN; i++) {
      const cell = pick(120 + i * 7);
      put("branco", cell, Math.max(0.2, (cell.top - cell.bed) * 0.55), "adult");
    }
  }

  function showTarget(t: string) {
    if (t === shownTarget) return;
    shownTarget = t;
    useGame.getState().setHud({ target: t });
  }

  function showHint(t: string) {
    if (t === shownHint) return;
    shownHint = t;
    useGame.getState().setHud({ hint: t });
  }

  function spawnQuakeDust() {
    for (let i = 0; i < 8; i++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = 1.2 + Math.random() * 10.6;
      const px = x + Math.cos(ang) * rad;
      const pz = z + Math.sin(ang) * rad;
      const sy = world.surfaceY(Math.floor(px), Math.floor(pz));
      const pebble = i < 2;
      emitParticle(
        "burst",
        px,
        sy + 0.04,
        pz,
        pebble ? 0x8d8478 : 0xa07a48,
        {
          vx: (Math.random() - 0.5) * (pebble ? 1.5 : 0.55),
          vy: pebble ? 1.8 + Math.random() * 1.1 : 0.45 + Math.random() * 0.7,
          vz: (Math.random() - 0.5) * (pebble ? 1.5 : 0.55),
        },
        pebble ? 0.75 : 0.42,
        0.82,
      );
    }
  }

  function spawnQuakePebbles() {
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    const n = 1;
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = 1.5 + Math.random() * 9.5;
      const ix = Math.floor(x + Math.cos(ang) * rad);
      const iz = Math.floor(z + Math.sin(ang) * rad);
      const [dx, dz] = dirs[(Math.random() * dirs.length) | 0]!;
      const sy = world.surfaceY(ix, iz);
      const ty = world.surfaceY(ix + dx, iz + dz);
      const dy = ty - sy;
      const peak = Math.max(1 + Math.random(), dy + 0.2);
      if (peak > 2.05) continue;
      const g = 18;
      const vy0 = Math.sqrt(2 * g * peak);
      const disc = vy0 * vy0 - 2 * g * dy;
      if (disc < 0) continue;
      const flight = (vy0 + Math.sqrt(disc)) / g;
      const p = emitParticle(
        "burst",
        ix + 0.5,
        sy + 0.08,
        iz + 0.5,
        Math.random() < 0.5 ? 0x8d8478 : 0x6e655c,
        { vx: dx / flight, vy: vy0, vz: dz / flight },
        flight + 0.35,
        1,
      );
      if (!p) continue;
      audio.pebbleCrack();
      p.arc = true;
      p.homeX = ix + dx + 0.5;
      p.homeY = ty + 0.08;
      p.homeZ = iz + dz + 0.5;
      p.mesh.geometry = STONE_PEBBLE_GEO;
      p.mesh.scale.setScalar(1.1);
      const skin = p.mesh.material as THREE.MeshLambertMaterial;
      skin.map = world.material.map;
      skin.color.setHex(0xffffff);
    }
  }

  function spawnQuakeLeaves() {
    for (let n = 0; n < 10; n++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = Math.random() * 12;
      const ix = Math.floor(x + Math.cos(ang) * rad);
      const iz = Math.floor(z + Math.sin(ang) * rad);
      const top = Math.min(HEIGHT - 2, Math.floor(y) + 16);
      const bot = Math.max(1, Math.floor(y) - 8);
      for (let iy = top; iy >= bot; iy--) {
        const id = world.getBlock(ix, iy, iz);
        if (!isLeaves(id)) continue;
        let ground = 1;
        for (let gy = iy - 1; gy >= 1; gy--) {
          const under = world.getBlock(ix, gy, iz);
          if (under === AIR || isLeaves(under) || isLog(under) || isPlant(under) || isCarpet(under) || isFluid(under)) continue;
          if (isSolid(under)) {
            ground = gy + 1;
            break;
          }
        }
        const group = Math.random() < 0.5;
        const count = group ? 3 + ((Math.random() * 3) | 0) : 1;
        for (let i = 0; i < count; i++) {
          const spread = group ? 0.55 : 0.12;
          const p = emitParticle(
            "leaf",
            ix + 0.5 + (Math.random() - 0.5) * spread,
            iy + 0.35 + Math.random() * 0.4,
            iz + 0.5 + (Math.random() - 0.5) * spread,
            0xffffff,
            {
              vx: (Math.random() - 0.5) * 0.4,
              vy: -0.15 - Math.random() * 0.35,
              vz: (Math.random() - 0.5) * 0.4,
            },
            6,
            0.95,
            undefined,
            leafAtlasTile(id),
          );
          if (p) p.homeY = ground + 0.04;
        }
        audio.quakeLeaves();
        return;
      }
    }
  }

  function beginQuake() {
    if (quakeStage !== 0 || jobs.length) return;
    quakeStage = 1;
    quakeLen = 3;
    quakeLeft = quakeLen;
    quakeJolt = 0.35;
    hintT = 2.6;
    showHint("Terremoto");
    audio.beginQuakeBed();
    audio.quakeRumble(0.55);
    const avoid = new Set<string>();
    for (const ditch of openDitches) for (const col of ditch) avoid.add(`${col.x},${col.z}`);
    const count = (Math.random() * 5) | 0;
    for (let n = 0; n < count; n++) {
      let cols: FissureCol[] | null = null;
      for (let attempt = 0; attempt < 6; attempt++) {
        const planned = world.planQuakeFissure(x, z);
        if (planned.length < 4) continue;
        if (planned.some((c) => avoid.has(`${c.x},${c.z}`))) continue;
        cols = planned;
        break;
      }
      if (!cols) continue;
      for (const col of cols) avoid.add(`${col.x},${col.z}`);
      jobs.push({ cols, age: 0, seeped: false, started: false, mode: "open" });
    }
    if (openDitches.length && Math.random() < 0.5) {
      const pick = (Math.random() * openDitches.length) | 0;
      const cols = openDitches.splice(pick, 1)[0];
      if (cols) jobs.push({ cols, age: 0, seeped: false, started: false, mode: "close" });
    }
  }

  /** Hill Top warning, then a short Marble Garden shock, then one aftershock. */
  function stepQuake(dt: number): boolean {
    if (quakeStage === 0) {
      quakeAmp = Math.max(0, quakeAmp - dt * 1.4);
      return false;
    }
    quakeLeft -= dt;
    const u = 1 - Math.max(0, quakeLeft) / quakeLen;
    if (quakeStage === 1) quakeAmp = 0.07 + u * 0.14;
    else if (quakeStage === 2) quakeAmp = 0.32 + Math.sin(Math.max(0, u) * Math.PI) * 0.58;
    else if (quakeStage === 3) quakeAmp = 0.05;
    else if (quakeStage === 4) quakeAmp = 0.62 + Math.sin(Math.max(0, u) * Math.PI) * 0.34;
    else if (quakeStage === 5) quakeAmp = 0.08 + u * 0.2;
    else quakeAmp = 0.26 + Math.sin(Math.max(0, u) * Math.PI) * 0.42;

    let jolted = false;
    quakeJolt -= dt;
    const warning = quakeStage === 1 || quakeStage === 5;
    if (quakeJolt <= 0 && quakeStage !== 3 && !warning) {
      jolted = true;
      quakeJolt =
        quakeStage === 1 ? 0.72 : quakeStage === 5 ? 0.55 : quakeStage === 4 ? 0.32 : 0.4 + Math.random() * 0.18;
      if (onGround && !hovering && !eyeFluid) {
        vx += (Math.random() - 0.5) * 0.9 * (0.4 + quakeAmp);
        vz += (Math.random() - 0.5) * 0.9 * (0.4 + quakeAmp);
        if (vy < 1.1) vy += 0.28 + quakeAmp * 0.45;
      }
      spawnQuakeDust();
      if ((quakeStage === 2 || quakeStage === 4 || quakeStage === 6) && Math.random() < 0.55) spawnQuakePebbles();
      if ((quakeStage === 2 || quakeStage === 4 || quakeStage === 6) && Math.random() < 0.62) spawnQuakeLeaves();
      if (quakeStage === 4 || quakeStage === 6 || quakeAmp > 0.55) audio.quakeThud();
      else audio.quakeRumble(0.35 + quakeAmp);
    }
    if (quakeLeft <= 0) {
      if (quakeStage === 1) {
        quakeStage = 2;
        quakeLen = 10 + Math.random() * 2;
        quakeLeft = quakeLen;
        audio.quakeThud();
      } else if (quakeStage === 2) {
        quakeStage = 4;
        quakeLen = 4 + Math.random() * 2;
        quakeLeft = quakeLen;
        audio.quakeThud();
      } else if (quakeStage === 4 || quakeStage === 6) {
        if (Math.random() < 0.4) {
          quakeStage = 3;
          quakeLen = 2.5;
          quakeLeft = quakeLen;
        } else {
          quakeStage = 0;
          quakeWait = 80 + Math.random() * 70;
          quakeAmp = 0.1;
          audio.endQuakeBed();
        }
      } else if (quakeStage === 3) {
        quakeStage = 5;
        quakeLen = 2;
        quakeLeft = quakeLen;
        quakeJolt = 0.25;
        hintT = 2;
        showHint("Tremor");
        audio.quakeRumble(0.7);
      } else if (quakeStage === 5) {
        quakeStage = 6;
        quakeLen = 6;
        quakeLeft = quakeLen;
        audio.quakeThud();
      }
    } else audio.setQuakeBed(quakeAmp);
    return jolted;
  }

  let crushAcc = 0;

  function insideShutDitch(px: number, py: number, pz: number, w: number, h: number, d: number): boolean {
    const x0 = px;
    const x1 = px + w;
    const y0 = py;
    const y1 = py + h;
    const z0 = pz;
    const z1 = pz + d;
    for (const job of jobs) {
      if (job.mode !== "close") continue;
      if (heldBy(job.cols, x0, x1, y0, y1, z0, z1)) return true;
    }
    for (const cols of graves) {
      if (heldBy(cols, x0, x1, y0, y1, z0, z1)) return true;
    }
    return false;
  }

  function heldBy(
    cols: FissureCol[],
    x0: number,
    x1: number,
    y0: number,
    y1: number,
    z0: number,
    z1: number,
  ): boolean {
    for (const col of cols) {
      if (!col.shut) continue;
      if (x1 <= col.x + 0.05 || x0 >= col.x + 0.95 || z1 <= col.z + 0.05 || z0 >= col.z + 0.95) continue;
      if (y1 <= col.bed + 0.2 || y0 >= col.top - 0.15) continue;
      return true;
    }
    return false;
  }

  function tickCrush(dt: number) {
    const playerBuried = insideShutDitch(x - PW / 2, y, z - PD / 2, PW, PH, PD);
    if (playerBuried) {
      if (crushAcc <= 0) crushAcc = 1;
      crushAcc += dt;
      if (crushAcc >= 1) {
        crushAcc -= 1;
        health -= 5;
        hurtFlash = 0.35;
        audio.hurt();
        if (health <= 0) {
          health = 0;
          setPhase("dead");
          document.exitPointerLock?.();
        }
        pushHud();
      }
    } else crushAcc = 0;
    for (const c of creatures) {
      if (!c.alive || c.dying) continue;
      const buried = insideShutDitch(c.x - c.w / 2, c.y, c.z - c.d / 2, c.w, c.h, c.d);
      if (!buried) {
        c.crushAcc = 0;
        continue;
      }
      if (c.crushAcc <= 0) c.crushAcc = 1;
      c.crushAcc += dt;
      if (c.crushAcc >= 1) {
        c.crushAcc -= 1;
        c.damage(3);
      }
    }
    for (let i = graves.length - 1; i >= 0; i--) {
      const cols = graves[i]!;
      const playerIn = heldBy(cols, x - PW / 2, x + PW / 2, y, y + PH, z - PD / 2, z + PD / 2);
      let mobIn = false;
      if (!playerIn) {
        for (const c of creatures) {
          if (!c.alive || c.dying) continue;
          if (heldBy(cols, c.x - c.w / 2, c.x + c.w / 2, c.y, c.y + c.h, c.z - c.d / 2, c.z + c.d / 2)) {
            mobIn = true;
            break;
          }
        }
      }
      if (!playerIn && !mobIn) graves.splice(i, 1);
    }
  }

  function stepFissure(dt: number) {
    for (let i = jobs.length - 1; i >= 0; i--) {
      const job = jobs[i]!;
      job.age += dt;
      if (job.age < 4) continue;
      if (!job.started) {
        job.started = true;
        hintT = 3.2;
        showHint(job.mode === "close" ? "O chão fecha" : "O chão cede");
        audio.quakeCrack();
      }
      const p = Math.min(1, (job.age - 4) / 12);
      if (job.mode === "open") {
        const dug = world.digFissure(job.cols, p);
        if (dug.crumbled) audio.break(dug.id);
        if (dug.dust.length) {
          audio.quakeCrack();
          for (const d of dug.dust) {
            emitParticle(
              "burst",
              d.x,
              d.y,
              d.z,
              0x8a6840,
              { vx: (Math.random() - 0.5) * 0.8, vy: 0.4 + Math.random() * 0.6, vz: (Math.random() - 0.5) * 0.8 },
              0.55,
              0.8,
            );
          }
        }
        const wet = job.cols.some((c) => !c.dry);
        if (wet && !job.seeped && p >= 0.3) {
          job.seeped = true;
          audio.quakeSeep();
        }
        if (p >= 1) {
          audio.quakeThud();
          openDitches.push(job.cols);
          jobs.splice(i, 1);
        }
      } else {
        const sealed = world.sealFissure(job.cols, p, { x, y, z });
        if (sealed.dust.length) {
          audio.quakeCrack();
          for (const d of sealed.dust) {
            emitParticle(
              "burst",
              d.x,
              d.y,
              d.z,
              0x6a5030,
              { vx: (Math.random() - 0.5) * 0.6, vy: 0.3 + Math.random() * 0.45, vz: (Math.random() - 0.5) * 0.6 },
              0.5,
              0.8,
            );
          }
        }
        if (p >= 1 && job.cols.every((c) => c.shut)) {
          audio.quakeThud();
          graves.push(job.cols);
          jobs.splice(i, 1);
        }
      }
    }
    if (jobs.some((job) => job.mode === "close") || graves.length) tickCrush(dt);
  }

  function bodyInLiquidBlock(): FluidKind | null {
    const minX = Math.floor(x - PW / 2 + 0.02);
    const maxX = Math.floor(x + PW / 2 - 0.02);
    const minZ = Math.floor(z - PD / 2 + 0.02);
    const maxZ = Math.floor(z + PD / 2 - 0.02);
    const y0 = Math.floor(y + 0.08);
    const y1 = Math.floor(y + 0.92);
    let kind: FluidKind | null = null;
    for (let by = y0; by <= y1; by++) {
      for (let bx = minX; bx <= maxX; bx++) {
        for (let bz = minZ; bz <= maxZ; bz++) {
          const id = world.getBlock(bx, by, bz);
          const k = fluidKind(id);
          if (k && !isRiccia(id) && id !== GRASS_CARPET_WET && id !== CERRADO_CARPET_WET) kind = k;
        }
      }
    }
    return kind;
  }

  function headInLiquidBlock(): boolean {
    const id = world.getBlock(Math.floor(x), Math.floor(y + EYE), z);
    const k = fluidKind(id);
    return !!(k && !isRiccia(id) && id !== GRASS_CARPET_WET && id !== CERRADO_CARPET_WET);
  }

  function findCreatureGround(sx: number, sz: number) {
    const offsets: [number, number][] = [
      [0, 0],
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
      [2, 1],
      [-2, 1],
      [1, 2],
      [-1, -2],
      [3, 0],
      [0, 3],
      [-3, 2],
      [2, -3],
      [4, 1],
      [-4, -1],
    ];
    for (const [dx, dz] of offsets) {
      const gx = sx + dx;
      const gz = sz + dz;
      if (!world.getChunk(Math.floor(gx / CHUNK), Math.floor(gz / CHUNK))) continue;
      const y = world.spawnY(gx, gz);
      if (y !== null) return { x: gx + 0.5, y, z: gz + 0.5 };
    }
    return { x: sx + 0.5, y: world.heightAt(sx, sz) + 1, z: sz + 0.5 };
  }

  const nightQueue: { kind: "murcha" | "beholder"; dx: number; dz: number }[] = [];
  let nightSpawnAcc = 0;

  function queueNightMonsters() {
    nightQueue.length = 0;
    let murchas = 0;
    let beholders = 0;
    for (const c of creatures) {
      if (!c.alive || c.dying) continue;
      if (c.kind === "murcha") murchas++;
      if (c.kind === "beholder") beholders++;
    }
    const spots: [number, number][] = [
      [12, -5],
      [-9, 13],
      [17, 8],
      [-15, -7],
      [7, 16],
      [-18, 4],
      [14, -14],
      [-6, -16],
    ];
    for (const [dx, dz] of spots) {
      if (murchas >= 4) break;
      nightQueue.push({ kind: "murcha", dx, dz });
      murchas++;
    }
    const extra: [number, number][] = [
      [10, -10],
      [-11, 9],
    ];
    for (const [dx, dz] of extra) {
      if (beholders >= 2) break;
      nightQueue.push({ kind: "beholder", dx, dz });
      beholders++;
    }
  }

  const findSpawn = () => {
    world.stream(0, 0, 2);
    world.placeStarterMelon();
    world.placeStarterWeeds();
    world.placeStarterRestinga();
    world.placeStarterAraucaria();
    world.processMeshes(2);
    y = world.surfaceY(0, 0) + 0.02;
    x = 0.5;
    z = 0.5;
    yaw = 0;
    pitch = -0.42;
  };

  /** Old showcase near spawn: red carpet, acid block, and the starter ditch. */
  const starterShowcaseEdit = (key: string, id: number) => {
    const [xs, , zs] = key.split(",");
    const x = Number(xs);
    const z = Number(zs);
    if (id === RED_CARPET && x >= 11 && x <= 13 && z >= 1 && z <= 2) return true;
    if (id === ACID && x === 0 && z === 3) return true;
    if (x >= -2 && x <= 2 && (z === -7 || z === -8)) return true;
    if ((id === WATER || id === RICCIA) && x === 0 && z === -4) return true;
    if (
      (id === VARZEA_GRASS || id === VARZEA_CARPET) &&
      ((x === 3 && z === -6) ||
        (x === 4 && z === -6) ||
        (x === 5 && z === -5) ||
        (x === 4 && z === -5) ||
        (x === 3 && z === -5) ||
        (x === 5 && z === -4))
    ) {
      return true;
    }
    return false;
  };

  const applySave = (s: SaveData) => {
    seed = s.seed;
    scene.remove(world.group);
    world.dispose();
    clearFloaters();
    world = new World(seed);
    const lift = s.version < 6 ? WORLD_LIFT : 0;
    for (const [k, id] of s.edits) {
      if (starterShowcaseEdit(k, id)) continue;
      const parts = k.split(",");
      const ey = Number(parts[1]) + lift;
      world.edits.set(`${parts[0]},${ey},${parts[2]}`, id);
    }
    scene.add(world.group);
    x = s.x;
    y = s.y + lift;
    z = s.z;
    yaw = s.yaw;
    pitch = s.pitch;
    health = s.health;
    hunger = s.hunger ?? 20;
    sat = Math.min(hunger, 5);
    exhaust = 0;
    starveT = 0;
    regenT = 0;
    eatT = 0;
    oxygen = 100;
    const keepInv = (s.invRev ?? 0) >= 2;
    slots = s.slots?.length ? packSlots(s.slots) : starterSlots();
    if (!keepInv) {
      for (let i = 0; i < HOTBAR_LEN; i++) {
        const id = slots[i]?.id ?? AIR;
        if (id && !isFood(id) && !isItemOnly(id)) slots[i] = emptySlot();
      }
      const hand = slots.findIndex((slot, i) => i < HOTBAR_LEN && (!slot || slot.count <= 0 || !slot.id));
      const at = hand >= 0 ? hand : 0;
      slots[at] = { id: WATER, count: 1 };
    }
    selected = keepInv ? Math.max(0, Math.min(HOTBAR_LEN - 1, s.selected)) : 0;
    time = s.time;
    world.stream(x, z, 2);
    world.placeStarterMelon();
    world.placeStarterWeeds();
    world.placeStarterRestinga();
    world.placeStarterAraucaria();
    world.processMeshes(2);
    spawnCreatures();
  };

  const snapshot = (): SaveData => ({
    version: 1,
    seed,
    x,
    y,
    z,
    yaw,
    pitch,
    health,
    hunger,
    slots,
    selected,
    edits: [...world.edits.entries()],
    time,
    invRev: INV_REV,
  });

  const persist = () => {
    if (phase === "menu") return;
    writeSave(snapshot());
    useGame.getState().setHud({ savedAt: Date.now() });
  };

  findSpawn();
  spawnCreatures();
  const existing = loadSave();
  if (existing) applySave(existing);

  const setPhase = (p: Phase) => {
    phase = p;
    if (p !== "playing") {
      inventoryOpen = false;
      dumpCursor();
    }
    input.enabled = p === "playing" && !inventoryOpen;
    audio.setActive(p === "playing");
    useGame.getState().setHud({ phase: p, inventoryOpen });
  };

  const holdBrowserKeys = () => {
    const kb = (navigator as Navigator & { keyboard?: { lock?: () => Promise<void> } }).keyboard;
    kb?.lock?.().catch(() => {});
  };

  const releaseBrowserKeys = () => {
    const kb = (navigator as Navigator & { keyboard?: { unlock?: () => void } }).keyboard;
    kb?.unlock?.();
  };

  const lockPointer = () => {
    const el = canvas as HTMLElement & {
      requestPointerLock: (opts?: { unadjustedMovement?: boolean }) => Promise<void> | void;
    };
    try {
      const r = el.requestPointerLock({ unadjustedMovement: true });
      if (r && typeof (r as Promise<void>).catch === "function") {
        (r as Promise<void>).catch(() => el.requestPointerLock());
      }
    } catch {
      try {
        el.requestPointerLock();
      } catch {
        /* iframe may block */
      }
    }
    holdBrowserKeys();
  };

  const play = () => {
    audio.unlock();
    if (phase === "dead") return;
    setPhase("playing");
    lockPointer();
  };

  const toMenu = () => {
    setPhase("menu");
  };

  const pause = () => {
    if (inventoryOpen) closeInventory();
    if (phase === "playing") {
      releaseBrowserKeys();
      setPhase("paused");
      persist();
    }
  };

  const resume = () => {
    if (phase === "paused") {
      setPhase("playing");
      lockPointer();
    }
  };

  const respawn = () => {
    health = maxHealth;
    hunger = 20;
    sat = 5;
    exhaust = 0;
    starveT = 0;
    regenT = 0;
    eatT = 0;
    oxygen = 100;
    hovering = false;
    breathing = false;
    findSpawn();
    vx = vy = vz = 0;
    setPhase("playing");
    lockPointer();
    pushHud();
  };

  const newWorld = () => {
    clearSave();
    seed = (Math.random() * 1e9) | 0;
    scene.remove(world.group);
    world.dispose();
    clearFloaters();
    world = new World(seed);
    scene.add(world.group);
    slots = starterSlots();
    selected = 0;
    cursor = emptySlot();
    inventoryOpen = false;
    health = maxHealth;
    hunger = 20;
    sat = 5;
    exhaust = 0;
    eatT = 0;
    oxygen = 100;
    time = 0.22;
    hovering = false;
    breathing = false;
    yaw = 0;
    pitch = 0;
    findSpawn();
    spawnCreatures();
    persist();
    setPhase("playing");
    lockPointer();
    pushHud();
  };

  const dumpCursor = () => {
    if (cursor.count <= 0 || !cursor.id) {
      cursor = emptySlot();
      return;
    }
    addItem(cursor.id, cursor.count);
    cursor = emptySlot();
  };

  const dumpCraft = () => {
    for (const s of craft) {
      if (s.count > 0 && s.id) addItem(s.id, s.count);
      s.id = AIR;
      s.count = 0;
    }
    craftOut = emptySlot();
    craftSize = 2;
  };

  const refreshCraft = () => {
    const res = matchCraft(craft, craftSize);
    craftOut = res ? { id: res.id, count: res.n } : emptySlot();
  };

  const openInventory = (size: 2 | 3 = 2) => {
    if (phase !== "playing") return;
    craftSize = size;
    if (!inventoryOpen) {
      inventoryOpen = true;
      input.enabled = false;
      input.physical.clear();
      hadLock = false;
      document.exitPointerLock();
    }
    refreshCraft();
    pushHud();
  };

  const closeInventory = () => {
    if (!inventoryOpen) return;
    dumpCursor();
    dumpCraft();
    inventoryOpen = false;
    if (phase === "playing") {
      input.enabled = true;
      lockPointer();
    }
    pushHud();
  };

  const toggleInventory = () => {
    if (phase !== "playing") return;
    if (inventoryOpen) closeInventory();
    else openInventory();
  };

  const invClick = (i: number, right: boolean) => {
    if (!inventoryOpen || i < 0 || i >= slots.length) return;
    const slot = slots[i]!;
    if (right) {
      if (cursor.count <= 0) {
        if (slot.count <= 0) return;
        const n = Math.max(1, Math.ceil(slot.count / 2));
        cursor = { id: slot.id, count: n };
        slot.count -= n;
        if (slot.count <= 0) {
          slot.id = AIR;
          slot.count = 0;
        }
      } else if (slot.count <= 0) {
        slot.id = cursor.id;
        slot.count = 1;
        cursor.count -= 1;
        if (cursor.count <= 0) cursor = emptySlot();
      } else if (slot.id === cursor.id) {
        slot.count += 1;
        cursor.count -= 1;
        if (cursor.count <= 0) cursor = emptySlot();
      }
    } else if (cursor.count <= 0) {
      cursor = { id: slot.id, count: slot.count };
      slot.id = AIR;
      slot.count = 0;
      if (cursor.count <= 0) cursor = emptySlot();
    } else if (slot.count <= 0) {
      slot.id = cursor.id;
      slot.count = cursor.count;
      cursor = emptySlot();
    } else if (slot.id === cursor.id) {
      slot.count += cursor.count;
      cursor = emptySlot();
    } else {
      const tmp = { id: slot.id, count: slot.count };
      slot.id = cursor.id;
      slot.count = cursor.count;
      cursor = tmp;
    }
    if (i < HOTBAR_LEN) selected = i;
    pushHud();
  };

  const craftClick = (i: number, right: boolean) => {
    if (!inventoryOpen || i < 0 || i >= 9) return;
    const slot = craft[i]!;
    if (craftSize === 2 && i !== 0 && i !== 1 && i !== 3 && i !== 4) return;
    if (right) {
      if (cursor.count <= 0) {
        if (slot.count <= 0) return;
        const n = Math.max(1, Math.ceil(slot.count / 2));
        cursor = { id: slot.id, count: n };
        slot.count -= n;
        if (slot.count <= 0) {
          slot.id = AIR;
          slot.count = 0;
        }
      } else if (slot.count <= 0) {
        slot.id = cursor.id;
        slot.count = 1;
        cursor.count -= 1;
        if (cursor.count <= 0) cursor = emptySlot();
      } else if (slot.id === cursor.id) {
        slot.count += 1;
        cursor.count -= 1;
        if (cursor.count <= 0) cursor = emptySlot();
      }
    } else if (cursor.count <= 0) {
      if (slot.count <= 0) return;
      cursor = { id: slot.id, count: slot.count };
      slot.id = AIR;
      slot.count = 0;
    } else if (slot.count <= 0) {
      slot.id = cursor.id;
      slot.count = cursor.count;
      cursor = emptySlot();
    } else if (slot.id === cursor.id) {
      slot.count += cursor.count;
      cursor = emptySlot();
    } else {
      const tmp = { id: slot.id, count: slot.count };
      slot.id = cursor.id;
      slot.count = cursor.count;
      cursor = tmp;
    }
    refreshCraft();
    pushHud();
  };

  const craftTake = () => {
    if (!inventoryOpen) return;
    const res = matchCraft(craft, craftSize);
    if (!res) return;
    if (cursor.count > 0 && cursor.id !== res.id) return;
    if (cursor.count <= 0) cursor = { id: res.id, count: res.n };
    else cursor.count += res.n;
    const idxs = craftSize === 2 ? [0, 1, 3, 4] : [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (const i of idxs) {
      const s = craft[i]!;
      if (s.count <= 0) continue;
      s.count -= 1;
      if (s.count <= 0) {
        s.id = AIR;
        s.count = 0;
      }
    }
    refreshCraft();
    pushHud();
  };

  const handle: GameHandle = {
    play,
    toMenu,
    pause,
    resume,
    respawn,
    newWorld,
    selectSlot: (i) => {
      selected = Math.max(0, Math.min(HOTBAR_LEN - 1, i));
      pushHud();
    },
    toggleInventory,
    invClick,
    craftClick,
    craftTake,
    setTouchMove: (mx, my) => {
      input.touchMoveX = mx;
      input.touchMoveY = my;
    },
    addLook: (lx, ly) => {
      input.touchLookX += lx;
      input.touchLookY += ly;
    },
    setTouchJump: (v) => {
      input.touchJump = v;
    },
    setTouchBreak: (v) => {
      input.touchBreak = v;
    },
    setTouchPlace: (v) => {
      input.touchPlace = v;
    },
  };
  useGame.getState().setHandle(handle);

  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const lookDir = new THREE.Vector3();

  function addExhaust(n: number) {
    exhaust += n;
    while (exhaust >= 4) {
      exhaust -= 4;
      if (sat > 0) sat = Math.max(0, sat - 1);
      else hunger = Math.max(0, hunger - 1);
    }
  }

  function stepHunger(dt: number) {
    if (hunger <= 0 && health > 1) {
      starveT += dt;
      if (starveT >= 4) {
        starveT = 0;
        health = Math.max(1, health - 1);
        hurtFlash = 0.25;
        audio.hurt();
      }
    } else starveT = 0;
    if (hunger >= 18 && sat > 0 && health < maxHealth) {
      regenT += dt;
      if (regenT >= 4) {
        regenT = 0;
        health = Math.min(maxHealth, health + 1);
        addExhaust(1.5);
      }
    } else regenT = 0;
  }

  function compassHud() {
    const t = COMPASS_BIOMES[compassI]!;
    const dx = t.x - x;
    const dz = t.z - z;
    const face = Math.atan2(-dx, -dz);
    let ang = yaw - face;
    while (ang > Math.PI) ang -= Math.PI * 2;
    while (ang < -Math.PI) ang += Math.PI * 2;
    return { compass: t.name, compassAng: ang };
  }

  function pushHud() {
    useGame.getState().setHud({
      phase,
      health,
      maxHealth,
      slots: slots.map((s) => ({ ...s })),
      selected,
      inventoryOpen,
      cursor: { ...cursor },
      time,
      mine,
      underwater: submerged,
      underFluid: eyeFluid,
      oxygen,
      hunger,
      hungerShake: sat <= 0 && hunger < 20,
      eat: eatId ? Math.min(1, eatT / (foodDef(eatId)?.seconds || 1)) : 0,
      hovering,
      breathing,
      third,
      sneaking,
      craftSize,
      craft: craft.map((s) => ({ ...s })),
      craftOut: { ...craftOut },
      ...compassHud(),
    });
  }

  function addItem(id: number, n = 1) {
    if (id === AIR || n <= 0) return;
    const found = slots.find((s) => s.id === id && s.count > 0);
    if (found) found.count += n;
    else {
      const empty = slots.find((s) => s.count === 0);
      if (empty) {
        empty.id = id;
        empty.count = n;
      }
    }
  }

  function consumeSelected(): boolean {
    return consumeSelectedN(1);
  }

  function consumeSelectedN(n: number): boolean {
    const s = slots[selected];
    if (!s || s.count < n) return false;
    s.count -= n;
    return true;
  }

  function tryPlantMelon(hx: number, hy: number, hz: number, nx: number, ny: number, nz: number): boolean {
    const plantAt = (sx: number, sy: number, sz: number) => {
      if (sy < 1 || sy >= HEIGHT) return false;
      const soil = world.getBlock(sx, sy - 1, sz);
      if (!isSoil(soil)) return false;
      const here = world.getBlock(sx, sy, sz);
      if (here !== AIR && !isPlant(here) && !isCarpet(here)) return false;
      if (soil !== FARMLAND) world.setBlock(sx, sy - 1, sz, FARMLAND);
      world.setBlock(sx, sy, sz, MELON_STEM);
      return true;
    };
    const soilHit = world.getBlock(hx, hy, hz);
    if (isSoil(soilHit) && ny === 1) return plantAt(hx, hy + 1, hz);
    return plantAt(hx + nx, hy + ny, hz + nz);
  }

  function tryPlaceMelon(hx: number, hy: number, hz: number, nx: number, ny: number, nz: number): boolean {
    const px = hx + nx;
    const py = hy + ny;
    const pz = hz + nz;
    const insidePlayer =
      px + 1 > x - PW / 2 &&
      px < x + PW / 2 &&
      py + 1 > y &&
      py < y + PH &&
      pz + 1 > z - PD / 2 &&
      pz < z + PD / 2;
    if (py < 0 || py >= HEIGHT || insidePlayer) return false;
    if (isSolid(world.getBlock(px, py, pz))) return false;
    if (!consumeSelectedN(9)) return false;
    world.setBlock(px, py, pz, MELON);
    audio.place(MELON);
    return true;
  }

  function eatMelonSlice(): boolean {
    if (health >= maxHealth) return false;
    if (!consumeSelectedN(1)) return false;
    health = Math.min(maxHealth, health + 1);
    audio.place(MELON_SLICE);
    return true;
  }

  function craftSeedFromSlice(): boolean {
    if (!consumeSelectedN(1)) return false;
    addItem(MELON_SEEDS, 1);
    audio.place(MELON_SEEDS);
    return true;
  }

  function fluidSurfaceY(px: number, py: number, pz: number): number {
    const bx = Math.floor(px);
    const bz = Math.floor(pz);
    let by = Math.floor(py);
    if (by < 0) by = 0;
    if (by >= HEIGHT) by = HEIGHT - 1;
    if (!isFluid(world.getBlock(bx, by, bz))) {
      if (isFluid(world.getBlock(bx, by + 1, bz))) by++;
      else if (by > 0 && isFluid(world.getBlock(bx, by - 1, bz))) by--;
    }
    if (!isFluid(world.getBlock(bx, by, bz))) return py;
    while (by < HEIGHT - 1 && isFluid(world.getBlock(bx, by + 1, bz))) by++;
    return by + fluidFill(world.getBlock(bx, by, bz));
  }

  function inFluidColumn(px: number, py: number, pz: number): boolean {
    const bx = Math.floor(px);
    const bz = Math.floor(pz);
    const by = Math.floor(py);
    return (
      isFluid(world.getBlock(bx, by, bz)) ||
      isFluid(world.getBlock(bx, by + 1, bz)) ||
      (by > 0 && isFluid(world.getBlock(bx, by - 1, bz)))
    );
  }

  function liquidOpacity(kind: FluidKind): number {
    if (kind === "mud") return world.mudMat.opacity;
    const src = kind === "acid" ? world.acidMat : world.waterMat;
    return (src.uniforms.uOpacity!.value as number) ?? 0.4;
  }

  function liquidParticleMat(kind: FluidKind, opacity: number, darken = false) {
    if (kind === "mud") {
      const k = darken ? 0.78 : 1;
      return new THREE.MeshBasicMaterial({
        map: world.mudMat.map,
        color: new THREE.Color(k, k, k),
        transparent: true,
        opacity: darken ? opacity * 0.72 : opacity,
        depthWrite: false,
      });
    }
    const src = kind === "acid" ? world.acidMat : world.waterMat;
    const tint = src.uniforms.uTint!.value as THREE.Vector3;
    const map = src.uniforms.uMap!.value as THREE.Texture;
    const k = darken ? 0.78 : 1;
    return new THREE.MeshBasicMaterial({
      map,
      color: new THREE.Color(tint.x * k, tint.y * k, tint.z * k),
      transparent: true,
      opacity: darken ? opacity * 0.72 : opacity,
      depthWrite: false,
    });
  }

  function emitParticle(
    mode: Particle["mode"],
    px: number,
    py: number,
    pz: number,
    color: number,
    vel: { vx: number; vy: number; vz: number },
    life: number,
    opacity: number,
    kind?: FluidKind,
    leafTile?: number,
  ): Particle | undefined {
    if (particles.length >= PARTICLE_CAP) return;
    const geo =
      mode === "leaf" ? LEAF_GEO[leafTile ?? 0]! : PART_GEO[mode === "trapped" ? "bubble" : mode];
    const mat =
      mode === "leaf"
        ? new THREE.MeshBasicMaterial({
            map: world.leafTex,
            color: 0xffffff,
            transparent: true,
            opacity,
            depthWrite: false,
            side: THREE.DoubleSide,
          })
        : kind
          ? liquidParticleMat(kind, opacity, mode === "bubble" || mode === "trapped")
          : new THREE.MeshLambertMaterial({
              color,
              transparent: true,
              opacity,
              depthWrite: false,
            });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(px, py, pz);
    mesh.renderOrder = 6;
    if (mode === "leaf") {
      mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
    }
    scene.add(mesh);
    particles.push({
      mesh,
      vx: vel.vx,
      vy: vel.vy,
      vz: vel.vz,
      life,
      maxLife: life,
      mode,
      kind,
      baseOp: opacity,
      spinX: mode === "leaf" ? (Math.random() - 0.5) * 6 : 0,
      spinY: mode === "leaf" ? (Math.random() - 0.5) * 8 : 0,
      spinZ: mode === "leaf" ? (Math.random() - 0.5) * 5 : 0,
      wobble: Math.random() * 6.28,
    });
    return particles[particles.length - 1];
  }

  function burst(bx: number, by: number, bz: number, color: number) {
    for (let i = 0; i < 8; i++) {
      emitParticle(
        "burst",
        bx + 0.5 + (Math.random() - 0.5) * 0.4,
        by + 0.5,
        bz + 0.5,
        color,
        {
          vx: (Math.random() - 0.5) * 3,
          vy: 2 + Math.random() * 2,
          vz: (Math.random() - 0.5) * 3,
        },
        0.5 + Math.random() * 0.3,
        1,
      );
    }
  }

  function spawnFloater(px: number, py: number, pz: number, id: number, n = 1) {
    if (floaters.length >= 24) {
      const old = floaters.shift();
      if (old) {
        scene.remove(old.mesh);
        (old.mesh.material as THREE.Material).dispose();
      }
    }
    const hex = Number.parseInt((BLOCK_COLOR[id] ?? "#c4b05a").slice(1), 16);
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.28, 0.28),
      new THREE.MeshLambertMaterial({ color: hex }),
    );
    mesh.position.set(px, py, pz);
    scene.add(mesh);
    floaters.push({
      mesh,
      x: px,
      y: py,
      z: pz,
      vx: (Math.random() - 0.5) * 0.6,
      vy: 1.2,
      vz: (Math.random() - 0.5) * 0.6,
      id,
      n,
      life: 45,
      tag: floaterTag++,
      claimed: false,
    });
  }

  function clearFloaters() {
    for (const f of floaters) {
      scene.remove(f.mesh);
      (f.mesh.material as THREE.Material).dispose();
    }
    floaters.length = 0;
  }

  function spawnSplash(px: number, py: number, pz: number, kind: FluidKind, strength: number) {
    const n = Math.min(22, 8 + Math.floor(strength * 12));
    const sy = fluidSurfaceY(px, py, pz);
    const op = Math.min(0.82, liquidOpacity(kind) + 0.28);
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = 0.12 + Math.random() * 0.38;
      const up = 1.4 + strength * 2.4 + Math.random() * 1.6;
      emitParticle(
        "splash",
        px + Math.cos(ang) * rad,
        sy + 0.02,
        pz + Math.sin(ang) * rad,
        0xffffff,
        {
          vx: Math.cos(ang) * (0.6 + Math.random() * 1.8 + strength * 0.6),
          vy: up,
          vz: Math.sin(ang) * (0.6 + Math.random() * 1.8 + strength * 0.6),
        },
        0.35 + Math.random() * 0.35,
        op,
        kind,
      );
    }
  }

  function spawnWake(px: number, py: number, pz: number, kind: FluidKind, dx: number, dz: number) {
    const sy = fluidSurfaceY(px, py, pz);
    const op = Math.min(0.72, liquidOpacity(kind) + 0.2);
    const n = 2 + (Math.random() > 0.45 ? 1 : 0);
    for (let i = 0; i < n; i++) {
      const side = (Math.random() - 0.5) * 0.45;
      emitParticle(
        "wake",
        px - dx * (0.18 + Math.random() * 0.22) + dz * side,
        sy + 0.01,
        pz - dz * (0.18 + Math.random() * 0.22) - dx * side,
        0xffffff,
        {
          vx: -dx * 0.35 + (Math.random() - 0.5) * 0.25,
          vy: 0.08 + Math.random() * 0.12,
          vz: -dz * 0.35 + (Math.random() - 0.5) * 0.25,
        },
        0.28 + Math.random() * 0.18,
        op,
        kind,
      );
    }
  }

  function ricciaStickPoint(rx: number, ry: number, rz: number) {
    const jx = ((rx * 13 + rz * 7) % 5) * 0.018 - 0.036;
    const jz = ((rz * 11 + rx * 3) % 5) * 0.018 - 0.036;
    const y0 = ry - 0.06;
    const spots: [number, number, number][] = [
      [0.46 + jx, 0.28, 0.5 + jz],
      [0.54 + jx, 0.36, 0.46 + jz],
      [0.5 + jx, 0.22, 0.54 + jz],
      [0.42 + jx, 0.32, 0.48 + jz],
      [0.58 + jx, 0.26, 0.52 + jz],
      [0.48 + jx, 0.4, 0.42 + jz],
      [0.52 + jx, 0.34, 0.58 + jz],
    ];
    const s = spots[(Math.random() * spots.length) | 0]!;
    return { x: rx + s[0], y: y0 + s[1], z: rz + s[2] };
  }

  function spawnPlantBubbles(px: number, py: number, pz: number, trapped: boolean, huge = false, stickKey?: string) {
    const src = world.waterMat;
    const op = Math.min(0.7, ((src.uniforms.uOpacity!.value as number) ?? 0.4) + 0.16);
    if (trapped) {
      const p = emitParticle(
        "trapped",
        px,
        py,
        pz,
        0xffffff,
        { vx: 0, vy: 0, vz: 0 },
        280 + Math.random() * 70,
        op * 0.8,
        "water",
      );
      if (!p) return false;
      p.homeX = px;
      p.homeY = py;
      p.homeZ = pz;
      p.wobble = Math.random() * 6.28;
      p.stickKey = stickKey;
      p.mesh.scale.setScalar(0.38);
      return true;
    }
    const p = emitParticle(
      "bubble",
      px + (Math.random() - 0.5) * 0.2,
      py + 0.12 + Math.random() * 0.08,
      pz + (Math.random() - 0.5) * 0.2,
      0xffffff,
      {
        vx: (Math.random() - 0.5) * 0.04,
        vy: 0.055 + Math.random() * 0.04,
        vz: (Math.random() - 0.5) * 0.04,
      },
      80,
      op,
      "water",
    );
    if (p) {
      p.slow = true;
      p.huge = huge;
      p.mesh.scale.setScalar(huge ? 3.6 : 0.52);
    }
  }

  function spawnBubbles(px: number, py: number, pz: number, kind: FluidKind, count = 1) {
    const op = Math.min(0.7, liquidOpacity(kind) + 0.16);
    for (let i = 0; i < count; i++) {
      let bx = px + (Math.random() - 0.5) * 0.28;
      let by = py + (Math.random() - 0.5) * 0.2;
      let bz = pz + (Math.random() - 0.5) * 0.28;
      if (!world.fluidAt(bx, by, bz)) by = Math.floor(py) + 0.22;
      if (!world.fluidAt(bx, by, bz)) continue;
      emitParticle(
        "bubble",
        bx,
        by,
        bz,
        0xffffff,
        {
          vx: (Math.random() - 0.5) * (kind === "mud" ? 0.035 : 0.1),
          vy: kind === "mud" ? 0.06 + Math.random() * 0.03 : 0.2 + Math.random() * 0.1,
          vz: (Math.random() - 0.5) * (kind === "mud" ? 0.035 : 0.1),
        },
        80,
        op,
        kind,
      );
    }
  }

  function hitPlayer(dmg: number) {
    if (invuln > 0 || phase !== "playing") return;
    health -= dmg;
    invuln = 0.8;
    hurtFlash = 0.35;
    audio.hurt();
    if (health <= 0) {
      health = 0;
      setPhase("dead");
      document.exitPointerLock?.();
    }
    pushHud();
  }

  function tryPunch(ox: number, oy: number, oz: number) {
    lookDir.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
    let best: Creature | null = null;
    let bestT = 4;
    for (const c of creatures) {
      if (!c.alive || c.dying) continue;
      const t = c.hitByRay(ox, oy, oz, lookDir.x, lookDir.y, lookDir.z, 4);
      if (t !== null && t < bestT) {
        bestT = t;
        best = c;
      }
    }
    if (best) {
      best.damage(3);
      audio.punch();
      addExhaust(0.1);
      swing = 1;
      return true;
    }
    return false;
  }

  function greetVillager(ox: number, oy: number, oz: number) {
    lookDir.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
    let best: Creature | null = null;
    let bestT = 3.6;
    for (const c of creatures) {
      if (!c.alive || c.dying || c.kind !== "aldeao") continue;
      const t = c.hitByRay(ox, oy, oz, lookDir.x, lookDir.y, lookDir.z, 3.6);
      if (t !== null && t < bestT) {
        bestT = t;
        best = c;
      }
    }
    if (!best) return false;
    best.greetT = 2.4;
    best.yaw = Math.atan2(x - best.x, z - best.z);
    hintT = 3.2;
    showHint(villagerLine(best.role));
    audio.villagerYes();
    return true;
  }

  const onPointerLock = () => {
    if (document.pointerLockElement === canvas) {
      hadLock = true;
      holdBrowserKeys();
      return;
    }
    if (hadLock && phase === "playing" && !inventoryOpen) {
      const crouching =
        input.physical.has("ControlLeft") ||
        input.physical.has("ControlRight") ||
        input.physical.has("KeyC");
      // Ctrl faz o navegador soltar o mouse. Pedir o lock de novo neste
      // evento entra em loop e a aba trava até fechar.
      if (crouching) return;
      hadLock = false;
      releaseBrowserKeys();
      pause();
    }
  };
  document.addEventListener("pointerlockchange", onPointerLock);

  const onVis = () => {
    if (document.hidden) persist();
    audio.unlock();
  };
  document.addEventListener("visibilitychange", onVis);

  const onResize = () => {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  };
  window.addEventListener("resize", onResize);
  onResize();

  let last = performance.now();
  let acc = 0;
  let frameHeavy = false;
  const STEP = 1 / 60;
  let raf = 0;
  let disposed = false;

  const tick = (dt: number) => {
    waterClock += dt;
    if (phase === "playing") {
      time = (time + dt / 480) % 1;
      const acts = input.poll();
      if (
        hadLock &&
        !inventoryOpen &&
        !document.pointerLockElement &&
        !acts.crouch &&
        performance.now() > relockAt
      ) {
        relockAt = performance.now() + 500;
        lockPointer();
      }
      const f6 = input.physical.has("F6");
      if (f6 && !compassWas) compassI = (compassI + 1) % COMPASS_BIOMES.length;
      compassWas = f6;
      if (inventoryOpen) {
        acts.lookX = 0;
        acts.lookY = 0;
        acts.moveX = 0;
        acts.moveY = 0;
        acts.jump = false;
        acts.jumpHeld = false;
        acts.break = false;
        acts.place = false;
        acts.useHeld = false;
        acts.punch = false;
        acts.cam = false;
        acts.slot = null;
      }

      yaw -= acts.lookX * SENS;
      pitch -= acts.lookY * SENS;
      const lim = Math.PI / 2 - 0.02;
      if (pitch > lim) pitch = lim;
      if (pitch < -lim) pitch = -lim;

      if (acts.slot !== null) {
        if (acts.slot === 100) selected = (selected + 1) % HOTBAR_LEN;
        else if (acts.slot === 101) selected = (selected + HOTBAR_LEN - 1) % HOTBAR_LEN;
        else selected = Math.max(0, Math.min(HOTBAR_LEN - 1, acts.slot));
      }

      if (acts.hover) {
        hovering = !hovering;
        if (hovering) hoverY = y + 7;
      }
      if (acts.gills) breathing = !breathing;
      if (acts.quake) beginQuake();
      if (acts.cam) third = !third;

      forward.set(-Math.sin(yaw), 0, -Math.cos(yaw));
      right.set(Math.cos(yaw), 0, -Math.sin(yaw));

      const bx = Math.floor(x);
      const bz = Math.floor(z);
      const standBlocked = overlapsBlock(world, x - PW / 2, y, z - PD / 2, PW, PH, PD);
      sneaking = !hovering && (acts.crouch || standBlocked);
      const bodyH = sneaking ? 1.5 : PH;
      const eye = sneaking ? EYE - 0.35 : EYE;
      const inFluid =
        world.fluidAt(x, y + 0.2, z) ?? world.fluidAt(x, y + 0.9, z);
      eyeFluid = world.fluidAt(x, y + eye, z);
      submerged = eyeFluid !== null;
      const headWet = sneaking
        ? (world.fluidAt(x, y + eye, z) ?? world.fluidAt(x, y + 1.15, z))
        : world.fluidAt(x, y + 1.12, z) ??
          world.fluidAt(x, y + 1.5, z) ??
          world.fluidAt(x, y + 1.88, z);
      if (headWet && !breathing) oxygen = Math.max(0, oxygen - 2 * dt);
      else oxygen = Math.min(100, oxygen + 5 * dt);
      if (headWet && !breathing && oxygen <= 0) hitPlayer(1);
      stepHunger(dt);

      const liquidBlock = bodyInLiquidBlock();
      if (liquidBlock && !wasLiquidBlock) {
        const impact = 0.4 + Math.min(2.4, Math.abs(vy) * 0.24);
        spawnSplash(x, y + 0.12, z, liquidBlock, impact);
        if (liquidBlock === "mud") audio.mudSplash(true, impact);
        else audio.splash(true, impact);
      } else if (!liquidBlock && wasLiquidBlock) {
        spawnSplash(x, y + 0.12, z, wasLiquidBlock, 0.22);
        const out = 0.5 + Math.min(0.9, Math.abs(vy) * 0.1);
        if (wasLiquidBlock === "mud") audio.mudSplash(false, out);
        else audio.splash(false, out);
      }
      wasLiquidBlock = liquidBlock;
      const moveSpd = Math.hypot(vx, vz);
      if (inFluid && !eyeFluid && moveSpd > 0.55) {
        splashAcc += dt;
        if (splashAcc > 0.07) {
          splashAcc = 0;
          spawnWake(x, y, z, inFluid, vx / moveSpd, vz / moveSpd);
        }
      } else splashAcc = Math.max(0, splashAcc - dt);
      if (eyeFluid) {
        bubbleAcc += dt;
        const gap = (moveSpd > 0.4 ? 0.24 : 0.52) * (eyeFluid === "mud" ? 3 : 1);
        if (bubbleAcc > gap) {
          bubbleAcc = 0;
          spawnBubbles(x, y + eye, z, eyeFluid, 1);
        }
      } else bubbleAcc = 0;
      wasFluid = inFluid;

      const leafHere =
        world.leavesAt(x, y + EYE * 0.5, z) ?? world.leavesAt(x, y + 0.45, z) ?? world.leavesAt(x, y + 1.1, z);
      if (leafHere && moveSpd > 0.35) {
        if (!wasLeaves || Math.random() < dt * 16) {
          emitParticle(
            "leaf",
            x + (Math.random() - 0.5) * 0.4,
            y + 0.8 + Math.random() * 0.6,
            z + (Math.random() - 0.5) * 0.4,
            0xffffff,
            { vx: (Math.random() - 0.5) * 0.6, vy: 0.15 + Math.random() * 0.35, vz: (Math.random() - 0.5) * 0.6 },
            0.55 + Math.random() * 0.35,
            0.85,
            undefined,
            leafAtlasTile(leafHere),
          );
        }
      }
      wasLeaves = !!leafHere;

      const wishX = forward.x * acts.moveY + right.x * acts.moveX;
      const wishZ = forward.z * acts.moveY + right.z * acts.moveX;
      const len = Math.hypot(wishX, wishZ);
      const nx = len > 1 ? wishX / len : wishX;
      const nz = len > 1 ? wishZ / len : wishZ;

      if (hovering) {
        const speed = acts.sprint ? SPRINT : WALK;
        vx = nx * speed;
        vz = nz * speed;
        const rise = hoverY - y;
        if (rise > 0.08) vy = Math.min(7.5, 3.2 + rise * 1.6);
        else if (rise < -0.08) vy = Math.max(-7.5, -3.2 + rise * 1.6);
        else vy = 0;
      } else if (inFluid) {
        const mud = inFluid === "mud";
        const swim = (acts.sprint && !sneaking ? 3.4 : 2.6) * (sneaking ? 0.45 : 1) * (mud ? 0.32 : 1);
        vx = nx * swim;
        vz = nz * swim;
        vy -= (mud ? 16 : 6) * dt;
        vy *= Math.pow(mud ? 0.45 : 0.8, dt * 20);
        if (acts.jumpHeld) vy += (mud ? 4.2 : 12) * dt;
        if (acts.crouch && !acts.jumpHeld) vy -= (mud ? 8 : 16) * dt;
        if (onGround && acts.jumpHeld) vy = Math.max(vy, mud ? 1.6 : 4.2);
        if (acts.jump) {
          if (!eyeFluid) vy = Math.max(vy, mud ? 2.4 : JUMP);
          else vy = Math.max(vy, mud ? 1.8 : 3.8);
        }
        const [cx, cy, cz] = world.waterCurrent(bx, Math.floor(y + 0.4), bz);
        vx += cx;
        vz += cz;
        if (cy < 0) vy += cy * 2.4 * dt;
      } else {
        let speed = acts.sprint && onGround && !sneaking ? SPRINT : WALK;
        if (sneaking) speed = Math.abs(acts.moveX) > 0.1 && Math.abs(acts.moveY) > 0.1 ? 1.83 : 1.3;
        if (quakeStage !== 0 && onGround) speed *= 0.75;
        const heldFood = slots[selected];
        const biting = !!(heldFood && heldFood.count > 0 && foodDef(heldFood.id) && acts.useHeld && hunger < 20);
        if (biting) speed *= 0.4;
        vx = nx * speed;
        vz = nz * speed;
        vy -= GRAVITY * dt;
        coyote = onGround ? 0.12 : Math.max(0, coyote - dt);
        if (acts.jump) jumpBuf = 0.12;
        else jumpBuf = Math.max(0, jumpBuf - dt);
        if (jumpBuf > 0 && coyote > 0) {
          vy = JUMP;
          onGround = false;
          coyote = 0;
          jumpBuf = 0;
          addExhaust(0.05);
          audio.jump();
        }
        if (sneaking && onGround && vy <= 0) {
          const margin = 0.28;
          const supported = (ox: number, oz: number) =>
            overlapsBlock(world, x - PW / 2 + ox, y - 0.45, z - PD / 2 + oz, PW, 0.45, PD);
          const sx = Math.sign(vx) * margin;
          const sz = Math.sign(vz) * margin;
          if (sx !== 0 && !supported(sx, 0)) vx = 0;
          if (sz !== 0 && !supported(0, sz)) vz = 0;
          if (vx !== 0 && vz !== 0 && !supported(sx, sz)) vz = 0;
        }
      }

      const moved = moveAABB(world, x - PW / 2, y, z - PD / 2, PW, bodyH, PD, vx, vy, vz, dt, 0.6, true);
      x = moved.x + PW / 2;
      y = moved.y;
      z = moved.z + PD / 2;
      vy = moved.vy;
      onGround = moved.onGround;
      const ride = world.stepSinks(dt, x, y, z, onGround && !hovering);
      if (ride !== 0) {
        y += ride;
        vy = 0;
        onGround = true;
      }
      if (inFluid) {
        const hitWall =
          (Math.abs(nx) > 0.12 && Math.abs(moved.vx) < 0.02) ||
          (Math.abs(nz) > 0.12 && Math.abs(moved.vz) < 0.02);
        if (hitWall) {
          const up = y + 0.62;
          const stillWet = world.immersed(x, up + 0.2, z);
          const blocked = overlapsBlock(world, x - PW / 2, up, z - PD / 2, PW, PH, PD);
          if (!stillWet && !blocked) vy = Math.max(vy, 7.2);
        }
      }
      if (y < -8) hitPlayer(10);

      const moving = Math.hypot(nx, nz) > 0.1 && onGround && !inFluid;
      if (moving && acts.sprint && !hovering) addExhaust(0.45 * dt);
      else if (inFluid && Math.hypot(nx, nz) > 0.1) addExhaust(0.12 * dt);
      if (moving) {
        bob += dt * WALK * 1.8;
        stepT += dt;
        if (stepT > (sneaking ? 0.62 : 0.42)) {
          stepT = 0;
          if (!sneaking) {
            const fy = Math.floor(y - 0.02);
            let fid = world.getBlock(Math.floor(x), fy, Math.floor(z));
            if (fid === AIR) fid = world.getBlock(Math.floor(x), fy - 1, Math.floor(z));
            audio.step(fid);
          }
        }
      } else stepT = 0.3;

      invuln = Math.max(0, invuln - dt);
      hurtFlash = Math.max(0, hurtFlash - dt);
      swing = Math.max(0, swing - dt * 4);

      const ox = x;
      const oy = y + eye;
      const oz = z;
      lookDir.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
      const hit = voxelRaycast(world, ox, oy, oz, lookDir.x, lookDir.y, lookDir.z, REACH);

      if (acts.punch) {
        if (!tryPunch(ox, oy, oz)) {
          /* mining starts via hold */
        } else {
          mine = 0;
          mineKey = "";
        }
      }

      if (hit && isBreakable(world.getBlock(hit.x, hit.y, hit.z)) && acts.break && swing === 0) {
        const key = `${hit.x},${hit.y},${hit.z}`;
        if (mineKey !== key) {
          mineKey = key;
          mine = 0;
        }
        mine += dt / hardness(world.getBlock(hit.x, hit.y, hit.z));
        audio.mine(world.getBlock(hit.x, hit.y, hit.z));
        if (mine >= 1) {
          addExhaust(0.05);
          const id = world.getBlock(hit.x, hit.y, hit.z);
          const hanging = id === PEACH_LEAVES && world.getBlock(hit.x, hit.y - 1, hit.z) === PEACH;
          world.setBlock(hit.x, hit.y, hit.z, isRiccia(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET ? WATER : AIR);
          for (const d of dropsFrom(id)) addItem(d.id, d.n);
          if (hanging) addItem(FOOD_PEACH, 1);
          if (isLeaves(id)) {
            for (let i = 0; i < 6; i++) {
              emitParticle(
                "leaf",
                hit.x + 0.3 + Math.random() * 0.4,
                hit.y + 0.3 + Math.random() * 0.4,
                hit.z + 0.3 + Math.random() * 0.4,
                0xffffff,
                { vx: (Math.random() - 0.5) * 1.4, vy: 0.4 + Math.random() * 0.8, vz: (Math.random() - 0.5) * 1.4 },
                0.7 + Math.random() * 0.4,
                0.9,
                undefined,
                leafAtlasTile(id),
              );
            }
          } else {
            burst(
              hit.x,
              hit.y,
              hit.z,
              isRiccia(id)
                ? 0x5aaa48
                : isWeed(id)
                  ? Number.parseInt((BLOCK_COLOR[id] ?? "#5cb03a").slice(1), 16)
                  : isGrassCarpet(id)
                    ? 0x5c9a3c
                    : isCarpet(id)
                      ? Number.parseInt((BLOCK_COLOR[id] ?? "#b32626").slice(1), 16)
                      : id === MELON
                        ? 0xe0a84a
                        : 0x8a5a32,
            );
          }
          audio.break(id);
          mine = 0;
          mineKey = "";
        }
      } else {
        mine = Math.max(0, mine - dt * 2);
        if (!acts.break) mineKey = "";
      }

      const bite = slots[selected];
      const biteFood = bite && bite.count > 0 ? foodDef(bite.id) : null;
      if (biteFood && acts.useHeld && hunger < 20) {
        if (eatId !== bite.id) {
          eatId = bite.id;
          eatT = 0;
        }
        eatT += dt;
        if (eatT >= biteFood.seconds) {
          if (consumeSelected()) {
            hunger = Math.min(20, hunger + biteFood.hunger);
            sat = Math.min(hunger, sat + biteFood.sat);
            audio.eat();
            if (bite.id === FOOD_CASSAVA_RAW) {
              hintT = 2.4;
              showHint("Amarga. Melhor cozida.");
            }
          }
          eatT = 0;
          eatId = 0;
        }
      } else {
        eatT = 0;
        eatId = 0;
      }

      if (acts.place) {
        const greeted = greetVillager(ox, oy, oz);
        const slot = slots[selected];
        if (greeted) {
          swing = 0.45;
        } else if (hit && (isDoor(world.getBlock(hit.x, hit.y, hit.z)) || isGate(world.getBlock(hit.x, hit.y, hit.z)))) {
          world.togglePassage(hit.x, hit.y, hit.z);
          swing = 0.4;
        } else if (hit && isCandle(world.getBlock(hit.x, hit.y, hit.z))) {
          const cur = world.getBlock(hit.x, hit.y, hit.z);
          world.setBlock(hit.x, hit.y, hit.z, cur === CANDLE_LIT ? CANDLE : CANDLE_LIT);
          audio.place(CANDLE);
          swing = 0.35;
        } else if (hit && world.getBlock(hit.x, hit.y, hit.z) === CRAFTING_TABLE) {
          openInventory(3);
          swing = 0.35;
        } else if (hit && slot && slot.id === SHOVEL && slot.count > 0 && hit.ny === 1 && isSoil(world.getBlock(hit.x, hit.y, hit.z))) {
          world.setBlock(hit.x, hit.y, hit.z, PATH);
          audio.place(PATH);
          swing = 0.8;
        } else if (slot && slot.id === MELON_SLICE && slot.count > 0) {
          let used = false;
          if (acts.crouch && slot.count >= 9 && hit) {
            used = tryPlaceMelon(hit.x, hit.y, hit.z, hit.nx, hit.ny, hit.nz);
          }
          if (!used && acts.crouch) used = craftSeedFromSlice();
          if (!used) used = eatMelonSlice();
          if (used) swing = 0.8;
        } else if (hit && slot && slot.id === MELON_SEEDS && slot.count > 0) {
          const planted = tryPlantMelon(hit.x, hit.y, hit.z, hit.nx, hit.ny, hit.nz);
          if (planted) {
            consumeSelected();
            audio.place(MELON_SEEDS);
            swing = 0.8;
          }
        } else if (hit && slot && isRiccia(slot.id) && slot.count > 0) {
          let px = hit.x + hit.nx;
          let py = hit.y + hit.ny;
          let pz = hit.z + hit.nz;
          const tgt = world.getBlock(hit.x, hit.y, hit.z);
          if (isWater(tgt)) {
            px = hit.x;
            py = hit.y;
            pz = hit.z;
          }
          const dest = world.getBlock(px, py, pz);
          const below = world.getBlock(px, py - 1, pz);
          if (isWater(dest) && isSolid(below) && py >= 0 && py < HEIGHT) {
            if (consumeSelected()) {
              world.setBlock(px, py, pz, RICCIA);
              audio.place(RICCIA);
              swing = 0.8;
            }
          }
        } else if (hit && slot && isCarpet(slot.id) && slot.count > 0) {
          const tgt = world.getBlock(hit.x, hit.y, hit.z);
          let px = hit.x + hit.nx;
          let py = hit.y + hit.ny;
          let pz = hit.z + hit.nz;
          if (isWeed(tgt) && isFloorCarpet(slot.id)) {
            px = hit.x;
            py = hit.y;
            pz = hit.z;
          }
          if (isWeed(tgt) && slot.id === RED_CARPET) {
            px = hit.x;
            py = hit.y;
            pz = hit.z;
          }
          const dest = world.getBlock(px, py, pz);
          const below = world.getBlock(px, py - 1, pz);
          const replacing = px === hit.x && py === hit.y && pz === hit.z && isCarpet(dest);
          const inFluid =
            (isGrassCarpet(slot.id) && isFluid(dest) && !isRiccia(dest)) ||
            (isCerradoCarpet(slot.id) && (isWater(dest) || dest === CERRADO_CARPET_WET));
          const liftWeed = isWeed(dest) && isFloorCarpet(slot.id);
          if (
            py >= 0 &&
            py < HEIGHT &&
            canSupportCarpet(below) &&
            !isCarpet(below) &&
            !isCarpet(dest) &&
            (dest === AIR || inFluid || liftWeed || (isWeed(dest) && slot.id === RED_CARPET)) &&
            !(isFloorCarpet(dest) && isFloorCarpet(slot.id) && !replacing)
          ) {
            const placed = isGrassCarpet(slot.id) && (isWater(dest) || dest === GRASS_CARPET_WET)
              ? GRASS_CARPET_WET
              : isCerradoCarpet(slot.id) && (isWater(dest) || dest === CERRADO_CARPET_WET)
                ? CERRADO_CARPET_WET
                : slot.id;
            if (liftWeed) {
              const up = world.getBlock(px, py + 1, pz);
              if (up !== AIR || py + 1 >= HEIGHT) {
                /* don't cut the weed */
              } else if (consumeSelected()) {
                world.setBlock(px, py + 1, pz, dest);
                world.setBlock(px, py, pz, placed);
                audio.place(placed);
                swing = 0.8;
              }
            } else if (consumeSelected()) {
              world.setBlock(px, py, pz, placed);
              audio.place(placed);
              swing = 0.8;
            }
          }
        } else if (hit) {
          const tgt = world.getBlock(hit.x, hit.y, hit.z);
          let px = hit.x + hit.nx;
          let py = hit.y + hit.ny;
          let pz = hit.z + hit.nz;
          if (isCarpet(tgt) && slot && slot.id && !isCarpet(slot.id) && !isItemOnly(slot.id) && !isRiccia(slot.id)) {
            const onCarpet = isWeed(slot.id) || isGardenFlower(slot.id) || isCrop(slot.id) || isStem(slot.id);
            if (onCarpet) {
              px = hit.x;
              py = hit.y + 1;
              pz = hit.z;
            } else {
              px = hit.x;
              py = hit.y;
              pz = hit.z;
            }
          }
          const insidePlayer =
            px + 1 > x - PW / 2 &&
            px < x + PW / 2 &&
            py + 1 > y &&
            py < y + PH &&
            pz + 1 > z - PD / 2 &&
            pz < z + PD / 2;
          if (
            slot &&
            slot.count > 0 &&
            slot.id &&
            slot.id !== MELON_SEEDS &&
            slot.id !== MELON_SLICE &&
            !isItemOnly(slot.id) &&
            !isCarpet(slot.id) &&
            !isRiccia(slot.id) &&
            py >= 0 &&
            py < HEIGHT &&
            !isSolid(world.getBlock(px, py, pz)) &&
            !insidePlayer
          ) {
            const dest = world.getBlock(px, py, pz);
            const under = world.getBlock(px, py - 1, pz);
            if (isWeed(dest) && isCerradoCarpet(under) && slot.id === WATER) {
              if (under === CERRADO_CARPET && consumeSelected()) {
                world.setBlock(px, py - 1, pz, CERRADO_CARPET_WET);
                audio.place(WATER);
                swing = 0.8;
              }
            } else if (isCerradoCarpet(dest) && slot.id === WATER) {
              if (consumeSelected()) {
                world.setBlock(px, py, pz, CERRADO_CARPET_WET);
                audio.place(WATER);
                swing = 0.8;
              }
            } else {
              const face = isVine(slot.id) ? vineFaceFromNormal(hit.nx, hit.ny, hit.nz) : 0;
              if (!(isVine(slot.id) && face < 0) && consumeSelected()) {
                const fx = -Math.sin(yaw);
                const fz = -Math.cos(yaw);
                const doorId =
                  Math.abs(fx) > Math.abs(fz) ? DOOR + (fx > 0 ? 3 : 2) : DOOR + (fz > 0 ? 1 : 0);
                const placeId = isVine(slot.id) ? vineId(vineSpecies(slot.id), face) : slot.id === DOOR ? doorId : slot.id;
                world.setBlock(px, py, pz, placeId);
                audio.place(placeId);
                swing = 0.8;
              }
            }
          }
        }
      }

      let lookT = hit ? hit.dist : REACH;
      let lookC: Creature | null = null;
      for (const c of creatures) {
        if (!c.alive || c.dying) continue;
        const rdx = c.x - ox;
        const rdz = c.z - oz;
        if (rdx * rdx + rdz * rdz > 36) continue;
        const t = c.hitByRay(ox, oy, oz, lookDir.x, lookDir.y, lookDir.z, REACH);
        if (t !== null && t < lookT) {
          lookT = t;
          lookC = c;
        }
      }
      if (lookC) {
        highlight.visible = true;
        highlight.scale.set(Math.max(0.35, lookC.w), Math.max(0.2, lookC.h), Math.max(0.35, lookC.d));
        highlight.position.set(lookC.x, lookC.y + lookC.h * 0.5, lookC.z);
        showTarget(lookC.label());
      } else if (hit && isTarget(world.getBlock(hit.x, hit.y, hit.z))) {
        const hid = world.getBlock(hit.x, hit.y, hit.z);
        highlight.visible = true;
        if (isCarpet(hid)) {
          highlight.scale.set(1, CARPET_H, 1);
          highlight.position.set(hit.x + 0.5, hit.y + CARPET_H * 0.5, hit.z + 0.5);
        } else if (isRiccia(hid)) {
          highlight.scale.set(1, 0.58, 1);
          highlight.position.set(hit.x + 0.5, hit.y + 0.22, hit.z + 0.5);
        } else if (isVine(hid)) {
          const face = vineFace(hid);
          const t = 1.5 / 16;
          if (face === 0) {
            highlight.scale.set(1, 1, t);
            highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 1 - t / 2);
          } else if (face === 1) {
            highlight.scale.set(1, 1, t);
            highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + t / 2);
          } else if (face === 2) {
            highlight.scale.set(t, 1, 1);
            highlight.position.set(hit.x + 1 - t / 2, hit.y + 0.5, hit.z + 0.5);
          } else {
            highlight.scale.set(t, 1, 1);
            highlight.position.set(hit.x + t / 2, hit.y + 0.5, hit.z + 0.5);
          }
        } else if (isCandle(hid) || hid === COMODA) {
          const box = aimBox(hid, hit.x, hit.y, hit.z, world.getBlock(hit.x, hit.y - 1, hit.z));
          if (box) {
            highlight.scale.set(box.x1 - box.x0, box.y1 - box.y0, box.z1 - box.z0);
            highlight.position.set((box.x0 + box.x1) / 2, (box.y0 + box.y1) / 2, (box.z0 + box.z1) / 2);
          }
        } else {
          highlight.scale.set(1, 1, 1);
          highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
        }
        showTarget(BLOCK_NAME[hid] ?? "");
      } else {
        highlight.visible = false;
        showTarget("");
      }

      const nightNow = time > 0.52 && time < 0.92;
      const spawnMonsters = false;
      if (spawnMonsters && nightNow && !wasNight) queueNightMonsters();
      wasNight = nightNow;
      if (!nightNow) nightQueue.length = 0;
      else if (spawnMonsters && nightQueue.length) {
        nightSpawnAcc += dt;
        if (nightSpawnAcc > 0.45) {
          nightSpawnAcc = 0;
          const job = nightQueue.shift()!;
          const pos = findCreatureGround(x + job.dx, z + job.dz);
          const y0 = job.kind === "beholder" ? pos.y + 1.7 : pos.y;
          addCreature(job.kind, pos.x, y0, pos.z, "adult");
        }
      }
      hintT = Math.max(0, hintT - dt);
      if (hintT <= 0) showHint("");
      const quakeJolted = stepQuake(dt);
      stepFissure(dt);
      const holes: { x: number; z: number }[] = [];
      for (const job of jobs) {
        if (!job.started && job.age < 4) continue;
        for (const col of job.cols) holes.push({ x: col.x + 0.5, z: col.z + 0.5 });
      }
      for (const cols of openDitches) {
        for (const col of cols) holes.push({ x: col.x + 0.5, z: col.z + 0.5 });
      }
      world.holes = holes;
      world.publishGroundFood(
        floaters
          .filter((f) => !f.claimed && (foodDef(f.id) || f.id === MELON))
          .map((f) => ({ x: f.x, y: f.y, z: f.z, id: f.id, n: f.n, tag: f.tag })),
      );
      for (const c of creatures) {
        if (!c.alive) continue;
        const cdx = c.x - x;
        const cdz = c.z - z;
        if (cdx * cdx + cdz * cdz > 42 * 42) continue;
        c.quake = quakeStage !== 0;
        const meet = time > 0.4 && time <= 0.52;
        c.tick(dt, world, { x, y, z, vy }, nightNow, creatures, meet, time);
        if (c.kind === "aldeao" && c.scared && Math.random() < dt * 6) {
          emitParticle(
            "drip",
            c.x + (Math.random() - 0.5) * 0.3,
            c.y + c.h * 0.92,
            c.z + (Math.random() - 0.5) * 0.2,
            0x9fd4ee,
            { vx: (Math.random() - 0.5) * 0.15, vy: 0.4, vz: (Math.random() - 0.5) * 0.15 },
            0.35,
            0.7,
          );
        }
        if (c.kind === "aldeao" && c.alive && c.humT <= 0) {
          const hd = (c.x - x) * (c.x - x) + (c.z - z) * (c.z - z);
          if (hd < 16 * 16) audio.villagerHum();
          c.humT = 4 + Math.random() * 5;
        }
        if (c.kind === "aldeao" && c.farmed) {
          audio.place(c.farmed === "plant" ? MELON_SEEDS : MELON);
          emitParticle(
            "burst",
            c.x,
            c.y + 1.1,
            c.z,
            c.farmed === "plant" ? 0x6a8f3a : 0xf0c24a,
            { vx: (Math.random() - 0.5) * 0.4, vy: 1.2, vz: (Math.random() - 0.5) * 0.4 },
            0.45,
            0.9,
          );
          c.farmed = "";
        }
        if (c.kind === "aldeao" && c.wantChild) {
          c.wantChild = false;
          let n = 0;
          for (const o of creatures) if (o.alive && o.kind === "aldeao") n++;
          if (n < 8) {
            const pos = findCreatureGround(c.childX, c.childZ);
            const baby = addCreature("aldeao", pos.x, pos.y, pos.z, "baby");
            baby.setRole("crianca");
            baby.setHome(c.homeX, c.homeY, c.homeZ);
            baby.meetX = c.meetX || 35;
            baby.meetZ = c.meetZ || -6;
            hintT = 3;
            showHint("Nasceu uma criança na aldeia.");
            audio.villagerYes();
            for (let i = 0; i < 6; i++) {
              emitParticle(
                "burst",
                (c.x + pos.x) / 2,
                c.y + 1.4 + Math.random() * 0.4,
                (c.z + pos.z) / 2,
                0xf07aa8,
                { vx: (Math.random() - 0.5) * 0.3, vy: 0.8 + Math.random() * 0.4, vz: (Math.random() - 0.5) * 0.3 },
                0.7,
                0.9,
              );
            }
          }
        }
        if (quakeJolted && !c.dying) {
          const qdx = c.x - x;
          const qdz = c.z - z;
          if (qdx * qdx + qdz * qdz <= 12 * 12) {
            c.vx += (Math.random() - 0.5) * 0.7;
            c.vz += (Math.random() - 0.5) * 0.7;
            c.vy += c.fish ? 0.12 : 0.35 + quakeAmp * 0.55;
          }
        }
        if (c.dieStarted) {
          c.dieStarted = false;
          const col = c.kind === "beholder" ? 0x6a28a0 : 0xee6620;
          burst(Math.floor(c.x), Math.floor(c.y + 0.4), Math.floor(c.z), col);
          if (c.kind === "murcha") {
            for (let i = 0; i < 10; i++) {
              emitParticle(
                "burst",
                c.x + (Math.random() - 0.5) * 0.5,
                c.y + 0.4 + Math.random() * 1.1,
                c.z + (Math.random() - 0.5) * 0.5,
                Math.random() > 0.4 ? 0xee6620 : 0xffee88,
                {
                  vx: (Math.random() - 0.5) * 1.6,
                  vy: 1.4 + Math.random() * 2.2,
                  vz: (Math.random() - 0.5) * 1.6,
                },
                0.55 + Math.random() * 0.4,
                0.95,
              );
            }
          }
        }
        if (c.playerHit > 0) hitPlayer(c.playerHit);
        if (c.witnessed) {
          audio.witness();
          hintT = 1.8;
          showHint("Testemunha");
          for (let i = 0; i < 16; i++) {
            const a = (i / 16) * Math.PI * 2;
            emitParticle(
              "burst",
              c.x + Math.cos(a) * 0.55,
              c.y + 0.45,
              c.z + Math.sin(a) * 0.55,
              i % 2 ? 0x8a3ad0 : 0xf4eee4,
              {
                vx: Math.cos(a) * 2.4,
                vy: 1.1 + Math.random() * 1.4,
                vz: Math.sin(a) * 2.4,
              },
              0.7 + Math.random() * 0.25,
              0.9,
            );
          }
        }
        if (c.fish || c.bird || c.kind === "beholder" || c.dying) continue;
        if (c.fluid && !c.wasFluid) {
          spawnSplash(c.x, c.y + 0.08, c.z, c.fluid, 0.3 + Math.min(1.8, Math.abs(c.vy) * 0.2));
        } else if (!c.fluid && c.wasFluid) {
          spawnSplash(c.x, c.y + 0.08, c.z, c.wasFluid, 0.2);
        } else if (c.fluid) {
          const cspd = Math.hypot(c.vx, c.vz);
          const headIn = world.fluidAt(c.x, c.y + c.h * 0.85, c.z);
          if (!headIn && cspd > 0.35 && Math.random() < dt * 11) {
            spawnWake(c.x, c.y, c.z, c.fluid, c.vx / cspd, c.vz / cspd);
          } else if (headIn && !isFish(c.kind) && Math.random() < dt * (cspd > 0.3 ? 1.5 : 0.625) * (c.fluid === "mud" ? 0.34 : 1)) {
            spawnBubbles(c.x, c.y + c.h * 0.85, c.z, c.fluid, 1);
          }
        }
      }
      if (world.takeDoorPulse()) audio.door();
      for (let i = creatures.length - 1; i >= 0; i--) {
        const c = creatures[i]!;
        if (c.alive) continue;
        scene.remove(c.group);
        c.dispose();
        creatures.splice(i, 1);
      }

      ricciaAcc += dt;
      if (ricciaAcc > 0.28) {
        ricciaAcc = 0;
        world.forEachRicciaNear(x, z, 50, (rx, ry, rz) => {
          if (!nightNow && Math.random() < 0.035) {
            const roll = Math.random();
            const key = `${rx},${ry},${rz}`;
            const stuck = ricciaStuck.get(key) ?? 0;
            if (roll < 0.1) {
              spawnPlantBubbles(rx + 0.5, ry + 0.22, rz + 0.5, false, true);
            } else if (roll < 0.2 && stuck < 15) {
              const a = ricciaStickPoint(rx, ry, rz);
              if (spawnPlantBubbles(a.x, a.y, a.z, true, false, key)) ricciaStuck.set(key, stuck + 1);
            } else {
              spawnPlantBubbles(rx + 0.5, ry + 0.22, rz + 0.5, false, false);
            }
          }
        });
      }

      aquiferAcc += dt;
      if (aquiferAcc > 0.38) {
        aquiferAcc = 0;
        let drips = 0;
        world.forEachAquiferNear(x, z, 22, (ax, ay, az) => {
          if (drips >= 7) return;
          if (Math.random() > 0.18) return;
          let faces = world.aquiferOpenFaces(ax, ay, az);
          if (!faces.length) {
            const below = world.getBlock(ax, ay - 1, az);
            if (isFluid(below) || below === AIR) faces = [[0, -1, 0]];
            else return;
          }
          const down = faces.find((f) => f[1] < 0);
          const f = down ?? faces[(Math.random() * faces.length) | 0]!;
          emitParticle(
            "drip",
            ax + 0.5 + f[0] * 0.52,
            ay + 0.5 + f[1] * 0.52,
            az + 0.5 + f[2] * 0.52,
            0x7eb8c8,
            { vx: f[0] * 0.15, vy: f[1] < 0 ? -0.4 : 0.05, vz: f[2] * 0.15 },
            1.15 + Math.random() * 0.4,
            0.82,
            "water",
          );
          drips++;
        });
      }

      if (!frameHeavy) {
      frameHeavy = true;
      world.stream(x, z, 1);
      fishScanAcc += dt;
      if (fishScanAcc > 4.5) {
        fishScanAcc = 0;
        seedLakesNear(x, z);
      }
      world.tickFluids(dt);
      world.tickCrops(dt, !nightNow);
      const sprung = world.tickAquifers(dt);
      for (const s of sprung) {
        if (Math.hypot(s.x + 0.5 - x, s.z + 0.5 - z) < 18) {
          spawnSplash(s.x + 0.5, s.y + 0.2, s.z + 0.5, "water", 0.35);
          audio.splash(false, 0.25);
        }
      }
      for (const w of world.takeWashed()) {
        spawnFloater(w.x + 0.5, w.y + 0.35, w.z + 0.5, w.id, w.n);
        burst(w.x, w.y, w.z, Number.parseInt((BLOCK_COLOR[w.id] ?? "#c4b05a").slice(1), 16));
      }
      world.processMeshes(1);
      }

      audio.tick(dt, {
        night: nightNow,
        cerrado: world.biomeAt(x, z) === "cerrado",
        nearWater: inFluid === "mud" || eyeFluid === "mud" ? 0 : inFluid || eyeFluid ? 1 : world.waterColumn(Math.floor(x), Math.floor(z)) ? 0.55 : 0.08,
        nearLeaves: wasLeaves ? 1 : 0.12,
        inWater: eyeFluid === "water" || eyeFluid === "acid",
        inMud: eyeFluid === "mud",
        inLeaves: wasLeaves,
      });

      for (const tag of world.drainFoodClaims()) {
        const hit = floaters.find((f) => f.tag === tag);
        if (hit) hit.claimed = true;
      }
      for (let i = floaters.length - 1; i >= 0; i--) {
        const f = floaters[i]!;
        f.life -= dt;
        const wet = world.fluidAt(f.x, f.y + 0.1, f.z);
        if (wet) {
          f.vy += 8 * dt;
          f.vy *= Math.pow(0.78, dt * 20);
          const [cx, cy, cz] = world.waterCurrent(Math.floor(f.x), Math.floor(f.y + 0.1), Math.floor(f.z));
          f.vx += cx * dt * 3.2;
          f.vz += cz * dt * 3.2;
          f.vx *= 0.9;
          f.vz *= 0.9;
          if (cy < 0) f.vy += cy * 1.6 * dt;
          const top = fluidSurfaceY(f.x, f.y, f.z);
          if (f.y > top - 0.12) {
            f.y = top - 0.12;
            f.vy = Math.min(f.vy, 0.2);
          }
        } else {
          f.vy -= 18 * dt;
        }
        const moved = moveAABB(world, f.x - 0.14, f.y, f.z - 0.14, 0.28, 0.28, 0.28, f.vx, f.vy, f.vz, dt);
        f.x = moved.x + 0.14;
        f.y = moved.y;
        f.z = moved.z + 0.14;
        f.vy = moved.vy;
        f.mesh.position.set(f.x, f.y + 0.14 + Math.sin(waterClock * 3 + i) * 0.04, f.z);
        f.mesh.rotation.y += dt * 1.6;
        const near = !f.claimed && Math.hypot(f.x - x, f.y - y, f.z - z) < 1.25;
        if (f.claimed || near || f.life <= 0) {
          if (near) addItem(f.id, f.n ?? 1);
          scene.remove(f.mesh);
          (f.mesh.material as THREE.Material).dispose();
          floaters.splice(i, 1);
        }
      }

      saveAcc += dt;
      if (saveAcc > 8) {
        saveAcc = 0;
        persist();
      }
    }

    const skyDay = new THREE.Color(0x87b4d6);
    const skyDusk = new THREE.Color(0xc47848);
    const skyNight = new THREE.Color(0x0b1220);
    const t = time;
    let sky: THREE.Color;
    if (t < 0.22) sky = skyNight.clone().lerp(skyDusk, t / 0.22);
    else if (t < 0.3) sky = skyDusk.clone().lerp(skyDay, (t - 0.22) / 0.08);
    else if (t < 0.55) sky = skyDay.clone();
    else if (t < 0.65) sky = skyDay.clone().lerp(skyDusk, (t - 0.55) / 0.1);
    else if (t < 0.72) sky = skyDusk.clone().lerp(skyNight, (t - 0.65) / 0.07);
    else sky = skyNight.clone();
    const sunA = (t - 0.25) * Math.PI * 2;

    renderer.setClearColor(sky);
    if (scene.fog && "color" in scene.fog) (scene.fog as THREE.FogExp2).color.copy(sky);
    const depth = eyeFluid ? world.fluidDepth(x, y + EYE, z) : 0;
    if (scene.fog && "density" in scene.fog) {
      const mud = eyeFluid === "mud";
      (scene.fog as THREE.FogExp2).density = submerged
        ? mud
          ? 0.28
          : 0.046 + Math.min(10, depth) * 0.012
        : 0.012;
    }
    if (submerged) {
      const uw = new THREE.Color(eyeFluid === "acid" ? 0x1a2810 : eyeFluid === "mud" ? 0x24141c : 0x336f78);
      renderer.setClearColor(uw);
      if (scene.fog && "color" in scene.fog) (scene.fog as THREE.FogExp2).color.copy(uw);
    }
    sun.position.set(Math.cos(sunA) * 80, Math.sin(sunA) * 80, 30);
    let sunI = Math.max(0.08, Math.sin(sunA) * 1.15);
    let hemiI = 0.38 + Math.max(0, Math.sin(sunA)) * 0.42;
    if (submerged) {
      const fade = Math.max(0.22, 1 - depth * 0.1);
      sunI *= fade;
      hemiI *= Math.max(0.35, fade + 0.1);
    }
    sun.intensity = sunI;
    hemi.intensity = hemiI;
    const slosh = quakeAmp * Math.sin(waterClock * 19) * 0.4;
    world.animateWater(waterClock + slosh, 0.35 + Math.max(0, Math.sin(sunA)) * 0.8, Math.cos(sunA) * 80, Math.sin(sunA) * 80, 30, sunI, hemiI);
    const bobY = phase === "playing" ? Math.sin(bob * 2) * 0.035 : 0;
    const stride = Math.hypot(vx, vz) > 0.4 ? Math.sin(bob * 2) * 0.7 : 0;
    armL.rotation.x = stride;
    armR.rotation.x = -stride;
    legL.rotation.x = -stride;
    legR.rotation.x = stride;
    playerMesh.position.set(x, y, z);
    playerMesh.rotation.set(0, yaw, 0);
    headPivot.rotation.x = pitch;
    torso.rotation.x = sneaking ? 0.5 : 0;
    torso.position.y = sneaking ? 0.72 : 0.98;
    playerMesh.visible = third && phase === "playing";
    hand.visible = !third;
    const eye = sneaking ? EYE - 0.35 : EYE;
    if (!third) {
      camera.position.set(x, y + eye, z);
      camera.rotation.set(0, 0, 0);
      camera.rotateY(yaw);
      camera.rotateX(pitch);
      camera.position.y += bobY * (sneaking ? 0.35 : 1);
    } else {
      const dist = 4;
      const lx = -Math.sin(yaw) * Math.cos(pitch);
      const ly = Math.sin(pitch);
      const lz = -Math.cos(yaw) * Math.cos(pitch);
      const eyeX = x;
      const eyeY = y + eye + bobY * (sneaking ? 0.35 : 1);
      const eyeZ = z;
      const tx = eyeX - lx * dist;
      const ty = eyeY - ly * dist;
      const tz = eyeZ - lz * dist;
      let cx = eyeX;
      let cy = eyeY;
      let cz = eyeZ;
      const steps = 20;
      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const sx = eyeX + (tx - eyeX) * t;
        const sy = eyeY + (ty - eyeY) * t;
        const sz = eyeZ + (tz - eyeZ) * t;
        if (isSolid(world.getBlock(Math.floor(sx), Math.floor(sy), Math.floor(sz)))) break;
        cx = sx;
        cy = sy;
        cz = sz;
      }
      camera.position.set(cx, cy, cz);
      camera.rotation.set(0, 0, 0);
      camera.rotateY(yaw);
      camera.rotateX(pitch);
    }
    if (quakeAmp > 0.001) {
      const s = quakeAmp;
      const qt = waterClock;
      camera.position.x += (Math.sin(qt * 41.7) * 0.62 + Math.sin(qt * 18.2) * 0.38) * s * 0.09;
      camera.position.y += (Math.sin(qt * 33.4) * 0.75 + Math.sin(qt * 57) * 0.25) * s * 0.065;
      camera.position.z += (Math.cos(qt * 37.2) * 0.62 + Math.sin(qt * 22.6) * 0.38) * s * 0.09;
      camera.rotateZ(Math.sin(qt * 23.5) * s * 0.011);
    }

    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i]!;
      if (p.mode === "trapped") {
        const hx = p.homeX ?? p.mesh.position.x;
        const hy = p.homeY ?? p.mesh.position.y;
        const hz = p.homeZ ?? p.mesh.position.z;
        const plant = isRiccia(world.getBlock(Math.floor(hx), Math.floor(hy), Math.floor(hz)));
        p.life -= dt;
        if (!plant) p.life = -1;
        else {
          const w = p.wobble ?? 0;
          p.mesh.position.set(
            hx + Math.sin(waterClock * 1.5 + w) * 0.016,
            hy + Math.sin(waterClock * 2.2 + w) * 0.01,
            hz + Math.cos(waterClock * 1.7 + w) * 0.016,
          );
        }
        if (p.life <= 0) {
          const key = p.stickKey;
          if (key) {
            const n = (ricciaStuck.get(key) ?? 1) - 1;
            if (n <= 0) ricciaStuck.delete(key);
            else ricciaStuck.set(key, n);
          }
          if (plant) spawnPlantBubbles(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z, false, false);
          scene.remove(p.mesh);
          (p.mesh.material as THREE.Material).dispose();
          particles.splice(i, 1);
        }
        continue;
      }
      if (p.mode === "bubble") {
        const pos = p.mesh.position;
        if (p.sip !== undefined) {
          p.sip -= dt;
          p.mesh.scale.setScalar(3.6 * Math.max(0, p.sip / 0.5));
          if (p.sip <= 0) p.life = 0;
        } else {
          const mud = p.kind === "mud";
          const cap = p.slow ? 0.13 : mud ? 0.11 : 0.36;
          const acc = p.slow ? 0.035 : mud ? 0.025 : 0.1;
          p.vy = Math.min(cap, p.vy + acc * dt);
          p.vx *= 0.985;
          p.vz *= 0.985;
          pos.x += p.vx * dt;
          pos.y += p.vy * dt;
          pos.z += p.vz * dt;
          if (p.huge && p.life > 0) {
            const r = 0.27;
            const headHit =
              phase === "playing" &&
              pos.x > x - PW / 2 - r &&
              pos.x < x + PW / 2 + r &&
              pos.z > z - PD / 2 - r &&
              pos.z < z + PD / 2 + r &&
              pos.y > y + 1 - r &&
              pos.y < y + PH + r;
            let sipped = false;
            if (headHit) {
              oxygen = Math.min(100, oxygen + 40);
              audio.splash(false, 0.4);
              sipped = true;
            } else {
              for (const c of creatures) {
                if (!c.alive) continue;
                const a = c.aabb();
                if (
                  pos.x > a.x - r &&
                  pos.x < a.x + a.w + r &&
                  pos.z > a.z - r &&
                  pos.z < a.z + a.d + r &&
                  pos.y >= a.y &&
                  pos.y <= a.y + a.h + 0.28
                ) {
                  sipped = true;
                  break;
                }
              }
            }
            if (sipped) p.sip = 0.5;
          }
          if (p.sip === undefined) {
            if (!inFluidColumn(pos.x, pos.y, pos.z) || pos.y >= fluidSurfaceY(pos.x, pos.y, pos.z)) {
              p.life = 0;
              if (p.huge) spawnSplash(pos.x, pos.y, pos.z, "water", 1.35);
            }
          }
        }
        if (p.life <= 0) {
          scene.remove(p.mesh);
          (p.mesh.material as THREE.Material).dispose();
          particles.splice(i, 1);
        }
        continue;
      }
      if (p.mode === "drip") {
        p.life -= dt;
        p.vy -= 16 * dt;
        if (p.vy < -9) p.vy = -9;
        p.mesh.position.x += p.vx * dt;
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.z += p.vz * dt;
        const pos = p.mesh.position;
        const bid = world.getBlock(Math.floor(pos.x), Math.floor(pos.y), Math.floor(pos.z));
        const mat = p.mesh.material as THREE.MeshBasicMaterial | THREE.MeshLambertMaterial;
        mat.opacity = Math.max(0, p.life / p.maxLife) * p.baseOp;
        if (isSolid(bid) || isFluid(bid) || p.life <= 0) {
          scene.remove(p.mesh);
          mat.dispose();
          particles.splice(i, 1);
        }
        continue;
      }
      p.life -= dt;
      if (p.mode === "wake") {
        p.vy *= 0.85;
        p.vx *= 0.88;
        p.vz *= 0.88;
      } else {
        p.vy -= 18 * dt;
      }
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      if (p.mode === "leaf") {
        p.mesh.rotation.x += (p.spinX ?? 0) * dt;
        p.mesh.rotation.y += (p.spinY ?? 0) * dt;
        p.mesh.rotation.z += (p.spinZ ?? 0) * dt;
      }
      const mat = p.mesh.material as THREE.MeshBasicMaterial | THREE.MeshLambertMaterial;
      if (p.arc && p.homeY !== undefined && p.vy < 0 && p.mesh.position.y <= p.homeY) {
        p.mesh.position.set(p.homeX ?? p.mesh.position.x, p.homeY, p.homeZ ?? p.mesh.position.z);
        audio.pebbleLand();
        scene.remove(p.mesh);
        mat.dispose();
        particles.splice(i, 1);
        continue;
      }
      if (p.mode === "leaf" && p.homeY !== undefined && p.vy < 0 && p.mesh.position.y <= p.homeY) {
        scene.remove(p.mesh);
        mat.dispose();
        particles.splice(i, 1);
        continue;
      }
      if (p.arc) {
        p.mesh.scale.setScalar(1.1);
        mat.opacity = p.baseOp;
      } else if (p.mode === "leaf" && p.homeY !== undefined) {
        p.mesh.scale.setScalar(1.35);
        mat.opacity = p.baseOp;
      } else {
        const fade = Math.max(0, p.life / p.maxLife);
        p.mesh.scale.setScalar(0.45 + fade * 0.7);
        mat.opacity = fade * p.baseOp;
      }
      if (p.life <= 0) {
        scene.remove(p.mesh);
        mat.dispose();
        particles.splice(i, 1);
      }
    }

    hand.rotation.x = -swing * 1.1;
    hand.rotation.y = swing * 0.4;
    const sid = slots[selected]?.id ?? 1;
    const hex = BLOCK_COLOR[sid];
    (hand.material as THREE.MeshLambertMaterial).color.setHex(hex ? Number.parseInt(hex.slice(1), 16) : 0x5a9a45);
    if (isCarpet(sid)) hand.scale.set(1.2, 0.16, 1.2);
    else if (isFood(sid)) hand.scale.set(0.45, 0.45, 0.45);
    else if (isWeed(sid) || isPlant(sid)) hand.scale.set(0.7, 1.2, 0.7);
    else hand.scale.set(1, 1, 1);

    hudAcc += dt;
    if (hudAcc > 0.12) {
      hudAcc = 0;
      useGame.getState().setHud({
        health,
        mine,
        time,
        selected,
        inventoryOpen,
        cursor: { ...cursor },
        underwater: submerged,
        underFluid: eyeFluid,
        oxygen,
        hunger,
        hungerShake: sat <= 0 && hunger < 20,
        eat: eatId ? Math.min(1, eatT / (foodDef(eatId)?.seconds || 1)) : 0,
        hovering,
        breathing,
        third,
      sneaking,
        slots: slots.map((s) => ({ ...s })),
        ...compassHud(),
      });
    }
  };

  const loop = (now: number) => {
    if (disposed) return;
    raf = requestAnimationFrame(loop);
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    frameHeavy = false;
    acc += dt;
    let steps = 0;
    while (acc >= STEP && steps < 5) {
      tick(STEP);
      acc -= STEP;
      steps++;
    }
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    if (canvas.width !== Math.floor(w * renderer.getPixelRatio()) || canvas.height !== Math.floor(h * renderer.getPixelRatio())) {
      onResize();
    }
    renderer.clear();
    renderer.render(scene, camera);
  };
  raf = requestAnimationFrame(loop);

  type ControlsProbe = {
    getYaw: () => number;
    getSpeed: () => number;
    setKeys?: (codes: string[]) => void;
    getPos?: () => { x: number; y: number; z: number };
    setPos?: (x: number, y: number, z: number) => void;
    getFluid?: () => { body: FluidKind | null; eyes: FluidKind | null };
    getBlock?: (x: number, y: number, z: number) => number;
    setBlock?: (x: number, y: number, z: number, id: number) => void;
    breakBlock?: (x: number, y: number, z: number) => number;
    getSlots?: () => { id: number; count: number }[];
    toggleInventory?: () => void;
    getInventory?: () => { open: boolean; selected: number; cursor: Slot };
    setBreak?: (v: boolean) => void;
    setLook?: (yaw: number, pitch: number) => void;
    getNests?: () => { x: number; y: number; z: number }[];
    setTime?: (t: number) => void;
    getCreatures?: () => {
      kind: string;
      x: number;
      y: number;
      z: number;
      dying: boolean;
      stage: string;
      huntT: number;
      summonT: number;
    }[];
    setHealth?: (n: number) => void;
    getAquifers?: () => { x: number; y: number; z: number }[];
    forceAquifer?: () => { x: number; y: number; z: number } | null;
    findDeep?: () => { x: number; z: number; waterY: number; bedY: number; dry: boolean }[];
  };
  (window as unknown as { __controlsTest?: ControlsProbe }).__controlsTest = {
    getYaw: () => yaw,
    getSpeed: () => Math.hypot(vx, vz),
    setKeys: (codes) => {
      if (phase !== "playing") play();
      input.setKeys(codes);
    },
    getPos: () => ({ x, y, z }),
    setPos: (nx: number, ny: number, nz: number) => {
      x = nx;
      y = ny;
      z = nz;
    },
    getFluid: () => ({ body: wasFluid, eyes: eyeFluid }),
    getBlock: (bx: number, by: number, bz: number) => world.getBlock(bx, by, bz),
    setBlock: (bx: number, by: number, bz: number, id: number) => {
      world.setBlock(bx, by, bz, id);
    },
    breakBlock: (bx: number, by: number, bz: number) => {
      const id = world.getBlock(bx, by, bz);
      if (!isBreakable(id)) return id;
      world.setBlock(bx, by, bz, isRiccia(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET ? WATER : AIR);
      for (const d of dropsFrom(id)) addItem(d.id, d.n);
      return 0;
    },
    getSlots: () => slots.map((s) => ({ id: s.id, count: s.count })),
    toggleInventory,
    getInventory: () => ({ open: inventoryOpen, selected, cursor: { ...cursor } }),
    setBreak: (v: boolean) => {
      if (phase !== "playing") play();
      input.touchBreak = v;
    },
    setLook: (ny: number, np: number) => {
      yaw = ny;
      pitch = np;
    },
    getNests: () => nests.map((n) => ({ x: n.position.x, y: n.position.y, z: n.position.z })),
    setTime: (t: number) => {
      time = Math.max(0, Math.min(1, t));
    },
    setHealth: (n: number) => {
      health = Math.max(1, Math.min(maxHealth, n));
      invuln = 8;
      if (phase === "dead") {
        setPhase("playing");
        lockPointer();
      }
      pushHud();
    },
    getCreatures: () =>
      creatures
        .filter((c) => c.alive)
        .map((c) => ({
          kind: c.kind,
          x: c.x,
          y: c.y,
          z: c.z,
          dying: c.dying,
          stage: c.stage,
          huntT: c.huntT,
          summonT: c.summonT,
        })),
    getAquifers: () => world.listAquifersNear(x, z, 48),
    forceAquifer: () => world.forceAquiferNear(x, z),
    findDeep: () => {
      const seen = new Set<string>();
      const out: { x: number; z: number; waterY: number; bedY: number; dry: boolean }[] = [];
      for (let sx = -90; sx <= 90; sx += 3) {
        for (let sz = -90; sz <= 90; sz += 3) {
          const b = world.basinAt(sx, sz);
          if (!b?.extreme) continue;
          const k = `${b.kx},${b.kz}`;
          if (seen.has(k)) continue;
          seen.add(k);
          out.push({ x: sx, z: sz, waterY: b.waterY, bedY: b.bedY, dry: b.dry });
        }
      }
      return out;
    },
  };

  pushHud();

  return {
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(raf);
      persist();
      input.detach();
      document.removeEventListener("pointerlockchange", onPointerLock);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("resize", onResize);
      for (const c of creatures) c.dispose();
      for (const n of nests) {
        scene.remove(n);
        n.traverse((o) => {
          if (o instanceof THREE.Mesh) {
            o.geometry.dispose();
            const list = Array.isArray(o.material) ? o.material : [o.material];
            for (const m of list) m.dispose();
          }
        });
      }
      for (const p of particles) {
        scene.remove(p.mesh);
        (p.mesh.material as THREE.Material).dispose();
      }
      clearFloaters();
      world.dispose();
      audio.dispose();
      renderer.dispose();
      useGame.getState().setHandle(null);
      delete (window as unknown as { __controlsTest?: ControlsProbe }).__controlsTest;
    },
  };
}
