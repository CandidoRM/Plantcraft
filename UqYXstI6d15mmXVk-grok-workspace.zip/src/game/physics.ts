import { HEIGHT, World } from "./world";
import { SINK_PLAT, aimBox, collisionTop, FENCE, isTarget } from "./blocks";

export type Hit = {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  dist: number;
};

function rayAabb(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  minX: number,
  minY: number,
  minZ: number,
  maxX: number,
  maxY: number,
  maxZ: number,
): { t: number; nx: number; ny: number; nz: number } | null {
  let tmin = -Infinity;
  let tmax = Infinity;
  let nx = 0;
  let ny = 0;
  let nz = 0;
  const test = (o: number, d: number, mn: number, mx: number, ax: number, ay: number, az: number) => {
    if (Math.abs(d) < 1e-12) {
      if (o < mn || o > mx) tmin = Infinity;
      return;
    }
    const inv = 1 / d;
    let t0 = (mn - o) * inv;
    let t1 = (mx - o) * inv;
    let s0 = -1;
    let s1 = 1;
    if (t0 > t1) {
      const tmp = t0;
      t0 = t1;
      t1 = tmp;
      s0 = 1;
      s1 = -1;
    }
    if (t0 > tmin) {
      tmin = t0;
      nx = ax * s0;
      ny = ay * s0;
      nz = az * s0;
    }
    if (t1 < tmax) tmax = t1;
  };
  test(ox, dx, minX, maxX, 1, 0, 0);
  test(oy, dy, minY, maxY, 0, 1, 0);
  test(oz, dz, minZ, maxZ, 0, 0, 1);
  if (tmin > tmax || tmax < 0) return null;
  const t = tmin >= 0 ? tmin : tmax;
  if (t < 0) return null;
  return { t, nx, ny, nz };
}

export function voxelRaycast(
  world: World,
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
): Hit | null {
  const len = Math.hypot(dx, dy, dz) || 1;
  dx /= len;
  dy /= len;
  dz /= len;

  let x = Math.floor(ox);
  let y = Math.floor(oy);
  let z = Math.floor(oz);

  const stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
  const stepY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
  const stepZ = dz > 0 ? 1 : dz < 0 ? -1 : 0;

  const tDeltaX = stepX !== 0 ? Math.abs(1 / dx) : Infinity;
  const tDeltaY = stepY !== 0 ? Math.abs(1 / dy) : Infinity;
  const tDeltaZ = stepZ !== 0 ? Math.abs(1 / dz) : Infinity;

  const frac = (v: number, d: number, step: number) => {
    if (step > 0) return (1 - (v - Math.floor(v))) / Math.abs(d);
    if (step < 0) return (v - Math.floor(v)) / Math.abs(d);
    return Infinity;
  };

  let tMaxX = stepX !== 0 ? frac(ox, dx, stepX) : Infinity;
  let tMaxY = stepY !== 0 ? frac(oy, dy, stepY) : Infinity;
  let tMaxZ = stepZ !== 0 ? frac(oz, dz, stepZ) : Infinity;

  let nx = 0;
  let ny = 0;
  let nz = 0;
  let t = 0;

  let sinkBest: Hit | null = null;
  for (const b of world.sinkSolids) {
    const hit = rayAabb(ox, oy, oz, dx, dy, dz, b.x, b.y, b.z, b.x + 1, b.y + 1, b.z + 1);
    if (!hit || hit.t > maxDist) continue;
    if (!sinkBest || hit.t < sinkBest.dist) {
      sinkBest = { x: b.x, y: b.home, z: b.z, nx: hit.nx, ny: hit.ny, nz: hit.nz, dist: hit.t };
    }
  }
  const preferSink = (hit: Hit | null): Hit | null => {
    if (sinkBest && (!hit || sinkBest.dist < hit.dist)) return sinkBest;
    return hit;
  };

  const partialHit = (bx: number, by: number, bz: number, tEnter: number, tExit: number): Hit | null => {
    if (by < 0 || by >= HEIGHT) return null;
    const id = world.getBlock(bx, by, bz);
    const box = aimBox(id, bx, by, bz, world.getBlock(bx, by - 1, bz));
    if (!box) return null;
    const hit = rayAabb(ox, oy, oz, dx, dy, dz, box.x0, box.y0, box.z0, box.x1, box.y1, box.z1);
    if (!hit || hit.t > maxDist) return null;
    if (hit.t > tExit + 1e-4 || hit.t < tEnter - 1e-4) return null;
    return { x: bx, y: by, z: bz, nx: hit.nx, ny: hit.ny, nz: hit.nz, dist: hit.t };
  };

  for (let i = 0; i < 96; i++) {
    if (t > maxDist) return preferSink(null);
    const tEnter = t;
    const tExit = Math.min(tMaxX, tMaxY, tMaxZ);
    if (y >= 0 && y < HEIGHT) {
      const id = world.getBlock(x, y, z);
      const slim = aimBox(id, x, y, z, world.getBlock(x, y - 1, z));
      if (isTarget(id) && !slim && id !== SINK_PLAT) {
        return preferSink({ x, y, z, nx, ny, nz, dist: t });
      }
      let best: Hit | null = null;
      for (const by of [y - 1, y, y + 1]) {
        const hit = partialHit(x, by, z, tEnter, tExit);
        if (hit && (!best || hit.dist < best.dist)) best = hit;
      }
      if (best) return preferSink(best);
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      t = tMaxX;
      x += stepX;
      tMaxX += tDeltaX;
      nx = -stepX;
      ny = 0;
      nz = 0;
    } else if (tMaxY < tMaxZ) {
      t = tMaxY;
      y += stepY;
      tMaxY += tDeltaY;
      nx = 0;
      ny = -stepY;
      nz = 0;
    } else {
      t = tMaxZ;
      z += stepZ;
      tMaxZ += tDeltaZ;
      nx = 0;
      ny = 0;
      nz = -stepZ;
    }
  }
  return preferSink(null);
}

function visitColliders(
  world: World,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  fn: (bx: number, by: number, bz: number, top: number) => void,
  passFence = false,
) {
  const minX = Math.floor(x);
  const maxX = Math.floor(x + w - 1e-5);
  const minY = Math.floor(y) - (passFence ? 0 : 1);
  const maxY = Math.floor(y + h - 1e-5);
  const minZ = Math.floor(z);
  const maxZ = Math.floor(z + d - 1e-5);
  for (let by = minY; by <= maxY; by++) {
    for (let bz = minZ; bz <= maxZ; bz++) {
      for (let bx = minX; bx <= maxX; bx++) {
        const id = world.getBlock(bx, by, bz);
        let top = collisionTop(id);
        if (id === FENCE) top = passFence ? 0 : 2;
        if (top <= 0) continue;
        if (x < bx + 1 && x + w > bx && z < bz + 1 && z + d > bz && y < by + top && y + h > by) {
          fn(bx, by, bz, top);
        }
      }
    }
  }
  for (const b of world.sinkSolids) {
    if (x < b.x + 1 && x + w > b.x && z < b.z + 1 && z + d > b.z && y < b.y + 1 && y + h > b.y) {
      fn(b.x, b.y, b.z, 1);
    }
  }
}

export function overlapsBlock(
  world: World,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  passFence = false,
): boolean {
  let hit = false;
  visitColliders(world, x, y, z, w, h, d, () => {
    hit = true;
  }, passFence);
  return hit;
}

export function moveAABB(
  world: World,
  px: number,
  py: number,
  pz: number,
  w: number,
  h: number,
  d: number,
  vx: number,
  vy: number,
  vz: number,
  dt: number,
  stepHeight = 0.6,
  passFence = false,
): { x: number; y: number; z: number; vx: number; vy: number; vz: number; onGround: boolean } {
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(vx), Math.abs(vy), Math.abs(vz)) * dt / 0.35));
  const sdt = dt / steps;
  let x = px;
  let y = py;
  let z = pz;
  let onGround = false;
  const hits = (ax: number, ay: number, az: number) => collides(world, ax, ay, az, w, h, d, passFence);

  for (let s = 0; s < steps; s++) {
    const yBefore = y;
    y += vy * sdt;
    if (hits(x, y, z)) {
      if (vy > 0) {
        let ceil = Infinity;
        visitColliders(world, x, y, z, w, h, d, (_bx, by) => {
          if (by < ceil) ceil = by;
        }, passFence);
        y = ceil - h - 1e-4;
      } else {
        let floor = -Infinity;
        let any = -Infinity;
        visitColliders(world, x, y, z, w, h, d, (_bx, by, _bz, top) => {
          const t = by + top;
          if (t <= yBefore + 0.08 && t > floor) floor = t;
          if (t > any) any = t;
        }, passFence);
        y = floor > -Infinity ? floor : any;
        onGround = true;
      }
      vy = 0;
    }

    const ox = x;
    x += vx * sdt;
    if (hits(x, y, z)) {
      if (
        stepHeight > 0 &&
        (onGround || vy <= 0.05) &&
        !hits(ox, y + stepHeight, z) &&
        !hits(x, y + stepHeight, z)
      ) {
        y += stepHeight;
        onGround = true;
      } else {
        if (vx > 0) x = Math.floor(x + w) - w - 1e-4;
        else x = Math.floor(x) + 1;
        vx = 0;
      }
    }

    const oz = z;
    z += vz * sdt;
    if (hits(x, y, z)) {
      if (
        stepHeight > 0 &&
        (onGround || vy <= 0.05) &&
        !hits(x, y + stepHeight, oz) &&
        !hits(x, y + stepHeight, z)
      ) {
        y += stepHeight;
        onGround = true;
      } else {
        if (vz > 0) z = Math.floor(z + d) - d - 1e-4;
        else z = Math.floor(z) + 1;
        vz = 0;
      }
    }
  }

  return { x, y, z, vx, vy, vz, onGround };
}

function collides(
  world: World,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  passFence = false,
): boolean {
  return overlapsBlock(world, x, y, z, w, h, d, passFence);
}
