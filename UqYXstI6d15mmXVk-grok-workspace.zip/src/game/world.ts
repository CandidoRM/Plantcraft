import * as THREE from "three";
import {
  AIR,
  ARAU_LEAVES,
  ARAU_LOG,
  BEDROCK,
  BIRCH_LEAVES,
  BIRCH_LOG,
  BREJO_CARPET,
  BREJO_DIRT,
  BREJO_GRASS,
  BREJO_GRASS_FULL,
  CARPET_H,
  DARK_LEAVES,
  DARK_LOG,
  DIRT,
  FARMLAND,
  FLOW_MAX,
  GRASS,
  GRASS_CARPET,
  GRASS_CARPET_WET,
  GRASS_FULL,
  LEAVES,
  LOG,
  MELON,
  MELON_ATTACH,
  RED_CARPET,
  RICCIA,
  SAND,
  STEM_DIRS,
  STONE,
  WATER,
  ACID,
  AQUIFER,
  CAMAPU,
  CANDLE_LIT,
  CAATINGA_CACTUS,
  CAATINGA_CARPET,
  CAATINGA_DIRT,
  CAATINGA_GRASS,
  CAATINGA_GRASS_FULL,
  CAATINGA_LEAVES,
  CAATINGA_LOG,
  CAATINGA_ROCK,
  COMODA,
  CERRADO_CARPET,
  CERRADO_CARPET_WET,
  CERRADO_DIRT,
  CERRADO_GRASS,
  DOOR,
  DOOR_OPEN,
  FENCE,
  GARDEN_IRIS,
  GARDEN_LILY,
  GATE,
  GATE_OPEN,
  GREEN_BRICK,
  MARBLE,
  MARBLE_BLUE,
  MARBLE_BRICK,
  MARBLE_BROKEN,
  MARBLE_CARPET,
  MARBLE_GRASS,
  MARBLE_GRASS_FULL,
  MARBLE_ORANGE,
  MARBLE_PURPLE,
  MARBLE_VASE,
  MONUMENT_BASE,
  MONUMENT_CROWN,
  MONUMENT_SHAFT,
  MELON_STEM,
  MUD,
  MUD_FLUID,
  PATH,
  PEACH,
  PEACH_LEAVES,
  PLANKS,
  RUST_METAL,
  SINK_PLAT,
  TOMATO,
  URUCUM,
  VINE,
  WEED_BEACH,
  WEED_CERRADO,
  WEED_DROOP,
  WEED_MACAMBIRA,
  WEED_REED,
  WEED_SHORT,
  WEED_TALL,
  attachFacing,
  canHoldFruit,
  canSupportCarpet,
  dropsFrom,
  faceTile,
  flowReach,
  fluidFall,
  fluidFill,
  fluidFromLevel,
  fluidKind,
  fluidLevel,
  fluidSource,
  isCandle,
  isCarpet,
  isDoor,
  isFluid,
  isFluidFall,
  isFluidSource,
  cropTile,
  gardenTile,
  isCaatingaGrass,
  isBrejoGrass,
  isCrop,
  isFluidPermeable,
  isGardenFlower,
  isGate,
  isFluidReplaceable,
  isFloorCarpet,
  isGrassCarpet,
  isLeaves,
  isLog,
  isMarbleGrass,
  isMeadowGrass,
  isMelonAttach,
  isOpaque,
  isPeach,
  isPlant,
  isRiccia,
  isSolid,
  isStem,
  isVase,
  isVine,
  isWeed,
  leafAtlasTile,
  vineFace,
  vineId,
  weedTile,
  weedModelHeight,
  sameFluid,
  doorWithOpen,
  stemFromStage,
  stemStage,
  type FluidKind,
} from "./blocks";
import { fbm, rand2 } from "./noise";
import { createAcidTexture, createAtlasTexture, createLeafTexture, createMudTexture, createStemTexture, createWaterTexture, leafUv, stemUv, tileUv } from "./textures";
import type { VillagerRole } from "./villagers";

export const CHUNK = 16;
/** Extra air above the old sky, and the same amount of stone under the old floor. */
export const WORLD_LIFT = 20;
export const HEIGHT = 48 + WORLD_LIFT * 2;
export const VIEW = 3;
export const FLUID_PUSH = 1.39;

export type Biome = "forest" | "cerrado" | "marble" | "caatinga" | "brejo";

export type FissureCol = {
  x: number;
  z: number;
  top: number;
  bed: number;
  dry: boolean;
  shut: boolean;
};

const VOLUME = CHUNK * HEIGHT * CHUNK;

function idx(x: number, y: number, z: number): number {
  return x + z * CHUNK + y * CHUNK * CHUNK;
}

type FaceDef = {
  dir: [number, number, number];
  corners: [number, number, number][];
};

const FACES: FaceDef[] = [
  { dir: [0, 1, 0], corners: [[0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]] },
  { dir: [0, -1, 0], corners: [[0, 0, 1], [1, 0, 1], [1, 0, 0], [0, 0, 0]] },
  { dir: [1, 0, 0], corners: [[1, 0, 0], [1, 0, 1], [1, 1, 1], [1, 1, 0]] },
  { dir: [-1, 0, 0], corners: [[0, 0, 1], [0, 0, 0], [0, 1, 0], [0, 1, 1]] },
  { dir: [0, 0, 1], corners: [[1, 0, 1], [0, 0, 1], [0, 1, 1], [1, 1, 1]] },
  { dir: [0, 0, -1], corners: [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]] },
];

export class Chunk {
  readonly cx: number;
  readonly cz: number;
  readonly blocks: Uint8Array;
  group: THREE.Group | null = null;
  dirty = true;
  /** Highest y that holds anything but air. The mesh stops here. */
  top = 0;

  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    this.blocks = new Uint8Array(VOLUME);
  }

  get(x: number, y: number, z: number): number {
    if (y < 0 || y >= HEIGHT || x < 0 || x >= CHUNK || z < 0 || z >= CHUNK) return AIR;
    return this.blocks[idx(x, y, z)]!;
  }

  set(x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= HEIGHT || x < 0 || x >= CHUNK || z < 0 || z >= CHUNK) return;
    this.blocks[idx(x, y, z)] = id;
    this.dirty = true;
    this.note(y, id);
  }

  note(y: number, id: number) {
    if (id !== AIR) {
      if (y > this.top) this.top = y;
      return;
    }
    if (y !== this.top) return;
    const stride = CHUNK * CHUNK;
    for (let yy = y; yy > 0; yy--) {
      const base = yy * stride;
      for (let i = 0; i < stride; i++) {
        if (this.blocks[base + i]) {
          this.top = yy;
          return;
        }
      }
    }
    this.top = 0;
  }
}

export class World {
  readonly seed: number;
  readonly group = new THREE.Group();
  readonly chunks = new Map<string, Chunk>();
  readonly edits = new Map<string, number>();
  /** Home height of each sinking-platform column. The block itself moves without being saved. */
  private readonly sinkHome = new Map<string, number>();
  private readonly sinkViews = new Map<string, { sig: string; drop: number; group: THREE.Group }>();
  sinkSolids: { x: number; y: number; z: number; home: number }[] = [];
  readonly material: THREE.MeshLambertMaterial;
  readonly cutout: THREE.MeshLambertMaterial;
  readonly plant: THREE.MeshLambertMaterial;
  readonly waterMat: THREE.ShaderMaterial;
  readonly acidMat: THREE.ShaderMaterial;
  readonly mudMat: THREE.MeshLambertMaterial;
  readonly leafTex: THREE.Texture;
  holes: { x: number; z: number }[] = [];
  groundFood: { x: number; y: number; z: number; id: number; n: number; tag: number }[] = [];
  fishPool: { x: number; y: number; z: number }[] = [];
  penSpawns: { x: number; y: number; z: number; kind: "vaca" | "porco" | "ovelha" }[] = [];
  mantisNests: { x: number; z: number; used: boolean }[] = [];
  hamletMeet = { x: 32, z: -12 };
  fishDock: { x: number; y: number; z: number } | null = null;
  repairs: { x: number; y: number; z: number; id: number }[] = [];
  private readonly atlas: THREE.Texture;
  private readonly leafMap: THREE.Texture;
  private readonly stemMap: THREE.Texture;
  private readonly waterMap: THREE.Texture;
  private readonly acidMap: THREE.Texture;
  private meshQueue: Chunk[] = [];
  private fluidQueue = new Set<string>();
  private fluidAcc = 0;
  private mudAcc = 0;
  private mudReady = false;
  private cropQueue = new Set<string>();
  private cropAcc = 0;
  private grassGrow = new Map<string, number>();
  private promoteQueue = new Map<string, number>();
  private washed: { x: number; y: number; z: number; id: number; n: number }[] = [];
  private ricciaCells = new Set<string>();
  private keptTree: { x: number; z: number } | null = null;
  private aquiferCells = new Map<string, number>();
  private foodClaims = new Set<number>();
  private doorPulse = false;
  private hamletSpots: { x: number; y: number; z: number; role: VillagerRole }[] | null = null;
  private villagePlan: { x: number; y: number; z: number; id: number }[] = [];
  private readonly mudMap: THREE.Texture;

  constructor(seed: number) {
    this.seed = seed;
    this.atlas = createAtlasTexture();
    this.leafMap = createLeafTexture();
    this.stemMap = createStemTexture();
    this.waterMap = createWaterTexture();
    this.acidMap = createAcidTexture();
    this.mudMap = createMudTexture();
    this.leafTex = this.leafMap;
    this.material = new THREE.MeshLambertMaterial({
      map: this.atlas,
      side: THREE.FrontSide,
      vertexColors: true,
    });
    this.cutout = new THREE.MeshLambertMaterial({
      map: this.leafMap,
      alphaTest: 0.5,
      transparent: false,
      depthWrite: true,
      side: THREE.DoubleSide,
      vertexColors: true,
    });
    this.plant = new THREE.MeshLambertMaterial({
      map: this.stemMap,
      alphaTest: 0.35,
      transparent: false,
      depthWrite: true,
      side: THREE.FrontSide,
      vertexColors: true,
    });
    this.waterMat = makeLiquidMat(this.waterMap, 0.288, [0.84, 0.89, 0.98]);
    this.acidMat = makeLiquidMat(this.acidMap, 0.464, [0.82, 0.9, 0.66]);
    this.mudMat = new THREE.MeshLambertMaterial({
      map: this.mudMap,
      transparent: true,
      opacity: 0.95,
      depthWrite: false,
      side: THREE.DoubleSide,
      vertexColors: true,
    });
    this.mudMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = { value: 0 };
      shader.vertexShader =
        "uniform float uTime;\n" +
        shader.vertexShader.replace(
          "#include <uv_vertex>",
          `#include <uv_vertex>
          vec3 mudW = (modelMatrix * vec4(position, 1.0)).xyz;
          vMapUv += vec2(uTime * 0.016, uTime * 0.011);
          vMapUv += 0.028 * vec2(sin(mudW.x * 1.6 + uTime * 0.95), cos(mudW.z * 1.4 + uTime * 0.8));`,
        );
      this.mudMat.userData.shader = shader;
    };
  }

  biomeAt(x: number, z: number): Biome {
    if (x > 96) return "marble";
    if (z > 88 && x < 70) return "caatinga";
    if (x < -88) return "cerrado";
    if (z < -96 && x > -70 && x < 80) return "brejo";
    return "forest";
  }

  basinAt(x: number, z: number): { waterY: number; bedY: number; bed: number; kx: number; kz: number; extreme: boolean; dry: boolean } | null {
    const body = this.waterBodyAt(x, z);
    if (!body) return null;
    return { waterY: body.waterY, bedY: body.bedY, bed: body.bed, kx: body.kx, kz: body.kz, extreme: body.extreme, dry: body.dry };
  }

  key(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  heightAt(x: number, z: number): number {
    const n = fbm(x * 0.028, z * 0.028, this.seed, 5);
    const r = fbm(x * 0.09 + 40, z * 0.09, this.seed + 9, 3);
    const forest = 22 + n * 12 + r * 5;
    const broad = fbm(x * 0.015, z * 0.015, this.seed + 70, 4);
    const crestN = 1 - Math.abs(fbm(x * 0.05, z * 0.018, this.seed + 91, 4) * 2 - 1);
    const crest = Math.pow(crestN, 1.35);
    const fold = fbm(x * 0.09, z * 0.09, this.seed + 94, 2);
    const hill = broad > 0.4 ? (broad - 0.4) / 0.6 : 0;
    const marble = 17 + hill * 15 + crest * 13 + fold * 4;
    const tall = hill > 0.28 ? hill * hill * 14 : 0;
    const extra = crest > 0.5 ? (crest - 0.5) * 18 : 0;
    const shelf = fbm(x * 0.05, z * 0.05, this.seed + 133, 3);
    const region = fbm(x * 0.013, z * 0.013, this.seed + 141, 2);
    const cut = region > 0.58 && shelf > 0.44 && shelf < 0.52 ? 4 : 0;
    const lifted = marble + tall + extra - cut;
    const t = x <= 72 ? 0 : x >= 120 ? 1 : (x - 72) / 48;
    const s = t * t * t * (t * (t * 6 - 15) + 10);
    const cap = 45;
    let h = WORLD_LIFT + Math.max(6, Math.min(cap, Math.floor(forest * (1 - s) + lifted * s)));
    if (x > -70 && x < 80 && z < -72) {
      const u = z <= -110 ? 1 : (-72 - z) / 38;
      const k = u * u * (3 - 2 * u);
      const hum = fbm(x * 0.045, z * 0.045, this.seed + 210, 3);
      const brejo = WORLD_LIFT + 7 + hum * 4;
      h = Math.floor(h * (1 - k) + brejo * k);
    }
    return h;
  }

  /** Lake / pond / ditch basin at a column, or null if dry land. */
  private waterBodyAt(x: number, z: number): {
    waterY: number;
    bedY: number;
    bed: number;
    kx: number;
    kz: number;
    dry: boolean;
    extreme: boolean;
  } | null {
    const biome = this.biomeAt(x, z);
    if (biome === "marble" || biome === "caatinga") return null;
    if (x * x + z * z < 36) return null;
    const lake = this.lakeAt(x, z);
    if (lake) return this.dressBody(lake);
    const ditch = this.ditchAt(x, z);
    if (ditch) return this.dressBody(ditch);
    const pond = this.pondAt(x, z);
    return pond ? this.dressBody(pond) : null;
  }

  private dressBody(raw: { waterY: number; bedY: number; bed: number; kx: number; kz: number }): {
    waterY: number;
    bedY: number;
    bed: number;
    kx: number;
    kz: number;
    dry: boolean;
    extreme: boolean;
  } {
    const dry = rand2(raw.kx, raw.kz, this.seed + 440) < 0.5;
    const extreme = rand2(raw.kx, raw.kz, this.seed + 441) < 0.25;
    const bedY = extreme ? Math.max(2, raw.bedY - 10) : raw.bedY;
    const span = Math.max(0, raw.waterY - bedY);
    const waterY = dry ? bedY : extreme ? bedY + Math.max(1, Math.floor(span * 0.75)) : raw.waterY;
    return { ...raw, bedY, waterY, dry, extreme };
  }

  private lakeAt(x: number, z: number): { waterY: number; bedY: number; bed: number; kx: number; kz: number } | null {
    const cell = 40;
    const ccx = Math.floor(x / cell);
    const ccz = Math.floor(z / cell);
    for (let ox = -1; ox <= 1; ox++) {
      for (let oz = -1; oz <= 1; oz++) {
        const ix = ccx + ox;
        const iz = ccz + oz;
        if (rand2(ix, iz, this.seed + 51) < 0.72) continue;
        const lx = ix * cell + 8 + Math.floor(rand2(ix, iz, this.seed + 52) * (cell - 16));
        const lz = iz * cell + 8 + Math.floor(rand2(ix, iz, this.seed + 53) * (cell - 16));
        if (lx * lx + lz * lz < 14 * 14) continue;
        const rx = 5.2 + rand2(ix, iz, this.seed + 54) * 5.5;
        const rz = 4.4 + rand2(ix, iz, this.seed + 55) * 5.2;
        const irregular = true;
        let px = x;
        let pz = z;
        if (irregular) {
          px += (fbm(x * 0.11, z * 0.11, this.seed + 70, 3) - 0.5) * 7.2;
          pz += (fbm(x * 0.11 + 17, z * 0.11, this.seed + 71, 3) - 0.5) * 7.2;
        }
        const dx = (px - lx) / rx;
        const dz = (pz - lz) / rz;
        let d2 = dx * dx + dz * dz;
        if (irregular) {
          const shore = fbm(x * 0.31, z * 0.31, this.seed + 72, 3);
          d2 *= 0.7 + shore * 0.58;
          if (d2 > 0.52 && fbm(x * 0.42, z * 0.42, this.seed + 74, 2) > 0.7) continue;
        }
        if (d2 >= 1) continue;
        let depth = 2 + (rand2(ix, iz, this.seed + 56) > 0.5 ? 1 : 0);
        if (irregular) {
          const pocket = fbm(x * 0.16 + ix, z * 0.16 + iz, this.seed + 73, 4);
          const edge = Math.sqrt(Math.max(0, Math.min(1, d2)));
          depth = 1 + ((pocket * 3.2 + (1 - edge) * 1.35) | 0);
          if (rand2(x, z, this.seed + 99) > 0.88 && edge < 0.55) depth += 1;
          depth = Math.max(1, Math.min(5, depth));
        }
        const waterY = this.heightAt(lx, lz) - 1;
        const bedY = Math.max(1, waterY - depth);
        return { waterY, bedY, bed: SAND, kx: ix, kz: iz };
      }
    }
    return null;
  }

  private pondAt(x: number, z: number): { waterY: number; bedY: number; bed: number; kx: number; kz: number } | null {
    const cell = 18;
    const ccx = Math.floor(x / cell);
    const ccz = Math.floor(z / cell);
    for (let ox = -1; ox <= 1; ox++) {
      for (let oz = -1; oz <= 1; oz++) {
        const ix = ccx + ox;
        const iz = ccz + oz;
        if (rand2(ix, iz, this.seed + 61) < 0.9) continue;
        const lx = ix * cell + 3 + Math.floor(rand2(ix, iz, this.seed + 62) * (cell - 6));
        const lz = iz * cell + 3 + Math.floor(rand2(ix, iz, this.seed + 63) * (cell - 6));
        if (lx * lx + lz * lz < 10 * 10) continue;
        const r = 1.6 + rand2(ix, iz, this.seed + 64) * 1.4;
        const dx = x - lx;
        const dz = z - lz;
        if (dx * dx + dz * dz > r * r) continue;
        const notch = rand2(ix, iz, this.seed + 65) * Math.PI * 2;
        const ang = Math.atan2(dz, dx);
        const delta = Math.atan2(Math.sin(ang - notch), Math.cos(ang - notch));
        if (Math.abs(delta) < 0.5 && dx * dx + dz * dz > r * r * 0.35) continue;
        const waterY = this.heightAt(lx, lz) - 1;
        const bedY = Math.max(1, waterY - 1);
        return { waterY, bedY, bed: DIRT, kx: ix, kz: iz };
      }
    }
    return null;
  }

  private ditchAt(x: number, z: number): { waterY: number; bedY: number; bed: number; kx: number; kz: number } | null {
    const cell = 28;
    const ccx = Math.floor(x / cell);
    const ccz = Math.floor(z / cell);
    for (let ox = -1; ox <= 1; ox++) {
      for (let oz = -1; oz <= 1; oz++) {
        const ix = ccx + ox;
        const iz = ccz + oz;
        if (rand2(ix, iz, this.seed + 81) < 0.8) continue;
        const ax = ix * cell + 4 + Math.floor(rand2(ix, iz, this.seed + 82) * (cell - 8));
        const az = iz * cell + 4 + Math.floor(rand2(ix, iz, this.seed + 83) * (cell - 8));
        if (ax * ax + az * az < 12 * 12) continue;
        const ang = rand2(ix, iz, this.seed + 84) * Math.PI * 2;
        const len = 5 + rand2(ix, iz, this.seed + 85) * 6;
        const bx = ax + Math.cos(ang) * len;
        const bz = az + Math.sin(ang) * len;
        const abx = bx - ax;
        const abz = bz - az;
        const ab2 = abx * abx + abz * abz;
        if (ab2 < 1) continue;
        const t = Math.max(0, Math.min(1, ((x - ax) * abx + (z - az) * abz) / ab2));
        const qx = ax + t * abx;
        const qz = az + t * abz;
        const dist = Math.hypot(x - qx, z - qz);
        const bulge = (fbm(x * 0.45, z * 0.45, this.seed + 88, 2) - 0.5) * 1.1;
        if (dist > 1.15 + bulge) continue;
        const waterY = this.heightAt(Math.round(ax), Math.round(az)) - 1;
        const depth = rand2(ix, iz, this.seed + 86) > 0.55 ? 2 : 1;
        const bedY = Math.max(1, waterY - depth);
        return { waterY, bedY, bed: DIRT, kx: ix, kz: iz };
      }
    }
    return null;
  }

  getChunk(cx: number, cz: number): Chunk | undefined {
    return this.chunks.get(this.key(cx, cz));
  }

  ensureChunk(cx: number, cz: number): Chunk {
    const k = this.key(cx, cz);
    let c = this.chunks.get(k);
    if (c) return c;
    c = new Chunk(cx, cz);
    this.generate(c);
    this.applyEdits(c);
    this.chunks.set(k, c);
    this.stripLooseCarpets(c);
    this.syncSinkViews();
    this.meshQueue.push(c);
    this.markNeighborDirty(cx, cz);
    return c;
  }

  private generate(c: Chunk) {
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;
    const trees: { x: number; y: number; z: number; kind: "oak" | "birch" | "dark" }[] = [];
    for (let z = 0; z < CHUNK; z++) {
      for (let x = 0; x < CHUNK; x++) {
        const wx = ox + x;
        const wz = oz + z;
        const h = this.heightAt(wx, wz);
        const biome = this.biomeAt(wx, wz);
        const body = this.waterBodyAt(wx, wz);
        const beach = !body && biome === "forest" && h <= 20;
        const top = biome === "marble" ? MARBLE_GRASS : biome === "cerrado" ? CERRADO_GRASS : biome === "caatinga" ? CAATINGA_GRASS : biome === "brejo" ? BREJO_GRASS : GRASS;
        const soil = biome === "marble" ? MARBLE : biome === "cerrado" ? CERRADO_DIRT : biome === "caatinga" ? CAATINGA_DIRT : biome === "brejo" ? BREJO_DIRT : DIRT;
        const deep = biome === "marble" ? MARBLE_BRICK : STONE;
        for (let y = 0; y < HEIGHT; y++) {
          let id = AIR;
          if (y === 0) id = BEDROCK;
          else if (body) {
            if (y > body.waterY) id = AIR;
            else if (y > body.bedY) id = WATER;
            else if (y === body.bedY) id = body.bed;
            else if (y > body.bedY - 3) id = DIRT;
            else id = STONE;
          } else if (y > h) id = AIR;
          else if (y === h) id = beach ? SAND : top;
          else if (y > h - 4) id = beach ? SAND : soil;
          else id = deep;
          if (id === STONE && y > 6 && y < h - 6 && rand2(wx + y, wz, this.seed + 66) > 0.9975) {
            id = AQUIFER;
            this.aquiferCells.set(`${wx},${y},${wz}`, 160 + rand2(wx, y, this.seed + 67) * 180);
          }
          if (biome === "marble" && id === MARBLE_BRICK && y > 4 && y < h - 5 && rand2(wx + y, wz, this.seed + 168) > 0.993) id = MARBLE_BLUE;
          if (
            biome === "marble" &&
            id === MARBLE_BRICK &&
            y > 4 &&
            y < h - 4 &&
            rand2(Math.floor(wx / 5), Math.floor(wz / 5), this.seed + 177) > 0.84 &&
            rand2(wx + y * 3, wz, this.seed + 178) > 0.62
          ) {
            id = GREEN_BRICK;
          }
          if (
            biome === "marble" &&
            id === MARBLE_BRICK &&
            y > 4 &&
            y < h - 4 &&
            rand2(Math.floor(wx / 4), Math.floor(wz / 4), this.seed + 190) > 0.8 &&
            rand2(wx + y, wz, this.seed + 191) > 0.58
          ) {
            id = RUST_METAL;
          }
          c.blocks[idx(x, y, z)] = id;
          c.note(y, id);
        }
        if (body) {
          const py = body.bedY + 1;
          if (py <= body.waterY && c.get(x, py, z) === WATER) {
            const lives = rand2(body.kx, body.kz, this.seed + 310) >= 0.6;
            const patch = rand2(Math.floor(wx / 4), Math.floor(wz / 4), this.seed + 307);
            const local = rand2(wx, wz, this.seed + 301);
            if (lives && patch > 0.72 && local > 0.66 && rand2(wx, wz, this.seed + 312) >= 0.8) {
              c.set(x, py, z, RICCIA);
              this.ricciaCells.add(`${wx},${py},${wz}`);
            }
          }
        }
        if (!body && !beach && biome === "forest" && !this.inVillage(wx, wz) && x >= 3 && x <= 12 && z >= 3 && z <= 12 && rand2(wx, wz, this.seed + 77) > 0.974) {
          const roll = rand2(wx, wz, this.seed + 191);
          const dist2 = wx * wx + wz * wz;
          let kind: "oak" | "birch" | "dark" = "oak";
          if (roll < 0.2) kind = "dark";
          else if (dist2 >= 100 * 100 && rand2(wx, wz, this.seed + 211) < 0.22) kind = "birch";
          trees.push({ x, y: h + 1, z, kind });
        }
      }
    }
    for (const t of trees) {
      this.plantTree(c, t.x, t.y, t.z, t.kind);
      if (t.kind !== "birch") this.hangVines(c, t.x, t.z);
    }
    for (let z = 0; z < CHUNK; z++) {
      for (let x = 0; x < CHUNK; x++) {
        for (let y = 1; y < HEIGHT - 1; y++) {
          if (c.get(x, y, z) !== GRASS && c.get(x, y, z) !== MARBLE_GRASS && c.get(x, y, z) !== CERRADO_GRASS && c.get(x, y, z) !== CAATINGA_GRASS && c.get(x, y, z) !== BREJO_GRASS) continue;
          const up = c.get(x, y + 1, z);
          if (isSolid(up)) c.set(x, y, z, c.get(x, y, z) === MARBLE_GRASS ? MARBLE : c.get(x, y, z) === CERRADO_GRASS ? CERRADO_DIRT : c.get(x, y, z) === CAATINGA_GRASS ? CAATINGA_DIRT : c.get(x, y, z) === BREJO_GRASS ? BREJO_DIRT : DIRT);
          else if (up === AIR && canSupportCarpet(c.get(x, y, z)) && !isCarpet(c.get(x, y, z))) {
            const g = c.get(x, y, z);
            const carpet = g === MARBLE_GRASS ? MARBLE_CARPET : g === CERRADO_GRASS ? CERRADO_CARPET : g === CAATINGA_GRASS ? CAATINGA_CARPET : g === BREJO_GRASS ? BREJO_CARPET : GRASS_CARPET;
            if (g === GRASS || g === MARBLE_GRASS || g === CERRADO_GRASS || g === CAATINGA_GRASS || g === BREJO_GRASS) c.set(x, y + 1, z, carpet);
          }
        }
      }
    }
    this.dressBiome(c);
    this.carvePools(c);
    this.bakeFullGrass(c);
    this.stripLooseCarpets(c);
  }

  private stripLooseCarpets(c: Chunk) {
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;
    for (let z = 0; z < CHUNK; z++) {
      for (let x = 0; x < CHUNK; x++) {
        for (let y = 1; y < HEIGHT; y++) {
          if (!isCarpet(c.get(x, y, z))) continue;
          const below = c.get(x, y - 1, z);
          if (below !== AIR && !isCarpet(below)) continue;
          c.set(x, y, z, AIR);
          const key = `${ox + x},${y},${oz + z}`;
          if (this.edits.has(key)) this.edits.set(key, AIR);
        }
      }
    }
  }

  private poolAt(x: number, z: number): { wet: boolean; fate: number } | null {
    if (this.biomeAt(x, z) !== "marble") return null;
    const cell = 18;
    const gx = Math.floor(x / cell);
    const gz = Math.floor(z / cell);
    for (let ox = -1; ox <= 1; ox++) {
      for (let oz = -1; oz <= 1; oz++) {
        const ix = gx + ox;
        const iz = gz + oz;
        if (rand2(ix, iz, this.seed + 640) < 0.84) continue;
        const cx = ix * cell + 5 + Math.floor(rand2(ix, iz, this.seed + 641) * (cell - 10));
        const cz = iz * cell + 5 + Math.floor(rand2(ix, iz, this.seed + 642) * (cell - 10));
        const rx = 2.3 + rand2(ix, iz, this.seed + 643) * 2.1;
        const rz = 2 + rand2(ix, iz, this.seed + 644) * 2;
        const px = x + (fbm(x * 0.37, z * 0.37, this.seed + 645, 2) - 0.5) * 3.4;
        const pz = z + (fbm(x * 0.37 + 9, z * 0.37, this.seed + 646, 2) - 0.5) * 3.4;
        const dx = (px - cx) / rx;
        const dz = (pz - cz) / rz;
        const d2 = dx * dx + dz * dz;
        if (d2 >= 1) continue;
        const notch = rand2(ix, iz, this.seed + 647) * Math.PI * 2;
        const ang = Math.atan2(dz, dx);
        const delta = Math.atan2(Math.sin(ang - notch), Math.cos(ang - notch));
        if (Math.abs(delta) < 0.55 && d2 > 0.18) continue;
        return { wet: rand2(ix, iz, this.seed + 648) >= 0.75, fate: rand2(ix, iz, this.seed + 649) };
      }
    }
    return null;
  }

  private poolCell(x: number, z: number): boolean {
    return this.poolAt(x, z) !== null;
  }

  private poolInterior(x: number, z: number): boolean {
    return this.poolCell(x, z) && this.poolCell(x + 1, z) && this.poolCell(x - 1, z) && this.poolCell(x, z + 1) && this.poolCell(x, z - 1);
  }

  private poolLip(x: number, z: number): number {
    let lip = this.heightAt(x, z);
    lip = Math.min(lip, this.heightAt(x + 1, z), this.heightAt(x - 1, z), this.heightAt(x, z + 1), this.heightAt(x, z - 1));
    return lip;
  }

  private poolBed(x: number, z: number): number {
    const uneven = (rand2(x, z, this.seed + 650) * 3) | 0;
    return Math.max(2, this.poolLip(x, z) - 4 - uneven);
  }

  private dressBiome(c: Chunk) {
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;
    if (this.biomeAt(ox + 8, oz + 8) === "marble" && rand2(c.cx, c.cz, this.seed + 220) > 0.22) {
      const spots: [number, number][] = [
        [4, 4],
        [9, 6],
        [3, 10],
        [11, 3],
      ];
      for (const [sx, sz] of spots) {
        if (this.plantSink(c, sx, sz)) break;
      }
    }
    for (let z = 1; z < CHUNK - 1; z++) {
      for (let x = 1; x < CHUNK - 1; x++) {
        const wx = ox + x;
        const wz = oz + z;
        if (this.inVillage(wx, wz)) continue;
        const biome = this.biomeAt(wx, wz);
        const h = this.heightAt(wx, wz);
        if (biome === "marble" && this.poolCell(wx, wz)) continue;
        const above = c.get(x, h + 1, z);
        if (biome === "marble") {
          if (c.get(x, h, z) === SINK_PLAT || (h > 1 && c.get(x, h - 1, z) === SINK_PLAT)) continue;
          const roll = rand2(wx, wz, this.seed + 70);
          if (roll > 0.986 && this.columnRoom(wx, wz)) this.plantColumn(c, x, z, h + 1);
          else if (roll > 0.982) this.plantPeach(c, x, z, h + 1);
          else if (roll > 0.971) this.placeCover(c, x, h, z, rand2(wx, wz, this.seed + 81) < 0.5 ? GARDEN_LILY : GARDEN_IRIS);
          else if (roll > 0.93) this.placeCover(c, x, h, z, WEED_DROOP);
          if (rand2(wx, wz, this.seed + 90) > 0.9986 && this.columnRoom(wx, wz) && !this.poolCell(wx, wz)) this.plantMonument(c, x, z, h + 1, wx, wz);
          if (rand2(wx, wz, this.seed + 91) > 0.997) this.plantRuin(c, x, z, h + 1, wx, wz);
          if (this.isPeak(wx, wz) && rand2(wx, wz, this.seed + 77) > 0.82) this.dressPeak(c, x, z, h);
          else if (this.columnRoom(wx, wz) && rand2(wx, wz, this.seed + 89) > 0.994) {
            const at = c.get(x, h + 1, z);
            const over = h + 2 < HEIGHT ? c.get(x, h + 2, z) : AIR;
            if (!isGardenFlower(over) && !isWeed(over) && !isGardenFlower(at) && !isWeed(at)) this.placeVase(c, x, z, h);
          }
        } else if (biome === "brejo") {
          const ground = c.get(x, h, z);
          if (ground === BREJO_GRASS || ground === BREJO_GRASS_FULL) {
            const roll = rand2(wx, wz, this.seed + 160);
            if (roll > 0.58) this.coverPlant(c, x, h, z, roll > 0.84 ? WEED_TALL : WEED_REED);
          }
        } else if (biome === "caatinga") {
          const roll = rand2(wx, wz, this.seed + 120);
          if (roll > 0.988) this.plantCaatingaTree(c, x, z, h + 1);
          else if (roll > 0.975) this.plantCactus(c, x, z, h + 1);
          else if (roll > 0.96) c.set(x, h, z, CAATINGA_ROCK);
          else if (roll > 0.9) this.coverPlant(c, x, h, z, WEED_MACAMBIRA);
        } else if (biome === "cerrado" && rand2(wx, wz, this.seed + 130) > 0.93) {
          this.coverPlant(c, x, h, z, WEED_CERRADO);
        } else if (biome === "forest") {
          const ground = c.get(x, h, z);
          if (ground === SAND && rand2(wx, wz, this.seed + 142) > 0.62) {
            this.coverPlant(c, x, h, z, WEED_BEACH);
          } else if (ground === GRASS && rand2(wx, wz, this.seed + 140) > 0.74) {
            const slot = above === GRASS_CARPET ? h + 2 : h + 1;
            const occ = c.get(x, slot, z);
            if (slot < HEIGHT - 2 && (occ === AIR) && !isLeaves(occ) && !isLog(occ)) {
              const roll = rand2(wx, wz, this.seed + 141);
              const wet = !!this.waterBodyAt(wx + 2, wz) || !!this.waterBodyAt(wx, wz + 2);
              const id = wet && roll > 0.4 ? WEED_REED : roll > 0.78 ? WEED_TALL : WEED_SHORT;
              c.set(x, slot, z, id);
            }
          }
        }
      }
    }
  }

  private columnRoom(x: number, z: number): boolean {
    const h = this.heightAt(x, z);
    return Math.abs(this.heightAt(x + 1, z) - h) <= 1 && Math.abs(this.heightAt(x, z + 1) - h) <= 1;
  }

  private isPeak(x: number, z: number): boolean {
    const h = this.heightAt(x, z);
    return this.heightAt(x + 2, z) <= h - 2 && this.heightAt(x - 2, z) <= h - 2 && this.heightAt(x, z + 2) <= h - 2 && this.heightAt(x, z - 2) <= h - 2;
  }

  private carvePools(c: Chunk) {
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;
    for (let z = 0; z < CHUNK; z++) {
      for (let x = 0; x < CHUNK; x++) {
        const wx = ox + x;
        const wz = oz + z;
        if (this.poolAt(wx, wz)) this.carveMud(c, x, z, wx, wz);
      }
    }
  }

  private carveMud(c: Chunk, x: number, z: number, wx: number, wz: number) {
    const here = this.poolAt(wx, wz);
    if (!here) return;
    const h = this.heightAt(wx, wz);
    if (!this.poolInterior(wx, wz)) {
      const sides: [number, number][] = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ];
      for (const [dx, dz] of sides) {
        if (!this.poolInterior(wx + dx, wz + dz)) continue;
        const bed = this.poolBed(wx + dx, wz + dz);
        if (bed > 0 && bed < HEIGHT) c.set(x, bed, z, MARBLE_BRICK);
      }
      return;
    }
    const lip = this.poolLip(wx, wz);
    const bed = this.poolBed(wx, wz);
    const fluidTop = lip - 2;
    const firm = here.wet || here.fate < 0.25;
    if (h + 1 < HEIGHT) c.set(x, h + 1, z, AIR);
    if (h + 2 < HEIGHT && isPlant(c.get(x, h + 2, z))) c.set(x, h + 2, z, AIR);
    for (let y = bed; y <= h && y < HEIGHT; y++) {
      if (y === bed) c.set(x, y, z, firm ? MUD : MARBLE);
      else if (y <= fluidTop) {
        if (here.wet) c.set(x, y, z, MUD_FLUID);
        else if (here.fate < 0.25) c.set(x, y, z, MUD);
        else if (here.fate < 0.5) c.set(x, y, z, MARBLE_BROKEN);
        else c.set(x, y, z, AIR);
      } else c.set(x, y, z, AIR);
    }
    if (firm) {
      for (let y = bed - 1; y >= Math.max(1, bed - 4); y--) c.set(x, y, z, MUD);
    }
  }

  private plantSink(c: Chunk, x: number, z: number): boolean {
    const w = 3;
    const d = 2;
    if (x < 1 || z < 1 || x + w >= CHUNK - 1 || z + d >= CHUNK - 1) return false;
    let h = 999;
    for (let dz = 0; dz < d; dz++) {
      for (let dx = 0; dx < w; dx++) {
        const wx = x + dx + c.cx * CHUNK;
        const wz = z + dz + c.cz * CHUNK;
        if (this.poolCell(wx, wz) || this.biomeAt(wx, wz) !== "marble") return false;
        const top = this.heightAt(wx, wz);
        if (top < h) h = top;
      }
    }
    if (h < 8 || h >= HEIGHT - 2) return false;
    for (let dz = 0; dz < d; dz++) {
      for (let dx = 0; dx < w; dx++) {
        const top = this.heightAt(x + dx + c.cx * CHUNK, z + dz + c.cz * CHUNK);
        if (top - h > 1) return false;
        const skin = c.get(x + dx, top, z + dz);
        if (skin !== MARBLE_GRASS && skin !== MARBLE) return false;
      }
    }
    for (let dz = 0; dz < d; dz++) {
      for (let dx = 0; dx < w; dx++) {
        const wx = x + dx + c.cx * CHUNK;
        const wz = z + dz + c.cz * CHUNK;
        const top = this.heightAt(wx, wz);
        if (isCarpet(c.get(x + dx, top + 1, z + dz))) c.set(x + dx, top + 1, z + dz, AIR);
        if (top > h) c.set(x + dx, top, z + dz, AIR);
        c.set(x + dx, h - 1, z + dz, AIR);
        c.set(x + dx, h - 2, z + dz, AIR);
        c.set(x + dx, h - 3, z + dz, AIR);
        const floor = c.get(x + dx, h - 4, z + dz);
        if (floor === MARBLE || floor === MARBLE_BRICK || floor === MARBLE_BLUE || floor === GREEN_BRICK) c.set(x + dx, h - 4, z + dz, GREEN_BRICK);
        c.set(x + dx, h, z + dz, SINK_PLAT);
        this.sinkHome.set(`${wx},${wz}`, h);
      }
    }
    return true;
  }

  /** Slides a stood-on platform. Returns how far the player should ride with it. */
  stepSinks(dt: number, px: number, py: number, pz: number, onGround: boolean): number {
    let ride = 0;
    const groups = this.collectSinkGroups();
    const live = new Set<string>();
    this.sinkSolids = [];
    for (const g of groups) {
      live.add(g.lead);
      let view = this.sinkViews.get(g.lead);
      const sig = g.cells.map((c) => `${c.x},${c.z},${c.home}`).join("|");
      if (!view || view.sig !== sig) {
        if (view) this.disposeSink(view.group);
        view = { sig, drop: view?.drop ?? 0, group: this.makeSinkGroup(g.cells) };
        this.sinkViews.set(g.lead, view);
        this.group.add(view.group);
      }
      const top = g.home + 1 - view.drop;
      const stood =
        onGround &&
        py <= top + 0.2 &&
        py >= top - 0.45 &&
        g.cells.some((c) => Math.abs(px - (c.x + 0.5)) < 0.85 && Math.abs(pz - (c.z + 0.5)) < 0.85);
      const prev = view.drop;
      view.drop = Math.max(0, Math.min(3, view.drop + (stood ? dt * 0.85 : -dt * 0.5)));
      view.group.position.y = -view.drop;
      if (stood) ride += prev - view.drop;
      for (const c of g.cells) this.sinkSolids.push({ x: c.x, y: c.home - view.drop, z: c.z, home: c.home });
    }
    for (const [k, v] of this.sinkViews) {
      if (live.has(k)) continue;
      this.disposeSink(v.group);
      this.sinkViews.delete(k);
    }
    return ride;
  }

  private syncSinkViews() {
    this.stepSinks(0, 0, -999, 0, false);
  }

  private collectSinkGroups(): { lead: string; home: number; cells: { x: number; z: number; home: number }[] }[] {
    const seen = new Set<string>();
    const groups: { lead: string; home: number; cells: { x: number; z: number; home: number }[] }[] = [];
    for (const [key, home] of this.sinkHome) {
      if (seen.has(key)) continue;
      const comma = key.indexOf(",");
      const x0 = Number(key.slice(0, comma));
      const z0 = Number(key.slice(comma + 1));
      const cells: { x: number; z: number; home: number }[] = [];
      const stack: [number, number][] = [[x0, z0]];
      while (stack.length) {
        const [sx, sz] = stack.pop()!;
        const sk = `${sx},${sz}`;
        if (seen.has(sk)) continue;
        const sh = this.sinkHome.get(sk);
        if (sh === undefined || sh !== home) continue;
        if (this.getBlock(sx, sh, sz) !== SINK_PLAT) continue;
        seen.add(sk);
        cells.push({ x: sx, z: sz, home: sh });
        stack.push([sx + 1, sz], [sx - 1, sz], [sx, sz + 1], [sx, sz - 1]);
      }
      if (!cells.length) continue;
      let lead = `${cells[0]!.x},${cells[0]!.z}`;
      for (const c of cells) {
        const k = `${c.x},${c.z}`;
        if (k < lead) lead = k;
      }
      groups.push({ lead, home, cells });
    }
    return groups;
  }

  private makeSinkGroup(cells: { x: number; z: number; home: number }[]): THREE.Group {
    const body = emptyMeshData();
    const cap = emptyMeshData();
    for (const c of cells) {
      this.pushScaledBox(body, c.x, c.home, c.z, [0, 0, 0], [1, 0.9, 1], 48, [1, 1, 1]);
      this.pushScaledBox(cap, c.x, c.home, c.z, [0, 0.9, 0], [1, 1, 1], 28, [1, 1, 1]);
    }
    const group = new THREE.Group();
    if (body.indices.length) group.add(new THREE.Mesh(makeGeo(body), this.material));
    if (cap.indices.length) group.add(new THREE.Mesh(makeGeo(cap), this.material));
    return group;
  }

  private disposeSink(group: THREE.Group) {
    this.group.remove(group);
    for (const child of group.children) {
      (child as THREE.Mesh).geometry?.dispose();
    }
  }

  private sinkY(x: number, z: number, home: number): number {
    for (let y = home; y >= home - 4 && y > 1; y--) {
      if (this.getBlock(x, y, z) === SINK_PLAT) return y;
    }
    return -1;
  }

  private liveSet(x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= HEIGHT) return;
    const cx = Math.floor(x / CHUNK);
    const cz = Math.floor(z / CHUNK);
    const c = this.chunks.get(this.key(cx, cz));
    if (!c) return;
    const lx = ((x % CHUNK) + CHUNK) % CHUNK;
    const lz = ((z % CHUNK) + CHUNK) % CHUNK;
    c.set(lx, y, lz, id);
    this.meshQueue.push(c);
  }

  private plantColumn(c: Chunk, x: number, z: number, y0: number) {
    const wx = x + c.cx * CHUNK;
    const wz = z + c.cz * CHUNK;
    const purple = 1 + ((rand2(wx, wz, this.seed + 73) * 3) | 0);
    const bricks = purple + 1;
    const parts: number[] = [];
    for (let i = 0; i < purple; i++) parts.push(MARBLE_PURPLE);
    for (let i = 0; i < bricks; i++) parts.push(MARBLE_BRICK);
    parts.push(MARBLE_ORANGE);
    const fallen = rand2(wx, wz, this.seed + 71) < 0.38;
    if (!fallen) {
      if (this.columnBlocked(c, wx, wz, y0)) return;
      let y = y0;
      for (const id of parts) {
        if (y >= HEIGHT - 1) break;
        this.setBuilt(c, x, y, z, id);
        y++;
      }
      if (rand2(wx, wz, this.seed + 74) < 0.25) this.clingVine(c, x, z, y0, y - 1);
      this.maybeTwinColumn(c, x, z, y0, wx, wz, parts);
      return;
    }
    const fate = rand2(wx, wz, this.seed + 72);
    const alongZ = rand2(wx, wz, this.seed + 76) < 0.5;
    const sign = rand2(wx, wz, this.seed + 78) < 0.5 ? -1 : 1;
    const step = (i: number): [number, number] => (alongZ ? [0, i * sign] : [i * sign, 0]);
    const putFlat = (dx: number, dz: number, dy: number, id: number) => {
      const lx = x + dx;
      const lz = z + dz;
      const y = y0 + dy;
      if (lx < 1 || lz < 1 || lx >= CHUNK - 1 || lz >= CHUNK - 1 || y < 0 || y >= HEIGHT) return;
      const px = wx + dx;
      const pz = wz + dz;
      if (this.poolCell(px, pz)) return;
      if (Math.abs(this.heightAt(px, pz) - (y0 - 1)) > 1) return;
      this.setBuilt(c, lx, y, lz, id);
    };
    if (fate < 0.45) {
      parts.forEach((id, i) => putFlat(step(i)[0], step(i)[1], 0, id));
      return;
    }
    if (fate < 0.75) {
      this.setBuilt(c, x, y0, z, MARBLE_PURPLE);
      const rest = parts.slice(1);
      rest.forEach((id, i) => putFlat(step(i + 1)[0], step(i + 1)[1], 0, id));
      return;
    }
    const stand = Math.min(purple, 2);
    for (let i = 0; i < stand && y0 + i < HEIGHT; i++) this.setBuilt(c, x, y0 + i, z, MARBLE_PURPLE);
    const rest = parts.slice(stand);
    const side = alongZ ? ([1, 0] as const) : ([0, 1] as const);
    rest.forEach((id, i) => putFlat(side[0] * (i + 1) * sign, side[1] * (i + 1) * sign, i === rest.length - 1 && rand2(wx, wz, this.seed + 79) > 0.55 ? 1 : 0, id));
    this.maybeTwinColumn(c, x, z, y0, wx, wz, parts);
  }

  private maybeTwinColumn(c: Chunk, x: number, z: number, y0: number, wx: number, wz: number, parts: number[]) {
    if (rand2(wx, wz, this.seed + 80) >= 0.1) return;
    const dirs: [number, number][] = [
      [2, 0],
      [-2, 0],
      [0, 2],
      [0, -2],
    ];
    const start = (rand2(wx, wz, this.seed + 81) * 4) | 0;
    for (let i = 0; i < 4; i++) {
      const [dx, dz] = dirs[(start + i) % 4]!;
      const lx = x + dx;
      const lz = z + dz;
      if (lx < 1 || lz < 1 || lx >= CHUNK - 1 || lz >= CHUNK - 1) continue;
      const px = wx + dx;
      const pz = wz + dz;
      if (this.heightAt(px, pz) !== y0 - 1) continue;
      if (!this.columnRoom(px, pz) || this.poolCell(px, pz) || this.isPeak(px, pz)) continue;
      if (y0 - 1 < 0 || !isSolid(c.get(lx, y0 - 1, lz))) continue;
      const at = c.get(lx, y0, lz);
      if (isGardenFlower(at) || isWeed(at)) continue;
      let y = y0;
      for (const id of parts) {
        if (y >= HEIGHT - 1) break;
        this.setBuilt(c, lx, y, lz, id);
        y++;
      }
      return;
    }
  }

  private columnBlocked(c: Chunk, wx: number, wz: number, y0: number): boolean {
    if (this.poolCell(wx, wz)) return true;
    const roll = rand2(wx, wz, this.seed + 70);
    if (roll > 0.93 && roll <= 0.986) return true;
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (dx * dx + dz * dz > 5) continue;
        const px = wx + dx;
        const pz = wz + dz;
        if (this.isPeak(px, pz) && rand2(px, pz, this.seed + 77) > 0.82) return true;
      }
    }
    const lx = wx - c.cx * CHUNK;
    const lz = wz - c.cz * CHUNK;
    if (lx < 0 || lz < 0 || lx >= CHUNK || lz >= CHUNK) return false;
    for (let y = y0 - 1; y <= y0 + 2 && y < HEIGHT; y++) {
      if (y < 0) continue;
      const id = c.get(lx, y, lz);
      if (isGardenFlower(id) || isWeed(id)) return true;
    }
    return false;
  }

  private clingVine(c: Chunk, x: number, z: number, y0: number, top: number) {
    const side = x + 1 < CHUNK ? 1 : x > 0 ? -1 : 0;
    if (side === 0) return;
    const face = side > 0 ? 3 : 2;
    for (let y = y0; y < top && y < HEIGHT; y++) {
      const id = c.get(x + side, y, z);
      if (id !== AIR && id !== MARBLE_CARPET) continue;
      this.setBuilt(c, x + side, y, z, vineId(0, face));
    }
  }

  private plantPeach(c: Chunk, x: number, z: number, y0: number) {
    const wx = x + c.cx * CHUNK;
    const wz = z + c.cz * CHUNK;
    const trunk = 3 + ((rand2(wx, wz, this.seed + 3) * 2) | 0);
    if (y0 + trunk + 2 >= HEIGHT) return;
    for (let i = 0; i < trunk; i++) this.setBuilt(c, x, y0 + i, z, LOG);
    const top = y0 + trunk - 1;
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          if (dx === 0 && dz === 0 && dy <= 0) continue;
          const d2 = dx * dx + dz * dz + dy * dy;
          if (d2 > 6) continue;
          if (d2 > 3 && rand2(wx + dx, wz + dz, this.seed + 19 + dy) > 0.45) continue;
          const lx = x + dx;
          const ly = top + dy;
          const lz = z + dz;
          if (lx < 0 || lx >= CHUNK || lz < 0 || lz >= CHUNK || ly < 0 || ly >= HEIGHT) continue;
          if (c.get(lx, ly, lz) !== AIR) continue;
          this.setBuilt(c, lx, ly, lz, PEACH_LEAVES);
          if (ly > 1 && c.get(lx, ly - 1, lz) === AIR && rand2(wx + dx, wz + dz, this.seed + 44) > 0.55) this.setBuilt(c, lx, ly - 1, lz, PEACH);
        }
      }
    }
  }

  private monumentFeet(kind: number): [number, number][] {
    if (kind === 1) return [[0, 0], [3, 0]];
    if (kind === 2) return [[0, 0], [2, 0]];
    return [[0, 0]];
  }

  private footSupported(x: number, z: number, wx: number, wz: number, ground: number): boolean {
    if (x < 0 || z < 0 || x >= CHUNK || z >= CHUNK) return false;
    if (this.poolCell(wx, wz) || this.biomeAt(wx, wz) !== "marble") return false;
    return this.heightAt(wx, wz) === ground;
  }

  private plantMonument(c: Chunk, x: number, z: number, y0: number, wx: number, wz: number) {
    const ground = y0 - 1;
    const start = (rand2(wx, wz, this.seed + 95) * 5) | 0;
    let kind = -1;
    for (let k = 0; k < 5; k++) {
      const cand = (start + k) % 5;
      const ok = this.monumentFeet(cand).every(([dx, dz]) => this.footSupported(x + dx, z + dz, wx + dx, wz + dz, ground));
      if (ok) {
        kind = cand;
        break;
      }
    }
    if (kind < 0) return;
    const put = (dx: number, y: number, dz: number, id: number) => {
      const lx = x + dx;
      const lz = z + dz;
      if (lx < 0 || lx >= CHUNK || lz < 0 || lz >= CHUNK || y < 0 || y >= HEIGHT) return;
      this.setBuilt(c, lx, y, lz, id);
    };
    if (kind === 0) {
      put(0, y0, 0, MONUMENT_BASE);
      for (let i = 1; i <= 4; i++) put(0, y0 + i, 0, MONUMENT_SHAFT);
      put(0, y0 + 5, 0, MONUMENT_CROWN);
    } else if (kind === 1) {
      for (let i = 0; i <= 3; i++) {
        put(0, y0 + i, 0, i === 0 ? MONUMENT_BASE : MONUMENT_SHAFT);
        put(3, y0 + i, 0, i === 0 ? MONUMENT_BASE : MONUMENT_SHAFT);
      }
      for (let dx = 0; dx <= 3; dx++) put(dx, y0 + 4, 0, MONUMENT_CROWN);
    } else if (kind === 2) {
      put(0, y0, 0, MONUMENT_BASE);
      put(0, y0 + 1, 0, MONUMENT_SHAFT);
      put(0, y0 + 2, 0, MONUMENT_CROWN);
      put(2, y0, 0, MONUMENT_BASE);
      for (let i = 1; i <= 3; i++) put(2, y0 + i, 0, MONUMENT_SHAFT);
      put(2, y0 + 4, 0, MONUMENT_CROWN);
    } else if (kind === 3) {
      put(0, y0, 0, MONUMENT_BASE);
      for (let i = 1; i <= 5; i++) put(0, y0 + i, 0, MONUMENT_SHAFT);
      put(0, y0 + 6, 0, MONUMENT_CROWN);
    } else {
      for (let i = 0; i <= 4; i++) put(0, y0 + i, 0, i === 0 ? MONUMENT_BASE : i === 4 ? MONUMENT_CROWN : MONUMENT_SHAFT);
      put(-1, y0 + 3, 0, MONUMENT_SHAFT);
      put(1, y0 + 3, 0, MONUMENT_SHAFT);
      put(0, y0 + 3, -1, MONUMENT_SHAFT);
      put(0, y0 + 3, 1, MONUMENT_SHAFT);
    }
  }

  private dressPeak(c: Chunk, x: number, z: number, h: number) {
    this.placeVase(c, x, z, h);
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (dx === 0 && dz === 0 || dx * dx + dz * dz > 5) continue;
        this.placeCover(c, x + dx, h, z + dz, (dx + dz) % 2 === 0 ? GARDEN_LILY : GARDEN_IRIS);
      }
    }
  }

  private placeVase(c: Chunk, x: number, z: number, groundY: number) {
    if (x < 0 || z < 0 || x >= CHUNK || z >= CHUNK) return;
    const y = groundY + 1;
    if (y <= 0 || y >= HEIGHT) return;
    const below = c.get(x, groundY, z);
    if (below === AIR || !isSolid(below)) return;
    const at = c.get(x, y, z);
    if (isCarpet(at)) c.set(x, y, z, MARBLE_VASE);
    else if (at === AIR) c.set(x, y, z, MARBLE_VASE);
  }

  private placeCover(c: Chunk, x: number, h: number, z: number, id: number) {
    if (x < 0 || z < 0 || x >= CHUNK || z >= CHUNK || h + 1 >= HEIGHT) return;
    const ground = c.get(x, h, z);
    if (!isSolid(ground) || isLeaves(ground)) return;
    const at = c.get(x, h + 1, z);
    if (isCarpet(at)) {
      if (h + 2 < HEIGHT && c.get(x, h + 2, z) === AIR) c.set(x, h + 2, z, id);
      return;
    }
    if (at === AIR) c.set(x, h + 1, z, id);
  }

  private coverPlant(c: Chunk, x: number, h: number, z: number, id: number) {
    if (x < 0 || z < 0 || x >= CHUNK || z >= CHUNK || h + 1 >= HEIGHT) return;
    const at = c.get(x, h + 1, z);
    if (isCarpet(at)) {
      if (h + 2 < HEIGHT && c.get(x, h + 2, z) === AIR) c.set(x, h + 2, z, id);
      return;
    }
    if (at === AIR) c.set(x, h + 1, z, id);
  }

  private onPlant(c: Chunk, x: number, y: number, z: number): boolean {
    if (x < 0 || z < 0 || x >= CHUNK || z >= CHUNK || y < 0 || y >= HEIGHT) return true;
    const here = c.get(x, y, z);
    if (isGardenFlower(here) || isWeed(here)) return true;
    if (y > 0) {
      const under = c.get(x, y - 1, z);
      if (isGardenFlower(under) || isWeed(under)) return true;
    }
    return false;
  }

  private setBuilt(c: Chunk, x: number, y: number, z: number, id: number) {
    if (this.onPlant(c, x, y, z)) return;
    c.set(x, y, z, id);
  }

  private plantRuin(c: Chunk, x: number, z: number, y0: number, wx: number, wz: number) {
    if (this.poolCell(wx, wz)) return;
    const len = 4 + ((rand2(wx, wz, this.seed + 93) * 3) | 0);
    const gap = 1 + ((rand2(wx, wz, this.seed + 94) * (len - 2)) | 0);
    for (let i = 0; i < len; i++) {
      if (i === gap) continue;
      for (let dy = 0; dy < 2; dy++) {
        const lx = x + i;
        const y = y0 + dy;
        if (lx < 0 || lx >= CHUNK || y >= HEIGHT) continue;
        if (this.onPlant(c, lx, y, z)) continue;
        const id = c.get(lx, y, z);
        if (id === AIR || id === MARBLE_CARPET) c.set(lx, y, z, MARBLE_BRICK);
      }
    }
  }

  private plantCaatingaTree(c: Chunk, x: number, z: number, y0: number) {
    const trunk = 4;
    if (y0 + trunk + 2 >= HEIGHT) return;
    for (let i = 0; i < trunk; i++) c.set(x, y0 + i, z, CAATINGA_LOG);
    const top = y0 + trunk - 1;
    for (let dy = -1; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          if (dx * dx + dz * dz + dy * dy > 5) continue;
          const lx = x + dx;
          const ly = top + dy;
          const lz = z + dz;
          if (lx < 0 || lx >= CHUNK || lz < 0 || lz >= CHUNK || ly >= HEIGHT) continue;
          if (c.get(lx, ly, lz) === AIR) c.set(lx, ly, lz, CAATINGA_LEAVES);
        }
      }
    }
  }

  private plantCactus(c: Chunk, x: number, z: number, y0: number) {
    const n = 3 + ((rand2(x + c.cx * CHUNK, z + c.cz * CHUNK, this.seed + 12) * 2) | 0);
    for (let i = 0; i < n && y0 + i < HEIGHT; i++) c.set(x, y0 + i, z, CAATINGA_CACTUS);
    if (y0 + 2 < HEIGHT && x + 1 < CHUNK) c.set(x + 1, y0 + 2, z, CAATINGA_CACTUS);
  }

  private inVillage(x: number, z: number): boolean {
    return x > 16 && x < 56 && z > -40 && z < 4;
  }

  private hangVines(c: Chunk, x: number, z: number) {
    const wx = x + c.cx * CHUNK;
    const wz = z + c.cz * CHUNK;
    if (rand2(wx, wz, this.seed + 8) > 0.1) return;
    for (let dy = 0; dy < 8; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          const lx = x + dx;
          const lz = z + dz;
          const ly = this.heightAt(wx, wz) + dy;
          if (lx < 1 || lx >= CHUNK - 1 || lz < 1 || lz >= CHUNK - 1 || ly < 2 || ly >= HEIGHT) continue;
          if (!isLeaves(c.get(lx, ly, lz))) continue;
          if (c.get(lx, ly - 1, lz) !== AIR) continue;
          c.set(lx, ly - 1, lz, vineId(0, (dx + dz + 4) & 3));
        }
      }
    }
  }

  private plantTree(c: Chunk, x: number, y: number, z: number, kind: "oak" | "birch" | "dark") {
    const log = kind === "birch" ? BIRCH_LOG : kind === "dark" ? DARK_LOG : LOG;
    const leaf = kind === "birch" ? BIRCH_LEAVES : kind === "dark" ? DARK_LEAVES : LEAVES;
    const wx = x + c.cx * CHUNK;
    const wz = z + c.cz * CHUNK;
    const tall = kind === "birch";
    let trunk = tall
      ? 6 + ((rand2(wx, wz, this.seed + 3) * 3) | 0)
      : 5 + ((rand2(wx, wz, this.seed + 3) * 3) | 0);
    trunk = Math.min(trunk, HEIGHT - y - 3);
    if (trunk < 4) return;
    for (let i = 0; i < trunk; i++) {
      if (y + i < HEIGHT) c.set(x, y + i, z, log);
    }
    const top = y + trunk - 1;
    const cr = tall ? 2.15 : 2.45;
    const cry = tall ? 2.4 : 2.45;
    for (let dy = -3; dy <= 3; dy++) {
      for (let dx = -3; dx <= 3; dx++) {
        for (let dz = -3; dz <= 3; dz++) {
          if (dx === 0 && dz === 0 && dy <= 0) continue;
          const nx = dx / cr;
          const ny = (dy - 0.15) / cry;
          const nz = dz / cr;
          const d2 = nx * nx + ny * ny + nz * nz;
          if (d2 > 1.06) continue;
          if (d2 > 0.84) {
            const rim = rand2(wx + Math.abs(dx), wz + Math.abs(dz), this.seed + 19 + dy);
            if (rim > 0.8) continue;
          }
          const lx = x + dx;
          const ly = top + dy;
          const lz = z + dz;
          if (ly < 0 || ly >= HEIGHT) continue;
          if (c.get(lx, ly, lz) === AIR) c.set(lx, ly, lz, leaf);
        }
      }
    }
  }

  private applyEdits(c: Chunk) {
    for (const [k, id] of this.edits) {
      const [xs, ys, zs] = k.split(",");
      const x = Number(xs);
      const y = Number(ys);
      const z = Number(zs);
      if (Math.floor(x / CHUNK) === c.cx && Math.floor(z / CHUNK) === c.cz) {
        const lx = ((x % CHUNK) + CHUNK) % CHUNK;
        const lz = ((z % CHUNK) + CHUNK) % CHUNK;
        if (y >= 0 && y < HEIGHT) {
          c.blocks[idx(lx, y, lz)] = id;
          c.note(y, id);
          if (id === SINK_PLAT) this.sinkHome.set(`${x},${z}`, y);
          if (isPlant(id)) this.cropQueue.add(`${x},${y},${z}`);
          if (id === RICCIA) this.ricciaCells.add(`${x},${y},${z}`);
        }
      }
    }
    c.dirty = true;
  }

  getBlock(x: number, y: number, z: number): number {
    if (y < 0 || y >= HEIGHT) return y < 0 ? BEDROCK : AIR;
    const cx = Math.floor(x / CHUNK);
    const cz = Math.floor(z / CHUNK);
    const c = this.chunks.get(this.key(cx, cz));
    if (!c) return AIR;
    const lx = ((x % CHUNK) + CHUNK) % CHUNK;
    const lz = ((z % CHUNK) + CHUNK) % CHUNK;
    return c.get(lx, y, lz);
  }

  setBlock(x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= HEIGHT) return;
    const cx = Math.floor(x / CHUNK);
    const cz = Math.floor(z / CHUNK);
    const c = this.ensureChunk(cx, cz);
    const lx = ((x % CHUNK) + CHUNK) % CHUNK;
    const lz = ((z % CHUNK) + CHUNK) % CHUNK;
    if (isCarpet(id)) {
      const under = y > 0 ? c.get(lx, y - 1, lz) : AIR;
      if (under === AIR || isCarpet(under)) return;
    }
    if (this.sitsOnCarpet(id) && isCarpet(this.getBlock(x, y, z))) {
      if (y + 1 < HEIGHT && this.getBlock(x, y + 1, z) === AIR) this.setBlock(x, y + 1, z, id);
      return;
    }
    this.edits.set(`${x},${y},${z}`, id);
    const prev = c.get(lx, y, lz);
    c.blocks[idx(lx, y, lz)] = id;
    c.note(y, id);
    if (id === SINK_PLAT) this.sinkHome.set(`${x},${z}`, y);
    else if (prev === SINK_PLAT) this.sinkHome.delete(`${x},${z}`);
    if (id === SINK_PLAT || prev === SINK_PLAT) this.syncSinkViews();
    if (prev === RICCIA && id !== RICCIA) this.ricciaCells.delete(`${x},${y},${z}`);
    if (id === RICCIA) this.ricciaCells.add(`${x},${y},${z}`);
    c.dirty = true;
    this.meshQueue.push(c);
    if (lx === 0 || lx === CHUNK - 1 || lz === 0 || lz === CHUNK - 1) {
      this.markNeighborDirty(cx, cz);
    }
    if (isSolid(id) && y > 0) {
      const below = c.get(lx, y - 1, lz);
      if (below === GRASS) {
        c.blocks[idx(lx, y - 1, lz)] = DIRT;
        this.edits.set(`${x},${y - 1},${z}`, DIRT);
      }
    }
    this.scheduleFluid(x, y, z);
    this.scheduleFluid(x + 1, y, z);
    this.scheduleFluid(x - 1, y, z);
    this.scheduleFluid(x, y + 1, z);
    this.scheduleFluid(x, y - 1, z);
    this.scheduleFluid(x, y, z + 1);
    this.scheduleFluid(x, y, z - 1);
    this.scheduleCrop(x, y, z);
    this.scheduleCrop(x + 1, y, z);
    this.scheduleCrop(x - 1, y, z);
    this.scheduleCrop(x, y + 1, z);
    this.scheduleCrop(x, y - 1, z);
    this.scheduleCrop(x, y, z + 1);
    this.scheduleCrop(x, y, z - 1);
    this.scheduleGrassGrow(x, y, z);
    this.scheduleGrassGrow(x, y + 1, z);
    this.schedulePromote(x, y, z);
    this.schedulePromote(x + 1, y, z);
    this.schedulePromote(x - 1, y, z);
    this.schedulePromote(x, y, z + 1);
    this.schedulePromote(x, y, z - 1);
    this.schedulePromote(x, y + 1, z);
    this.schedulePromote(x, y - 1, z);
    if ((prev === GRASS || prev === DIRT || prev === GRASS_FULL) && id === AIR) this.clearWeedColumn(x, y, z);
    if (!canSupportCarpet(id) && y + 1 < HEIGHT && isCarpet(this.getBlock(x, y + 1, z))) {
      this.setBlock(x, y + 1, z, AIR);
    }
  }

  private sitsOnCarpet(id: number): boolean {
    return isWeed(id) || isGardenFlower(id) || isCrop(id) || isStem(id);
  }

  private clearWeedColumn(x: number, y: number, z: number) {
    const up = this.getBlock(x, y + 1, z);
    if (isWeed(up)) {
      this.setBlock(x, y + 1, z, AIR);
      return;
    }
    if (isCarpet(up) && isWeed(this.getBlock(x, y + 2, z))) this.setBlock(x, y + 2, z, AIR);
  }

  private markNeighborDirty(cx: number, cz: number) {
    const touch = (ncx: number, ncz: number) => {
      const ch = this.getChunk(ncx, ncz);
      if (!ch) return;
      ch.dirty = true;
      this.meshQueue.push(ch);
    };
    touch(cx - 1, cz);
    touch(cx + 1, cz);
    touch(cx, cz - 1);
    touch(cx, cz + 1);
  }

  stream(px: number, pz: number, _view = VIEW) {
    const pcx = Math.floor(px / CHUNK);
    const pcz = Math.floor(pz / CHUNK);
    for (let dz = -VIEW; dz <= VIEW; dz++) {
      for (let dx = -VIEW; dx <= VIEW; dx++) {
        if (dx * dx + dz * dz <= VIEW * VIEW + 1) this.ensureChunk(pcx + dx, pcz + dz);
      }
    }
    const drop = VIEW + 2;
    for (const [k, c] of this.chunks) {
      if (Math.abs(c.cx - pcx) > drop || Math.abs(c.cz - pcz) > drop) {
        if (c.group) {
          this.group.remove(c.group);
          for (const child of c.group.children) {
            const mesh = child as THREE.Mesh;
            mesh.geometry.dispose();
          }
          c.group = null;
        }
        this.chunks.delete(k);
      }
    }
  }

  processMeshes(budget = 3) {
    if (this.meshQueue.length === 0) {
      for (const c of this.chunks.values()) {
        if (c.dirty) this.meshQueue.push(c);
      }
    }
    let n = 0;
    while (n < budget && this.meshQueue.length) {
      const c = this.meshQueue.shift()!;
      if (!this.chunks.has(this.key(c.cx, c.cz))) continue;
      if (!c.dirty && c.group) continue;
      this.buildMesh(c);
      n++;
    }
  }

  private buildMesh(c: Chunk) {
    const opaque = emptyMeshData();
    const cutout = emptyMeshData();
    const plants = emptyMeshData();
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;

    const yMax = c.top;
    for (let y = 0; y <= yMax; y++) {
      for (let z = 0; z < CHUNK; z++) {
        for (let x = 0; x < CHUNK; x++) {
          const id = c.get(x, y, z);
          if (id === AIR) continue;
          if (id === SINK_PLAT) continue;
          if (y > 0 && y < yMax && x > 0 && x < CHUNK - 1 && z > 0 && z < CHUNK - 1 && isOpaque(id)) {
            const i = idx(x, y, z);
            const up = CHUNK * CHUNK;
            const b = c.blocks;
            if (
              isOpaque(b[i + up]!) &&
              isOpaque(b[i - up]!) &&
              isOpaque(b[i + 1]!) &&
              isOpaque(b[i - 1]!) &&
              isOpaque(b[i + CHUNK]!) &&
              isOpaque(b[i - CHUNK]!)
            ) {
              continue;
            }
          }
          if (isRiccia(id)) {
            this.pushRiccia(plants, ox + x, y, oz + z);
            continue;
          }
          if (isVine(id)) {
            this.pushVine(plants, ox + x, y, oz + z, id);
            continue;
          }
          if (isGardenFlower(id)) {
            const below = y > 0 ? c.get(x, y - 1, z) : AIR;
            const y0 = isFloorCarpet(below) ? y - 1 + CARPET_H : y;
            this.pushCross(plants, ox + x, y0, oz + z, stemUv(gardenTile(id)), 0.32, [1, 1, 1]);
            continue;
          }
          if (isWeed(id)) {
            const droop = id === WEED_DROOP;
            const below = y > 0 ? c.get(x, y - 1, z) : AIR;
            const y0 = isFloorCarpet(below) ? y - 1 + CARPET_H : y;
            this.pushCross(plants, ox + x, y0, oz + z, stemUv(weedTile(id)), droop ? 1 : weedModelHeight(id), [1, 1, 1], droop ? 0.02 : 0.15);
            continue;
          }
          if (isCrop(id)) {
            this.pushCross(plants, ox + x, y, oz + z, stemUv(cropTile(id)), 0.85, [1, 1, 1]);
            continue;
          }
          if (isPeach(id)) {
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.36, 0.55, 0.36], [0.64, 0.92, 0.64], 46, [1, 1, 1]);
            continue;
          }
          if (isVase(id)) {
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.32, 0, 0.32], [0.68, 0.08, 0.68], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.22, 0.08, 0.22], [0.78, 0.62, 0.78], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.26, 0.62, 0.26], [0.74, 0.78, 0.74], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.34, 0.74, 0.34], [0.66, 0.8, 0.66], 35, [0.42, 0.4, 0.48]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.16, 0.78, 0.16], [0.84, 1.02, 0.28], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.16, 0.78, 0.72], [0.84, 1.02, 0.84], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.16, 0.78, 0.28], [0.28, 1.02, 0.72], 35, [1, 1, 1]);
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.72, 0.78, 0.28], [0.84, 1.02, 0.72], 35, [1, 1, 1]);
            this.pushVaseBush(plants, ox + x, y, oz + z);
            continue;
          }
          if (isDoor(id) || isGate(id)) {
            this.pushDoor(opaque, ox + x, y, oz + z, id);
            continue;
          }
          if (isCandle(id)) {
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.45, 0, 0.45], [0.55, 0.38, 0.55], 2, id === CANDLE_LIT ? [1, 0.82, 0.45] : [0.55, 0.5, 0.42]);
            continue;
          }
          if (id === COMODA) {
            this.pushScaledBox(opaque, ox + x, y, oz + z, [0.12, 0, 0.16], [0.88, 0.7, 0.84], 7, [0.72, 0.48, 0.28]);
            continue;
          }
          if (isPlant(id)) {
            this.pushStem(plants, ox + x, y, oz + z, id);
            continue;
          }
          if (isCarpet(id)) {
            this.pushCarpet(opaque, ox + x, y, oz + z, id);
            continue;
          }
          if (!isSolid(id)) continue;
          const dest = isLeaves(id) ? cutout : opaque;
          for (let f = 0; f < 6; f++) {
            const face = FACES[f]!;
            const nx = x + face.dir[0];
            const ny = y + face.dir[1];
            const nz = z + face.dir[2];
            let nid: number;
            if (ny < 0 || ny >= HEIGHT) nid = ny < 0 ? BEDROCK : AIR;
            else if (nx < 0 || nx >= CHUNK || nz < 0 || nz >= CHUNK) {
              nid = this.getBlock(ox + nx, ny, oz + nz);
            } else nid = c.get(nx, ny, nz);
            if (isOpaque(nid) || (f === 0 && isCarpet(nid))) continue;
            const uv = isLeaves(id) ? leafUv(leafAtlasTile(id)) : tileUv(faceTile(id, f));
            const cr = face.corners;
            const i0 = dest.positions.length / 3;
            const uvPairs: [number, number][] = [
              [uv.u0, uv.v0],
              [uv.u1, uv.v0],
              [uv.u1, uv.v1],
              [uv.u0, uv.v1],
            ];
            const faceShade = FACE_SHADE[f]!;
            for (let i = 0; i < 4; i++) {
              const p = cr[i]!;
              dest.positions.push(ox + x + p[0], y + p[1], oz + z + p[2]);
              dest.normals.push(face.dir[0], face.dir[1], face.dir[2]);
              dest.uvs.push(uvPairs[i]![0], uvPairs[i]![1]);
              const ao = this.cornerAO(ox + x, y, oz + z, face.dir, p);
              const s = faceShade * ao;
              dest.colors.push(s, s, s);
            }
            dest.indices.push(i0, i0 + 2, i0 + 1, i0, i0 + 3, i0 + 2);
          }
        }
      }
    }

    if (!c.group) {
      c.group = new THREE.Group();
      this.group.add(c.group);
    }
    while (c.group.children.length) {
      const child = c.group.children[0] as THREE.Mesh;
      c.group.remove(child);
      child.geometry.dispose();
    }
    if (opaque.indices.length) {
      c.group.add(new THREE.Mesh(makeGeo(opaque), this.material));
    }
    if (cutout.indices.length) {
      c.group.add(new THREE.Mesh(makeGeo(cutout), this.cutout));
    }
    if (plants.indices.length) {
      c.group.add(new THREE.Mesh(makeGeo(plants), this.plant));
    }
    const water = this.buildFluidMesh(c, ox, oz, "water");
    if (water) {
      water.renderOrder = 2;
      c.group.add(water);
    }
    const acid = this.buildFluidMesh(c, ox, oz, "acid");
    if (acid) {
      acid.renderOrder = 2;
      c.group.add(acid);
    }
    const mud = this.buildFluidMesh(c, ox, oz, "mud");
    if (mud) {
      mud.renderOrder = 2;
      c.group.add(mud);
    }
    c.dirty = false;
  }

  private pushScaledBox(
    dest: MeshData,
    x: number,
    y: number,
    z: number,
    a: [number, number, number],
    b: [number, number, number],
    tile: number,
    tint: [number, number, number],
  ) {
    const uv = tileUv(tile);
    for (let f = 0; f < 6; f++) {
      const face = FACES[f]!;
      const i0 = dest.positions.length / 3;
      const uvPairs: [number, number][] = [
        [uv.u0, uv.v0],
        [uv.u1, uv.v0],
        [uv.u1, uv.v1],
        [uv.u0, uv.v1],
      ];
      const shade = FACE_SHADE[f]!;
      for (let i = 0; i < 4; i++) {
        const p = face.corners[i]!;
        dest.positions.push(x + a[0] + p[0] * (b[0] - a[0]), y + a[1] + p[1] * (b[1] - a[1]), z + a[2] + p[2] * (b[2] - a[2]));
        dest.normals.push(face.dir[0], face.dir[1], face.dir[2]);
        dest.uvs.push(uvPairs[i]![0], uvPairs[i]![1]);
        dest.colors.push(tint[0] * shade, tint[1] * shade, tint[2] * shade);
      }
      dest.indices.push(i0, i0 + 2, i0 + 1, i0, i0 + 3, i0 + 2);
    }
  }

  private pushVaseBush(dest: MeshData, x: number, y: number, z: number) {
    const stem = stemUv(weedTile(WEED_SHORT));
    const leaf = leafUv(0);
    const lily = stemUv(gardenTile(GARDEN_LILY));
    const iris = stemUv(gardenTile(GARDEN_IRIS));
    this.pushCross(dest, x, y + 0.8, z, stem, 0.36, [0.4, 0.58, 0.24], 0.4);
    this.pushCross(dest, x, y + 0.98, z, leaf, 0.64, [0.2, 0.52, 0.16], 0.16);
    this.pushCross(dest, x, y + 1.08, z, leaf, 0.5, [0.36, 0.68, 0.22], 0.26);
    this.pushCross(dest, x, y + 1.2, z, stem, 0.38, [0.28, 0.55, 0.18], 0.32);
    this.pushCross(dest, x, y + 1.3, z, lily, 0.34, [1, 1, 1], 0.34);
    this.pushCross(dest, x, y + 1.36, z, iris, 0.28, [1, 1, 1], 0.4);
  }

  private pushDoor(dest: MeshData, x: number, y: number, z: number, id: number) {
    const gate = isGate(id);
    const open = id === GATE_OPEN || (id >= DOOR_OPEN && id < DOOR_OPEN + 4);
    const facing = gate ? 0 : (id - (id >= DOOR_OPEN ? DOOR_OPEN : DOOR)) & 3;
    const face = open ? (facing + 1) & 3 : facing;
    const a: [number, number, number] = [0.08, 0, 0.08];
    const b: [number, number, number] = [0.92, gate ? 0.85 : 1, 0.92];
    if (face === 0) {
      a[2] = 0;
      b[2] = 0.16;
    } else if (face === 1) {
      a[2] = 0.84;
      b[2] = 1;
    } else if (face === 2) {
      a[0] = 0;
      b[0] = 0.16;
    } else {
      a[0] = 0.84;
      b[0] = 1;
    }
    this.pushScaledBox(dest, x, y, z, a, b, 7, [0.62, 0.42, 0.24]);
  }

  private pushCross(
    dest: MeshData,
    x: number,
    y: number,
    z: number,
    uv: { u0: number; v0: number; u1: number; v1: number },
    h: number,
    tint: [number, number, number],
    inset = 0.15,
  ) {
    const a = inset;
    const b = 1 - inset;
    this.pushQuad(
      dest,
      [
        [x + a, y, z + a],
        [x + b, y, z + b],
        [x + b, y + h, z + b],
        [x + a, y + h, z + a],
      ],
      uv,
      tint,
    );
    this.pushQuad(
      dest,
      [
        [x + b, y, z + a],
        [x + a, y, z + b],
        [x + a, y + h, z + b],
        [x + b, y + h, z + a],
      ],
      uv,
      tint,
    );
  }

  private pushVine(dest: MeshData, x: number, y: number, z: number, id: number) {
    const face = vineFace(id);
    const t = 1.5 / 16;
    const q: [number, number, number][] =
      face === 0
        ? [
            [x, y, z + 1 - t],
            [x + 1, y, z + 1 - t],
            [x + 1, y + 1, z + 1 - t],
            [x, y + 1, z + 1 - t],
          ]
        : face === 1
          ? [
              [x + 1, y, z + t],
              [x, y, z + t],
              [x, y + 1, z + t],
              [x + 1, y + 1, z + t],
            ]
          : face === 2
            ? [
                [x + 1 - t, y, z + 1],
                [x + 1 - t, y, z],
                [x + 1 - t, y + 1, z],
                [x + 1 - t, y + 1, z + 1],
              ]
            : [
                [x + t, y, z],
                [x + t, y, z + 1],
                [x + t, y + 1, z + 1],
                [x + t, y + 1, z],
              ];
    this.pushQuad(dest, q, stemUv(16 + vineFace(id)), [1, 1, 1]);
  }

  private pushFlower(dest: MeshData, x: number, y: number, z: number) {
    const uv = leafUv(0);
    this.pushQuad(
      dest,
      [
        [x + 0.2, y, z + 0.2],
        [x + 0.8, y, z + 0.8],
        [x + 0.8, y + 0.6, z + 0.8],
        [x + 0.2, y + 0.6, z + 0.2],
      ],
      uv,
      [0.95, 0.9, 0.7],
    );
    this.pushQuad(
      dest,
      [
        [x + 0.8, y, z + 0.2],
        [x + 0.2, y, z + 0.8],
        [x + 0.2, y + 0.6, z + 0.8],
        [x + 0.8, y + 0.6, z + 0.2],
      ],
      uv,
      [0.85, 0.7, 0.95],
    );
  }

  private pushQuad(dest: MeshData, q: [number, number, number][], uv: { u0: number; v0: number; u1: number; v1: number }, tint: [number, number, number]) {
    const ax = q[1]![0] - q[0]![0];
    const ay = q[1]![1] - q[0]![1];
    const az = q[1]![2] - q[0]![2];
    const bx = q[2]![0] - q[0]![0];
    const by = q[2]![1] - q[0]![1];
    const bz = q[2]![2] - q[0]![2];
    let nx = ay * bz - az * by;
    let ny = az * bx - ax * bz;
    let nz = ax * by - ay * bx;
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len;
    ny /= len;
    nz /= len;
    const lift = (sx: number, sy: number, sz: number): [number, number, number] => {
      const x = sx * 0.55;
      const y = sy * 0.55 + 0.85;
      const z = sz * 0.55;
      const l = Math.hypot(x, y, z) || 1;
      return [x / l, y / l, z / l];
    };
    this.pushQuadFace(dest, q, lift(nx, ny, nz), uv, tint, false);
    this.pushQuadFace(dest, q, lift(-nx, -ny, -nz), uv, tint, true);
  }

  private pushQuadFace(
    dest: MeshData,
    q: [number, number, number][],
    n: [number, number, number],
    uv: { u0: number; v0: number; u1: number; v1: number },
    tint: [number, number, number],
    back: boolean,
  ) {
    const i0 = dest.positions.length / 3;
    const uvPairs: [number, number][] = [
      [uv.u0, uv.v0],
      [uv.u1, uv.v0],
      [uv.u1, uv.v1],
      [uv.u0, uv.v1],
    ];
    for (let i = 0; i < 4; i++) {
      const p = q[i]!;
      dest.positions.push(p[0], p[1], p[2]);
      dest.normals.push(n[0], n[1], n[2]);
      dest.uvs.push(uvPairs[i]![0], uvPairs[i]![1]);
      dest.colors.push(tint[0], tint[1], tint[2]);
    }
    if (back) dest.indices.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3);
    else dest.indices.push(i0, i0 + 2, i0 + 1, i0, i0 + 3, i0 + 2);
  }

  private pushStem(dest: MeshData, x: number, y: number, z: number, id: number) {
    const attached = isMelonAttach(id);
    const tile = attached ? 8 : Math.max(0, stemStage(id));
    const uv = stemUv(tile);
    const quads: [[number, number, number], [number, number, number], [number, number, number], [number, number, number]][] = [];
    if (attached) {
      const face = attachFacing(id);
      if (face === 0) {
        quads.push([
          [x, y, z + 0.5],
          [x + 1, y, z + 0.5],
          [x + 1, y + 1, z + 1],
          [x, y + 1, z + 1],
        ]);
      } else if (face === 1) {
        quads.push([
          [x + 1, y, z + 0.5],
          [x, y, z + 0.5],
          [x, y + 1, z],
          [x + 1, y + 1, z],
        ]);
      } else if (face === 2) {
        quads.push([
          [x + 0.5, y, z],
          [x + 0.5, y, z + 1],
          [x + 1, y + 1, z + 1],
          [x + 1, y + 1, z],
        ]);
      } else {
        quads.push([
          [x + 0.5, y, z + 1],
          [x + 0.5, y, z],
          [x, y + 1, z],
          [x, y + 1, z + 1],
        ]);
      }
    } else {
      quads.push([
        [x, y, z],
        [x + 1, y, z + 1],
        [x + 1, y + 1, z + 1],
        [x, y + 1, z],
      ]);
      quads.push([
        [x + 1, y, z],
        [x, y, z + 1],
        [x, y + 1, z + 1],
        [x + 1, y + 1, z],
      ]);
    }
    for (const q of quads) this.pushQuad(dest, q, uv, [1, 1, 1]);
  }

  private pushRiccia(dest: MeshData, x: number, y: number, z: number) {
    const uv = stemUv(9);
    const jx = ((x * 13 + z * 7) % 5) * 0.018 - 0.036;
    const jz = ((z * 11 + x * 3) % 5) * 0.018 - 0.036;
    const y0 = y - 0.18;
    const h = 0.36;
    const cross = (
      ox: number,
      oz: number,
      hh: number,
      inset: number,
    ): [[number, number, number], [number, number, number], [number, number, number], [number, number, number]][] => {
      const x0 = x + inset + ox;
      const x1 = x + 1 - inset + ox;
      const z0 = z + inset + oz;
      const z1 = z + 1 - inset + oz;
      return [
        [
          [x0, y0, z0],
          [x1, y0, z1],
          [x1, y0 + hh, z1],
          [x0, y0 + hh, z0],
        ],
        [
          [x1, y0, z0],
          [x0, y0, z1],
          [x0, y0 + hh, z1],
          [x1, y0 + hh, z0],
        ],
      ];
    };
    const quads = [
      ...cross(jx, jz, h, 0.08),
      ...cross(jx * 0.4, jz * 0.4 + 0.04, h * 0.72, 0.16),
      ...cross(-0.02, 0.03, h * 0.55, 0.22),
    ];
    for (const q of quads) this.pushQuad(dest, q, uv, [1, 1, 1]);
  }

  private pushCarpet(dest: MeshData, x: number, y: number, z: number, id: number) {
    const h = CARPET_H;
    const uv = tileUv(faceTile(id, 0));
    const below = this.getBlock(x, y - 1, z);
    const vSide = uv.v0 + (uv.v1 - uv.v0) * h;
    const hideSide = (nid: number) => isOpaque(nid) || isCarpet(nid);
    const quads: {
      corners: [number, number, number][];
      n: [number, number, number];
      uv: [number, number][];
      shade: number;
    }[] = [
      {
        corners: [
          [x, y + h, z],
          [x + 1, y + h, z],
          [x + 1, y + h, z + 1],
          [x, y + h, z + 1],
        ],
        n: [0, 1, 0],
        uv: [
          [uv.u0, uv.v0],
          [uv.u1, uv.v0],
          [uv.u1, uv.v1],
          [uv.u0, uv.v1],
        ],
        shade: FACE_SHADE[0]!,
      },
    ];
    if (!hideSide(this.getBlock(x + 1, y, z))) {
      quads.push({
        corners: [
          [x + 1, y, z],
          [x + 1, y, z + 1],
          [x + 1, y + h, z + 1],
          [x + 1, y + h, z],
        ],
        n: [1, 0, 0],
        uv: [
          [uv.u0, uv.v0],
          [uv.u1, uv.v0],
          [uv.u1, vSide],
          [uv.u0, vSide],
        ],
        shade: FACE_SHADE[2]!,
      });
    }
    if (!hideSide(this.getBlock(x - 1, y, z))) {
      quads.push({
        corners: [
          [x, y, z + 1],
          [x, y, z],
          [x, y + h, z],
          [x, y + h, z + 1],
        ],
        n: [-1, 0, 0],
        uv: [
          [uv.u0, uv.v0],
          [uv.u1, uv.v0],
          [uv.u1, vSide],
          [uv.u0, vSide],
        ],
        shade: FACE_SHADE[3]!,
      });
    }
    if (!hideSide(this.getBlock(x, y, z + 1))) {
      quads.push({
        corners: [
          [x + 1, y, z + 1],
          [x, y, z + 1],
          [x, y + h, z + 1],
          [x + 1, y + h, z + 1],
        ],
        n: [0, 0, 1],
        uv: [
          [uv.u0, uv.v0],
          [uv.u1, uv.v0],
          [uv.u1, vSide],
          [uv.u0, vSide],
        ],
        shade: FACE_SHADE[4]!,
      });
    }
    if (!hideSide(this.getBlock(x, y, z - 1))) {
      quads.push({
        corners: [
          [x, y, z],
          [x + 1, y, z],
          [x + 1, y + h, z],
          [x, y + h, z],
        ],
        n: [0, 0, -1],
        uv: [
          [uv.u0, uv.v0],
          [uv.u1, uv.v0],
          [uv.u1, vSide],
          [uv.u0, vSide],
        ],
        shade: FACE_SHADE[5]!,
      });
    }
    if (!isOpaque(below)) {
      quads.push({
        corners: [
          [x, y, z + 1],
          [x + 1, y, z + 1],
          [x + 1, y, z],
          [x, y, z],
        ],
        n: [0, -1, 0],
        uv: [
          [uv.u0, uv.v1],
          [uv.u1, uv.v1],
          [uv.u1, uv.v0],
          [uv.u0, uv.v0],
        ],
        shade: FACE_SHADE[1]!,
      });
    }
    for (const q of quads) {
      const i0 = dest.positions.length / 3;
      for (let i = 0; i < 4; i++) {
        const p = q.corners[i]!;
        dest.positions.push(p[0], p[1], p[2]);
        dest.normals.push(q.n[0], q.n[1], q.n[2]);
        dest.uvs.push(q.uv[i]![0], q.uv[i]![1]);
        dest.colors.push(q.shade, q.shade, q.shade);
      }
      dest.indices.push(i0, i0 + 2, i0 + 1, i0, i0 + 3, i0 + 2);
    }
  }

  private buildFluidMesh(c: Chunk, ox: number, oz: number, kind: FluidKind): THREE.Mesh | null {
    const dest = emptyMeshData();
    for (let y = 0; y <= c.top; y++) {
      for (let z = 0; z < CHUNK; z++) {
        for (let x = 0; x < CHUNK; x++) {
          const id = c.get(x, y, z);
          if (!sameFluid(id, kind)) continue;
          const wx = ox + x;
          const wz = oz + z;
          const [cx, cy, cz] = this.waterCurrent(wx, y, wz);
          const cr = 0.5 + 0.5 * Math.max(-1, Math.min(1, cx / FLUID_PUSH));
          const cg =
            isFluidFall(id) || cy < -0.25
              ? 0.12
              : 0.5 + 0.5 * Math.max(-1, Math.min(1, cz / FLUID_PUSH));
          let stacked = 0;
          for (let yy = y + 1; yy < HEIGHT && sameFluid(this.getBlock(wx, yy, wz), kind); yy++) {
            stacked++;
            if (stacked > 12) break;
          }
          const cb = Math.max(0.42, 1 - stacked * 0.1);
          const shade = cb;
          const flowX = cr;
          const flowZ = cg;
          const mudTint = (n: [number, number, number]) => {
            const s = n[1] > 0.5 ? 1 : n[1] < -0.5 ? 0.52 : n[0] !== 0 ? 0.8 : 0.64;
            return [s, s, s] as const;
          };
          const h00 = this.fluidCorner(wx, y, wz, 0, 0, kind);
          const h10 = this.fluidCorner(wx, y, wz, 1, 0, kind);
          const h11 = this.fluidCorner(wx, y, wz, 1, 1, kind);
          const h01 = this.fluidCorner(wx, y, wz, 0, 1, kind);
          const up = y + 1 < HEIGHT ? this.getBlock(wx, y + 1, wz) : AIR;
          const down = y > 0 ? this.getBlock(wx, y - 1, wz) : BEDROCK;
          if (!sameFluid(up, kind)) {
            this.pushWaterQuad(
              dest,
              [wx, y + h00, wz],
              [wx + 1, y + h10, wz],
              [wx + 1, y + h11, wz + 1],
              [wx, y + h01, wz + 1],
              [0, 1, 0],
              wx,
              wz,
              ...(kind === "mud" ? mudTint([0, 1, 0]) : ([flowX, flowZ, shade] as const)),
            );
          }
          if (!sameFluid(down, kind) && !isOpaque(down)) {
            this.pushWaterQuad(
              dest,
              [wx, y, wz + 1],
              [wx + 1, y, wz + 1],
              [wx + 1, y, wz],
              [wx, y, wz],
              [0, -1, 0],
              wx,
              wz,
              ...(kind === "mud" ? mudTint([0, -1, 0]) : ([flowX, flowZ, shade] as const)),
            );
          }
          const sides: {
            nid: number;
            a: [number, number, number];
            b: [number, number, number];
            c: [number, number, number];
            d: [number, number, number];
            n: [number, number, number];
          }[] = [
            {
              nid: this.getBlock(wx + 1, y, wz),
              a: [wx + 1, y, wz],
              b: [wx + 1, y, wz + 1],
              c: [wx + 1, y + h11, wz + 1],
              d: [wx + 1, y + h10, wz],
              n: [1, 0, 0],
            },
            {
              nid: this.getBlock(wx - 1, y, wz),
              a: [wx, y, wz + 1],
              b: [wx, y, wz],
              c: [wx, y + h00, wz],
              d: [wx, y + h01, wz + 1],
              n: [-1, 0, 0],
            },
            {
              nid: this.getBlock(wx, y, wz + 1),
              a: [wx + 1, y, wz + 1],
              b: [wx, y, wz + 1],
              c: [wx, y + h01, wz + 1],
              d: [wx + 1, y + h11, wz + 1],
              n: [0, 0, 1],
            },
            {
              nid: this.getBlock(wx, y, wz - 1),
              a: [wx, y, wz],
              b: [wx + 1, y, wz],
              c: [wx + 1, y + h10, wz],
              d: [wx, y + h00, wz],
              n: [0, 0, -1],
            },
          ];
          for (const s of sides) {
            if (sameFluid(s.nid, kind) || isOpaque(s.nid)) continue;
            const tint = kind === "mud" ? mudTint(s.n) : ([flowX, flowZ, shade] as const);
            this.pushWaterQuad(dest, s.a, s.b, s.c, s.d, s.n, wx, y, tint[0], tint[1], tint[2]);
          }
        }
      }
    }
    if (!dest.indices.length) return null;
    const mat = kind === "acid" ? this.acidMat : kind === "mud" ? this.mudMat : this.waterMat;
    return new THREE.Mesh(makeGeo(dest), mat);
  }

  private fluidCorner(x: number, y: number, z: number, px: number, pz: number, kind: FluidKind): number {
    const x0 = x + px - 1;
    const z0 = z + pz - 1;
    let h = 0;
    for (let ix = 0; ix < 2; ix++) {
      for (let iz = 0; iz < 2; iz++) {
        const id = this.getBlock(x0 + ix, y, z0 + iz);
        if (!sameFluid(id, kind)) continue;
        if (sameFluid(this.getBlock(x0 + ix, y + 1, z0 + iz), kind) || isFluidFall(id)) return 1;
        const f = fluidFill(id);
        if (f > h) h = f;
      }
    }
    return h || fluidFill(this.getBlock(x, y, z));
  }

  private pushWaterQuad(
    dest: MeshData,
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number],
    d: [number, number, number],
    n: [number, number, number],
    uBase: number,
    vBase: number,
    cr = 0.5,
    cg = 0.5,
    cb = 1,
  ) {
    const i0 = dest.positions.length / 3;
    const pts = [a, b, c, d];
    const uvs: [number, number][] = [
      [uBase, vBase],
      [uBase + 1, vBase],
      [uBase + 1, vBase + 1],
      [uBase, vBase + 1],
    ];
    for (let i = 0; i < 4; i++) {
      const p = pts[i]!;
      dest.positions.push(p[0], p[1], p[2]);
      dest.normals.push(n[0], n[1], n[2]);
      dest.uvs.push(uvs[i]![0], uvs[i]![1]);
      dest.colors.push(cr, cg, cb);
    }
    dest.indices.push(i0, i0 + 2, i0 + 1, i0, i0 + 3, i0 + 2);
  }

  scheduleFluid(x: number, y: number, z: number) {
    if (y < 0 || y >= HEIGHT) return;
    this.fluidQueue.add(`${x},${y},${z}`);
  }

  tickFluids(dt: number) {
    this.fluidAcc += dt;
    this.mudAcc += dt;
    this.mudReady = false;
    if (this.mudAcc >= 1.2) {
      this.mudAcc = 0;
      this.mudReady = true;
    }
    const STEP = 0.2;
    let guard = 0;
    while (this.fluidAcc >= STEP && this.fluidQueue.size && guard++ < 4) {
      this.fluidAcc -= STEP;
      const batch = [...this.fluidQueue];
      this.fluidQueue.clear();
      for (const k of batch) {
        const p = k.split(",");
        this.updateFluid(Number(p[0]), Number(p[1]), Number(p[2]));
      }
    }
    if (!this.fluidQueue.size) this.fluidAcc = Math.min(this.fluidAcc, STEP);
  }

  fluidBusy(): boolean {
    return this.fluidQueue.size > 0;
  }

  animateWater(t: number, light: number, _sx = 0, _sy = 0, _sz = 0, _sun = 1, _hemi = 1) {
    this.waterMat.uniforms.uTime!.value = t;
    this.waterMat.uniforms.uLight!.value = light;
    this.acidMat.uniforms.uTime!.value = t;
    this.acidMat.uniforms.uLight!.value = light;
    const mudShader = this.mudMat.userData.shader as { uniforms: { uTime: { value: number } } } | undefined;
    if (mudShader) mudShader.uniforms.uTime.value = t;
  }

  waterCurrent(x: number, y: number, z: number): [number, number, number] {
    const id = this.getBlock(x, y, z);
    const kind = fluidKind(id);
    if (!kind) return [0, 0, 0];
    const below = this.getBlock(x, y - 1, z);
    let cy = 0;
    if (isFluidFall(id) || isFluidFall(below) || (!isSolid(below) && !sameFluid(below, kind))) {
      cy = -FLUID_PUSH;
    }
    if (isFluidFall(id)) return [0, cy, 0];
    let fx = 0;
    let fz = 0;
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    for (const [dx, dz] of dirs) {
      const nid = this.getBlock(x + dx, y, z + dz);
      if (this.flowsInto(id, nid, kind)) {
        fx += dx;
        fz += dz;
      }
      if (this.flowsInto(nid, id, kind)) {
        fx -= dx;
        fz -= dz;
      }
    }
    const len = Math.hypot(fx, fz);
    if (len < 0.01) return [0, cy, 0];
    const s = FLUID_PUSH / len;
    return [fx * s, cy, fz * s];
  }

  private flowsInto(fromId: number, toId: number, kind: FluidKind): boolean {
    if (!sameFluid(fromId, kind) || isFluidFall(fromId)) return false;
    if (isFluidReplaceable(toId)) return true;
    if (!sameFluid(toId, kind) || isFluidFall(toId)) return false;
    return fluidFill(toId) < fluidFill(fromId) - 0.02;
  }

  fluidDepth(px: number, py: number, pz: number): number {
    const x = Math.floor(px);
    const z = Math.floor(pz);
    let y = Math.floor(py);
    let d = 0;
    while (y < HEIGHT && isFluid(this.getBlock(x, y, z)) && d < 16) {
      d++;
      y++;
    }
    return d;
  }

  takeWashed(): { x: number; y: number; z: number; id: number; n: number }[] {
    const out = this.washed;
    this.washed = [];
    return out;
  }

  forEachRicciaNear(px: number, pz: number, r: number, fn: (x: number, y: number, z: number) => void) {
    const r2 = r * r;
    for (const k of this.ricciaCells) {
      const p = k.split(",");
      const x = Number(p[0]);
      const y = Number(p[1]);
      const z = Number(p[2]);
      const dx = x + 0.5 - px;
      const dz = z + 0.5 - pz;
      if (dx * dx + dz * dz > r2) continue;
      if (this.getBlock(x, y, z) !== RICCIA) {
        this.ricciaCells.delete(k);
        continue;
      }
      fn(x, y, z);
    }
  }

  placeStarterWater() {
    const wx = 0;
    const wz = -4;
    this.ensureChunk(Math.floor(wx / CHUNK), Math.floor(wz / CHUNK));
    const y = this.surfaceY(wx, wz);
    if (this.getBlock(wx, y, wz) === AIR) this.setBlock(wx, y, wz, WATER);
  }

  /** Small trench ~7 blocks in front of spawn, filled with source water. */
  placeStarterDitch() {
    const tiles: [number, number][] = [];
    for (let x = -2; x <= 2; x++) {
      for (let z = -8; z <= -7; z++) tiles.push([x, z]);
    }
    for (const [wx, wz] of tiles) {
      this.ensureChunk(Math.floor(wx / CHUNK), Math.floor(wz / CHUNK));
    }
    const waterY = this.heightAt(0, -7);
    const bedY = Math.max(2, waterY - 2);
    for (const [wx, wz] of tiles) {
      for (let y = waterY + 8; y >= bedY; y--) {
        if (y > waterY) this.setBlock(wx, y, wz, AIR);
        else if (y > bedY) this.setBlock(wx, y, wz, WATER);
        else this.setBlock(wx, y, wz, DIRT);
      }
    }
    const floor = bedY + 1;
    if (this.getBlock(0, floor, -7) === WATER) this.setBlock(0, floor, -7, RICCIA);
  }

  placeStarterAcid() {
    const wx = 0;
    const wz = 3;
    this.ensureChunk(Math.floor(wx / CHUNK), Math.floor(wz / CHUNK));
    const y = this.surfaceY(wx, wz);
    if (this.getBlock(wx, y, wz) === AIR) this.setBlock(wx, y, wz, ACID);
  }

  placeStarterMelon() {
    const patches: { x: number; z: number; stage: number; fruit?: [number, number] }[] = [
      { x: 11, z: -2, stage: 2 },
      { x: 12, z: -2, stage: 7, fruit: [1, 0] },
      { x: 13, z: -2, stage: 4 },
    ];
    for (const p of patches) {
      this.ensureChunk(Math.floor(p.x / CHUNK), Math.floor(p.z / CHUNK));
      const y = this.surfaceY(p.x, p.z);
      const soil = this.getBlock(p.x, y - 1, p.z);
      if (soil !== GRASS && soil !== DIRT && soil !== FARMLAND) continue;
      if (this.getBlock(p.x, y, p.z) !== AIR && !isPlant(this.getBlock(p.x, y, p.z)) && !isCarpet(this.getBlock(p.x, y, p.z))) continue;
      this.setBlock(p.x, y - 1, p.z, FARMLAND);
      if (p.fruit) {
        const fx = p.x + p.fruit[0];
        const fz = p.z + p.fruit[1];
        const fy = this.surfaceY(fx, fz);
        if (this.getBlock(fx, fy, fz) === AIR && canHoldFruit(this.getBlock(fx, fy - 1, fz))) {
          this.setBlock(fx, fy, fz, MELON);
          const face = STEM_DIRS.findIndex(([dx, dz]) => dx === p.fruit![0] && dz === p.fruit![1]);
          this.setBlock(p.x, y, p.z, MELON_ATTACH + Math.max(0, face));
          continue;
        }
      }
      this.setBlock(p.x, y, p.z, stemFromStage(p.stage));
    }
  }

  placeStarterCarpet() {
    const tiles: [number, number][] = [
      [11, 1],
      [12, 1],
      [13, 1],
      [11, 2],
      [12, 2],
      [13, 2],
    ];
    for (const [wx, wz] of tiles) {
      this.ensureChunk(Math.floor(wx / CHUNK), Math.floor(wz / CHUNK));
      const y = this.surfaceY(wx, wz);
      const below = this.getBlock(wx, y - 1, wz);
      if (!canSupportCarpet(below)) continue;
      const here = this.getBlock(wx, y, wz);
      if (here !== AIR && !isFluid(here) && !isCarpet(here)) continue;
      this.setBlock(wx, y, wz, RED_CARPET);
    }
  }

  scheduleCrop(x: number, y: number, z: number) {
    if (y < 0 || y >= HEIGHT) return;
    const id = this.getBlock(x, y, z);
    if (isPlant(id) && !isRiccia(id)) this.cropQueue.add(`${x},${y},${z}`);
  }

  tickCrops(dt: number, lit = true) {
    this.cropAcc += dt;
    const STEP = 1.15;
    let guard = 0;
    while (this.cropAcc >= STEP && guard++ < 3) {
      this.cropAcc -= STEP;
      const batch = [...this.cropQueue];
      this.cropQueue.clear();
      for (const k of batch) {
        const p = k.split(",");
        this.updateCrop(Number(p[0]), Number(p[1]), Number(p[2]), lit);
      }
    }
    this.tickGrassGrow(dt);
  }

  private scheduleGrassGrow(x: number, y: number, z: number) {
    if (y <= 0 || y >= HEIGHT) return;
    const key = `${x},${y},${z}`;
    if (!isGrassCarpet(this.getBlock(x, y, z)) || this.getBlock(x, y - 1, z) !== DIRT) {
      this.grassGrow.delete(key);
      return;
    }
    if (!this.grassGrow.has(key)) {
      this.grassGrow.set(key, 3 + rand2(x, z, this.seed + 404) * 4);
    }
  }

  private tickGrassGrow(dt: number) {
    if (this.grassGrow.size === 0) return;
    const done: string[] = [];
    for (const [k, t] of this.grassGrow) {
      const next = t - dt;
      if (next > 0) {
        this.grassGrow.set(k, next);
        continue;
      }
      done.push(k);
      const p = k.split(",");
      const x = Number(p[0]);
      const y = Number(p[1]);
      const z = Number(p[2]);
      if (!isGrassCarpet(this.getBlock(x, y, z))) continue;
      if (this.getBlock(x, y - 1, z) !== DIRT) continue;
      this.setBlock(x, y - 1, z, GRASS);
    }
    for (const k of done) this.grassGrow.delete(k);
    this.tickPromote(dt);
  }

  private halfGrass(id: number): boolean {
    return id === GRASS || id === MARBLE_GRASS || id === CAATINGA_GRASS || id === BREJO_GRASS;
  }

  private fullGrass(id: number): number {
    if (id === MARBLE_GRASS || id === MARBLE_GRASS_FULL) return MARBLE_GRASS_FULL;
    if (id === CAATINGA_GRASS || id === CAATINGA_GRASS_FULL) return CAATINGA_GRASS_FULL;
    if (id === BREJO_GRASS || id === BREJO_GRASS_FULL) return BREJO_GRASS_FULL;
    return GRASS_FULL;
  }

  private anyGrass(id: number): boolean {
    return isMeadowGrass(id) || isMarbleGrass(id) || isCaatingaGrass(id) || isBrejoGrass(id);
  }

  private bakeFullGrass(c: Chunk) {
    const ox = c.cx * CHUNK;
    const oz = c.cz * CHUNK;
    for (let z = 0; z < CHUNK; z++) {
      for (let x = 0; x < CHUNK; x++) {
        for (let y = 1; y < HEIGHT - 1; y++) {
          const id = c.get(x, y, z);
          if (!this.halfGrass(id)) continue;
          if (this.grassHeld(ox + x, y, oz + z, c)) continue;
          if (!this.grassReady(ox + x, y, oz + z, c)) continue;
          c.set(x, y, z, this.fullGrass(id));
        }
      }
    }
  }

  private grassHeld(x: number, y: number, z: number, c: Chunk | null): boolean {
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    for (const [dx, dz] of dirs) {
      const id = this.readCol(x + dx, y, z + dz, c);
      if (isFluid(id)) return true;
      if (id === AIR) {
        const under = this.readCol(x + dx, y - 1, z + dz, c);
        if (under === AIR || isFluid(under)) return true;
      }
    }
    return false;
  }

  private grassReady(x: number, y: number, z: number, c: Chunk | null): boolean {
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    let sides = 0;
    let step = false;
    for (const [dx, dz] of dirs) {
      if (this.anyGrass(this.readCol(x + dx, y, z + dz, c))) sides++;
      if (this.anyGrass(this.readCol(x + dx, y + 1, z + dz, c)) || this.anyGrass(this.readCol(x + dx, y - 1, z + dz, c))) step = true;
    }
    return sides === 4 || step;
  }

  private readCol(x: number, y: number, z: number, c: Chunk | null): number {
    const cx = Math.floor(x / CHUNK);
    const cz = Math.floor(z / CHUNK);
    const lx = ((x % CHUNK) + CHUNK) % CHUNK;
    const lz = ((z % CHUNK) + CHUNK) % CHUNK;
    if (c && cx === c.cx && cz === c.cz) return c.get(lx, y, lz);
    const other = this.chunks.get(this.key(cx, cz));
    if (other) return other.get(lx, y, lz);
    if (y === 0) return BEDROCK;
    if (y < 0 || y >= HEIGHT) return AIR;
    const body = this.waterBodyAt(x, z);
    if (body) {
      if (y > body.waterY) return AIR;
      if (y > body.bedY) return WATER;
      if (y === body.bedY) return body.bed;
      return y > body.bedY - 3 ? DIRT : STONE;
    }
    const h = this.heightAt(x, z);
    if (y > h) return AIR;
    if (y < h) return DIRT;
    const biome = this.biomeAt(x, z);
    if (biome === "marble") return MARBLE_GRASS;
    if (biome === "caatinga") return CAATINGA_GRASS;
    if (biome === "brejo") return BREJO_GRASS;
    if (biome === "cerrado") return CERRADO_GRASS;
    return GRASS;
  }

  private schedulePromote(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    const key = `${x},${y},${z}`;
    if (!this.halfGrass(id) || this.grassHeld(x, y, z, null) || !this.grassReady(x, y, z, null)) {
      this.promoteQueue.delete(key);
      return;
    }
    if (!this.promoteQueue.has(key)) this.promoteQueue.set(key, 140 + rand2(x, z, this.seed + 515) * 120);
  }

  private tickPromote(dt: number) {
    if (this.promoteQueue.size === 0) return;
    const done: string[] = [];
    for (const [k, t] of this.promoteQueue) {
      const next = t - dt;
      if (next > 0) {
        this.promoteQueue.set(k, next);
        continue;
      }
      done.push(k);
      const p = k.split(",");
      const x = Number(p[0]);
      const y = Number(p[1]);
      const z = Number(p[2]);
      const id = this.getBlock(x, y, z);
      if (!this.halfGrass(id) || this.grassHeld(x, y, z, null) || !this.grassReady(x, y, z, null)) continue;
      this.setBlock(x, y, z, this.fullGrass(id));
    }
    for (const k of done) this.promoteQueue.delete(k);
  }

  private updateCrop(x: number, y: number, z: number, lit: boolean) {
    const id = this.getBlock(x, y, z);
    if (!isPlant(id) || isRiccia(id) || isVine(id) || isWeed(id) || isGardenFlower(id)) return;
    const soil = this.getBlock(x, y - 1, z);
    if (soil !== FARMLAND) {
      if (isCarpet(soil)) return;
      for (const d of dropsFrom(id)) this.washed.push({ x, y, z, id: d.id, n: d.n });
      this.setBlock(x, y, z, AIR);
      return;
    }
    this.cropQueue.add(`${x},${y},${z}`);
    if (isMelonAttach(id)) {
      const face = attachFacing(id);
      const dir = STEM_DIRS[face] ?? STEM_DIRS[0]!;
      if (this.getBlock(x + dir[0], y, z + dir[1]) !== MELON) {
        this.setBlock(x, y, z, stemFromStage(7));
      }
      return;
    }
    if (!lit) return;
    const stage = stemStage(id);
    if (stage < 7) {
      if (Math.random() < 0.42) this.setBlock(x, y, z, stemFromStage(stage + 1));
      return;
    }
    if (Math.random() > 0.28) return;
    const i = (Math.random() * 4) | 0;
    const [dx, dz] = STEM_DIRS[i]!;
    const nx = x + dx;
    const nz = z + dz;
    if (this.getBlock(nx, y, nz) !== AIR) return;
    if (!canHoldFruit(this.getBlock(nx, y - 1, nz))) return;
    this.setBlock(nx, y, nz, MELON);
    this.setBlock(x, y, z, MELON_ATTACH + i);
  }

  immersed(px: number, py: number, pz: number): boolean {
    return this.fluidAt(px, py, pz) !== null;
  }

  leavesAt(px: number, py: number, pz: number): number | null {
    const id = this.getBlock(Math.floor(px), Math.floor(py), Math.floor(pz));
    return isLeaves(id) ? id : null;
  }

  waterColumn(x: number, z: number): { bed: number; top: number } | null {
    let top = -1;
    let bed = -1;
    for (let y = HEIGHT - 1; y >= 1; y--) {
      const kind = fluidKind(this.getBlock(x, y, z));
      if (kind === "water") {
        if (top < 0) top = y;
        bed = y;
      } else if (top >= 0) break;
    }
    if (top < 0) return null;
    return { bed, top };
  }

  fluidAt(px: number, py: number, pz: number): FluidKind | null {
    const x = Math.floor(px);
    const y = Math.floor(py);
    const z = Math.floor(pz);
    const id = this.getBlock(x, y, z);
    const kind = fluidKind(id);
    if (!kind) return null;
    if (py - y < fluidFill(id) - 0.02) return kind;
    return null;
  }

  private updateFluid(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    if (isRiccia(id) || id === GRASS_CARPET_WET || id === CERRADO_CARPET_WET) return;
    const kind = fluidKind(id);
    if (!kind) return;
    if (kind === "mud" && !this.mudReady) {
      this.scheduleFluid(x, y, z);
      return;
    }
    const below = this.getBlock(x, y - 1, z);
    if (isFluidPermeable(below)) {
      let y2 = y - 1;
      while (y2 > 1 && isFluidPermeable(this.getBlock(x, y2, z))) y2--;
      if (this.getBlock(x, y2, z) === AIR) {
        this.setFluid(x, y2, z, isFluidSource(id) ? id : fluidFall(kind));
        this.setFluid(x, y, z, AIR);
      }
      return;
    }
    if (below === AIR) {
      this.setFluid(x, y - 1, z, isFluidSource(id) ? id : fluidFall(kind));
      this.setFluid(x, y, z, AIR);
      return;
    }
    if (kind !== "mud" && this.slideToDrop(x, y, z, id, kind)) return;
    if (kind === "mud" && isFluidSource(id)) {
      this.spreadFluid(x, y, z, 0, kind);
      return;
    }
    if (isFluidSource(id)) return;
    const support = this.bestSupport(x, y, z, kind);
    const expected = support + (kind === "mud" ? 2 : 1);
    if (expected > flowReach(kind)) {
      this.setFluid(x, y, z, AIR);
      return;
    }
    const want = fluidFromLevel(kind, Math.max(1, expected));
    if (want !== id && fluidLevel(want) > 0) this.setFluid(x, y, z, want);
    if (kind === "mud") this.spreadFluid(x, y, z, expected, kind);
  }

  /** Move the same block into a hole beside it. Does not leave a copy. */
  private slideToDrop(x: number, y: number, z: number, id: number, kind: FluidKind): boolean {
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    for (const [dx, dz] of dirs) {
      const nx = x + dx;
      const nz = z + dz;
      const side = this.getBlock(nx, y, nz);
      if (side !== AIR && !isFluidPermeable(side)) continue;
      let y2 = y - 1;
      if (isFluidPermeable(side)) {
        y2 = y;
        while (y2 > 1 && isFluidPermeable(this.getBlock(nx, y2, nz))) y2--;
      }
      if (this.getBlock(nx, y2, nz) !== AIR) continue;
      this.setFluid(nx, y2, nz, isFluidSource(id) ? id : fluidFall(kind));
      this.setFluid(x, y, z, AIR);
      return true;
    }
    return false;
  }

  private bestSupport(x: number, y: number, z: number, kind: FluidKind): number {
    let best = 8;
    const sides: [number, number, number][] = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1],
    ];
    for (const [dx, dy, dz] of sides) {
      const nid = this.getBlock(x + dx, y + dy, z + dz);
      if (!sameFluid(nid, kind) || isFluidFall(nid)) continue;
      if (isFluidSource(nid)) return 0;
      const lv = fluidLevel(nid);
      if (lv >= 0 && lv < best) best = lv;
    }
    const above = this.getBlock(x, y + 1, z);
    if (sameFluid(above, kind)) return 0;
    return best;
  }

  private spreadFluid(x: number, y: number, z: number, depth: number, kind: FluidKind) {
    const reach = flowReach(kind);
    if (depth >= reach) return;
    const next = depth + (kind === "mud" ? 2 : 1);
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    let minDrop = 99;
    const dist: number[] = [];
    const look = Math.max(1, Math.ceil(FLOW_MAX / 2) + 1);
    for (const [dx, dz] of dirs) {
      const d = this.dropDist(x, y, z, dx, dz, look, kind);
      dist.push(d);
      if (d < minDrop) minDrop = d;
    }
    const prefer = minDrop <= look;
    for (let i = 0; i < 4; i++) {
      if (prefer && dist[i]! > minDrop) continue;
      const nx = x + dirs[i]![0];
      const nz = z + dirs[i]![1];
      const nid = this.getBlock(nx, y, nz);
      if (isRiccia(nid) || isFluidPermeable(nid) || nid === GRASS_CARPET_WET) continue;
      const want = fluidFromLevel(kind, next);
      if (fluidLevel(want) <= 0) continue;
      if (nid === AIR) this.setFluid(nx, y, nz, want);
      else if (sameFluid(nid, kind) && !isFluidSource(nid) && !isFluidFall(nid) && fluidLevel(nid) > next) {
        this.setFluid(nx, y, nz, want);
      }
    }
  }

  private dropDist(x: number, y: number, z: number, dx: number, dz: number, max: number, kind: FluidKind): number {
    for (let i = 1; i <= max; i++) {
      const nx = x + dx * i;
      const nz = z + dz * i;
      const here = this.getBlock(nx, y, nz);
      if (isOpaque(here) || (isFluid(here) && !sameFluid(here, kind))) return 99;
      if (isFluidReplaceable(here) && isFluidReplaceable(this.getBlock(nx, y - 1, nz))) return i;
    }
    return 99;
  }

  private setFluid(x: number, y: number, z: number, id: number) {
    const prev = this.getBlock(x, y, z);
    if (prev === id) return;
    if (isRiccia(prev) || prev === GRASS_CARPET_WET || prev === CERRADO_CARPET_WET) return;
    if (isFluidPermeable(prev) || isCarpet(prev) || (isPlant(prev) && !isRiccia(prev))) return;
    this.setBlock(x, y, z, id);
  }

  private cornerAO(
    x: number,
    y: number,
    z: number,
    dir: [number, number, number],
    p: [number, number, number],
  ): number {
    const [dx, dy, dz] = dir;
    const [px, py, pz] = p;
    const o1 = { x: 0, y: 0, z: 0 };
    const o2 = { x: 0, y: 0, z: 0 };
    let filled = 0;
    if (dx === 0) {
      (filled === 0 ? o1 : o2).x = px === 0 ? -1 : 1;
      filled++;
    }
    if (dy === 0) {
      (filled === 0 ? o1 : o2).y = py === 0 ? -1 : 1;
      filled++;
    }
    if (dz === 0) {
      (filled === 0 ? o1 : o2).z = pz === 0 ? -1 : 1;
    }
    const s1 = isOpaque(this.getBlock(x + dx + o1.x, y + dy + o1.y, z + dz + o1.z));
    const s2 = isOpaque(this.getBlock(x + dx + o2.x, y + dy + o2.y, z + dz + o2.z));
    const cr = isOpaque(this.getBlock(x + dx + o1.x + o2.x, y + dy + o1.y + o2.y, z + dz + o1.z + o2.z));
    const occ = s1 && s2 ? 3 : (s1 ? 1 : 0) + (s2 ? 1 : 0) + (cr ? 1 : 0);
    return [1, 0.8, 0.64, 0.5][occ]!;
  }

  surfaceY(x: number, z: number): number {
    for (let y = HEIGHT - 1; y >= 0; y--) {
      if (isSolid(this.getBlock(x, y, z))) return y + 1;
    }
    return this.heightAt(x, z) + 1;
  }

  /** Top walkable ground that is not a tree or leaf canopy. */
  spawnY(x: number, z: number): number | null {
    for (let y = HEIGHT - 2; y >= 1; y--) {
      const floor = this.getBlock(x, y, z);
      if (floor === AIR || isPlant(floor) || isFluid(floor) || isCarpet(floor)) continue;
      if (this.treeish(x, y, z)) continue;
      if (!isSolid(floor)) continue;
      const up1 = this.getBlock(x, y + 1, z);
      const up2 = this.getBlock(x, y + 2, z);
      if (up1 !== AIR && !isCarpet(up1)) return null;
      if (up2 !== AIR && !isCarpet(up2)) return null;
      return y + 1;
    }
    return null;
  }

  private treeish(x: number, y: number, z: number): boolean {
    const id = this.getBlock(x, y, z);
    if (isLeaves(id)) return true;
    if (!isLog(id)) return false;
    for (let dy = 0; dy <= 5; dy++) {
      for (let dx = -3; dx <= 3; dx++) {
        for (let dz = -3; dz <= 3; dz++) {
          if (isLeaves(this.getBlock(x + dx, y + dy, z + dz))) return true;
        }
      }
    }
    return false;
  }

  farFromVillage(x: number, z: number): boolean {
    const dx = x - this.hamletMeet.x;
    const dz = z - this.hamletMeet.z;
    return dx * dx + dz * dz > 36 * 36;
  }

  publishGroundFood(items: { x: number; y: number; z: number; id: number; n: number; tag: number }[]) {
    this.groundFood = items.filter((g) => !this.foodClaims.has(g.tag));
  }

  claimGroundFood(tag: number): { id: number; n: number } | null {
    const g = this.groundFood.find((f) => f.tag === tag);
    if (!g) return null;
    this.foodClaims.add(tag);
    this.groundFood = this.groundFood.filter((f) => f.tag !== tag);
    return { id: g.id, n: g.n };
  }

  drainFoodClaims(): number[] {
    const tags = [...this.foodClaims];
    this.foodClaims.clear();
    return tags;
  }

  togglePassage(x: number, y: number, z: number) {
    const id = this.getBlock(x, y, z);
    if (isDoor(id)) {
      this.setBlock(x, y, z, doorWithOpen(id, id < DOOR + 4));
      this.doorPulse = true;
    } else if (id === GATE) {
      this.setBlock(x, y, z, GATE_OPEN);
      this.doorPulse = true;
    } else if (id === GATE_OPEN) {
      this.setBlock(x, y, z, GATE);
      this.doorPulse = true;
    }
  }

  takeDoorPulse(): boolean {
    const v = this.doorPulse;
    this.doorPulse = false;
    return v;
  }

  placeStarterWeeds() {
    const spots: [number, number, number][] = [
      [3, 5, WEED_SHORT],
      [4, 6, WEED_TALL],
      [5, 5, WEED_SHORT],
      [-4, 6, WEED_SHORT],
    ];
    for (const [x, z, id] of spots) {
      this.ensureChunk(Math.floor(x / CHUNK), Math.floor(z / CHUNK));
      const y = this.surfaceY(x, z);
      const here = this.getBlock(x, y, z);
      if (here === AIR) this.setBlock(x, y, z, id);
      else if (isCarpet(here) && y + 1 < HEIGHT && this.getBlock(x, y + 1, z) === AIR) this.setBlock(x, y + 1, z, id);
    }
  }

  placeStarterRestinga() {
    for (let x = -8; x <= 8; x++) {
      const z = 16;
      this.ensureChunk(0, Math.floor(z / CHUNK));
      const g = this.surfaceY(x, z) - 1;
      if (this.getBlock(x, g, z) !== SAND && this.getBlock(x, g, z) !== GRASS) continue;
      const y = g + 1;
      const here = this.getBlock(x, y, z);
      if (here === AIR) this.setBlock(x, y, z, WEED_BEACH);
      else if (isCarpet(here) && y + 1 < HEIGHT && this.getBlock(x, y + 1, z) === AIR) this.setBlock(x, y + 1, z, WEED_BEACH);
    }
  }

  placeStarterAraucaria() {
    const x = -10;
    const z = 8;
    const y = this.surfaceY(x, z);
    this.ensureChunk(Math.floor(x / CHUNK), Math.floor(z / CHUNK));
    for (let i = 0; i < 7; i++) this.setBlock(x, y + i, z, ARAU_LOG);
    for (let dy = 3; dy <= 7; dy++) {
      const r = dy > 5 ? 1 : 2;
      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          if (dx === 0 && dz === 0) continue;
          if (this.getBlock(x + dx, y + dy, z + dz) === AIR) this.setBlock(x + dx, y + dy, z + dz, ARAU_LEAVES);
        }
      }
    }
  }

  planQuakeFissure(px: number, pz: number): FissureCol[] {
    const cols: FissureCol[] = [];
    const seen = new Set<string>();
    const ang = Math.random() * Math.PI * 2;
    const rad = 2 + Math.random() * 10;
    let x = px + Math.cos(ang) * rad;
    let z = pz + Math.sin(ang) * rad;
    const len = 14 + ((Math.random() * 10) | 0);
    let dx = Math.cos(Math.random() * Math.PI * 2);
    let dz = Math.sin(Math.random() * Math.PI * 2);
    const dry = Math.random() < 0.5;
    const depth = 8 + ((Math.random() * 5) | 0);
    const kink = 2 + ((Math.random() * (len - 4)) | 0);
    for (let i = 0; i < len; i++) {
      if (i === kink) {
        dx += (Math.random() - 0.5) * 1.1;
        dz += (Math.random() - 0.5) * 1.1;
      }
      const ix = Math.round(x);
      const iz = Math.round(z);
      const key = `${ix},${iz}`;
      if (!seen.has(key)) {
        seen.add(key);
        const top = this.groundY(ix, iz);
        cols.push({ x: ix, z: iz, top, bed: Math.max(2, top - depth), dry, shut: false });
      }
      x += dx;
      z += dz;
    }
    return cols;
  }

  private groundY(x: number, z: number): number {
    for (let y = HEIGHT - 2; y >= 1; y--) {
      const id = this.getBlock(x, y, z);
      if (!isSolid(id) || isLeaves(id) || isLog(id)) continue;
      return y;
    }
    return this.heightAt(x, z);
  }

  private fillCap(x: number, y: number, z: number, top: boolean): number {
    const biome = this.biomeAt(x, z);
    if (biome === "marble") return top ? MARBLE_GRASS : MARBLE;
    if (biome === "cerrado") return top ? CERRADO_GRASS : CERRADO_DIRT;
    if (biome === "caatinga") return top ? CAATINGA_GRASS : CAATINGA_DIRT;
    if (biome === "brejo") return top ? BREJO_GRASS : BREJO_DIRT;
    return top ? GRASS : DIRT;
  }

  digFissure(cols: FissureCol[], p: number): { crumbled: boolean; dust: { x: number; y: number; z: number }[]; id: number } {
    const dust: { x: number; y: number; z: number }[] = [];
    let crumbled = false;
    let id = DIRT;
    for (const col of cols) {
      const floor = col.bed + Math.ceil((1 - p) * Math.max(0, col.top - col.bed));
      for (let y = col.top + 2; y > floor; y--) {
        const here = this.getBlock(col.x, y, col.z);
        if (here === AIR || here === BEDROCK || isFluid(here)) continue;
        id = here;
        const wet = !col.dry && y <= col.bed + 2;
        this.setBlock(col.x, y, col.z, wet ? WATER : AIR);
        crumbled = true;
      }
      if (Math.random() < 0.35) dust.push({ x: col.x + 0.5, y: col.top + 1, z: col.z + 0.5 });
    }
    return { crumbled, dust, id };
  }

  sealFissure(cols: FissureCol[], p: number, _who: { x: number; y: number; z: number }): { dust: { x: number; y: number; z: number }[] } {
    const dust: { x: number; y: number; z: number }[] = [];
    const edge = Math.floor(p * (cols.length / 2 + 1));
    cols.forEach((col, i) => {
      if (Math.min(i, cols.length - 1 - i) > edge) return;
      for (let y = col.bed; y <= col.top; y++) {
        const id = this.getBlock(col.x, y, col.z);
        if (id !== AIR && !isFluid(id) && !isPlant(id) && !isCarpet(id)) continue;
        this.setBlock(col.x, y, col.z, this.fillCap(col.x, y, col.z, y === col.top));
      }
      col.shut = true;
      if (Math.random() < 0.2) dust.push({ x: col.x + 0.5, y: col.top + 1.1, z: col.z + 0.5 });
    });
    return { dust };
  }

  forEachAquiferNear(px: number, pz: number, r: number, fn: (x: number, y: number, z: number) => void) {
    for (const key of this.aquiferCells.keys()) {
      const [xs, ys, zs] = key.split(",");
      const x = Number(xs);
      const y = Number(ys);
      const z = Number(zs);
      if ((x - px) * (x - px) + (z - pz) * (z - pz) <= r * r) fn(x, y, z);
    }
  }

  aquiferOpenFaces(x: number, y: number, z: number): [number, number, number][] {
    const faces: [number, number, number][] = [
      [0, 1, 0],
      [0, -1, 0],
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1],
    ];
    return faces.filter(([dx, dy, dz]) => {
      const id = this.getBlock(x + dx, y + dy, z + dz);
      return id === AIR || isFluid(id);
    });
  }

  tickAquifers(dt: number): { x: number; y: number; z: number }[] {
    const sprung: { x: number; y: number; z: number }[] = [];
    for (const [key, left] of this.aquiferCells) {
      const next = left - dt;
      if (next > 0) {
        this.aquiferCells.set(key, next);
        continue;
      }
      this.aquiferCells.set(key, 150 + Math.random() * 200);
      const [xs, ys, zs] = key.split(",");
      const x = Number(xs);
      const y = Number(ys);
      const z = Number(zs);
      const faces = this.aquiferOpenFaces(x, y, z);
      const face = faces[0];
      if (!face) continue;
      const tx = x + face[0];
      const ty = y + face[1];
      const tz = z + face[2];
      if (this.getBlock(tx, ty, tz) === AIR) {
        this.setBlock(tx, ty, tz, WATER);
        sprung.push({ x: tx, y: ty, z: tz });
      }
    }
    return sprung;
  }

  listAquifersNear(px: number, pz: number, r: number): { x: number; y: number; z: number }[] {
    const out: { x: number; y: number; z: number }[] = [];
    this.forEachAquiferNear(px, pz, r, (x, y, z) => out.push({ x, y, z }));
    return out;
  }

  forceAquiferNear(px: number, pz: number): { x: number; y: number; z: number } | null {
    let hit: { x: number; y: number; z: number } | null = null;
    this.forEachAquiferNear(px, pz, 48, (x, y, z) => {
      if (hit) return;
      this.aquiferCells.set(`${x},${y},${z}`, 0.2);
      hit = { x, y, z };
    });
    return hit;
  }

  placeHamlet(): { x: number; y: number; z: number; role: VillagerRole }[] {
    if (this.hamletSpots) return this.hamletSpots;
    const houses: { x: number; z: number; w: number; d: number; role: VillagerRole }[] = [
      { x: 20, z: -28, w: 5, d: 5, role: "jardineiro" },
      { x: 28, z: -28, w: 7, d: 5, role: "contador" },
      { x: 38, z: -27, w: 6, d: 6, role: "vigia" },
      { x: 22, z: -18, w: 5, d: 6, role: "palerma" },
      { x: 32, z: -16, w: 6, d: 5, role: "pescador" },
      { x: 42, z: -16, w: 5, d: 5, role: "crianca" },
    ];
    const spots = houses.map((h) => this.buildHouse(h.x, h.z, h.w, h.d, h.role));
    this.buildPaths();
    this.buildConsortium(22, -8, 8);
    this.buildFarm(34, -8, 5, MELON_STEM);
    this.buildPen(46, -26);
    this.buildFishPool(44, -4);
    this.keepOneTree(26, -24);
    this.tidyVillage();
    this.hamletMeet = { x: 30, z: -22 };
    this.hamletSpots = spots;
    return spots;
  }

  private lay(x: number, y: number, z: number, id: number, remember = true) {
    this.ensureChunk(Math.floor(x / CHUNK), Math.floor(z / CHUNK));
    this.setBlock(x, y, z, id);
    if (remember) this.villagePlan.push({ x, y, z, id });
  }

  private buildHouse(x: number, z: number, w: number, d: number, role: VillagerRole): { x: number; y: number; z: number; role: VillagerRole } {
    let ground = 0;
    let n = 0;
    for (let dx = 0; dx < w; dx++) {
      for (let dz = 0; dz < d; dz++) {
        ground += this.surfaceY(x + dx, z + dz) - 1;
        n++;
      }
    }
    ground = Math.round(ground / n);
    const doorX = x + Math.floor(w / 2);
    for (let dx = 0; dx < w; dx++) {
      for (let dz = 0; dz < d; dz++) {
        const wx = x + dx;
        const wz = z + dz;
        const edge = dx === 0 || dz === 0 || dx === w - 1 || dz === d - 1;
        const corner = (dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1);
        const door = wx === doorX && dz === 0;
        for (let y = ground + 1; y <= ground + 6; y++) this.lay(wx, y, wz, AIR, false);
        for (let y = ground - 1; y >= Math.max(1, ground - 5); y--) {
          const here = this.getBlock(wx, y, wz);
          if (here !== AIR && !isPlant(here) && !isLeaves(here) && !isLog(here)) break;
          this.lay(wx, y, wz, PLANKS, false);
        }
        this.lay(wx, ground, wz, PLANKS);
        if (!edge) {
          this.lay(wx, ground + 4, wz, PLANKS);
          continue;
        }
        for (let dy = 1; dy <= 3; dy++) {
          let id = corner ? LOG : PLANKS;
          if (door && dy <= 2) id = DOOR;
          else if (dy === 2 && !corner) id = AIR;
          if (id === AIR) this.lay(wx, ground + dy, wz, AIR, false);
          else this.lay(wx, ground + dy, wz, id);
        }
        this.lay(wx, ground + 4, wz, PLANKS);
      }
    }
    for (let dx = -1; dx <= w; dx++) {
      for (const dz of [-1, d]) {
        if (dz === -1 && x + dx === doorX) continue;
        this.lay(x + dx, ground + 4, z + dz, PLANKS);
      }
    }
    this.lay(doorX, ground, z - 1, PATH);
    this.lay(doorX, ground + 1, z - 1, AIR, false);
    this.lay(doorX, ground + 2, z - 1, AIR, false);
    const cx = x + w - 2;
    const cz = z + d - 2;
    this.lay(cx, ground + 1, cz, COMODA);
    this.lay(cx, ground + 2, cz, CANDLE_LIT);
    this.lay(cx, ground + 3, cz, AIR, false);
    this.lay(cx, ground + 4, cz, AIR, false);
    return { x: doorX + 0.5, y: ground + 1, z: z - 1.4, role };
  }

  private buildConsortium(x: number, z: number, n: number) {
    const crops = [TOMATO + 6, URUCUM + 5, CAMAPU + 4];
    for (let dx = 0; dx < n; dx++) {
      for (let dz = 0; dz < n; dz++) {
        const wx = x + dx;
        const wz = z + dz;
        const edge = dx === 0 || dz === 0 || dx === n - 1 || dz === n - 1;
        const g = this.plotFloor(wx, wz);
        for (let y = g + 1; y <= g + 3; y++) this.lay(wx, y, wz, AIR, false);
        if (edge) {
          this.lay(wx, g + 1, wz, dx === 0 && dz === 1 ? GATE : FENCE);
          continue;
        }
        this.lay(wx, g, wz, FARMLAND);
        this.lay(wx, g + 1, wz, crops[(dx + dz) % crops.length]!);
      }
    }
  }

  private plotFloor(x: number, z: number): number {
    return this.surfaceY(x, z) - 1;
  }

  private keepOneTree(x: number, z: number) {
    for (let dz = -6; dz <= 6; dz++) {
      for (let dx = -6; dx <= 6; dx++) {
        const wx = x + dx;
        const wz = z + dz;
        const top = this.surfaceY(wx, wz);
        for (let y = top; y >= top - 8 && y > 1; y--) {
          if (!isLog(this.getBlock(wx, y, wz))) continue;
          this.keptTree = { x: wx, z: wz };
          const g = y;
          for (let a = -1; a <= 1; a++) {
            for (let b = -1; b <= 1; b++) {
              if (a === 0 && b === 0) continue;
              const edge = Math.abs(a) === 1 || Math.abs(b) === 1;
              if (!edge) continue;
              this.lay(wx + a, g, wz + b, a === 0 && b === 1 ? GATE : FENCE);
            }
          }
          return;
        }
      }
    }
  }

  private tidyVillage() {
    const keep = this.keptTree;
    for (let x = 17; x <= 55; x++) {
      for (let z = -39; z <= 2; z++) {
        const top = Math.min(HEIGHT - 2, this.surfaceY(x, z) + 8);
        for (let y = 2; y <= top; y++) {
          const id = this.getBlock(x, y, z);
          if (this.villagePlan.some((b) => b.x === x && b.y === y && b.z === z)) continue;
          const tree = isLog(id) || isLeaves(id);
          if (tree && keep && x === keep.x && z === keep.z && isLog(id)) continue;
          if (tree && keep && Math.abs(x - keep.x) <= 2 && Math.abs(z - keep.z) <= 2 && isLeaves(id)) continue;
          if (isWeed(id) || tree) this.lay(x, y, z, AIR, false);
        }
      }
    }
  }

  private buildPaths() {
    for (let x = 20; x <= 46; x++) this.lay(x, this.surfaceY(x, -22) - 1, -22, PATH);
    for (let z = -28; z <= -8; z++) this.lay(30, this.surfaceY(30, z) - 1, z, PATH);
  }

  private buildFarm(x: number, z: number, n: number, crop: number) {
    for (let dx = 0; dx < n; dx++) {
      for (let dz = 0; dz < n; dz++) {
        const wx = x + dx;
        const wz = z + dz;
        const edge = dx === 0 || dz === 0 || dx === n - 1 || dz === n - 1;
        const g = this.surfaceY(wx, wz) - 1;
        for (let y = g + 1; y <= g + 3; y++) this.lay(wx, y, wz, AIR, false);
        if (edge) {
          this.lay(wx, g + 1, wz, FENCE);
          continue;
        }
        this.lay(wx, g, wz, FARMLAND);
        this.lay(wx, g + 1, wz, crop);
      }
    }
  }

  private buildPen(x: number, z: number) {
    const n = 6;
    for (let dx = 0; dx < n; dx++) {
      for (let dz = 0; dz < n; dz++) {
        const wx = x + dx;
        const wz = z + dz;
        const g = this.surfaceY(wx, wz) - 1;
        for (let y = g + 1; y <= g + 4; y++) this.lay(wx, y, wz, AIR, false);
        const edge = dx === 0 || dz === 0 || dx === n - 1 || dz === n - 1;
        if (!edge) continue;
        this.lay(wx, g + 1, wz, dx === 0 && dz === 2 ? GATE : FENCE);
      }
    }
    const y = this.surfaceY(x + 2, z + 2);
    this.penSpawns.push({ x: x + 2.5, y, z: z + 2.5, kind: "vaca" });
    this.penSpawns.push({ x: x + 3.5, y, z: z + 3.5, kind: "porco" });
    this.penSpawns.push({ x: x + 2.5, y, z: z + 3.5, kind: "ovelha" });
  }

  private buildFishPool(x: number, z: number) {
    for (let dx = 0; dx < 5; dx++) {
      for (let dz = 0; dz < 4; dz++) {
        const wx = x + dx;
        const wz = z + dz;
        const g = this.surfaceY(wx, wz) - 1;
        const rim = dx === 0 || dz === 0 || dx === 4 || dz === 3;
        for (let y = g - 2; y <= g + 2; y++) this.lay(wx, y, wz, AIR, false);
        if (rim) {
          this.lay(wx, g, wz, PLANKS);
          continue;
        }
        this.lay(wx, g - 2, wz, DIRT, false);
        this.lay(wx, g - 1, wz, WATER, false);
        this.lay(wx, g, wz, WATER, false);
        this.fishPool.push({ x: wx + 0.5, y: g + 0.4, z: wz + 0.5 });
      }
    }
    this.fishDock = { x: x + 0.5, y: this.surfaceY(x, z + 1), z: z + 1.5 };
  }

  findHomesite(x: number, z: number): { x: number; floor: number; z: number } | null {
    for (let ring = 4; ring <= 18; ring += 2) {
      const hx = Math.floor(x) + ((Math.random() * ring * 2 - ring) | 0);
      const hz = Math.floor(z) + ((Math.random() * ring * 2 - ring) | 0);
      if (this.waterBodyAt(hx, hz)) continue;
      const floor = this.surfaceY(hx, hz);
      if (floor < 4) continue;
      return { x: hx, floor, z: hz };
    }
    return null;
  }

  cottageBlueprint(x: number, floor: number, z: number): { x: number; y: number; z: number; id: number }[] {
    const blocks: { x: number; y: number; z: number; id: number }[] = [];
    for (let dx = 0; dx < 4; dx++) {
      for (let dz = 0; dz < 4; dz++) {
        blocks.push({ x: x + dx, y: floor, z: z + dz, id: PLANKS });
        const edge = dx === 0 || dz === 0 || dx === 3 || dz === 3;
        if (!edge) continue;
        const door = dx === 0 && dz === 1;
        for (let dy = 1; dy <= 3; dy++) {
          blocks.push({ x: x + dx, y: floor + dy, z: z + dz, id: door && dy < 3 ? DOOR : dy === 3 ? FENCE : PLANKS });
        }
      }
    }
    return blocks;
  }

  nearestBroken(x: number, z: number, r: number): { x: number; y: number; z: number; id: number } | null {
    let best: { x: number; y: number; z: number; id: number } | null = null;
    let bestD = r;
    for (const b of this.villagePlan) {
      if (this.getBlock(b.x, b.y, b.z) === b.id) continue;
      const d = Math.hypot(b.x + 0.5 - x, b.z + 0.5 - z);
      if (d >= bestD) continue;
      bestD = d;
      best = b;
    }
    return best;
  }

  private stampCottage(x: number, z: number) {
    const floor = this.surfaceY(x + 1, z + 1);
    for (const b of this.cottageBlueprint(x, floor, z)) {
      this.ensureChunk(Math.floor(b.x / CHUNK), Math.floor(b.z / CHUNK));
      this.setBlock(b.x, b.y, b.z, b.id);
      this.villagePlan.push(b);
    }
  }

  dispose() {
    for (const c of this.chunks.values()) {
      if (c.group) {
        this.group.remove(c.group);
        for (const child of c.group.children) {
          (child as THREE.Mesh).geometry.dispose();
        }
      }
    }
    this.material.dispose();
    this.cutout.dispose();
    this.plant.dispose();
    this.waterMat.dispose();
    this.acidMat.dispose();
    this.mudMat.dispose();
    this.atlas.dispose();
    this.leafMap.dispose();
    this.stemMap.dispose();
    this.waterMap.dispose();
    this.acidMap.dispose();
    this.mudMap.dispose();
    this.chunks.clear();
  }
}

type MeshData = {
  positions: number[];
  normals: number[];
  uvs: number[];
  colors: number[];
  indices: number[];
};

const FACE_SHADE = [1, 0.52, 0.64, 0.64, 0.8, 0.8];

function emptyMeshData(): MeshData {
  return { positions: [], normals: [], uvs: [], colors: [], indices: [] };
}

function makeGeo(data: MeshData): THREE.BufferGeometry {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(data.positions, 3));
  geo.setAttribute("normal", new THREE.Float32BufferAttribute(data.normals, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(data.uvs, 2));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(data.colors, 3));
  geo.setIndex(data.indices);
  geo.computeBoundingSphere();
  return geo;
}

function makeLiquidMat(
  map: THREE.Texture,
  opacity: number,
  tint: [number, number, number],
  still = false,
  scroll = false,
): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uMap: { value: map },
      uLight: { value: 1 },
      uOpacity: { value: opacity },
      uTint: { value: new THREE.Vector3(tint[0], tint[1], tint[2]) },
      uStill: { value: still ? 1 : 0 },
      uScroll: { value: scroll || !still ? 1 : 0 },
    },
    vertexShader: `
      attribute vec3 color;
      varying vec2 vUv;
      varying vec3 vNorm;
      varying vec3 vWorld;
      varying vec3 vColor;
      void main() {
        vUv = uv;
        vColor = color;
        vNorm = normalize(normalMatrix * normal);
        vec4 w = modelMatrix * vec4(position, 1.0);
        vWorld = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform sampler2D uMap;
      uniform float uLight;
      uniform float uOpacity;
      uniform float uStill;
      uniform float uScroll;
      uniform vec3 uTint;
      varying vec2 vUv;
      varying vec3 vNorm;
      varying vec3 vWorld;
      varying vec3 vColor;
      void main() {
        vec2 uv = vUv;
        if (uScroll > 0.5) {
          vec2 flow = (vColor.xy - 0.5) * 2.0;
          float mag = length(flow);
          if (mag > 0.12) {
            uv -= normalize(flow) * uTime * 0.22;
          } else {
            uv += vec2(uTime * 0.016, uTime * 0.011);
            uv += 0.028 * vec2(
              sin(vWorld.x * 1.6 + uTime * 0.95),
              cos(vWorld.z * 1.4 + uTime * 0.8)
            );
          }
        }
        vec3 tex = texture2D(uMap, uv).rgb * uTint * vColor.z;
        float nd = max(dot(normalize(vNorm), normalize(vec3(0.35, 1.0, 0.25))), 0.0);
        float fres = pow(1.0 - abs(dot(normalize(vNorm), vec3(0.0, 1.0, 0.0))), 2.2);
        float shine = uStill > 0.5 ? 0.0 : fres;
        float light = uStill > 0.5 ? 1.0 : 0.55 + 0.5 * nd;
        vec3 col = tex * light * uLight + uTint * 0.22 * shine;
        gl_FragColor = vec4(col, uOpacity + shine * 0.16);
      }
    `,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
}
