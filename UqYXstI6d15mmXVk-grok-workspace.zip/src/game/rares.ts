import * as THREE from "three";

export type RareKind = "tamandua" | "tucano";
export const RARE_KINDS: RareKind[] = ["tamandua", "tucano"];
export function isRareKind(k: string): k is RareKind {
  return k === "tamandua" || k === "tucano";
}

export type RareInfo = { name: string; w: number; h: number; d: number; hp: number; speed: number };
export function rareStats(kind: RareKind, baby: boolean): RareInfo {
  const s = baby ? 0.5 : 1;
  if (kind === "tamandua") {
    return { name: baby ? "Tamanduá (filhote)" : "Tamanduá-bandeira", w: 0.72 * s, h: 1.05 * s, d: 1.65 * s, hp: baby ? 6 : 14, speed: baby ? 0.72 : 0.58 };
  }
  return { name: baby ? "Tucano (filhote)" : "Tucano-toco", w: 0.42 * s, h: 0.82 * s, d: 0.7 * s, hp: baby ? 3 : 6, speed: baby ? 1.35 : 1.18 };
}

function tex(paint: (ctx: CanvasRenderingContext2D, s: number) => void) {
  const s = 16;
  const canvas = document.createElement("canvas");
  canvas.width = s;
  canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  paint(ctx, s);
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}
function px(ctx: CanvasRenderingContext2D, c: string, x: number, y: number, w = 1, h = 1) {
  ctx.fillStyle = c;
  ctx.fillRect(x, y, w, h);
}
function noise(ctx: CanvasRenderingContext2D, s: number, base: string, spec: string, n = 18) {
  px(ctx, base, 0, 0, s, s);
  ctx.fillStyle = spec;
  for (let i = 0; i < n; i++) ctx.fillRect((i * 7 + 2) % s, (i * 11 + 4) % s, 1, 1);
}
function mat(map: THREE.CanvasTexture) {
  return new THREE.MeshLambertMaterial({ map });
}
function solid(color: number) {
  return new THREE.MeshLambertMaterial({ color });
}
function faces(paint: {
  px: (c: CanvasRenderingContext2D, s: number) => void;
  nx: (c: CanvasRenderingContext2D, s: number) => void;
  py: (c: CanvasRenderingContext2D, s: number) => void;
  ny: (c: CanvasRenderingContext2D, s: number) => void;
  pz: (c: CanvasRenderingContext2D, s: number) => void;
  nz: (c: CanvasRenderingContext2D, s: number) => void;
}) {
  return [mat(tex(paint.px)), mat(tex(paint.nx)), mat(tex(paint.py)), mat(tex(paint.ny)), mat(tex(paint.pz)), mat(tex(paint.nz))];
}
function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, material: THREE.Material | THREE.Material[]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}
function limb(parent: THREE.Object3D, w: number, h: number, d: number, x: number, hipY: number, z: number, material: THREE.Material | THREE.Material[], part: string) {
  const g = new THREE.Group();
  g.position.set(x, hipY, z);
  g.userData.part = part;
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(0, -h / 2, 0);
  g.add(m);
  parent.add(g);
  return g;
}
function partGroup(parent: THREE.Object3D, x: number, y: number, z: number, part: string) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.userData.part = part;
  parent.add(g);
  return g;
}

function buildTamandua() {
  const g = new THREE.Group();
  const tan = "#c8a46c";
  const tanD = "#8a6840";
  const tanL = "#d8b888";
  const vest = "#1c1612";
  const body = faces({
    px: (ctx, s) => {
      noise(ctx, s, tan, tanD, 10);
      px(ctx, vest, 4, 1, 8, 14);
    },
    nx: (ctx, s) => {
      noise(ctx, s, tan, tanD, 10);
      px(ctx, vest, 4, 1, 8, 14);
    },
    py: (ctx, s) => {
      noise(ctx, s, tanL, tan, 8);
      px(ctx, vest, 6, 3, 4, 10);
    },
    ny: (ctx, s) => noise(ctx, s, vest, tanD, 8),
    pz: (ctx, s) => {
      noise(ctx, s, tan, tanD, 8);
      px(ctx, vest, 3, 5, 10, 9);
    },
    nz: (ctx, s) => noise(ctx, s, tan, tanD, 8),
  });
  box(g, 0.48, 0.44, 0.78, 0, 0.66, 0.12, body);
  box(g, 0.4, 0.32, 0.48, 0, 0.54, -0.38, faces({
    px: (ctx, s) => noise(ctx, s, tan, tanD, 8),
    nx: (ctx, s) => noise(ctx, s, tan, tanD, 8),
    py: (ctx, s) => noise(ctx, s, tanL, tan, 6),
    ny: (ctx, s) => noise(ctx, s, tanD, vest, 6),
    pz: (ctx, s) => noise(ctx, s, tan, tanD, 6),
    nz: (ctx, s) => noise(ctx, s, tan, tanD, 6),
  }));

  const head = partGroup(g, 0, 0.7, 0.5, "head");
  box(head, 0.24, 0.2, 0.22, 0, 0.02, 0.08, solid(0xc8a46c));
  box(head, 0.07, 0.09, 0.05, 0.1, 0.12, 0.02, solid(0x8a6840));
  box(head, 0.07, 0.09, 0.05, -0.1, 0.12, 0.02, solid(0x8a6840));
  box(head, 0.035, 0.05, 0.02, 0.1, 0.12, 0.04, solid(0x3a2a1c));
  box(head, 0.035, 0.05, 0.02, -0.1, 0.12, 0.04, solid(0x3a2a1c));
  box(head, 0.03, 0.03, 0.025, 0.1, 0.06, 0.16, solid(0x141210));
  box(head, 0.03, 0.03, 0.025, -0.1, 0.06, 0.16, solid(0x141210));
  box(head, 0.014, 0.014, 0.012, 0.108, 0.07, 0.172, solid(0xf0ece4));
  box(head, 0.014, 0.014, 0.012, -0.108, 0.07, 0.172, solid(0xf0ece4));

  const snout = partGroup(head, 0, -0.01, 0.18, "snout");
  snout.rotation.x = 0.32;
  box(snout, 0.16, 0.14, 0.16, 0, -0.01, 0.08, solid(0xc0a060));
  box(snout, 0.12, 0.11, 0.16, 0, -0.02, 0.22, solid(0xb89458));
  box(snout, 0.085, 0.08, 0.14, 0, -0.025, 0.35, solid(0xa8824c));
  box(snout, 0.055, 0.05, 0.1, 0, -0.03, 0.45, solid(0x8a6840));
  box(snout, 0.04, 0.035, 0.04, 0, -0.032, 0.51, solid(0x2a2018));

  const leg = solid(0x1c1612);
  const claw = solid(0x3a3228);
  const fl = limb(g, 0.14, 0.48, 0.16, 0.16, 0.5, 0.32, leg, "legFL");
  const fr = limb(g, 0.14, 0.48, 0.16, -0.16, 0.5, 0.32, leg, "legFR");
  limb(g, 0.12, 0.4, 0.14, 0.14, 0.42, -0.32, leg, "legBL");
  limb(g, 0.12, 0.4, 0.14, -0.14, 0.42, -0.32, leg, "legBR");
  box(fl, 0.04, 0.045, 0.16, 0.04, -0.48, 0.08, claw);
  box(fr, 0.04, 0.045, 0.16, -0.04, -0.48, 0.08, claw);

  const tail = partGroup(g, 0, 0.52, -0.58, "tail");
  box(tail, 0.36, 0.34, 0.42, 0, 0.06, -0.16, solid(0xc8a46c));
  box(tail, 0.44, 0.4, 0.42, 0, 0.1, -0.48, solid(0xd0b078));
  box(tail, 0.34, 0.3, 0.3, 0, 0.08, -0.78, solid(0xb89058));
  box(tail, 0.2, 0.18, 0.18, 0, 0.04, -0.98, solid(0xa07040));
  return g;
}

function buildTucano() {
  const g = new THREE.Group();
  const ink = "#161618";
  const inkL = "#2a2a30";
  const body = faces({
    px: (ctx, s) => noise(ctx, s, ink, inkL, 8),
    nx: (ctx, s) => noise(ctx, s, ink, inkL, 8),
    py: (ctx, s) => noise(ctx, s, inkL, ink, 6),
    ny: (ctx, s) => noise(ctx, s, ink, "#c42828", 6),
    pz: (ctx, s) => {
      noise(ctx, s, ink, inkL, 6);
      px(ctx, "#f2ece4", 3, 6, 10, 8);
    },
    nz: (ctx, s) => noise(ctx, s, ink, inkL, 6),
  });
  box(g, 0.32, 0.36, 0.42, 0, 0.52, 0, body);
  const head = partGroup(g, 0, 0.78, 0.18, "head");
  box(head, 0.26, 0.24, 0.26, 0, 0, 0.04, solid(0x161618));
  box(head, 0.08, 0.08, 0.04, 0.07, 0.04, 0.14, solid(0xf2ece4));
  box(head, 0.08, 0.08, 0.04, -0.07, 0.04, 0.14, solid(0xf2ece4));
  const beak = partGroup(head, 0, -0.02, 0.18, "beak");
  const bill = faces({
    px: (ctx, s) => { px(ctx, "#e89828", 0, 0, s, s); px(ctx, "#1a1410", 0, 4, 4, 8); },
    nx: (ctx, s) => { px(ctx, "#e89828", 0, 0, s, s); px(ctx, "#1a1410", 12, 4, 4, 8); },
    py: (ctx, s) => px(ctx, "#f0b038", 0, 0, s, s),
    ny: (ctx, s) => px(ctx, "#d87820", 0, 0, s, s),
    pz: (ctx, s) => px(ctx, "#1a1410", 0, 0, s, s),
    nz: (ctx, s) => px(ctx, "#e89828", 0, 0, s, s),
  });
  box(beak, 0.16, 0.16, 0.58, 0, 0, 0.28, bill);
  box(beak, 0.12, 0.1, 0.1, 0, 0, 0.6, solid(0x1a1410));
  const wing = faces({
    px: (ctx, s) => noise(ctx, s, ink, inkL, 8),
    nx: (ctx, s) => noise(ctx, s, ink, inkL, 8),
    py: (ctx, s) => noise(ctx, s, inkL, ink, 6),
    ny: (ctx, s) => noise(ctx, s, ink, "#c42828", 6),
    pz: (ctx, s) => noise(ctx, s, ink, inkL, 6),
    nz: (ctx, s) => noise(ctx, s, ink, inkL, 6),
  });
  const wingL = partGroup(g, 0.2, 0.54, -0.02, "wingL");
  box(wingL, 0.08, 0.28, 0.36, 0.04, 0, -0.04, wing);
  const wingR = partGroup(g, -0.2, 0.54, -0.02, "wingR");
  box(wingR, 0.08, 0.28, 0.36, -0.04, 0, -0.04, wing);
  const foot = solid(0xe8b020);
  limb(g, 0.08, 0.32, 0.08, 0.08, 0.32, 0.06, foot, "legFL");
  limb(g, 0.08, 0.32, 0.08, -0.08, 0.32, 0.06, foot, "legFR");
  const tail = partGroup(g, 0, 0.48, -0.22, "tail");
  box(tail, 0.18, 0.1, 0.28, 0, 0, -0.12, solid(0x161618));
  box(tail, 0.16, 0.08, 0.12, 0, -0.02, -0.28, solid(0xc42828));
  return g;
}

export function buildRare(kind: RareKind): THREE.Group {
  return kind === "tamandua" ? buildTamandua() : buildTucano();
}
