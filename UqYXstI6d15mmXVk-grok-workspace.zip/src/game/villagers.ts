import * as THREE from "three";

export type VillagerRole = "jardineiro" | "contador" | "vigia" | "palerma" | "crianca" | "pescador";

export function villagerName(role: VillagerRole, baby: boolean): string {
  if (baby || role === "crianca") return "Criança da aldeia";
  if (role === "jardineiro") return "Jardineiro";
  if (role === "contador") return "Contador de histórias";
  if (role === "palerma") return "Palerma";
  if (role === "pescador") return "Pescador";
  return "Vigia";
}

const LINES: Record<VillagerRole, string[]> = {
  jardineiro: [
    "Não arranque o capim. Ele segura o chão.",
    "A riccia solta bolha grande quando o sol está alto.",
    "A água atravessa o mato. O mato fica.",
  ],
  contador: [
    "Uma vez o chão respirou e abriu uma vala devagar.",
    "As crianças dizem que a bolha enorme dá um pouco de ar.",
    "Quem corre na hora do ronco tropeça no próprio medo.",
  ],
  vigia: [
    "Se o ronco subir, afaste os pés da vala.",
    "Eu olho o horizonte. O chão avisa antes de ceder.",
    "De noite a aldeia deita. De dia ela escuta.",
  ],
  palerma: [
    "Hmm. Hmm? Hmm.",
    "Eu não trabalho. O sol trabalha por mim.",
    "Se eu ficar parado, o dia passa do mesmo jeito.",
  ],
  pescador: [
    "A linha entrou. Espera ela puxar.",
    "Peixe pequeno também é jantar.",
    "Não corre na beira. A água engole o apressado.",
  ],
  crianca: [
    "Pega-pega! Você é lento.",
    "Pula que eu pulo também.",
    "O vigia faz cara de sério, mas dança por dentro.",
  ],
};

export function villagerLine(role: VillagerRole): string {
  const list = LINES[role];
  return list[(Math.random() * list.length) | 0]!;
}

function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, color: number, part?: string) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
  mesh.position.set(x, y, z);
  if (part) mesh.userData.part = part;
  parent.add(mesh);
  return mesh;
}

function pivot(parent: THREE.Object3D, x: number, y: number, z: number, part: string) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.userData.part = part;
  parent.add(g);
  return g;
}

export function buildVillager(role: VillagerRole, baby: boolean): THREE.Group {
  const root = new THREE.Group();
  const skin = 0xc48a62;
  const skinDark = 0xa86e48;
  const robe =
    role === "contador"
      ? 0x5c3d73
      : role === "vigia"
        ? 0x3d4e6b
        : role === "palerma"
          ? 0x2f6b3a
          : role === "pescador"
            ? 0x2a6a78
            : role === "crianca" || baby
              ? 0xd2a15a
              : 0x3f6b42;
  const cloth = role === "jardineiro" && !baby ? 0x6e9440 : robe;
  const shoe = 0x3a2a1c;

  const torso = pivot(root, 0, baby ? 0.42 : 0.78, 0, "torso");
  box(torso, baby ? 0.34 : 0.46, baby ? 0.32 : 0.52, baby ? 0.22 : 0.28, 0, 0, 0, robe);
  if (!baby && role === "jardineiro") box(torso, 0.34, 0.28, 0.06, 0, -0.02, 0.16, cloth);
  if (!baby && role !== "crianca" && role !== "palerma") box(torso, 0.16, 0.08, 0.04, 0, -0.16, 0.15, 0xc9a24a);

  const head = pivot(torso, 0, baby ? 0.28 : 0.4, 0, "head");
  box(head, baby ? 0.42 : 0.46, baby ? 0.4 : 0.46, baby ? 0.4 : 0.44, 0, baby ? 0.16 : 0.2, 0, skin);
  box(head, 0.12, 0.1, 0.16, 0, baby ? 0.08 : 0.1, baby ? 0.24 : 0.28, skinDark, "nose");
  const eyeL = pivot(head, 0.1, baby ? 0.22 : 0.26, baby ? 0.18 : 0.2, "eyeL");
  box(eyeL, 0.08, 0.08, 0.04, 0, 0, 0, 0xf4f0e6);
  box(eyeL, 0.04, 0.04, 0.02, 0, 0, 0.03, 0x1c140c);
  const eyeR = pivot(head, -0.1, baby ? 0.22 : 0.26, baby ? 0.18 : 0.2, "eyeR");
  box(eyeR, 0.08, 0.08, 0.04, 0, 0, 0, 0xf4f0e6);
  box(eyeR, 0.04, 0.04, 0.02, 0, 0, 0.03, 0x1c140c);
  box(head, 0.22, 0.04, 0.04, 0, baby ? 0.3 : 0.34, baby ? 0.18 : 0.2, 0x4a3424);

  if (!baby && role === "jardineiro") {
    const hat = pivot(head, 0, 0.42, 0, "hat");
    box(hat, 0.5, 0.08, 0.5, 0, 0.04, 0, 0xe2c56a);
    box(hat, 0.62, 0.04, 0.62, 0, 0, 0, 0xc9a24a);
  } else if (!baby && role === "vigia") {
    box(head, 0.48, 0.08, 0.48, 0, 0.46, 0, 0x2a241c, "hat");
  } else if (!baby && role === "contador") {
    box(head, 0.16, 0.22, 0.16, 0, 0.5, -0.02, 0x3a2848, "hat");
  } else if (!baby && role === "pescador") {
    box(head, 0.52, 0.06, 0.52, 0, 0.46, 0, 0xd8c48a, "hat");
    box(head, 0.28, 0.1, 0.28, 0, 0.5, 0, 0xc4a46a);
  }

  const armL = pivot(torso, baby ? 0.24 : 0.32, baby ? 0.08 : 0.16, 0, "armL");
  box(armL, 0.12, baby ? 0.28 : 0.46, 0.12, 0, baby ? -0.12 : -0.2, 0, skin);
  const armR = pivot(torso, baby ? -0.24 : -0.32, baby ? 0.08 : 0.16, 0, "armR");
  box(armR, 0.12, baby ? 0.28 : 0.46, 0.12, 0, baby ? -0.12 : -0.2, 0, skin);
  if (!baby && role === "pescador") {
    box(armR, 0.04, 0.7, 0.04, 0.02, -0.55, 0.1, 0x6a3e1c, "rod");
    box(armR, 0.07, 0.05, 0.07, 0.02, -0.9, 0.1, 0xe6d2a4);
  }

  const legL = pivot(root, baby ? 0.08 : 0.1, baby ? 0.28 : 0.52, 0, "legL");
  box(legL, 0.12, baby ? 0.22 : 0.48, 0.12, 0, baby ? -0.1 : -0.22, 0, robe);
  box(legL, 0.13, 0.06, 0.16, 0, baby ? -0.22 : -0.48, 0.02, shoe);
  const legR = pivot(root, baby ? -0.08 : -0.1, baby ? 0.28 : 0.52, 0, "legR");
  box(legR, 0.12, baby ? 0.22 : 0.48, 0.12, 0, baby ? -0.1 : -0.22, 0, robe);
  box(legR, 0.13, 0.06, 0.16, 0, baby ? -0.22 : -0.48, 0.02, shoe);

  if (baby) root.scale.setScalar(1);
  return root;
}
