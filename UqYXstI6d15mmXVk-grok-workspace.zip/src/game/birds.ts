import * as THREE from "three";

export type BirdKind = "beijaflor" | "arara" | "joaobarro";
export const BIRD_KINDS: BirdKind[] = ["beijaflor", "arara", "joaobarro"];
export function isBirdKind(k: string): k is BirdKind {
  return k === "beijaflor" || k === "arara" || k === "joaobarro";
}
export type BirdInfo = { name: string; w: number; h: number; d: number; hp: number; speed: number };
export function birdStats(kind: BirdKind, baby: boolean): BirdInfo {
  const s = baby ? 0.55 : 1;
  if (kind === "beijaflor") return { name: baby ? "Beija-flor (filhote)" : "Beija-flor", w: 0.18 * s, h: 0.16 * s, d: 0.28 * s, hp: baby ? 2 : 3, speed: baby ? 5.2 : 6.4 };
  if (kind === "arara") return { name: baby ? "Arara (filhote)" : "Arara-vermelha", w: 0.42 * s, h: 0.38 * s, d: 0.85 * s, hp: baby ? 5 : 10, speed: baby ? 4.2 : 5.6 };
  return { name: baby ? "João-de-barro (filhote)" : "João-de-barro", w: 0.32 * s, h: 0.28 * s, d: 0.38 * s, hp: baby ? 3 : 6, speed: baby ? 3.4 : 4.2 };
}

function tex(paint: (ctx: CanvasRenderingContext2D, s: number) => void) {
  const s = 16;
  const canvas = document.createElement("canvas");
  canvas.width = s; canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  paint(ctx, s);
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false; t.colorSpace = THREE.SRGBColorSpace; t.needsUpdate = true;
  return t;
}
function px(ctx: CanvasRenderingContext2D, c: string, x: number, y: number, w = 1, h = 1) { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); }
function noise(ctx: CanvasRenderingContext2D, s: number, base: string, spec: string, n = 18) {
  px(ctx, base, 0, 0, s, s); ctx.fillStyle = spec;
  for (let i = 0; i < n; i++) ctx.fillRect((i * 7 + 2) % s, (i * 11 + 4) % s, 1, 1);
}
function mat(map: THREE.CanvasTexture) { return new THREE.MeshLambertMaterial({ map }); }
function solid(color: number) { return new THREE.MeshLambertMaterial({ color }); }
function faces(paint: { px: (c: CanvasRenderingContext2D, s: number) => void; nx: (c: CanvasRenderingContext2D, s: number) => void; py: (c: CanvasRenderingContext2D, s: number) => void; ny: (c: CanvasRenderingContext2D, s: number) => void; pz: (c: CanvasRenderingContext2D, s: number) => void; nz: (c: CanvasRenderingContext2D, s: number) => void; }) {
  return [mat(tex(paint.px)), mat(tex(paint.nx)), mat(tex(paint.py)), mat(tex(paint.ny)), mat(tex(paint.pz)), mat(tex(paint.nz))];
}
function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, material: THREE.Material | THREE.Material[]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material); m.position.set(x, y, z); parent.add(m); return m;
}
function partGroup(parent: THREE.Object3D, x: number, y: number, z: number, part: string) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.userData.part = part; parent.add(g); return g;
}

function buildBeijaflor() {
  const g = new THREE.Group();
  const em = "#14a868", emD = "#0a6a44", emL = "#3cd090", ruby = "#d01838";
  const body = faces({
    px: (c, s) => noise(c, s, em, emD, 10), nx: (c, s) => noise(c, s, em, emD, 10),
    py: (c, s) => noise(c, s, emL, em, 8), ny: (c, s) => noise(c, s, emD, em, 8),
    pz: (c, s) => { noise(c, s, em, emL, 8); px(c, ruby, 4, 8, 8, 6); },
    nz: (c, s) => noise(c, s, emD, em, 8),
  });
  box(g, 0.1, 0.09, 0.16, 0, 0.1, 0, body);
  const head = partGroup(g, 0, 0.14, 0.1, "head");
  const face = faces({
    px: (c, s) => noise(c, s, em, emD, 6), nx: (c, s) => noise(c, s, em, emD, 6),
    py: (c, s) => noise(c, s, emL, em, 5), ny: (c, s) => noise(c, s, ruby, "#8a1028", 4),
    pz: (c, s) => { noise(c, s, em, emL, 5); px(c, ruby, 3, 8, 10, 6); px(c, "#101010", 4, 5, 2, 2); px(c, "#101010", 10, 5, 2, 2); px(c, "#f4f4f0", 5, 5, 1, 1); px(c, "#f4f4f0", 11, 5, 1, 1); },
    nz: (c, s) => noise(c, s, emD, em, 5),
  });
  box(head, 0.09, 0.09, 0.1, 0, 0, 0.02, face);
  box(head, 0.02, 0.02, 0.16, 0, -0.01, 0.12, solid(0x2a2018));
  const wing = faces({
    px: (c, s) => noise(c, s, emD, emL, 8), nx: (c, s) => noise(c, s, emD, emL, 8),
    py: (c, s) => noise(c, s, emL, "#88e8b0", 6), ny: (c, s) => noise(c, s, emD, em, 6),
    pz: (c, s) => noise(c, s, emD, em, 6), nz: (c, s) => noise(c, s, emD, em, 6),
  });
  const wingL = partGroup(g, 0.06, 0.12, 0, "wingL"); box(wingL, 0.16, 0.02, 0.1, 0.08, 0, 0, wing);
  const wingR = partGroup(g, -0.06, 0.12, 0, "wingR"); box(wingR, 0.16, 0.02, 0.1, -0.08, 0, 0, wing);
  const tail = partGroup(g, 0, 0.1, -0.1, "tail"); box(tail, 0.06, 0.02, 0.1, 0, 0, -0.04, solid(0x0c5a3a));
  return g;
}

function buildArara() {
  const g = new THREE.Group();
  const red = "#d42222", redD = "#8a1414", redL = "#f04038", blue = "#1a48c0", blueD = "#102878", yel = "#e8c028";
  const body = faces({
    px: (c, s) => noise(c, s, red, redD, 12), nx: (c, s) => noise(c, s, red, redD, 12),
    py: (c, s) => noise(c, s, redL, red, 10),
    ny: (c, s) => { noise(c, s, redD, yel, 8); px(c, yel, 2, 6, 12, 6); },
    pz: (c, s) => noise(c, s, red, redL, 10), nz: (c, s) => noise(c, s, redD, red, 10),
  });
  box(g, 0.28, 0.26, 0.48, 0, 0.22, 0.02, body);
  const head = partGroup(g, 0, 0.34, 0.28, "head");
  const face = faces({
    px: (c, s) => { noise(c, s, red, redD, 6); px(c, "#f2ece4", 8, 4, 8, 8); },
    nx: (c, s) => { noise(c, s, red, redD, 6); px(c, "#f2ece4", 0, 4, 8, 8); },
    py: (c, s) => noise(c, s, redL, red, 6), ny: (c, s) => noise(c, s, redD, red, 5),
    pz: (c, s) => { px(c, red, 0, 0, s, s); px(c, "#f2ece4", 1, 5, 14, 8); px(c, "#101010", 4, 7, 2, 2); px(c, "#101010", 10, 7, 2, 2); px(c, "#f8f8f4", 5, 7, 1, 1); px(c, "#f8f8f4", 11, 7, 1, 1); },
    nz: (c, s) => noise(c, s, redD, red, 6),
  });
  box(head, 0.22, 0.2, 0.22, 0, 0, 0.04, face);
  const beak = partGroup(head, 0, -0.02, 0.16, "beak");
  box(beak, 0.1, 0.1, 0.16, 0, 0, 0.06, solid(0x1a1614));
  box(beak, 0.08, 0.06, 0.08, 0, -0.06, 0.08, solid(0x2a2420));
  const wingUp = faces({
    px: (c, s) => { noise(c, s, blue, blueD, 8); px(c, yel, 0, 10, s, 6); },
    nx: (c, s) => { noise(c, s, blue, blueD, 8); px(c, yel, 0, 10, s, 6); },
    py: (c, s) => noise(c, s, blue, "#4a78e0", 8), ny: (c, s) => noise(c, s, yel, "#c49018", 8),
    pz: (c, s) => noise(c, s, blueD, blue, 6), nz: (c, s) => noise(c, s, blue, yel, 6),
  });
  const wingL = partGroup(g, 0.16, 0.26, 0.02, "wingL"); box(wingL, 0.1, 0.08, 0.5, 0.06, 0, -0.04, wingUp);
  const wingR = partGroup(g, -0.16, 0.26, 0.02, "wingR"); box(wingR, 0.1, 0.08, 0.5, -0.06, 0, -0.04, wingUp);
  const tail = partGroup(g, 0, 0.2, -0.28, "tail");
  box(tail, 0.16, 0.06, 0.55, 0, 0, -0.24, solid(0xc81818));
  box(tail, 0.12, 0.05, 0.18, 0, 0.01, -0.52, solid(0x1838b0));
  box(g, 0.05, 0.12, 0.05, 0.07, 0.08, 0.08, solid(0xc8a020));
  box(g, 0.05, 0.12, 0.05, -0.07, 0.08, 0.08, solid(0xc8a020));
  return g;
}

function buildJoaobarro() {
  const g = new THREE.Group();
  const ru = "#c46228", ruD = "#8a3e18", ruL = "#e88848", cream = "#f0e4cc";
  const body = faces({
    px: (c, s) => noise(c, s, ru, ruD, 12), nx: (c, s) => noise(c, s, ru, ruD, 12),
    py: (c, s) => noise(c, s, ruL, ru, 10), ny: (c, s) => noise(c, s, ruD, ru, 8),
    pz: (c, s) => { noise(c, s, ru, ruL, 8); px(c, cream, 4, 8, 8, 7); },
    nz: (c, s) => noise(c, s, ruD, ru, 8),
  });
  box(g, 0.24, 0.2, 0.28, 0, 0.18, 0, body);
  const head = partGroup(g, 0, 0.28, 0.14, "head");
  const face = faces({
    px: (c, s) => noise(c, s, ru, ruD, 6), nx: (c, s) => noise(c, s, ru, ruD, 6),
    py: (c, s) => noise(c, s, ruL, ru, 5), ny: (c, s) => noise(c, s, ruD, cream, 4),
    pz: (c, s) => { noise(c, s, ru, ruL, 5); px(c, cream, 4, 8, 8, 6); px(c, "#1a1410", 4, 6, 2, 2); px(c, "#1a1410", 10, 6, 2, 2); px(c, "#f8f4e8", 5, 6, 1, 1); px(c, "#f8f4e8", 11, 6, 1, 1); },
    nz: (c, s) => noise(c, s, ruD, ru, 5),
  });
  box(head, 0.18, 0.16, 0.18, 0, 0, 0.02, face);
  box(head, 0.04, 0.04, 0.1, 0, -0.02, 0.12, solid(0x3a2a18));
  const wing = faces({
    px: (c, s) => noise(c, s, ruD, ru, 8), nx: (c, s) => noise(c, s, ruD, ru, 8),
    py: (c, s) => noise(c, s, ru, ruL, 6), ny: (c, s) => noise(c, s, ruD, ru, 6),
    pz: (c, s) => noise(c, s, ruD, ru, 6), nz: (c, s) => noise(c, s, ruD, ru, 6),
  });
  const wingL = partGroup(g, 0.13, 0.2, 0, "wingL"); box(wingL, 0.08, 0.1, 0.22, 0.04, 0, -0.02, wing);
  const wingR = partGroup(g, -0.13, 0.2, 0, "wingR"); box(wingR, 0.08, 0.1, 0.22, -0.04, 0, -0.02, wing);
  const tail = partGroup(g, 0, 0.2, -0.16, "tail"); box(tail, 0.12, 0.05, 0.16, 0, 0, -0.06, solid(0xa84a1c));
  box(g, 0.05, 0.1, 0.05, 0.06, 0.07, 0.04, solid(0x3a2a18));
  box(g, 0.05, 0.1, 0.05, -0.06, 0.07, 0.04, solid(0x3a2a18));
  return g;
}

export function buildBird(kind: BirdKind): THREE.Group {
  if (kind === "beijaflor") return buildBeijaflor();
  if (kind === "arara") return buildArara();
  return buildJoaobarro();
}

export function buildNest(kind: BirdKind): THREE.Group {
  const g = new THREE.Group();
  if (kind === "beijaflor") {
    const twig = solid(0x6a4a28); const soft = solid(0x8a6a3a);
    box(g, 0.22, 0.05, 0.22, 0, 0.03, 0, twig);
    box(g, 0.18, 0.06, 0.18, 0, 0.06, 0, soft);
    box(g, 0.12, 0.04, 0.12, 0, 0.08, 0, solid(0x4a3420));
    box(g, 0.04, 0.08, 0.04, 0.08, 0.06, 0.06, twig);
    box(g, 0.04, 0.07, 0.04, -0.07, 0.05, -0.05, twig);
  } else if (kind === "arara") {
    const stick = solid(0x5a3a1c); const stickL = solid(0x7a5428);
    box(g, 0.7, 0.08, 0.55, 0, 0.06, 0, stick);
    box(g, 0.55, 0.07, 0.7, 0, 0.1, 0, stickL);
    box(g, 0.18, 0.16, 0.08, 0.22, 0.16, 0.1, stick);
    box(g, 0.08, 0.18, 0.2, -0.18, 0.18, -0.12, stickL);
    box(g, 0.4, 0.06, 0.4, 0, 0.14, 0, solid(0x4a3018));
  } else {
    const clay = faces({
      px: (c, s) => noise(c, s, "#c47848", "#8a4a28", 14), nx: (c, s) => noise(c, s, "#c47848", "#8a4a28", 14),
      py: (c, s) => noise(c, s, "#d49058", "#c47848", 10), ny: (c, s) => noise(c, s, "#8a4a28", "#6a3418", 8),
      pz: (c, s) => { noise(c, s, "#c47848", "#a06038", 12); px(c, "#1a120c", 5, 6, 6, 6); },
      nz: (c, s) => noise(c, s, "#b86a3c", "#8a4a28", 12),
    });
    box(g, 0.48, 0.4, 0.48, 0, 0.22, 0, clay);
    box(g, 0.38, 0.14, 0.38, 0, 0.46, 0, clay);
    box(g, 0.16, 0.16, 0.08, 0, 0.22, 0.26, solid(0x1a120c));
  }
  return g;
}
