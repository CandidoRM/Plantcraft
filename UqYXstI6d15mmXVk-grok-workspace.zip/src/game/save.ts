import type { Slot } from "./store";

const KEY = "plantcraft-save-v5";
const VERSION = 6;
/** Bumped when the carried inventory should be replaced once, without wiping the world. */
export const INV_REV = 2;

export type SaveData = {
  version: number;
  seed: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  health: number;
  hunger?: number;
  slots: Slot[];
  selected: number;
  edits: [string, number][];
  time: number;
  invRev?: number;
};

export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as SaveData;
    if (!data || (data.version !== 5 && data.version !== VERSION)) return null;
    return data;
  } catch {
    return null;
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...data, version: VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
