import * as THREE from "three";

export type RanchKind = "vaca" | "porco" | "ovelha";
export const RANCH_KINDS: RanchKind[] = ["vaca", "porco", "ovelha"];
export function isRanchKind(k: string): k is RanchKind {
  return k === "vaca" || k === "porco" || k === "ovelha";
}

export type RanchInfo = { name: string; w: number; h: number; d: number; hp: number; speed: number };

export function ranchStats(kind: RanchKind, baby: boolean): RanchInfo {
  const s = baby ? 0.5 : 1;
  if (kind === "vaca") return { name: baby ? "Vaca (filhote)" : "Vaca", w: 0.9 * s, h: 1.4 * s, d: 1.25 * s, hp: baby ? 5 : 10, speed: baby ? 0.95 : 0.82 };
  if (kind === "porco") return { name: baby ? "Porco (filhote)" : "Porco", w: 0.95 * s, h: 1.05 * s, d: 1.1 * s, hp: baby ? 4 : 8, speed: baby ? 1.15 : 1.02 };
  return { name: baby ? "Ovelha (filhote)" : "Ovelha", w: 0.85 * s, h: 1.32 * s, d: 1.15 * s, hp: baby ? 4 : 8, speed: baby ? 1.05 : 0.92 };
}

function tex(paint: (ctx: CanvasRenderingContext2D, s: number) => void) {
  const s = 16;
  const canvas = document.createElement("canvas");
  canvas.width = s;
  canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  paint(ctx, s);
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}
function px(ctx: CanvasRenderingContext2D, c: string, x: number, y: number, w = 1, h = 1) {
  ctx.fillStyle = c;
  ctx.fillRect(x, y, w, h);
}
function noise(ctx: CanvasRenderingContext2D, s: number, base: string, spec: string, n = 18) {
  px(ctx, base, 0, 0, s, s);
  ctx.fillStyle = spec;
  for (let i = 0; i < n; i++) ctx.fillRect((i * 7 + 2) % s, (i * 11 + 4) % s, 1, 1);
}
function mat(map: THREE.CanvasTexture) {
  return new THREE.MeshLambertMaterial({ map });
}
function solid(color: number) {
  return new THREE.MeshLambertMaterial({ color });
}
function faces(paint: {
  px: (c: CanvasRenderingContext2D, s: number) => void;
  nx: (c: CanvasRenderingContext2D, s: number) => void;
  py: (c: CanvasRenderingContext2D, s: number) => void;
  ny: (c: CanvasRenderingContext2D, s: number) => void;
  pz: (c: CanvasRenderingContext2D, s: number) => void;
  nz: (c: CanvasRenderingContext2D, s: number) => void;
}) {
  return [mat(tex(paint.px)), mat(tex(paint.nx)), mat(tex(paint.py)), mat(tex(paint.ny)), mat(tex(paint.pz)), mat(tex(paint.nz))];
}
function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, material: THREE.Material | THREE.Material[]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}
function limb(parent: THREE.Object3D, w: number, h: number, d: number, x: number, hipY: number, z: number, material: THREE.Material | THREE.Material[], part: string) {
  const g = new THREE.Group();
  g.position.set(x, hipY, z);
  g.userData.part = part;
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(0, -h / 2, 0);
  g.add(m);
  parent.add(g);
  return g;
}
function partGroup(parent: THREE.Object3D, x: number, y: number, z: number, part: string) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.userData.part = part;
  parent.add(g);
  return g;
}

function buildCow() {
  const g = new THREE.Group();
  const hide = "#4a2e1c";
  const hideD = "#2e1c10";
  const white = "#e8e0d0";
  const body = faces({
    px: (ctx, s) => { noise(ctx, s, hide, hideD, 14); px(ctx, white, 0, 4, 6, 8); },
    nx: (ctx, s) => { noise(ctx, s, hide, hideD, 14); px(ctx, white, 10, 4, 6, 8); },
    py: (ctx, s) => noise(ctx, s, "#6a4428", hide, 10),
    ny: (ctx, s) => noise(ctx, s, hideD, hide, 8),
    pz: (ctx, s) => noise(ctx, s, hide, hideD, 10),
    nz: (ctx, s) => noise(ctx, s, hide, white, 10),
  });
  box(g, 0.9, 0.7, 1.15, 0, 0.95, 0, body);
  const head = partGroup(g, 0, 1.22, 0.72, "head");
  const face = faces({
    px: (ctx, s) => noise(ctx, s, hide, hideD, 6),
    nx: (ctx, s) => noise(ctx, s, hide, hideD, 6),
    py: (ctx, s) => noise(ctx, s, "#6a4428", hide, 5),
    ny: (ctx, s) => noise(ctx, s, "#c47878", hideD, 4),
    pz: (ctx, s) => {
      noise(ctx, s, hide, hideD, 5);
      px(ctx, white, 4, 6, 8, 8);
      px(ctx, "#1a1410", 5, 7, 2, 2);
      px(ctx, "#1a1410", 9, 7, 2, 2);
    },
    nz: (ctx, s) => noise(ctx, s, hideD, hide, 5),
  });
  box(head, 0.42, 0.42, 0.36, 0, 0, 0.08, face);
  box(head, 0.08, 0.18, 0.08, 0.14, 0.28, 0.04, solid(0xe8e0d0));
  box(head, 0.08, 0.18, 0.08, -0.14, 0.28, 0.04, solid(0xe8e0d0));
  box(g, 0.22, 0.14, 0.18, 0, 0.58, 0.08, solid(0xc47878));
  const leg = solid(0x2e1c10);
  limb(g, 0.18, 0.62, 0.18, 0.28, 0.62, 0.38, leg, "legFL");
  limb(g, 0.18, 0.62, 0.18, -0.28, 0.62, 0.38, leg, "legFR");
  limb(g, 0.18, 0.62, 0.18, 0.28, 0.62, -0.38, leg, "legBL");
  limb(g, 0.18, 0.62, 0.18, -0.28, 0.62, -0.38, leg, "legBR");
  const tail = partGroup(g, 0, 1.18, -0.58, "tail");
  box(tail, 0.08, 0.08, 0.45, 0, 0, -0.18, solid(0x4a2e1c));
  box(tail, 0.12, 0.12, 0.12, 0, -0.04, -0.4, solid(0x1a1410));
  return g;
}

function buildPig() {
  const g = new THREE.Group();
  const pink = "#f2a090";
  const pinkD = "#d07868";
  const pinkL = "#f8c0b0";
  const body = faces({
    px: (ctx, s) => noise(ctx, s, pink, pinkD, 12),
    nx: (ctx, s) => noise(ctx, s, pink, pinkD, 12),
    py: (ctx, s) => noise(ctx, s, pinkL, pink, 10),
    ny: (ctx, s) => noise(ctx, s, pinkD, pink, 8),
    pz: (ctx, s) => noise(ctx, s, pink, pinkD, 10),
    nz: (ctx, s) => noise(ctx, s, pink, pinkD, 10),
  });
  box(g, 0.95, 0.78, 0.95, 0, 0.62, 0.02, body);
  const head = partGroup(g, 0, 0.72, 0.52, "head");
  const face = faces({
    px: (ctx, s) => noise(ctx, s, pink, pinkD, 6),
    nx: (ctx, s) => noise(ctx, s, pink, pinkD, 6),
    py: (ctx, s) => noise(ctx, s, pinkL, pink, 5),
    ny: (ctx, s) => noise(ctx, s, pinkD, pink, 4),
    pz: (ctx, s) => {
      noise(ctx, s, pink, pinkL, 5);
      px(ctx, "#fff8f0", 3, 4, 3, 3);
      px(ctx, "#fff8f0", 10, 4, 3, 3);
      px(ctx, "#14110e", 4, 5, 2, 2);
      px(ctx, "#14110e", 11, 5, 2, 2);
    },
    nz: (ctx, s) => noise(ctx, s, pinkD, pink, 5),
  });
  box(head, 0.62, 0.58, 0.5, 0, 0.02, 0.08, face);
  box(head, 0.16, 0.16, 0.08, 0.22, 0.3, 0.02, solid(0xe09080));
  box(head, 0.16, 0.16, 0.08, -0.22, 0.3, 0.02, solid(0xe09080));
  const snout = faces({
    px: (ctx, s) => { px(ctx, "#e88878", 0, 0, s, s); px(ctx, "#5a3028", 10, 5, 4, 6); },
    nx: (ctx, s) => { px(ctx, "#e88878", 0, 0, s, s); px(ctx, "#5a3028", 2, 5, 4, 6); },
    py: (ctx, s) => px(ctx, "#f0a090", 0, 0, s, s),
    ny: (ctx, s) => px(ctx, "#d07060", 0, 0, s, s),
    pz: (ctx, s) => {
      px(ctx, "#f09888", 0, 0, s, s);
      px(ctx, "#4a2820", 3, 5, 3, 4);
      px(ctx, "#4a2820", 10, 5, 3, 4);
    },
    nz: (ctx, s) => px(ctx, "#e88878", 0, 0, s, s),
  });
  box(head, 0.38, 0.28, 0.22, 0, -0.08, 0.36, snout);
  const leg = solid(0xd07868);
  limb(g, 0.2, 0.28, 0.2, 0.28, 0.28, 0.28, leg, "legFL");
  limb(g, 0.2, 0.28, 0.2, -0.28, 0.28, 0.28, leg, "legFR");
  limb(g, 0.2, 0.28, 0.2, 0.28, 0.28, -0.26, leg, "legBL");
  limb(g, 0.2, 0.28, 0.2, -0.28, 0.28, -0.26, leg, "legBR");
  const tail = partGroup(g, 0, 0.88, -0.48, "tail");
  box(tail, 0.08, 0.08, 0.16, 0, 0.04, -0.06, solid(0xf2a090));
  box(tail, 0.08, 0.14, 0.08, 0.06, 0.08, -0.14, solid(0xe88878));
  box(tail, 0.08, 0.08, 0.08, 0.02, 0.14, -0.08, solid(0xf2a090));
  return g;
}

function buildSheep() {
  const g = new THREE.Group();
  const wool = "#f0ece4";
  const woolD = "#d0ccc4";
  const skin = "#2a2018";
  const body = faces({
    px: (ctx, s) => noise(ctx, s, wool, woolD, 16),
    nx: (ctx, s) => noise(ctx, s, wool, woolD, 16),
    py: (ctx, s) => noise(ctx, s, "#f8f4ec", wool, 12),
    ny: (ctx, s) => noise(ctx, s, woolD, wool, 10),
    pz: (ctx, s) => noise(ctx, s, wool, woolD, 12),
    nz: (ctx, s) => noise(ctx, s, wool, woolD, 12),
  });
  box(g, 0.86, 0.7, 1.1, 0, 0.95, 0, body);
  const head = partGroup(g, 0, 1.18, 0.68, "head");
  const face = faces({
    px: (ctx, s) => noise(ctx, s, "#3a2a20", skin, 6),
    nx: (ctx, s) => noise(ctx, s, "#3a2a20", skin, 6),
    py: (ctx, s) => noise(ctx, s, wool, woolD, 5),
    ny: (ctx, s) => noise(ctx, s, skin, "#1a1410", 4),
    pz: (ctx, s) => {
      noise(ctx, s, "#3a2a20", skin, 5);
      px(ctx, "#f0ece4", 3, 0, 10, 6);
      px(ctx, "#f4f4f0", 5, 8, 2, 2);
      px(ctx, "#f4f4f0", 9, 8, 2, 2);
      px(ctx, "#101010", 5, 8, 1, 1);
      px(ctx, "#101010", 9, 8, 1, 1);
    },
    nz: (ctx, s) => noise(ctx, s, skin, "#1a1410", 5),
  });
  box(head, 0.32, 0.32, 0.32, 0, 0, 0.06, face);
  const leg = solid(0x2a2018);
  limb(g, 0.14, 0.52, 0.14, 0.26, 0.6, 0.36, leg, "legFL");
  limb(g, 0.14, 0.52, 0.14, -0.26, 0.6, 0.36, leg, "legFR");
  limb(g, 0.14, 0.52, 0.14, 0.26, 0.6, -0.36, leg, "legBL");
  limb(g, 0.14, 0.52, 0.14, -0.26, 0.6, -0.36, leg, "legBR");
  const tail = partGroup(g, 0, 1.12, -0.58, "tail");
  box(tail, 0.16, 0.16, 0.14, 0, 0, -0.04, solid(0xf0ece4));
  return g;
}

export function buildRanch(kind: RanchKind): THREE.Group {
  if (kind === "vaca") return buildCow();
  if (kind === "porco") return buildPig();
  return buildSheep();
}
